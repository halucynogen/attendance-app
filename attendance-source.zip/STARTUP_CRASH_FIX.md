# 근무로그 v1.0 — Android 16 / 앱 즉시 종료 대응

## 왜 새 소스가 적용되지 않았을 수 있나요?

기존 GitHub Actions의 `unzip -q attendance-source.zip -d project`는 **정확히 `attendance-source.zip`만** 풀어 빌드합니다. 다른 이름으로 새 ZIP을 올리고 옛 파일을 남겨두면 구버전이 계속 빌드됩니다.

이번 산출물에서는 기존 사용자의 `project` 압축 해제 방식과 `attendance-app-apk` 아티팩트 이름을 유지합니다. 새로 빌드할 때 `project`를 먼저 제거하며 압축을 풀고 `compileSdk = 36`, `targetSdk = 36`을 확인합니다. Android SDK 36을 설치하고 Gradle 8.13 / Java 17 / Android Gradle Plugin 8.11.1을 사용합니다.

## 실행시 오류 대응

- 메인 화면 초기화 및 복귀 중 발생하는 Java/Kotlin 예외는 `AttendanceStartup`으로 기록하고, 앱을 곧바로 종료하는 대신 **진단 정보 복사** 화면을 표시하게 했습니다.
- 상태바·하단바 여백은 뷰 초기화 후 적용합니다. 시스템 인셋으로 인한 반복적인 레이아웃 요청을 줄였습니다.
- 이전에 저장한 근무기록은 지우지 않습니다. 접근성 설정 및 공개 동의는 계속 사용자가 직접 합니다.
- 기본 4개 탭, 다채로운 색상 디자인, v1.0 표시, 출근부 파싱·식사시간 차감은 유지했습니다.

**중요:** 실제 기기 로그가 없는 상태에서 원래 즉시 종료의 정확한 원인까지 확인된 것은 아닙니다. 이 수정은 앱 시작 시 예외를 잡아 진단할 수 있게 하고, 화면 여백 처리의 잠재적 문제를 줄입니다. Java/Kotlin 예외가 아닌 프로세스 강제 종료나 네이티브 충돌은 별도 Logcat 기록이 필요합니다.

## 설치/확인 순서

1. GitHub 저장소 **최상위**의 `attendance-source.zip`을 새 파일로 교체하세요. 구버전 ZIP은 같은 이름으로 남겨 두지 마세요.
2. `.github/workflows/build-apk.yml`을 동봉된 버전으로 교체하고 커밋하세요.
3. Actions > Build Android APK > Run workflow를 누르고 새 실행의 성공 여부를 확인하세요. 예전 `attendance-app-apk` 결과물을 혼동하지 마세요.
4. 아티팩트 ZIP을 완전히 압축 해제한 다음 `app-debug.apk`를 설치하세요. 디버그 서명이 이전과 다르면 설치가 거부될 수 있습니다. **앱을 삭제하면 기존 근무기록이 삭제될 수 있으므로**, 기존 기록을 TXT/CSV로 백업하고 설치 옵션을 확인하세요.
5. 앱이 실행되지 않으면 PC에서 USB 디버깅을 활성화하고 다음 명령으로 오류 로그를 얻습니다.

```bash
adb logcat -c
adb shell am force-stop io.local.attendance
adb shell monkey -p io.local.attendance 1
adb logcat -d -b crash -v time > attendance-crash.txt
```

Logcat 전체가 필요하면 `adb logcat -d -v time AndroidRuntime:E AttendanceStartup:E '*:S'`로 추가 확인하세요. 로그에는 기기 정보가 포함될 수 있으므로 공개 공유 전에 검토하세요.

## 변경하지 않은 설정

- 패키지 이름 `io.local.attendance`
- 앱 버전 표시 `v1.0`, Gradle `versionCode = 100`, `versionName = 1.0.0`
- 최소 Android API 26 (Android 8.0)
- 출퇴근·식사/휴게 계산과 기록 저장 키

## 검증 범위

Gradle/Android SDK를 사용할 수 없는 환경에서 실제 APK 빌드 및 Android 16 실기기 실행 검사는 **완료되지 않았습니다**. 추출 경로/버전 설정, Kotlin 독립 파서 테스트, 리소스 XML 구조 등 정적 검사는 별도로 수행했습니다. GitHub Actions의 빌드 성공 여부와 새 APK의 실기기 실행 여부를 반드시 확인하세요.

### 추가 시작 화면 안정화

`onCreate()` 직후 `onResume()`에서 동일한 화면을 중복 생성하던 경로를 제거했습니다. 앱 정보 탭의 **빌드 구분**은 `Android 16 시작 안정화판`으로 표시해 옛 APK와 구별할 수 있습니다.

## 디버그 APK 업데이트 시 서명이 다르면

GitHub Actions의 일회성 러너에서 기본 `assembleDebug`를 수행하면 새 디버그 서명 키가 만들어질 수 있습니다. 이전 디버그 APK와 서명이 다르면 같은 패키지 `io.local.attendance`의 덮어쓰기가 거부됩니다. 이 경우 **기록을 백업하지 않고 바로 제거하지 마세요**. 앱이 켜지지 않아 내보내기가 불가능한 상황이라면, 이전에 설치한 앱이 디버그 빌드이고 USB 디버깅이 가능할 때만 아래 명령으로 기존 SharedPreferences를 읽을 수 있는지 확인할 수 있습니다.

```bash
adb exec-out run-as io.local.attendance cat shared_prefs/attendance_local_only.xml > attendance-backup.xml
```

`run-as`가 거부되면 무리하게 시스템 보호 기능을 우회하지 말고, 이전 백업이나 원본 출근부 앱에서 재수집하는 방법을 검토하세요. 정식 배포 및 안정적인 업데이트에는 본인이 관리하는 **동일한 서명 키로 서명한 릴리스 APK**를 계속 사용해야 합니다.
