# v1.3 검증 결과 (2026-11-04)

- `ParserTestKt` — 기본 파서 11개 검사 통과
- `ExtendedParserTestKt` — 확장 35그룹 / 330개 생성 시간조합 통과
- `YearRangeTestKt` — 연도 범위 429개 검사 통과
- `AprilScreenshotRegressionTestKt` — 13건 · 출퇴근 총 73시간 · 식사 5시간 · 실제 68시간 · 불일치 0건 통과
- `StartupSafetyStaticTest.py` — 시작 관련 API / 버전 / XML 검사 통과
- `AutoCollectionSafetyStaticTest.py` — 사용자 동의·공식 패키지 제한·캡처 조건 정적 검사 통과
- `OfficialAppLauncherStaticTest.py` — 패키지 검색 선언·공식 앱 열기 정적 검사 통과
- `DateShortcutStaticTest.py` — 노란 날짜 버튼 순서·화면 이동 경로·최근 앱 버튼 영역·버전 기록 요약 검사 통과

**미검증:** Android Gradle Plugin/SDK가 이 실행 환경에 없어 전체 Android APK 빌드 및 삼성 Android 16 실기기 실행을 테스트하지 못했습니다. 컴파일/실행에 문제가 있으면 GitHub Actions 첫 오류 줄과 휴대폰 기기/One UI 버전으로 확인해야 합니다.
