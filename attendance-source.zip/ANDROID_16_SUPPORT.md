# 근무로그 v1.0 — Android 16 지원 설정

## 유지한 앱 버전

- 앱에 표시되는 버전: **v1.0** (변경 없음)
- Android `versionCode`: **100** (변경 없음)
- Android `versionName`: **1.0.0** (변경 없음)
- 최소 Android 버전(`minSdk`): **26 / Android 8.0** (변경 없음)
- 앱의 4개 탭, 기존 저장 형식, 접근성 동의와 수집 범위, 식사시간 차감 로직은 그대로 유지.

## Android 16 대응

- 빌드 SDK(`compileSdk`)를 **36**으로 변경.
- 대상 SDK(`targetSdk`)를 **36**으로 변경. Google Play에 2026-08-31 이후 새로운 앱/업데이트를 제출하려면 일반 모바일 앱은 API 36 이상이 요구됩니다.
- Android 16(API 36)의 edge-to-edge 필수 동작에 대응하여 상태표시줄 및 하단 내비게이션 영역에 UI 요소가 겹치지 않게 `WindowInsets`로 처리. 노치/가로 화면의 좌우 cutout 영역도 보호.
- Android 8~10은 기존 시스템 UI 플래그로, Android 11~16은 플랫폼 `WindowInsets` API로 분기 처리.
- GitHub Actions 디버그/릴리스 빌드 모두 Android SDK Platform 36 및 Build Tools 36.0.0 사용. 릴리스 `apksigner` 확인 경로도 일치.
- 공식 출근부와의 연동 방식은 그대로이며, 보안 제한과 접근성 설정을 우회하지 않습니다.

> **중요:** SDK 36을 대상으로 *빌드하도록 준비*한 수정입니다. Android 16 실기기나 에뮬레이터에서 APK 빌드·설치·접근성 화면 수집 테스트까지 완료했다는 뜻은 아닙니다. GitHub Actions 빌드 로그를 확인한 뒤 실제 Android 16 휴대전화에서 상태표시줄·버튼·권한 안내·조회 목록 수집을 테스트하세요. 구글 Play 프로텍트의 경고 여부는 SDK 숫자만으로 보장되지 않습니다.

## 재검증

`ParserTest`, `ExtendedParserTest`, `YearRangeTest`, `AprilScreenshotRegressionTest` 4개 테스트를 Kotlin/JVM에서 실행하고 모두 통과했습니다. 2026년 4월 13건의 근무기록은 출퇴근 구간 73시간, 확인된 식사시간 5시간, 실근무 68시간, 차이 0건으로 검증되었습니다.

공식 문서:
- https://developer.android.com/about/versions/16/setup-sdk
- https://developer.android.com/about/versions/16/behavior-changes-16
- https://developer.android.com/develop/ui/views/layout/edge-to-edge
- https://support.google.com/googleplay/android-developer/answer/11926878
