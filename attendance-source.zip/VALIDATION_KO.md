# V1.8 수정본 검사 결과

검사일: 2026년 11월 7일 (한국 시간). 기존 APK 빌드 환경(Java 17·Gradle 8.13·Android SDK 36)을 유지했습니다. 이 PC는 Windows 11 ARM64이며 테스트용 Java 21도 별도로 사용했습니다.

## 완료한 검사

- Java 17 Debug APK 및 Release APK 컴파일 성공. Release는 소유자 키를 제공받지 않은 **서명 전 APK**입니다. 기존 서명 워크플로 2개는 원본과 동일합니다.
- Android Lint: **오류 0건**, 경고 21건. 새 API 접근·시스템 여백·뒤로 가기 관련 오류를 해결했습니다. 권장 버전, 기존 리소스, 터치 접근성 등 남은 경고는 아래에 공개합니다.
- JUnit/Robolectric: **53건 통과, 실패 0건, 오류 0건, 건너뜀 0건**. Android API 26·35·36 테스트 런타임에서 검증했습니다. 에뮬레이터/실기기 테스트와는 다릅니다.
- 기존 GitHub 사전 검사, 인라인 편집/스크롤바 검사, 클래식 스크롤바 검사 3개 통과.
- 실제 Android View를 Native Graphics로 렌더한 라이트·다크 화면 10장 생성 및 육안 검토.
- APK 및 배포 ZIP 무결성, 원본 워크플로 유지, 앱 버전·SDK 설정 확인.

## 동작 검사 범위

4개 탭과 테마 전환, 빈 기록·기록이 있는 화면, 붙여넣기, 편집 저장·취소, 복사, 임시 편집 보존, 월 삭제·되돌리기, TXT/CSV 저장 시작, 공유 시작, 날짜 범위 경고·월 이동, 달력 날짜와 차트 전환, 설정·공식 앱 미설치 시 처리, 권한 안내 동의·거절, 시작 화면의 시간 제한과 재개 시 미반복, 날짜 바로가기의 구형/신형 뒤로 가기를 실행했습니다.

접근성 단독 재연결 시 실행 허용 상태가 열리지 않는지, 실행 중인 작업이 있을 때만 공식 앱 트리를 허용하는지, 최근 앱 작업 제거 시 읽기와 진행 중 수집을 중단하는지를 모의 Android 서비스/작업 목록으로 검사했습니다. 단순히 화면 메뉴만 감추는 방식이 아니라 읽기·수집 진입부도 차단합니다.

되돌리기는 식사·휴게·표시시간·기관 확인 상태 전체 복원, 다른 월 보존, 이후 수집 시 복원 차단, 최신 1회만 유지, 실행 종료 시 폐기, 손상된 저장소 덮어쓰기 방지를 검사했습니다.

## 실행된 테스트

- `io.local.attendance.AppRegressionTest`: 33건 통과
- `io.local.attendance.LegacyAprilScreenshotRegressionTest`: 1건 통과
- `io.local.attendance.LegacyExtendedParserTest`: 1건 통과
- `io.local.attendance.LegacyParserTest`: 1건 통과
- `io.local.attendance.LegacyV14ShareTest`: 1건 통과
- `io.local.attendance.LegacyV16CalendarWeekTest`: 1건 통과
- `io.local.attendance.LegacyV16FloatingCollectionStatusTest`: 1건 통과
- `io.local.attendance.LegacyYearRangeTest`: 1건 통과
- `io.local.attendance.RecordUndoTest`: 12건 통과
- `io.local.attendance.VisualReviewTest`: 1건 통과

## 남은 Lint 경고

AndroidGradlePluginVersion 1건, ApplySharedPref 2건, ClickableViewAccessibility 4건, DataExtractionRules 1건, DrawAllocation 1건, MonochromeLauncherIcon 1건, NewerVersionAvailable 1건, ObsoleteSdkInt 1건, StaticFieldLeak 1건, UnusedAttribute 1건, UnusedResources 7건

동기 저장은 저장 성공 확인과 기존 데이터 보호를 위한 동작입니다. 버전 업그레이드 권고·사용하지 않는 이전 그림·기존 드래그/스크롤의 접근성 경고 등은 별도로 남아 있으며, 검사 결과를 숨기거나 전체 비활성화하지 않았습니다. API 26~32 뒤로 가기만을 위한 기존 메서드에는 구형 대체 처리임을 명시하고, API 33 이상에는 플랫폼 뒤로 가기 콜백을 적용했습니다.

## 실기기 확인이 필요한 범위

이 PC에는 연결된 Android 기기와 실제 한국장학재단 출근부 앱이 없습니다. 모든 단말·버튼에서 강제 종료가 절대 없다고 보장하는 검사는 아닙니다. 특히 다음은 실제 기기에서 확인해야 합니다.

1. 기존 서명키로 만든 APK를 기존 앱 위에 설치해 기록이 유지되는지 확인.
2. 새 실행의 약 2초 시작 화면, 백그라운드 복귀·회전·날짜 바로가기에서 중복되지 않는지 확인.
3. 접근성 권한만 켠 상태에서는 메뉴가 없고, 근무로그를 직접 열어 둔 동안 공식 출근부에만 표시되는지 확인.
4. 최근 앱에서 근무로그를 제거하면 다음 이벤트 또는 약 1초 확인 주기 내 메뉴·수집이 중단되는지 확인. 기기/프로세스 재시작 후에는 직접 앱을 열어야 함.
5. 공식 앱의 실제 조회 목록을 수집하고 원본 날짜·시각·휴게·합계를 대조. 실제 WebView 텍스트 제공 여부와 OEM 접근성 동작은 모의 테스트로 대신할 수 없음.
6. 설치된 문서 저장 앱·공유 앱·캘린더와의 실제 외부 연동 확인. 자동 테스트는 시작 경로와 실패 처리까지 검사함.

## 호환성과 데이터

`io.local.attendance`, 버전 `1.8.0 / 180`, minSdk 26, compileSdk/targetSdk 36 및 저장 키·JSON 형식을 유지했습니다. `AttendanceParser.kt`, `MonthlyWeekStats.kt`, `FloatingCollectionStatus.kt`와 두 GitHub 워크플로는 원본과 바이트 단위로 동일합니다. 새 실행 상태·되돌리기는 메모리에서만 관리합니다. 추가 권한·OCR·스크린샷·서버 전송 기능은 없습니다.
