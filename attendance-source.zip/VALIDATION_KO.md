# V1.8 Spatial Quantum HUD 업그레이드 검사 결과

검사일: 2026년 11월 16일 (한국 시간). 기존 APK 빌드 환경(Java 17 · Gradle 8.13 · Android SDK 36)을 유지했으며, API 36 Robolectric 단위 테스트는 별도 JDK 21(`21.0.13`)로 검증했습니다.

## 완료한 검사 (최종 수정 후)

- **Java 17 Debug & Release APK 빌드**: `:app:assembleDebug`, `:app:assembleRelease` 성공 (`exit code 0`).
- **Android Lint (`:app:lintDebug`)**: **오류(Error) 0건**, 경고 35건 (`DrawAllocation` 0건, `MonochromeLauncherIcon` 0건).
- **JUnit / Robolectric 단위 테스트 (`:app:testDebugUnitTest`, JDK 21)**: **총 75건 통과, 실패 0건, 오류 0건, 건너뜀 0건** (Android API 26 · 35 · 36 런타임 포함).
- **Python 정적 회귀 검사 (`tests/*.py`)**: **18개 스크립트 18/18 전부 통과** (`V16BuildPreflight.py`, `V17InlineEditorScrollBarRegressionTest.py`, `V18ClassicScrollbarRegressionTest.py` 포함).
- **실제 Android View 렌더링 육안 검수**: Native Graphics로 렌더링된 라이트·다크·다이어리·오버레이 스크린샷(`app/build/reports/ui-preview/*.png`)을 직접 열어 태양 코로나 눈부심 제어, 대비·가독성, 행성 궤도 그래픽, 상단 탭별 부제목 동기화까지 확인 완료.
- **기존 GitHub 워크플로 무결성**: `.github/workflows/build-apk.yml`, `build-signed-release.yml` 바이트 단위 원본 유지, `io.local.attendance`, `versionCode = 180`, `versionName = "1.8.0"`, `minSdk = 26`, `compileSdk/targetSdk = 36` 유지.

## 실행된 테스트 상세

- `io.local.attendance.AppRegressionTest`: 54건 통과 (원본 V1.8 홈 기능 보존 확인, 4개 탭 × 라이트/다크/시스템 자동 전환, 월 목표·한도 계산 및 다이얼로그 검증, 설정 4단계 안내/도움말 펼침·접기, 플로팅 오버레이 드래그·길게 누르기·핀치·테두리 리사이즈·숨김, 393×852 그리드 균일성·스트레스 테스트 포함)
- `io.local.attendance.RecordUndoTest`: 12건 통과
- `io.local.attendance.VisualReviewTest`: 2건 통과 (라이트/다크 4탭, 다이어리, 차트/그래프, 목표 설정, 날짜 경고/접근성 안내 다이얼로그, 플로팅 위성 오버레이 PNG 렌더링)
- `io.local.attendance.LegacyAprilScreenshotRegressionTest`: 1건 통과
- `io.local.attendance.LegacyExtendedParserTest`: 1건 통과 (35개 그룹 / 330개 케이스)
- `io.local.attendance.LegacyParserTest`: 1건 통과
- `io.local.attendance.LegacyV14ShareTest`: 1건 통과
- `io.local.attendance.LegacyV16CalendarWeekTest`: 1건 통과 (7,292개 달력 주차·비율 체크)
- `io.local.attendance.LegacyV16FloatingCollectionStatusTest`: 1건 통과
- `io.local.attendance.LegacyYearRangeTest`: 1건 통과 (429개 연도 범위 체크)

## 남은 Lint 경고 (35건, Error 0건)

- `UnusedResources`: 15건 (미사용 보조 드로어블 및 XML 컬러 토큰)
- `ClickableViewAccessibility`: 6건 (플로팅 패널/스크롤 레일 커스텀 터치 제스처)
- `SetTextI18n`: 4건
- `ApplySharedPref`: 2건 (`RecordStore` 동의 동기 저장)
- `ViewConstructor`: 2건 (`QuantumSolarSystemView`, `PlanetaryOrbitStripView` 코드 전용 커스텀 뷰)
- `AndroidGradlePluginVersion` 1건, `DataExtractionRules` 1건, `NewerVersionAvailable` 1건, `ObsoleteSdkInt` 1건, `StaticFieldLeak` 1건, `UnusedAttribute` 1건

## 실기기 확인 권장 범위

로컬 PC 환경에는 실물 단말과 한국장학재단 출근부 앱이 설치되어 있지 않으므로, 서명 키 기반 실기기 배포 시 시스템 다크/라이트 자동 전환, 공식 출근부 앱 목록 스크롤 수집 및 외부 문서/캘린더 앱 연동을 최종 확인하는 것을 권장합니다.
