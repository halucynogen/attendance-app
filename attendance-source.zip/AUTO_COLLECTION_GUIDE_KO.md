# 근무로그 v1.1 — 자동 수집 모드 (GitHub 서명 APK)

## 지금 할 일 (기존 Secret 4개 재사용)

1. 이 패키지의 `attendance-source.zip`을 GitHub 저장소의 **맨 위**에 업로드해 기존 파일과 교체합니다.
2. `.github/workflows/build-signed-release.yml`을 동봉한 동일 경로의 파일로 교체합니다. (처음 한 번만)
3. 변경 사항을 `Commit changes`로 저장합니다.
4. `Actions → Build Signed Attendance APK → Run workflow`를 누릅니다.
5. 성공한 실행 항목의 `Artifacts`에서 `attendance-v1.1-signed-apk`를 받습니다.
6. ZIP을 **완전히 압축 해제**하고 `app-release.apk`를 확인합니다.

`SIGNING_KEYSTORE_B64`, `RELEASE_KEYSTORE_PASSWORD`, `RELEASE_KEY_ALIAS`, `RELEASE_KEY_PASSWORD`는 이미 등록했다면 **그대로 둡니다**. 재등록하거나 키를 새로 만들 필요 없습니다. APK를 동일 패키지에 업데이트하려면 **같은 키**여야 합니다.

## 사용 방법 (접근성이 사용자에게 허용된 경우)

1. 근무로그 실행 → 홈의 **자동 수집 모드** → `자동 수집 시작 안내 · 권한 설정`.
2. 수집 범위(날짜·출퇴근·식사·확인 상태), 스크롤, 일시 OCR, 기기 내 저장 안내를 확인하고 동의.
3. Android 설정에서 근무로그 접근성 서비스 권한을 **사용자가 직접 승인**.
4. 공식 한국장학재단 출근부 앱을 열고 본인이 조회할 **연도·월의 목록**으로 이동.
5. 나타나는 `목록 수집`을 본인이 눌러 시작. 자동 스크롤은 **조회 목록에 한정**합니다.
6. 수집 완료 시 서비스는 자동으로 사용 중지를 요청합니다. 언제든 `중지`를 눌러 중단 가능.

앱은 대상 패키지 `com.kosaf.gpsAttendance`에 한정합니다. 다른 앱으로 전환하거나 화면 대상이 확인되지 않으면 수집과 화면 OCR을 중지합니다. 화면 이미지는 디스크에 저장하거나 서버로 전송하지 않습니다. 앱은 INTERNET 권한을 요구하지 않습니다.

## 중요한 설치 제한

- **Play 프로텍트 차단은 서명된 APK로도 발생할 수 있습니다.** 이 패키지는 Play 프로텍트 차단을 회피하거나 기기의 보안 기능을 해제하지 않습니다.
- 외부 설치 앱에 적용되는 Android/삼성의 **접근성 '제한된 설정'은 사용자가 승인해야** 합니다. 정책에 따라 승인 버튼이 없거나 차단이 지속될 수 있습니다.
- `isAccessibilityTool=true`를 허위로 선언하지 않습니다. 근무로그는 장애 지원용 도구가 아닙니다.
- 보안 검사가 거절한다면 Google 공식 차단 이의신청 및 앱 보안 검토를 거치세요: https://developers.google.com/android/play-protect/warning-dev-guidance?hl=ko
- 사용자 기록을 보존하려면 기존 앱을 삭제하기 전 TXT/CSV로 백업하세요. 이전 디버그 APK와 릴리스 APK는 서명이 달라 덮어쓰기 설치가 불가능할 수 있습니다.

## 검증 범위

Kotlin 파서 단위 테스트, XML 유효성 및 워크플로 정적 검사를 확인합니다. 현재 환경에서는 Android SDK가 없어 실제 Release APK 빌드·삼성 실기기 접근성 승인은 검증할 수 없습니다.
