# V1.6.0 / build 160: GitHub Actions archive mismatch fix

The run showing `Source archive: 6affa39b70df9e53...` is using the previous
V1.5 archive (versionName 1.5.0, versionCode 150). The V1.6 workflows
correctly reject that archive. This release package provides all three matching
files, so **replace all three in one commit**:

1. `attendance-source.zip` at the repository root.
2. `.github/workflows/build-apk.yml`
3. `.github/workflows/build-signed-release.yml`

Do not upload the outer GitHub bundle ZIP directly as `attendance-source.zip`;
extract it first and upload the inner archive with the exact file name.
The workflows now print a precise version mismatch and GitHub Actions summary.
They do not silently upgrade v1.5 source or bypass version checking.

Expected Android build metadata:
- `versionName = "1.6.0"`
- `versionCode = 160`
- `compileSdk = 36`
- `targetSdk = 36`

The app implementation, layouts, accessibility behavior, and persisted record
format have not been modified in this packaging fix.
