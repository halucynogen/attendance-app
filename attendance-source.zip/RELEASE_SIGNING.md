# 배포용 빌드 및 Play 프로텍트 대응 가이드

Google Play 프로텍트의 검사를 숨기거나 차단 경고를 우회할 수 없습니다. 이 프로젝트는 **검증 가능한 정식 릴리스 서명과 투명한 데이터 수집 안내**를 위한 기본 도구를 제공합니다.

## 1. 설치용 빌드의 출처 구분

- `.github/workflows/build-apk.yml`: 기본 디버그 APK. 임시 개발 키로 서명되므로 실제 배포에 사용하지 마세요.
- `.github/workflows/build-signed-release.yml`: GitHub Actions에서 사용자가 직접 수동 실행하는 릴리스 APK 및 Play 업로드용 AAB. 반드시 개인 소유 키가 필요합니다.
- Google Play 등록/승인 후 스토어를 통해 배포하는 것이 사용자가 앱의 출처와 업데이트를 확인하기 가장 쉽습니다. APK 서명만으로 심사나 안전 판정이 완료되지는 않습니다.

## 2. 사용자 소유 키 준비

키를 처음 한 번 만들고 이후 업데이트에서 **반드시 동일한 키**를 사용하세요. 키 파일/비밀번호는 ZIP·Git 저장소·이슈·채팅에 공개하지 마세요.

```bash
keytool -genkeypair -v -keystore release-upload.jks -alias attendance-upload -keyalg RSA -keysize 3072 -validity 10000
```

키 파일을 안전한 오프라인 저장소에 백업합니다. Google Play App Signing을 사용하는 경우 upload key와 Google 관리 앱 서명 키의 역할이 다르므로 Play Console 안내에 따라 설정합니다.

Github 저장소의 **Settings → Secrets and variables → Actions**에 아래 비밀값을 추가합니다.

- `SIGNING_KEYSTORE_B64`: `release-upload.jks`의 base64 인코딩 결과(인코딩 시 줄바꿈을 없앰)
- `RELEASE_KEYSTORE_PASSWORD`: 키스토어 비밀번호
- `RELEASE_KEY_ALIAS`: 키 별칭(예: `attendance-upload`)
- `RELEASE_KEY_PASSWORD`: 해당 키 비밀번호

예: macOS/Linux에서 `base64 -w 0 release-upload.jks` (macOS에서 `-w`가 없으면 `base64 < release-upload.jks | tr -d '\\n'`). 이 결과는 GitHub Secret 입력란에만 붙여넣으세요.

## 3. 릴리스 빌드

GitHub 저장소에서 **Actions → Build signed release APK and AAB → Run workflow**를 선택합니다. 성공 시 `attendance-v1-signed-release` 아티팩트에서 APK/AAB를 받을 수 있습니다. 작업 중 서명 검증과 SHA-256 인증서 지문 확인이 수행됩니다.

기존 버전을 덮어쓰려면 package name(`io.local.attendance`)과 실제 **설치 APK 서명 인증서**가 모두 같아야 합니다. 기존 임시 디버그 APK와 릴리스 APK는 대부분 호환되지 않습니다. 삭제가 필요한 경우 출근부 기록을 먼저 TXT/CSV로 백업하세요.

## 4. 접근성 정책 및 Play 등록

이 앱의 접근성 사용 목적은 일반적인 근무 목록 자동 정리로, 장애인 지원 앱 전용 `isAccessibilityTool=true` 대상이 아닙니다. 그런 속성을 임의로 추가하지 마세요. Play Console의 **AccessibilityService API 선언**, 해당 기능 설명, 명시적 공개·동의 화면 및 사용자 흐름 시연 영상을 준비하세요. 개인정보처리방침을 실제로 공개하고 Play Console 데이터 보안 입력 내용을 사실과 맞추세요.

- 구글 정책: https://support.google.com/googleplay/android-developer/answer/10964491?hl=ko
- 명시적 공개 안내: https://support.google.com/googleplay/android-developer/answer/11150561?hl=en
- Android 릴리스 서명: https://developer.android.com/studio/publish/app-signing

Android 13 이상에서 설치 출처에 따라 접근성 사용이 제한될 수 있습니다. 보안 기능 비활성화, 우회 또는 '무조건 안전'을 주장하는 안내는 하지 마세요. Play 프로텍트에서 실제 오탐이 발생하면 배포 파일을 유지한 채 Play Console/Google 지원 경로로 검토를 요청하고 정책과 실제 권한 사용 범위를 점검하세요.
