plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// No credentials are kept in source control. A release build uses owner-provided secrets.
val releaseKeystoreFile = System.getenv("RELEASE_KEYSTORE_FILE")
val releaseKeystorePassword = System.getenv("RELEASE_KEYSTORE_PASSWORD")
val releaseKeyAlias = System.getenv("RELEASE_KEY_ALIAS")
val releaseKeyPassword = System.getenv("RELEASE_KEY_PASSWORD")

android {
    namespace = "io.local.attendance"
    compileSdk = 36

    defaultConfig {
        applicationId = "io.local.attendance"
        minSdk = 26
        targetSdk = 36
        versionCode = 180
        versionName = "1.8.0"
    }
    signingConfigs {
        if (listOf(releaseKeystoreFile, releaseKeystorePassword, releaseKeyAlias, releaseKeyPassword)
                .all { !it.isNullOrBlank() }) {
            create("ownerRelease") {
                storeFile = file(releaseKeystoreFile!!)
                storePassword = releaseKeystorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }
    buildTypes {
        getByName("release") {
            // Only signed when all owner-provided credentials are present.
            signingConfigs.findByName("ownerRelease")?.let { signingConfig = it }
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    testOptions {
        unitTests.isIncludeAndroidResources = true
    }
}

dependencies {
    // No OCR/ML Kit dependency; records use text supplied by accessibility or user input.
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.robolectric:robolectric:4.16")
}

// Reuse the original parser/calendar regression bodies as executable JUnit tests.
val legacyTestOutput = layout.buildDirectory.dir("generated/legacy-tests")
val generateLegacyTests by tasks.registering {
    val sources = fileTree(rootProject.file("tests")) { include("*.kt") }
    inputs.files(sources)
    outputs.dir(legacyTestOutput)
    doLast {
        val output = legacyTestOutput.get().asFile.apply { mkdirs() }
        sources.forEach { source ->
            val content = source.readText(Charsets.UTF_8)
                .replace("fun main() {", "class Legacy${source.nameWithoutExtension} { @org.junit.Test fun regression() {")
            output.resolve(source.name).writeText(content + "\n}\n", Charsets.UTF_8)
        }
    }
}
android.sourceSets.getByName("test").java.srcDir(legacyTestOutput)
tasks.matching { it.name.contains("UnitTest") }.configureEach {
    dependsOn(generateLegacyTests)
}
tasks.withType<Test>().configureEach {
    maxHeapSize = "2g"
    maxParallelForks = 1
}
