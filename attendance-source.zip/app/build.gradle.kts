plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// No credentials are kept in source control. A release build uses owner-provided secrets.
val releaseKeystoreFile = System.getenv("RELEASE_KEYSTORE_FILE")
val releaseKeystorePassword = System.getenv("RELEASE_KEYSTORE_PASSWORD")
val releaseKeyAlias = System.getenv("RELEASE_KEY_ALIAS")
val releaseKeyPassword = System.getenv("RELEASE_KEY_PASSWORD")

android {
    namespace = "io.local.attendance"
    compileSdk = 36

    defaultConfig {
        applicationId = "io.local.attendance"
        minSdk = 26
        targetSdk = 36
        versionCode = 130
        versionName = "1.3.0"
    }
    signingConfigs {
        if (listOf(releaseKeystoreFile, releaseKeystorePassword, releaseKeyAlias, releaseKeyPassword)
                .all { !it.isNullOrBlank() }) {
            create("ownerRelease") {
                storeFile = file(releaseKeystoreFile!!)
                storePassword = releaseKeystorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }
    buildTypes {
        getByName("release") {
            // Only signed when all owner-provided credentials are present.
            signingConfigs.findByName("ownerRelease")?.let { signingConfig = it }
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Korean OCR is processed on the device; app declares no INTERNET permission.
    implementation("com.google.mlkit:text-recognition-korean:16.0.1")
}
