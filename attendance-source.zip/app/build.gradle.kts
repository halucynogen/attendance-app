plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "io.local.attendance"
    compileSdk = 35

    defaultConfig {
        applicationId = "io.local.attendance"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "0.3-list-tested"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // On-device Korean OCR. No image needs to be uploaded to a server.
    implementation("com.google.mlkit:text-recognition-korean:16.0.1")
}
