package io.local.attendance

import android.content.Context
import org.junit.After
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.time.YearMonth

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [26, 35, 36])
class RecordUndoTest {
    private val context: Context get() = RuntimeEnvironment.getApplication()
    private val november = YearMonth.of(2026, 11)
    private val old = WorkRecord("2026-11-02", "09:00", "18:00", 480, "기관확인 전", "12:00", "13:00")
    private val edited = WorkRecord("2026-11-02", "10:00", "12:00")
    private val october = WorkRecord("2026-10-31", "09:00", "12:00")

    @After fun cleanup() { RecordStore.clearUndo() }

    @Test fun editAndDeleteCanRestoreAllFieldsWithoutChangingOtherMonths() {
        assertTrue(RecordStore.add(context, listOf(old, october)))
        assertTrue(RecordStore.replaceMonth(context, november, listOf(edited)))
        assertEquals(november, RecordStore.undoMonth())
        assertEquals(RecordStore.UndoResult.RESTORED, RecordStore.undoLastChange(context))
        assertEquals(setOf(old, october), RecordStore.read(context).toSet())
        assertEquals(RecordStore.UndoResult.UNAVAILABLE, RecordStore.undoLastChange(context))
        assertTrue(RecordStore.replaceMonth(context, november, emptyList()))
        assertEquals(listOf(october), RecordStore.read(context))
        assertEquals(RecordStore.UndoResult.RESTORED, RecordStore.undoLastChange(context))
        assertEquals(setOf(old, october), RecordStore.read(context).toSet())
    }

    @Test fun newCollectionRecordsBlockUndoWithoutLosingData() {
        RecordStore.add(context, listOf(old))
        RecordStore.replaceMonth(context, november, listOf(edited))
        val collected = WorkRecord("2026-11-03", "09:00", "10:00")
        RecordStore.add(context, listOf(collected))
        assertEquals(RecordStore.UndoResult.RECORDS_CHANGED, RecordStore.undoLastChange(context))
        assertEquals(setOf(edited, collected), RecordStore.read(context).toSet())
        assertNull(RecordStore.undoMonth())
    }

    @Test fun onlyLatestChangeCanBeRestoredAndSessionCloseClearsSnapshot() {
        RecordStore.add(context, listOf(old))
        RecordStore.replaceMonth(context, november, listOf(edited))
        RecordStore.replaceMonth(context, november, emptyList())
        assertEquals(RecordStore.UndoResult.RESTORED, RecordStore.undoLastChange(context))
        assertEquals(listOf(edited), RecordStore.read(context))
        RecordStore.replaceMonth(context, november, emptyList())
        CollectionSession.close()
        assertEquals(RecordStore.UndoResult.UNAVAILABLE, RecordStore.undoLastChange(context))
        assertTrue(RecordStore.read(context).isEmpty())
    }

    @Test fun corruptStoreIsNeverOverwrittenByUndo() {
        RecordStore.add(context, listOf(old))
        RecordStore.replaceMonth(context, november, listOf(edited))
        val prefs = context.getSharedPreferences("attendance_local_only", Context.MODE_PRIVATE)
        prefs.edit().putString("records", "damaged json").commit()
        assertEquals(RecordStore.UndoResult.SAVE_FAILED, RecordStore.undoLastChange(context))
        assertEquals("damaged json", prefs.getString("records", null))
    }
}
