package io.local.attendance

import android.app.ActivityManager
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Outline
import android.os.Bundle
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowAlertDialog
import org.robolectric.shadows.ShadowAppTask
import org.robolectric.shadows.ShadowDialog
import java.time.Duration
import java.time.YearMonth

/** Execute real Activity click handlers and lifecycle transitions on two Android runtimes. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [26, 35, 36], qualifiers = "ko-rKR-w393dp-h852dp")
class AppRegressionTest {
    private val controller = Robolectric.buildActivity(MainActivity::class.java,
        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER))
    private lateinit var activity: MainActivity

    @Before fun launch() {
        CollectionSession.close()
        activity = controller.create().start().resume().visible().get()
        RecordStore.setSelectedMonth(activity, YearMonth.of(2026, 11))
        invoke("changeTo", arrayOf(YearMonth::class.java, Boolean::class.javaPrimitiveType!!), YearMonth.of(2026, 11), false)
        assertFalse(texts().any { it.contains("앱을 시작하지 못") })
    }

    @After fun close() {
        if (!activity.isDestroyed) {
            controller.pause().stop().destroy()
        }
        CollectionSession.close()
    }

    private fun all(view: View = activity.window.decorView): List<View> =
        listOf(view) + if (view is ViewGroup) (0 until view.childCount).flatMap { all(view.getChildAt(it)) } else emptyList()
    private fun texts() = all().filterIsInstance<TextView>().map { it.text.toString() }
    private fun click(text: String) {
        val view = all().filterIsInstance<TextView>().firstOrNull { it.text.toString() == text && it.isClickable }
            ?: error("Missing action: $text; texts=${texts()}")
        assertTrue(view.performClick())
    }
    private fun tab(title: String) {
        val item = all().first { it.contentDescription?.toString() == "$title 탭" ||
            it.contentDescription?.toString() == "$title 탭, 선택됨" }
        item.performClick()
    }
    private fun invoke(name: String, types: Array<Class<*>> = emptyArray(), vararg values: Any?) {
        MainActivity::class.java.getDeclaredMethod(name, *types).apply { isAccessible = true }.invoke(activity, *values)
    }
    private fun render() = invoke("renderTab")
    private fun dialogButton(which: Int) {
        ShadowAlertDialog.getLatestAlertDialog().getButton(which).performClick()
        shadowOf(Looper.getMainLooper()).idle()
    }
    private fun seed() {
        assertTrue(RecordStore.add(activity, listOf(
            WorkRecord("2026-11-02", "09:00", "18:00", 480, "기관확인 전", "12:00", "13:00"),
            WorkRecord("2026-11-04", "09:00", "11:30"))))
        render()
    }

    @Test fun everyTabAndThemeRendersWithAndWithoutData() {
        repeat(2) { pass ->
            if (pass == 1) seed()
            for (theme in listOf("다크", "라이트")) {
                tab("설정"); click(theme)
                assertTrue(texts().contains("처음 시작하기"))
                assertFalse(texts().contains("업데이트 기록"))
                for ((title, heading) in listOf("홈" to "빠른 실행", "기록" to "근무기록", "통계" to "근무 통계", "설정" to "처음 시작하기")) {
                    tab(title)
                    assertTrue("$title in $theme", texts().contains(heading))
                }
            }
        }
    }

    @Test fun pasteEditCancelSaveAndCopyKeepRecords() {
        tab("기록")
        val paste = all().filterIsInstance<EditText>().first()
        paste.setText("2026.11\n11.02 근무 09:00 ~ 11:30")
        click("기록 추가")
        assertEquals(150, RecordStore.read(activity).single().minutes)
        click("전체 복사")
        click("수정하기")
        val edit = all().filterIsInstance<EditText>().last()
        edit.setText("2026-11-02 09:00 ~ 12:00")
        click("수정 저장")
        dialogButton(AlertDialog.BUTTON_POSITIVE)
        assertEquals(180, RecordStore.read(activity).single().minutes)
        click("수정하기")
        all().filterIsInstance<EditText>().last().setText("2026-11-02 09:00 ~ 15:00")
        click("취소")
        assertEquals(180, RecordStore.read(activity).single().minutes)
        click("수정하기")
        all().filterIsInstance<EditText>().last().setText("invalid record")
        click("수정 저장")
        assertEquals(180, RecordStore.read(activity).single().minutes)
    }

    @Test fun draftSurvivesTabSwitchAndRecreation() {
        seed(); tab("기록"); click("수정하기")
        all().filterIsInstance<EditText>().last().setText("2026-11-02 10:00 ~ 12:00")
        tab("통계"); tab("기록")
        assertTrue(all().filterIsInstance<EditText>().any { it.text.toString() == "2026-11-02 10:00 ~ 12:00" })
        val saved = Bundle()
        controller.saveInstanceState(saved)
        assertTrue(saved.getBoolean("record_edit_mode"))
        assertEquals("2026-11-02 10:00 ~ 12:00", saved.getString("draft_text"))
    }

    @Test fun deleteAndUndoButtonsRestoreRecords() {
        seed(); tab("기록")
        val before = RecordStore.read(activity)
        click("내보내기 · 기록 관리  ⌄")
        click("이 달 기록 삭제")
        dialogButton(AlertDialog.BUTTON_POSITIVE)
        assertTrue(RecordStore.read(activity).isEmpty())
        click("내보내기 · 기록 관리  ⌄")
        click("마지막 변경 되돌리기")
        dialogButton(AlertDialog.BUTTON_POSITIVE)
        assertEquals(before, RecordStore.read(activity))
        assertFalse(texts().contains("마지막 변경 되돌리기"))
    }

    @Test fun exportShareAndSettingsFallbacksDoNotChangeRecords() {
        seed()
        val before = RecordStore.read(activity)
        invoke("shareSummary")
        invoke("copyMonthDetails")
        tab("기록"); click("내보내기 · 기록 관리  ⌄")
        click("TXT 저장"); click("CSV 저장")
        tab("설정")
        for (button in listOf("근무로그 앱 설정 열기", "Google Play 열기", "제한된 설정 · 공식 도움말", "Play 프로텍트 · 공식 도움말")) {
            click(button)
        }
        click("접근성 상태 다시 확인")
        click("접근성 수집 범위 설명")
        ShadowAlertDialog.getLatestAlertDialog()?.dismiss()
        assertEquals(before, RecordStore.read(activity))
    }

    @Test fun monthAndInvalidYearButtonsWork() {
        tab("설정"); click("조회 기간 선택하기")
        assertTrue(texts().contains("이 연도 · 월 적용"))
        val fields = all().filterIsInstance<EditText>()
        fields.first().setText("1999"); fields[1].setText("13")
        click("이 연도 · 월 적용")
        assertEquals(YearMonth.of(2026, 11), RecordStore.selectedMonth(activity))
        fields.first().setText("2024"); fields[1].setText("2")
        click("이 연도 · 월 적용")
        assertEquals(YearMonth.of(2024, 2), RecordStore.selectedMonth(activity))
        click("다음 달 〉")
        assertEquals(YearMonth.of(2024, 3), RecordStore.selectedMonth(activity))
        click("〈 이전 달")
        assertEquals(YearMonth.of(2024, 2), RecordStore.selectedMonth(activity))
    }

    @Test fun calendarAndChartsHandleMonthChanges() {
        seed(); tab("통계")
        click("그래프"); click("차트")
        val day = all().first { it.contentDescription?.toString()?.startsWith("2026년 11월 3일,") == true }
        assertTrue(day.performClick())
        ShadowAlertDialog.getLatestAlertDialog()?.dismiss()
        val workDay = all().first { it.contentDescription?.toString()?.startsWith("2026년 11월 2일,") == true }
        workDay.performClick()
        ShadowAlertDialog.getLatestAlertDialog()?.dismiss()
        click("›")
        assertEquals(YearMonth.of(2026, 12), RecordStore.selectedMonth(activity))
        click("‹")
        assertEquals(YearMonth.of(2026, 11), RecordStore.selectedMonth(activity))
        click("근무 통계 새로고침")
    }

    @Test fun backFromPeriodShortcutKeepsDashboardAndUnregistersCallback() {
        tab("설정"); click("조회 기간 선택하기")
        val field = MainActivity::class.java.getDeclaredField("periodBackCallback").apply { isAccessible = true }
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            val callback = field.get(activity) as android.window.OnBackInvokedCallback
            callback.onBackInvoked()
            assertNull(field.get(activity))
        } else {
            @Suppress("DEPRECATION")
            activity.onBackPressed()
        }
        assertTrue(texts().contains("빠른 실행"))
        assertFalse(activity.isFinishing)
    }

    @Test fun permissionDisclosureAndMissingOfficialAppDoNotCrash() {
        tab("설정"); click("접근성 설정 열기")
        var dialog = ShadowAlertDialog.getLatestAlertDialog()
        assertNotNull(dialog)
        dialogButton(AlertDialog.BUTTON_NEGATIVE)
        assertFalse(RecordStore.consent(activity))
        click("접근성 설정 열기")
        dialog = ShadowAlertDialog.getLatestAlertDialog()
        dialogButton(AlertDialog.BUTTON_POSITIVE)
        assertTrue(RecordStore.consent(activity))
        click("한국장학재단 출근부 열기")
        ShadowAlertDialog.getLatestAlertDialog()?.dismiss()
        assertEquals(0, RecordStore.read(activity).size)
    }

    @Test fun sessionRequiresAppLaunchAndExistingTaskEvenAfterServiceReconnect() {
        val manager = activity.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val task = ShadowAppTask.newInstance()
        shadowOf(task).setTaskInfo(ActivityManager.RecentTaskInfo().apply {
            id = activity.taskId
            if (android.os.Build.VERSION.SDK_INT >= 29) taskId = activity.taskId
        })
        shadowOf(manager).setAppTasks(listOf(task))
        CollectionSession.close()
        assertFalse(CollectionSession.isOpen(activity))
        val service = Robolectric.buildService(CollectorAccessibilityService::class.java).create().get()
        RecordStore.setConsent(activity, true)
        val root = android.view.accessibility.AccessibilityNodeInfo.obtain().apply {
            packageName = "com.kosaf.gpsAttendance"
        }
        shadowOf(service).setRootInActiveWindow(root)
        val readRoot = CollectorAccessibilityService::class.java.getDeclaredMethod("appRoot").apply { isAccessible = true }
        CollectorAccessibilityService::class.java.getDeclaredMethod("onServiceConnected").apply {
            isAccessible = true
        }.invoke(service)
        assertNull("Service reconnect cannot read a tree without an app session", readRoot.invoke(service))
        service.onAccessibilityEvent(AccessibilityEvent.obtain().apply { packageName = "com.kosaf.gpsAttendance" })
        assertFalse(CollectionSession.isOpen(activity))
        CollectionSession.open(activity)
        assertTrue(CollectionSession.isOpen(activity))
        assertNotNull("A running app can access the authorized official root", readRoot.invoke(service))
        controller.pause().stop()
        assertTrue("Switching to official app preserves session", CollectionSession.isOpen(activity))
        controller.start().resume()
        shadowOf(manager).setAppTasks(emptyList())
        assertFalse("Removing app task ends session", CollectionSession.isOpen(activity))
        assertNull("No tree reads after removing the task", readRoot.invoke(service))
        val activeField = CollectorAccessibilityService::class.java.getDeclaredField("active").apply { isAccessible = true }
        activeField.setBoolean(service, true)
        service.onAccessibilityEvent(AccessibilityEvent.obtain().apply { packageName = "com.kosaf.gpsAttendance" })
        assertFalse("Task removal cancels in-flight collection", activeField.getBoolean(service))
        shadowOf(manager).setAppTasks(listOf(task))
        assertFalse("A stale recent task cannot reopen a closed session", CollectionSession.isOpen(activity))
        service.onDestroy()
    }

    @Test fun splashHasDeadlineAndIsNotRepeatedOnResume() {
        val field = MainActivity::class.java.getDeclaredField("launchDrawListener").apply { isAccessible = true }
        assertNotNull(field.get(activity))
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(3))
        activity.window.decorView.viewTreeObserver.dispatchOnPreDraw()
        // The listener belongs to the dashboard's observer, shared once attached.
        val shellField = MainActivity::class.java.getDeclaredField("shell").apply { isAccessible = true }
        (shellField.get(activity) as View).viewTreeObserver.dispatchOnPreDraw()
        assertNull(field.get(activity))
        controller.pause().stop().start().resume()
        assertNull(field.get(activity))
    }

    @Test fun splashShowsLoadingWindowAndCleansUpOnEarlyDestroy() {
        val overlayField = MainActivity::class.java.getDeclaredField("launchSplashOverlay").apply { isAccessible = true }
        val overlay = overlayField.get(activity) as? ViewGroup
        assertNotNull("Fresh launch should show splash overlay", overlay)
        val overlayViews = all(overlay!!)
        assertTrue(overlayViews.any { it is android.widget.ProgressBar })
        assertTrue(overlayViews.filterIsInstance<TextView>().any { it.text.toString().contains("불러오는 중") })

        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(2100))
        assertNull("Splash overlay should auto-dismiss after 2 seconds", overlayField.get(activity))
    }

    @Test fun openDialogAndNestedTouchEventsSurviveDestroyWithoutCrash() {
        seed()
        tab("기록")
        val scrollViews = all().filterIsInstance<android.widget.ScrollView>()
        val innerScroll = scrollViews.last()
        val down = android.view.MotionEvent.obtain(0L, 0L, android.view.MotionEvent.ACTION_DOWN, 50f, 100f, 0)
        val move = android.view.MotionEvent.obtain(0L, 16L, android.view.MotionEvent.ACTION_MOVE, 50f, 40f, 0)
        val up = android.view.MotionEvent.obtain(0L, 32L, android.view.MotionEvent.ACTION_UP, 50f, 40f, 0)
        innerScroll.dispatchTouchEvent(down)
        innerScroll.dispatchTouchEvent(move)
        innerScroll.dispatchTouchEvent(up)
        down.recycle(); move.recycle(); up.recycle()

        invoke("showDateRangeWarning", arrayOf(String::class.java), "테스트 날짜 경고")
        val activeField = MainActivity::class.java.getDeclaredField("activeDialog").apply { isAccessible = true }
        assertNotNull(activeField.get(activity))
        // Tear-down with an open dialog & active splash must never throw WindowManager/View exceptions.
        controller.pause().stop().destroy()
        shadowOf(Looper.getMainLooper()).idle()
        assertNull(activeField.get(activity))
    }

    @Test fun calculateMonthlyGoalProgressComputesStatesCorrectly() {
        assertNull(calculateMonthlyGoalProgress(600, 0))
        val onTrack = calculateMonthlyGoalProgress(2400, 60)!!
        assertEquals(MonthlyGoalTone.ON_TRACK, onTrack.tone)
        assertEquals(667, onTrack.percentTenths)
        assertEquals(1200, onTrack.remainingMinutes)
        assertEquals(0, onTrack.excessMinutes)

        val nearLimit = calculateMonthlyGoalProgress(3060, 60)!!
        assertEquals(MonthlyGoalTone.NEAR_LIMIT, nearLimit.tone)
        assertEquals(850, nearLimit.percentTenths)
        assertEquals(540, nearLimit.remainingMinutes)

        val exceeded = calculateMonthlyGoalProgress(3900, 60)!!
        assertEquals(MonthlyGoalTone.EXCEEDED, exceeded.tone)
        assertEquals(1083, exceeded.percentTenths)
        assertEquals(0, exceeded.remainingMinutes)
        assertEquals(300, exceeded.excessMinutes)
        assertEquals(1.0f, exceeded.fillFraction, 0.0001f)
    }

    @Test fun homeTrimsRedundantShortcutsAndTracksMonthlyGoalProgress() {
        seed()
        val homeTexts = texts()
        assertTrue(homeTexts.contains("빠른 실행"))
        assertTrue(homeTexts.contains("월 목표 · 한도 시간"))
        assertTrue(homeTexts.contains("이번 달 근무 흐름"))
        assertTrue(homeTexts.contains("조회 기간"))
        assertFalse(homeTexts.contains("근무 캘린더에서 날짜별 보기"))
        assertFalse(homeTexts.contains("전체 날짜·시각 복사"))
        assertFalse(homeTexts.contains("처음 사용하시나요?"))
        assertFalse(homeTexts.contains("사용 방법 자세히 보기"))

        click("60시간")
        assertTrue(texts().any { it.contains("10시간 30분 / 60시간 0분 (17.5%)") })
        assertTrue(texts().contains("● 여유롭게 진행 중"))
        assertTrue(texts().contains("목표 60h · 17%"))

        click("목표 변경")
        val dialog = ShadowDialog.getLatestDialog()
        assertNotNull(dialog)
        val decor = dialog!!.window!!.decorView
        val dialogViews = all(decor)
        dialogViews.filterIsInstance<EditText>().first().setText("8")
        dialogViews.filterIsInstance<TextView>().first { it.text.toString() == "적용하기" && it.isClickable }.performClick()
        shadowOf(Looper.getMainLooper()).idle()
        assertFalse(dialog.isShowing)

        assertTrue(texts().contains("⚠ 한도 초과"))
        assertTrue(texts().contains("목표보다 +2시간 30분 초과했어요"))

        click("목표 해제")
        assertTrue(texts().contains("60시간"))

        click("목표 시간 직접 입력")
        val errorDialog = ShadowDialog.getLatestDialog()
        assertNotNull(errorDialog)
        val errorViews = all(errorDialog!!.window!!.decorView)
        errorViews.filterIsInstance<EditText>().first().setText("999")
        errorViews.filterIsInstance<TextView>().first { it.text.toString() == "적용하기" && it.isClickable }.performClick()
        shadowOf(Looper.getMainLooper()).idle()
        assertTrue(errorDialog.isShowing)
        assertTrue(errorViews.filterIsInstance<TextView>().any {
            it.visibility == View.VISIBLE && it.text.toString().contains("1~400")
        })

        controller.pause().stop().destroy()
        shadowOf(Looper.getMainLooper()).idle()
        val activeField = MainActivity::class.java.getDeclaredField("activeDialog").apply { isAccessible = true }
        assertNull(activeField.get(activity))
    }

    @Test fun settingsCollapsibleGuideAndHelpToggleCleanly() {
        tab("설정")
        assertTrue(texts().contains("화면 모드"))
        assertTrue(texts().contains("접근성 자동 수집"))
        assertTrue(texts().contains("기록 관리"))
        assertTrue(texts().contains("사용 방법 4단계 펼치기  ⌄"))
        assertTrue(texts().contains("제한된 설정 · 설치 도움말 펼치기  ⌄"))

        val stepTitle = all().filterIsInstance<TextView>().first { it.text.toString().contains("가져올 월을 선택해요") }
        val helpLinkBtn = all().filterIsInstance<TextView>().first { it.text.toString() == "제한된 설정 · 공식 도움말" }
        assertEquals(View.GONE, (stepTitle.parent?.parent?.parent as View).visibility)
        assertEquals(View.GONE, (helpLinkBtn.parent as View).visibility)

        click("사용 방법 4단계 펼치기  ⌄")
        assertTrue(texts().contains("사용 방법 4단계 접기  ⌃"))
        assertEquals(View.VISIBLE, (all().filterIsInstance<TextView>().first {
            it.text.toString().contains("가져올 월을 선택해요")
        }.parent?.parent?.parent as View).visibility)

        click("사용 방법 4단계 접기  ⌃")
        assertTrue(texts().contains("사용 방법 4단계 펼치기  ⌄"))
        assertEquals(View.GONE, (all().filterIsInstance<TextView>().first {
            it.text.toString().contains("가져올 월을 선택해요")
        }.parent?.parent?.parent as View).visibility)

        click("제한된 설정 · 설치 도움말 펼치기  ⌄")
        assertTrue(texts().contains("제한된 설정 · 설치 도움말 접기  ⌃"))
        assertEquals(View.VISIBLE, (all().filterIsInstance<TextView>().first {
            it.text.toString() == "제한된 설정 · 공식 도움말"
        }.parent as View).visibility)

        click("제한된 설정 · 설치 도움말 접기  ⌃")
        assertTrue(texts().contains("제한된 설정 · 설치 도움말 펼치기  ⌄"))
        assertEquals(View.GONE, (all().filterIsInstance<TextView>().first {
            it.text.toString() == "제한된 설정 · 공식 도움말"
        }.parent as View).visibility)
    }

    @Test fun floatingOverlaySupportsFullSurfaceDragSmallSpanPinchCornerResizeAndHide() {
        val manager = activity.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val task = ShadowAppTask.newInstance()
        shadowOf(task).setTaskInfo(ActivityManager.RecentTaskInfo().apply {
            id = activity.taskId
            if (android.os.Build.VERSION.SDK_INT >= 29) taskId = activity.taskId
        })
        shadowOf(manager).setAppTasks(listOf(task))
        CollectionSession.open(activity)
        RecordStore.setConsent(activity, true)
        activity.getSharedPreferences("floating_menu_position", Context.MODE_PRIVATE).edit()
            .putFloat("pinch_zoom", 0.65f)
            .putBoolean("collapsed", true)
            .apply()

        val service = Robolectric.buildService(CollectorAccessibilityService::class.java).create().get()
        shadowOf(service).setRootInActiveWindow(AccessibilityNodeInfo.obtain().apply {
            packageName = "com.kosaf.gpsAttendance"
        })
        CollectorAccessibilityService::class.java.getDeclaredMethod("onServiceConnected").apply {
            isAccessible = true
        }.invoke(service)

        fun field(name: String) = CollectorAccessibilityService::class.java.getDeclaredField(name).apply { isAccessible = true }
        val wrap = field("overlay").get(service) as LinearLayout
        val params = field("overlayLayout").get(service) as WindowManager.LayoutParams
        val compactStatusView = field("compactStatus").get(service) as TextView
        val badgeView = field("overlayStateBadge").get(service) as TextView
        val hideBtn = field("overlayHideButton").get(service) as TextView
        @Suppress("UNCHECKED_CAST")
        val actionButtons = field("overlayActionButtons").get(service) as List<Button>

        fun layoutWrap() {
            wrap.measure(
                View.MeasureSpec.makeMeasureSpec(params.width, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(852, View.MeasureSpec.AT_MOST)
            )
            wrap.layout(0, 0, wrap.measuredWidth, wrap.measuredHeight)
        }
        fun offsetInWrap(target: View): Pair<Float, Float> {
            var x = target.width / 2f
            var y = target.height / 2f
            var cur: View? = target
            while (cur != null && cur !== wrap) {
                x += cur.left
                y += cur.top
                cur = cur.parent as? View
            }
            return x to y
        }

        layoutWrap()
        assertTrue("Overlay must enable clipToOutline for 28dp rounded panel", wrap.clipToOutline)
        wrap.background.getOutline(Outline())

        CollectorAccessibilityService::class.java.getDeclaredMethod("status", String::class.java)
            .apply { isAccessible = true }
            .invoke(service, "수집 완료 · 총 9건 / 신규 2건 · 통계 탭에서 확인하세요")
        assertEquals("✓ 수집 완료", badgeView.text.toString())

        layoutWrap()
        val overlayTexts = all(wrap).filterIsInstance<TextView>().map { it.text.toString() }
        assertFalse("Removed clutter move button must not appear", overlayTexts.any { it.contains("이동") })
        assertFalse("Removed clutter resize label must not appear", overlayTexts.any { it.contains("핀치") || it.contains("크기") })
        assertEquals("Compact header badge and close button must share uniform height", badgeView.height, hideBtn.height)
        assertEquals(3, actionButtons.size)
        assertEquals("All 3 compact buttons must share identical height", actionButtons[0].height, actionButtons[1].height)
        assertEquals("All 3 compact buttons must share identical height", actionButtons[1].height, actionButtons[2].height)
        assertTrue("All 3 compact buttons must share uniform width", abs(actionButtons[0].width - actionButtons[1].width) <= 2)

        // 1. Full-surface drag initiated directly on compactStatus.
        val initialX = params.x
        val initialY = params.y
        val (statusX, statusY) = offsetInWrap(compactStatusView)
        var t = SystemClock.uptimeMillis()
        wrap.dispatchTouchEvent(MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, statusX, statusY, 0))
        wrap.dispatchTouchEvent(MotionEvent.obtain(t, t + 16, MotionEvent.ACTION_MOVE, statusX + 34f, statusY - 28f, 0))
        wrap.dispatchTouchEvent(MotionEvent.obtain(t, t + 32, MotionEvent.ACTION_UP, statusX + 34f, statusY - 28f, 0))
        assertTrue("Full-surface drag from compactStatus should move X (was $initialX, now ${params.x})",
            abs(params.x - initialX) >= 24)
        assertTrue("Full-surface drag from compactStatus should move Y (was $initialY, now ${params.y})",
            abs(params.y - initialY) >= 20)

        // 2. Long-press anywhere (even directly on the '수집' button) moves the window without clicking the button.
        layoutWrap()
        val beforeLongPressX = params.x
        val (btnX, btnY) = offsetInWrap(actionButtons[0])
        t = SystemClock.uptimeMillis()
        wrap.dispatchTouchEvent(MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, btnX, btnY, 0))
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(280))
        wrap.dispatchTouchEvent(MotionEvent.obtain(t, t + 290, MotionEvent.ACTION_MOVE, btnX - 30f, btnY, 0))
        wrap.dispatchTouchEvent(MotionEvent.obtain(t, t + 310, MotionEvent.ACTION_UP, btnX - 30f, btnY, 0))
        assertTrue("Long-press on button should drag window X", abs(params.x - beforeLongPressX) >= 20)
        assertFalse("Long-press drag on button must not trigger collection", field("startPending").getBoolean(service))

        // 3. Single-finger outer rim/border drag expands compact overlay.
        layoutWrap()
        val widthBeforeRim = params.width
        val rimX = (wrap.width - 4).toFloat()
        val rimY = (wrap.height - 4).toFloat()
        t = SystemClock.uptimeMillis()
        wrap.dispatchTouchEvent(MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, rimX, rimY, 0))
        wrap.dispatchTouchEvent(MotionEvent.obtain(t, t + 20, MotionEvent.ACTION_MOVE, rimX + 95f, rimY + 45f, 0))
        wrap.dispatchTouchEvent(MotionEvent.obtain(t, t + 40, MotionEvent.ACTION_UP, rimX + 95f, rimY + 45f, 0))
        assertTrue("Outer rim drag should expand overlay", field("overlayExpanded").getBoolean(service))
        assertTrue("Outer rim drag should widen overlay", params.width > widthBeforeRim)

        // 4. Double-tap on header badge toggles expanded <-> compact immediately.
        layoutWrap()
        val (badgeX, badgeY) = offsetInWrap(badgeView)
        t = SystemClock.uptimeMillis()
        wrap.dispatchTouchEvent(MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, badgeX, badgeY, 0))
        wrap.dispatchTouchEvent(MotionEvent.obtain(t, t + 40, MotionEvent.ACTION_UP, badgeX, badgeY, 0))
        wrap.dispatchTouchEvent(MotionEvent.obtain(t + 100, t + 100, MotionEvent.ACTION_DOWN, badgeX, badgeY, 0))
        wrap.dispatchTouchEvent(MotionEvent.obtain(t + 100, t + 140, MotionEvent.ACTION_UP, badgeX, badgeY, 0))
        assertFalse("Double-tap on expanded header should collapse to compact mode", field("overlayExpanded").getBoolean(service))
        wrap.dispatchTouchEvent(MotionEvent.obtain(t + 220, t + 220, MotionEvent.ACTION_DOWN, badgeX, badgeY, 0))
        wrap.dispatchTouchEvent(MotionEvent.obtain(t + 220, t + 260, MotionEvent.ACTION_UP, badgeX, badgeY, 0))
        wrap.dispatchTouchEvent(MotionEvent.obtain(t + 320, t + 320, MotionEvent.ACTION_DOWN, badgeX, badgeY, 0))
        wrap.dispatchTouchEvent(MotionEvent.obtain(t + 320, t + 360, MotionEvent.ACTION_UP, badgeX, badgeY, 0))
        assertTrue("Second double-tap on header should expand back", field("overlayExpanded").getBoolean(service))

        // 3. Small two-finger pinch gesture (span <= 90px) still resizes even inside compact threshold.
        layoutWrap()
        val zoomBeforePinch = field("overlayZoom").getFloat(service)
        fun twoFingerEvent(downTime: Long, eventTime: Long, action: Int, x0: Float, y0: Float, x1: Float, y1: Float): MotionEvent {
            val props = arrayOf(
                MotionEvent.PointerProperties().apply { id = 0; toolType = MotionEvent.TOOL_TYPE_FINGER },
                MotionEvent.PointerProperties().apply { id = 1; toolType = MotionEvent.TOOL_TYPE_FINGER }
            )
            val coords = arrayOf(
                MotionEvent.PointerCoords().apply { x = x0; y = y0; pressure = 1f; size = 1f },
                MotionEvent.PointerCoords().apply { x = x1; y = y1; pressure = 1f; size = 1f }
            )
            return MotionEvent.obtain(downTime, eventTime, action, 2, props, coords, 0, 0, 1f, 1f, 0, 0, 0, 0)
        }
        t = SystemClock.uptimeMillis()
        wrap.dispatchTouchEvent(MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, 20f, 30f, 0))
        wrap.dispatchTouchEvent(twoFingerEvent(t, t + 10, MotionEvent.ACTION_POINTER_DOWN or (1 shl MotionEvent.ACTION_POINTER_INDEX_SHIFT), 20f, 30f, 100f, 30f))
        wrap.dispatchTouchEvent(twoFingerEvent(t, t + 20, MotionEvent.ACTION_MOVE, 20f, 30f, 86f, 30f))
        wrap.dispatchTouchEvent(twoFingerEvent(t, t + 30, MotionEvent.ACTION_MOVE, 20f, 30f, 74f, 30f))
        wrap.dispatchTouchEvent(twoFingerEvent(t, t + 40, MotionEvent.ACTION_MOVE, 20f, 30f, 64f, 30f))
        wrap.dispatchTouchEvent(twoFingerEvent(t, t + 50, MotionEvent.ACTION_MOVE, 20f, 30f, 54f, 30f))
        wrap.dispatchTouchEvent(twoFingerEvent(t, t + 60, MotionEvent.ACTION_POINTER_UP or (1 shl MotionEvent.ACTION_POINTER_INDEX_SHIFT), 20f, 30f, 54f, 30f))
        wrap.dispatchTouchEvent(MotionEvent.obtain(t, t + 70, MotionEvent.ACTION_UP, 20f, 30f, 0))
        val zoomAfterPinch = field("overlayZoom").getFloat(service)
        assertTrue("Small-span pinch inward must reduce zoom (before=$zoomBeforePinch, after=$zoomAfterPinch)",
            zoomAfterPinch < zoomBeforePinch - 0.15f)

        // 4. Temporary close button hides overlay for this visit, and resets when leaving official app.
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(500))
        assertTrue(hideBtn.performClick())
        assertEquals(View.GONE, wrap.visibility)
        assertTrue(field("overlayUserHiddenThisVisit").getBoolean(service))
        CollectorAccessibilityService::class.java.getDeclaredMethod("restoreOverlayForOfficialApp")
            .apply { isAccessible = true }.invoke(service)
        assertEquals("Recovery must respect user hide within same visit", View.GONE, wrap.visibility)

        shadowOf(service).setRootInActiveWindow(AccessibilityNodeInfo.obtain().apply {
            packageName = "com.android.launcher3"
        })
        service.onAccessibilityEvent(AccessibilityEvent.obtain().apply {
            eventType = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            packageName = "com.android.launcher3"
        })
        assertFalse("Leaving official app must reset temporary hide flag", field("overlayUserHiddenThisVisit").getBoolean(service))

        shadowOf(service).setRootInActiveWindow(AccessibilityNodeInfo.obtain().apply {
            packageName = "com.kosaf.gpsAttendance"
        })
        CollectorAccessibilityService::class.java.getDeclaredMethod("restoreOverlayForOfficialApp")
            .apply { isAccessible = true }.invoke(service)
        assertEquals("Returning to official app restores overlay", View.VISIBLE, wrap.visibility)

        service.onDestroy()
        shadowOf(Looper.getMainLooper()).idle()
    }

    @Test fun launchStressAndUniformGridCompartmentsNeverCrashAcrossTabsAndMonths() {
        val shell = MainActivity::class.java.getDeclaredField("shell").apply { isAccessible = true }.get(activity) as ViewGroup
        fun layoutAndDraw() {
            shell.measure(
                View.MeasureSpec.makeMeasureSpec(393, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(852, View.MeasureSpec.EXACTLY)
            )
            shell.layout(0, 0, 393, 852)
            val bmp = android.graphics.Bitmap.createBitmap(393, 852, android.graphics.Bitmap.Config.ARGB_8888)
            shell.draw(android.graphics.Canvas(bmp))
            bmp.recycle()
        }

        // Seed mixed records (ASCII "9h 0m" + Korean "건"/"일" + mismatch) and verify uniform cell heights.
        RecordStore.replaceMonth(activity, YearMonth.of(2026, 11), listOf(
            WorkRecord("2026-11-02", "09:00", "18:00", 480, "기관확인 완료", "12:00", "13:00"),
            WorkRecord("2026-11-04", "09:00", "17:00", 480, "기관확인 완료", "12:00", "13:00"),
            WorkRecord("2026-11-11", "10:00", "15:00", 300, "미확인", "", "")
        ))
        render()
        layoutAndDraw()
        assertFalse(texts().any { it.contains("앱을 시작하지 못") })

        // 1. Hero Card 3 bottom metric cells must have identical measured height.
        val heroCell1 = all(shell).filterIsInstance<TextView>().first { it.text.toString() == "총 기록" }.parent?.parent as View
        val heroCell2 = all(shell).filterIsInstance<TextView>().first { it.text.toString() == "휴게" }.parent?.parent as View
        val heroCell3 = all(shell).filterIsInstance<TextView>().first { it.text.toString() == "확인 필요" }.parent?.parent as View
        assertTrue(heroCell1.height > 0)
        assertEquals("Hero metric cells 1 & 2 must match height", heroCell1.height, heroCell2.height)
        assertEquals("Hero metric cells 2 & 3 must match height", heroCell2.height, heroCell3.height)

        // 2. Quick Actions 2x2 grid tiles must have identical measured height.
        val qaTitles = listOf("자동 수집", "내 근무기록", "월간 공유", "접근성 설정")
        val qaHeights = qaTitles.map { title ->
            (all(shell).filterIsInstance<TextView>().first { it.text.toString() == title }.parent?.parent as View).height
        }
        assertTrue(qaHeights.all { it == qaHeights.first() && it > 0 })

        // 3. Records & Stats top summary pair cards must have identical measured height.
        tab("기록")
        layoutAndDraw()
        val recCardLeft = all(shell).filterIsInstance<TextView>().first { it.text.toString() == "계산 근무" }.parent?.parent as View
        val recCardRight = all(shell).filterIsInstance<TextView>().first { it.text.toString() == "휴게 차감" }.parent?.parent as View
        assertEquals("Records summary pair must match height", recCardLeft.height, recCardRight.height)

        tab("통계")
        layoutAndDraw()
        val statCardLeft = all(shell).filterIsInstance<TextView>().first { it.text.toString() == "계산 근무" }.parent?.parent as View
        val statCardRight = all(shell).filterIsInstance<TextView>().first { it.text.toString() == "근무 일수" }.parent?.parent as View
        assertEquals("Stats summary pair must match height", statCardLeft.height, statCardRight.height)

        // 4. Monthly Work Diary 7-column calendar grid cells (including empty ghost cells) must match height in every row.
        val day1Cell = all(shell).filterIsInstance<TextView>().first { it.text.toString() == "1" && (it.parent as? View)?.isClickable == true }.parent as View
        val day2Cell = all(shell).filterIsInstance<TextView>().first { it.text.toString() == "2" && (it.parent as? View)?.isClickable == true }.parent as View
        val day3Cell = all(shell).filterIsInstance<TextView>().first { it.text.toString() == "3" && (it.parent as? View)?.isClickable == true }.parent as View
        val weekRow1 = day1Cell.parent as ViewGroup
        assertEquals(7, weekRow1.childCount)
        assertEquals("Empty ghost cell and day 1 cell must match height", weekRow1.getChildAt(0).height, day1Cell.height)
        assertEquals("Worked day 2 cell and non-worked day 3 cell must match height", day2Cell.height, day3Cell.height)

        // 5. Stress-test boundary months, dark/light toggles, chart/graph switches, and rapid tab switches.
        for (ym in listOf(YearMonth.of(2000, 1), YearMonth.of(2024, 2), YearMonth.of(2100, 12), YearMonth.of(2026, 11))) {
            invoke("changeTo", arrayOf(YearMonth::class.java, Boolean::class.javaPrimitiveType!!), ym, false)
            for (dark in listOf(true, false)) {
                invoke("setDarkMode", arrayOf(Boolean::class.javaPrimitiveType!!), dark)
                for (tName in listOf("홈", "기록", "통계", "설정")) {
                    tab(tName)
                    layoutAndDraw()
                    assertFalse("No startup/render error banner allowed on $ym dark=$dark tab=$tName",
                        texts().any { it.contains("앱을 시작하지 못") })
                }
            }
        }
        shadowOf(Looper.getMainLooper()).idle()
    }
}
