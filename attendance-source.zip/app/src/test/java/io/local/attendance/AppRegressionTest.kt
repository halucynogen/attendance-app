package io.local.attendance

import android.app.ActivityManager
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityEvent
import android.widget.EditText
import android.widget.TextView
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowAlertDialog
import org.robolectric.shadows.ShadowAppTask
import java.time.Duration
import java.time.YearMonth

/** Execute real Activity click handlers and lifecycle transitions on two Android runtimes. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [26, 35, 36], qualifiers = "ko-rKR-w393dp-h852dp")
class AppRegressionTest {
    private val controller = Robolectric.buildActivity(MainActivity::class.java,
        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER))
    private lateinit var activity: MainActivity

    @Before fun launch() {
        CollectionSession.close()
        activity = controller.create().start().resume().visible().get()
        RecordStore.setSelectedMonth(activity, YearMonth.of(2026, 11))
        invoke("changeTo", arrayOf(YearMonth::class.java, Boolean::class.javaPrimitiveType!!), YearMonth.of(2026, 11), false)
        assertFalse(texts().any { it.contains("앱을 시작하지 못") })
    }

    @After fun close() {
        controller.pause().stop().destroy()
        CollectionSession.close()
    }

    private fun all(view: View = activity.window.decorView): List<View> =
        listOf(view) + if (view is ViewGroup) (0 until view.childCount).flatMap { all(view.getChildAt(it)) } else emptyList()
    private fun texts() = all().filterIsInstance<TextView>().map { it.text.toString() }
    private fun click(text: String) {
        val view = all().filterIsInstance<TextView>().firstOrNull { it.text.toString() == text && it.isClickable }
            ?: error("Missing action: $text; texts=${texts()}")
        assertTrue(view.performClick())
    }
    private fun tab(title: String) {
        val item = all().first { it.contentDescription?.toString() == "$title 탭" ||
            it.contentDescription?.toString() == "$title 탭, 선택됨" }
        item.performClick()
    }
    private fun invoke(name: String, types: Array<Class<*>> = emptyArray(), vararg values: Any?) {
        MainActivity::class.java.getDeclaredMethod(name, *types).apply { isAccessible = true }.invoke(activity, *values)
    }
    private fun render() = invoke("renderTab")
    private fun dialogButton(which: Int) {
        ShadowAlertDialog.getLatestAlertDialog().getButton(which).performClick()
        shadowOf(Looper.getMainLooper()).idle()
    }
    private fun seed() {
        assertTrue(RecordStore.add(activity, listOf(
            WorkRecord("2026-11-02", "09:00", "18:00", 480, "기관확인 전", "12:00", "13:00"),
            WorkRecord("2026-11-04", "09:00", "11:30"))))
        render()
    }

    @Test fun everyTabAndThemeRendersWithAndWithoutData() {
        repeat(2) { pass ->
            if (pass == 1) seed()
            for (theme in listOf("다크", "라이트")) {
                tab("설정"); click(theme)
                assertTrue(texts().contains("처음 시작하기"))
                assertFalse(texts().contains("업데이트 기록"))
                for ((title, heading) in listOf("홈" to "빠른 실행", "기록" to "근무기록", "통계" to "근무 통계", "설정" to "처음 시작하기")) {
                    tab(title)
                    assertTrue("$title in $theme", texts().contains(heading))
                }
            }
        }
    }

    @Test fun pasteEditCancelSaveAndCopyKeepRecords() {
        tab("기록")
        val paste = all().filterIsInstance<EditText>().first()
        paste.setText("2026.11\n11.02 근무 09:00 ~ 11:30")
        click("기록 추가")
        assertEquals(150, RecordStore.read(activity).single().minutes)
        click("전체 복사")
        click("수정하기")
        val edit = all().filterIsInstance<EditText>().last()
        edit.setText("2026-11-02 09:00 ~ 12:00")
        click("수정 저장")
        dialogButton(AlertDialog.BUTTON_POSITIVE)
        assertEquals(180, RecordStore.read(activity).single().minutes)
        click("수정하기")
        all().filterIsInstance<EditText>().last().setText("2026-11-02 09:00 ~ 15:00")
        click("취소")
        assertEquals(180, RecordStore.read(activity).single().minutes)
        click("수정하기")
        all().filterIsInstance<EditText>().last().setText("invalid record")
        click("수정 저장")
        assertEquals(180, RecordStore.read(activity).single().minutes)
    }

    @Test fun draftSurvivesTabSwitchAndRecreation() {
        seed(); tab("기록"); click("수정하기")
        all().filterIsInstance<EditText>().last().setText("2026-11-02 10:00 ~ 12:00")
        tab("통계"); tab("기록")
        assertTrue(all().filterIsInstance<EditText>().any { it.text.toString() == "2026-11-02 10:00 ~ 12:00" })
        val saved = Bundle()
        controller.saveInstanceState(saved)
        assertTrue(saved.getBoolean("record_edit_mode"))
        assertEquals("2026-11-02 10:00 ~ 12:00", saved.getString("draft_text"))
    }

    @Test fun deleteAndUndoButtonsRestoreRecords() {
        seed(); tab("기록")
        val before = RecordStore.read(activity)
        click("내보내기 · 기록 관리  ⌄")
        click("이 달 기록 삭제")
        dialogButton(AlertDialog.BUTTON_POSITIVE)
        assertTrue(RecordStore.read(activity).isEmpty())
        click("내보내기 · 기록 관리  ⌄")
        click("마지막 변경 되돌리기")
        dialogButton(AlertDialog.BUTTON_POSITIVE)
        assertEquals(before, RecordStore.read(activity))
        assertFalse(texts().contains("마지막 변경 되돌리기"))
    }

    @Test fun exportShareAndSettingsFallbacksDoNotChangeRecords() {
        seed()
        val before = RecordStore.read(activity)
        invoke("shareSummary")
        invoke("copyMonthDetails")
        tab("기록"); click("내보내기 · 기록 관리  ⌄")
        click("TXT 저장"); click("CSV 저장")
        tab("설정")
        for (button in listOf("근무로그 앱 설정 열기", "Google Play 열기", "제한된 설정 · 공식 도움말", "Play 프로텍트 · 공식 도움말")) {
            click(button)
        }
        click("접근성 상태 다시 확인")
        click("접근성 수집 범위 설명")
        ShadowAlertDialog.getLatestAlertDialog()?.dismiss()
        assertEquals(before, RecordStore.read(activity))
    }

    @Test fun monthAndInvalidYearButtonsWork() {
        tab("설정"); click("조회 기간 선택하기")
        assertTrue(texts().contains("이 연도 · 월 적용"))
        val fields = all().filterIsInstance<EditText>()
        fields.first().setText("1999"); fields[1].setText("13")
        click("이 연도 · 월 적용")
        assertEquals(YearMonth.of(2026, 11), RecordStore.selectedMonth(activity))
        fields.first().setText("2024"); fields[1].setText("2")
        click("이 연도 · 월 적용")
        assertEquals(YearMonth.of(2024, 2), RecordStore.selectedMonth(activity))
        click("다음 달 〉")
        assertEquals(YearMonth.of(2024, 3), RecordStore.selectedMonth(activity))
        click("〈 이전 달")
        assertEquals(YearMonth.of(2024, 2), RecordStore.selectedMonth(activity))
    }

    @Test fun calendarAndChartsHandleMonthChanges() {
        seed(); tab("통계")
        click("그래프"); click("차트")
        val day = all().first { it.contentDescription?.toString()?.startsWith("2026년 11월 3일,") == true }
        assertTrue(day.performClick())
        ShadowAlertDialog.getLatestAlertDialog()?.dismiss()
        val workDay = all().first { it.contentDescription?.toString()?.startsWith("2026년 11월 2일,") == true }
        workDay.performClick()
        ShadowAlertDialog.getLatestAlertDialog()?.dismiss()
        click("›")
        assertEquals(YearMonth.of(2026, 12), RecordStore.selectedMonth(activity))
        click("‹")
        assertEquals(YearMonth.of(2026, 11), RecordStore.selectedMonth(activity))
        click("근무 통계 새로고침")
    }

    @Test fun backFromPeriodShortcutKeepsDashboardAndUnregistersCallback() {
        tab("설정"); click("조회 기간 선택하기")
        val field = MainActivity::class.java.getDeclaredField("periodBackCallback").apply { isAccessible = true }
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            val callback = field.get(activity) as android.window.OnBackInvokedCallback
            callback.onBackInvoked()
            assertNull(field.get(activity))
        } else {
            @Suppress("DEPRECATION")
            activity.onBackPressed()
        }
        assertTrue(texts().contains("빠른 실행"))
        assertFalse(activity.isFinishing)
    }

    @Test fun permissionDisclosureAndMissingOfficialAppDoNotCrash() {
        tab("설정"); click("접근성 설정 열기")
        var dialog = ShadowAlertDialog.getLatestAlertDialog()
        assertNotNull(dialog)
        dialogButton(AlertDialog.BUTTON_NEGATIVE)
        assertFalse(RecordStore.consent(activity))
        click("접근성 설정 열기")
        dialog = ShadowAlertDialog.getLatestAlertDialog()
        dialogButton(AlertDialog.BUTTON_POSITIVE)
        assertTrue(RecordStore.consent(activity))
        click("한국장학재단 출근부 열기")
        ShadowAlertDialog.getLatestAlertDialog()?.dismiss()
        assertEquals(0, RecordStore.read(activity).size)
    }

    @Test fun sessionRequiresAppLaunchAndExistingTaskEvenAfterServiceReconnect() {
        val manager = activity.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val task = ShadowAppTask.newInstance()
        shadowOf(task).setTaskInfo(ActivityManager.RecentTaskInfo().apply {
            id = activity.taskId
            if (android.os.Build.VERSION.SDK_INT >= 29) taskId = activity.taskId
        })
        shadowOf(manager).setAppTasks(listOf(task))
        CollectionSession.close()
        assertFalse(CollectionSession.isOpen(activity))
        val service = Robolectric.buildService(CollectorAccessibilityService::class.java).create().get()
        RecordStore.setConsent(activity, true)
        val root = android.view.accessibility.AccessibilityNodeInfo.obtain().apply {
            packageName = "com.kosaf.gpsAttendance"
        }
        shadowOf(service).setRootInActiveWindow(root)
        val readRoot = CollectorAccessibilityService::class.java.getDeclaredMethod("appRoot").apply { isAccessible = true }
        CollectorAccessibilityService::class.java.getDeclaredMethod("onServiceConnected").apply {
            isAccessible = true
        }.invoke(service)
        assertNull("Service reconnect cannot read a tree without an app session", readRoot.invoke(service))
        service.onAccessibilityEvent(AccessibilityEvent.obtain().apply { packageName = "com.kosaf.gpsAttendance" })
        assertFalse(CollectionSession.isOpen(activity))
        CollectionSession.open(activity)
        assertTrue(CollectionSession.isOpen(activity))
        assertNotNull("A running app can access the authorized official root", readRoot.invoke(service))
        controller.pause().stop()
        assertTrue("Switching to official app preserves session", CollectionSession.isOpen(activity))
        controller.start().resume()
        shadowOf(manager).setAppTasks(emptyList())
        assertFalse("Removing app task ends session", CollectionSession.isOpen(activity))
        assertNull("No tree reads after removing the task", readRoot.invoke(service))
        val activeField = CollectorAccessibilityService::class.java.getDeclaredField("active").apply { isAccessible = true }
        activeField.setBoolean(service, true)
        service.onAccessibilityEvent(AccessibilityEvent.obtain().apply { packageName = "com.kosaf.gpsAttendance" })
        assertFalse("Task removal cancels in-flight collection", activeField.getBoolean(service))
        shadowOf(manager).setAppTasks(listOf(task))
        assertFalse("A stale recent task cannot reopen a closed session", CollectionSession.isOpen(activity))
        service.onDestroy()
    }

    @Test fun splashHasDeadlineAndIsNotRepeatedOnResume() {
        val field = MainActivity::class.java.getDeclaredField("launchDrawListener").apply { isAccessible = true }
        assertNotNull(field.get(activity))
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(3))
        activity.window.decorView.viewTreeObserver.dispatchOnPreDraw()
        // The listener belongs to the dashboard's observer, shared once attached.
        val shellField = MainActivity::class.java.getDeclaredField("shell").apply { isAccessible = true }
        (shellField.get(activity) as View).viewTreeObserver.dispatchOnPreDraw()
        assertNull(field.get(activity))
        controller.pause().stop().start().resume()
        assertNull(field.get(activity))
    }
}
