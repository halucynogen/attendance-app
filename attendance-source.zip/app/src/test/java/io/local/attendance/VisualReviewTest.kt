package io.local.attendance

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.shadows.ShadowAlertDialog
import org.robolectric.shadows.ShadowDialog
import java.io.File
import java.time.YearMonth

/** Render the actual Android Views for visual review; not an HTML approximation. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "ko-rKR-w393dp-h852dp-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class VisualReviewTest {
    @Test fun renderLightAndDarkScreens() {
        val controller = Robolectric.buildActivity(MainActivity::class.java, Intent(Intent.ACTION_VIEW)).setup()
        val activity = controller.get()
        RecordStore.setSelectedMonth(activity, YearMonth.of(2026, 11))
        RecordStore.add(activity, listOf(2, 4, 6, 9, 11, 13, 16, 18, 20).map { day ->
            WorkRecord("2026-11-${day.toString().padStart(2, '0')}", "09:00", "18:00", 480, "기관확인 완료", "12:00", "13:00")
        })
        val root = MainActivity::class.java.getDeclaredField("shell").apply { isAccessible = true }.get(activity) as ViewGroup
        val output = File("build/reports/ui-preview").apply { mkdirs() }
        fun descendants(view: View): List<View> = listOf(view) + if (view is ViewGroup)
            (0 until view.childCount).flatMap { descendants(view.getChildAt(it)) } else emptyList()
        fun layout() {
            root.measure(View.MeasureSpec.makeMeasureSpec(393, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(852, View.MeasureSpec.EXACTLY))
            root.layout(0, 0, 393, 852)
        }
        fun capture(name: String) {
            layout()
            // TextView centers single-line text in pre-draw (bringTextIntoView).
            // A direct Canvas draw must run that phase just like an actual frame.
            root.viewTreeObserver.dispatchOnPreDraw()
            // Snapshot a settled UI; entrance animation does not change layout.
            descendants(root).forEach {
                it.animate().cancel(); it.alpha = 1f; it.translationY = 0f; it.scaleX = 1f; it.scaleY = 1f
            }
            File(output, "$name-layout.txt").writeText(descendants(root).filterIsInstance<TextView>().joinToString("\n") {
                "${it.text}: ${it.width}x${it.height} at ${it.left},${it.top}; lines=${it.lineCount}; color=${it.currentTextColor}"
            })
            val image = Bitmap.createBitmap(393, 852, Bitmap.Config.ARGB_8888)
            root.draw(Canvas(image))
            File(output, "$name.png").outputStream().use { image.compress(Bitmap.CompressFormat.PNG, 100, it) }
            image.recycle()
        }
        fun clickText(target: String) {
            layout()
            val btn = descendants(root).filterIsInstance<TextView>()
                .first { it.text.toString() == target && it.isClickable }
            btn.performClick()
        }
        for (dark in listOf(false, true)) {
            MainActivity::class.java.getDeclaredMethod("setDarkMode", Boolean::class.javaPrimitiveType).apply {
                isAccessible = true
            }.invoke(activity, dark)
            val mode = if (dark) "dark" else "light"
            for ((index, _) in listOf("홈", "기록", "통계", "설정").withIndex()) {
                MainActivity::class.java.getDeclaredField("tab").apply { isAccessible = true }.setInt(activity, index)
                MainActivity::class.java.getDeclaredMethod("renderTab").apply { isAccessible = true }.invoke(activity)
                capture("$index-$mode")
                if (index == 2) {
                    val diary = descendants(root).filterIsInstance<TextView>().first { it.text == "근무 다이어리" }
                    val scroll = descendants(root).filterIsInstance<ScrollView>().first()
                    val section = diary.parent as View
                    scroll.scrollTo(0, section.top)
                    capture("diary-$mode")
                }
            }
        }

        // Capture interactive graph mode preview too.
        MainActivity::class.java.getDeclaredMethod("setDarkMode", Boolean::class.javaPrimitiveType).apply {
            isAccessible = true
        }.invoke(activity, false)
        MainActivity::class.java.getDeclaredField("tab").apply { isAccessible = true }.setInt(activity, 0)
        MainActivity::class.java.getDeclaredMethod("renderTab").apply { isAccessible = true }.invoke(activity)
        clickText("그래프")
        layout()
        val flowHeader = descendants(root).filterIsInstance<TextView>().first { it.text == "이번 달 근무 흐름" }
        val homeScroll = descendants(root).filterIsInstance<ScrollView>().first()
        val scrollChild = homeScroll.getChildAt(0)
        var targetY = 0
        var cursor: View? = flowHeader.parent as? View
        while (cursor != null && cursor != scrollChild) {
            targetY += cursor.top
            cursor = cursor.parent as? View
        }
        homeScroll.scrollTo(0, targetY)
        capture("home-graph-light")

        controller.pause().stop().destroy()
        CollectionSession.close()
    }

    @Test fun renderSplashAndClickedInteractions() {
        CollectionSession.close()
        val splashController = Robolectric.buildActivity(
            MainActivity::class.java,
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        ).setup()
        val activity = splashController.get()
        val output = File("build/reports/ui-preview").apply { mkdirs() }
        fun descendants(view: View): List<View> = listOf(view) + if (view is ViewGroup)
            (0 until view.childCount).flatMap { descendants(view.getChildAt(it)) } else emptyList()
        val rootContainer = MainActivity::class.java.getDeclaredField("rootContainer").apply { isAccessible = true }.get(activity) as ViewGroup
        fun layoutView(v: View, w: Int = 393, h: Int = 852) {
            v.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.EXACTLY))
            v.layout(0, 0, w, h)
            v.viewTreeObserver.dispatchOnPreDraw()
            descendants(v).forEach {
                it.animate().cancel(); it.alpha = 1f; it.translationY = 0f; it.scaleX = 1f; it.scaleY = 1f
            }
        }
        fun savePng(name: String, v: View, w: Int = 393, h: Int = 852) {
            layoutView(v, w, h)
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            v.draw(Canvas(bmp))
            File(output, "$name.png").outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            bmp.recycle()
        }
        savePng("splash-light", rootContainer)

        RecordStore.setSelectedMonth(activity, YearMonth.of(2026, 11))
        RecordStore.add(activity, listOf(2, 4, 6, 9, 11).map { day ->
            WorkRecord("2026-11-${day.toString().padStart(2, '0')}", "09:00", "18:00", 480, "기관확인 완료", "12:00", "13:00")
        })
        MainActivity::class.java.getDeclaredMethod("dismissLaunchSplashOverlay", Boolean::class.javaPrimitiveType).apply {
            isAccessible = true
        }.invoke(activity, true)
        val shell = MainActivity::class.java.getDeclaredField("shell").apply { isAccessible = true }.get(activity) as ViewGroup
        fun click(text: String) {
            layoutView(shell)
            descendants(shell).filterIsInstance<TextView>().first { it.text.toString() == text && it.isClickable }.performClick()
        }

        // Click through Settings -> 조회 기간 선택하기
        descendants(shell).first { it.contentDescription?.toString()?.startsWith("설정 탭") == true }.performClick()
        click("조회 기간 선택하기")
        val periodHeader = descendants(shell).filterIsInstance<TextView>().first { it.text == "조회 기간" }
        descendants(shell).filterIsInstance<ScrollView>().first().scrollTo(0, (periodHeader.parent as View).top)
        savePng("home-period-light", shell)

        // Invalid date warning dialog click
        descendants(shell).filterIsInstance<EditText>().first().setText("1999")
        click("이 연도 · 월 적용")
        ShadowDialog.getLatestDialog()?.window?.decorView?.let { dlgView ->
            dlgView.measure(
                View.MeasureSpec.makeMeasureSpec(360, View.MeasureSpec.AT_MOST),
                View.MeasureSpec.makeMeasureSpec(760, View.MeasureSpec.AT_MOST)
            )
            val w = dlgView.measuredWidth.coerceAtLeast(330)
            val h = dlgView.measuredHeight.coerceAtLeast(240)
            savePng("dialog-date-warning-light", dlgView, w, h)
        }
        ShadowDialog.getLatestDialog()?.dismiss()

        // Records tab inline edit & export expanded click screen
        descendants(shell).first { it.contentDescription?.toString()?.startsWith("기록 탭") == true }.performClick()
        click("내보내기 · 기록 관리  ⌄")
        click("수정하기")
        val resultHeader = descendants(shell).filterIsInstance<TextView>().first { it.text == "추출 결과 · 복사" }
        descendants(shell).filterIsInstance<ScrollView>().first().scrollTo(0, (resultHeader.parent as View).top)
        savePng("records-edit-light", shell)

        // Accessibility disclosure dialog click screen
        descendants(shell).first { it.contentDescription?.toString()?.startsWith("설정 탭") == true }.performClick()
        click("접근성 설정 열기")
        ShadowAlertDialog.getLatestAlertDialog()?.window?.decorView?.let { dlgView ->
            dlgView.measure(
                View.MeasureSpec.makeMeasureSpec(360, View.MeasureSpec.AT_MOST),
                View.MeasureSpec.makeMeasureSpec(760, View.MeasureSpec.AT_MOST)
            )
            val w = dlgView.measuredWidth.coerceAtLeast(330)
            val h = dlgView.measuredHeight.coerceAtLeast(240)
            savePng("dialog-a11y-light", dlgView, w, h)
        }
        ShadowAlertDialog.getLatestAlertDialog()?.dismiss()

        splashController.pause().stop().destroy()
        CollectionSession.close()
    }
}
