package io.local.attendance

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.view.View
import android.view.ViewGroup
import android.widget.ScrollView
import android.widget.TextView
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File
import java.time.YearMonth

/** Render the actual Android Views for visual review; not an HTML approximation. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "ko-rKR-w393dp-h852dp-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class VisualReviewTest {
    @Test fun renderLightAndDarkScreens() {
        val controller = Robolectric.buildActivity(MainActivity::class.java, Intent(Intent.ACTION_VIEW)).setup()
        val activity = controller.get()
        RecordStore.setSelectedMonth(activity, YearMonth.of(2026, 11))
        RecordStore.add(activity, listOf(2, 4, 6, 9, 11, 13, 16, 18, 20).map { day ->
            WorkRecord("2026-11-${day.toString().padStart(2, '0')}", "09:00", "18:00", 480, "기관확인 완료", "12:00", "13:00")
        })
        val root = MainActivity::class.java.getDeclaredField("shell").apply { isAccessible = true }.get(activity) as ViewGroup
        val output = File("build/reports/ui-preview").apply { mkdirs() }
        fun descendants(view: View): List<View> = listOf(view) + if (view is ViewGroup)
            (0 until view.childCount).flatMap { descendants(view.getChildAt(it)) } else emptyList()
        fun layout() {
            root.measure(View.MeasureSpec.makeMeasureSpec(393, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(852, View.MeasureSpec.EXACTLY))
            root.layout(0, 0, 393, 852)
        }
        fun capture(name: String) {
            layout()
            // TextView centers single-line text in pre-draw (bringTextIntoView).
            // A direct Canvas draw must run that phase just like an actual frame.
            root.viewTreeObserver.dispatchOnPreDraw()
            // Snapshot a settled UI; entrance animation does not change layout.
            descendants(root).forEach {
                it.animate().cancel(); it.alpha = 1f; it.translationY = 0f; it.scaleX = 1f; it.scaleY = 1f
            }
            File(output, "$name-layout.txt").writeText(descendants(root).filterIsInstance<TextView>().joinToString("\n") {
                "${it.text}: ${it.width}x${it.height} at ${it.left},${it.top}; lines=${it.lineCount}; color=${it.currentTextColor}"
            })
            val image = Bitmap.createBitmap(393, 852, Bitmap.Config.ARGB_8888)
            root.draw(Canvas(image))
            File(output, "$name.png").outputStream().use { image.compress(Bitmap.CompressFormat.PNG, 100, it) }
            image.recycle()
        }
        for (dark in listOf(false, true)) {
            MainActivity::class.java.getDeclaredMethod("setDarkMode", Boolean::class.javaPrimitiveType).apply {
                isAccessible = true
            }.invoke(activity, dark)
            val mode = if (dark) "dark" else "light"
            for ((index, title) in listOf("홈", "기록", "통계", "설정").withIndex()) {
                MainActivity::class.java.getDeclaredField("tab").apply { isAccessible = true }.setInt(activity, index)
                MainActivity::class.java.getDeclaredMethod("renderTab").apply { isAccessible = true }.invoke(activity)
                capture("$index-$mode")
                if (index == 2) {
                    val diary = descendants(root).filterIsInstance<TextView>().first { it.text == "근무 다이어리" }
                    val scroll = descendants(root).filterIsInstance<ScrollView>().first()
                    val section = diary.parent as View
                    scroll.scrollTo(0, section.top)
                    capture("diary-$mode")
                }
            }
        }
        controller.pause().stop().destroy()
        CollectionSession.close()
    }
}
