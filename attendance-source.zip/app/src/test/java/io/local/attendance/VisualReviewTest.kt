package io.local.attendance

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.os.Build
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.shadows.ShadowAlertDialog
import org.robolectric.shadows.ShadowAppTask
import org.robolectric.shadows.ShadowDialog
import java.io.File
import java.time.YearMonth

/** Render the actual Android Views for visual review; not an HTML approximation. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "ko-rKR-w393dp-h852dp-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class VisualReviewTest {
    @Test fun renderLightAndDarkScreens() {
        val controller = Robolectric.buildActivity(MainActivity::class.java, Intent(Intent.ACTION_VIEW)).setup()
        val activity = controller.get()
        RecordStore.setSelectedMonth(activity, YearMonth.of(2026, 11))
        RecordStore.add(activity, listOf(2, 4, 6, 9, 11, 13, 16, 18, 20).map { day ->
            WorkRecord("2026-11-${day.toString().padStart(2, '0')}", "09:00", "18:00", 480, "기관확인 완료", "12:00", "13:00")
        })
        val root = MainActivity::class.java.getDeclaredField("shell").apply { isAccessible = true }.get(activity) as ViewGroup
        val output = File("build/reports/ui-preview").apply { mkdirs() }
        fun descendants(view: View): List<View> = listOf(view) + if (view is ViewGroup)
            (0 until view.childCount).flatMap { descendants(view.getChildAt(it)) } else emptyList()
        fun layout() {
            root.measure(View.MeasureSpec.makeMeasureSpec(393, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(852, View.MeasureSpec.EXACTLY))
            root.layout(0, 0, 393, 852)
        }
        fun capture(name: String) {
            layout()
            // TextView centers single-line text in pre-draw (bringTextIntoView).
            // A direct Canvas draw must run that phase just like an actual frame.
            root.viewTreeObserver.dispatchOnPreDraw()
            // Snapshot a settled UI; entrance animation does not change layout.
            descendants(root).forEach {
                it.animate().cancel(); it.alpha = 1f; it.translationY = 0f; it.scaleX = 1f; it.scaleY = 1f
            }
            File(output, "$name-layout.txt").writeText(descendants(root).filterIsInstance<TextView>().joinToString("\n") {
                "${it.text}: ${it.width}x${it.height} at ${it.left},${it.top}; lines=${it.lineCount}; color=${it.currentTextColor}"
            })
            val image = Bitmap.createBitmap(393, 852, Bitmap.Config.ARGB_8888)
            root.draw(Canvas(image))
            File(output, "$name.png").outputStream().use { image.compress(Bitmap.CompressFormat.PNG, 100, it) }
            image.recycle()
        }
        fun clickText(target: String) {
            layout()
            val btn = descendants(root).filterIsInstance<TextView>()
                .first { it.text.toString() == target && it.isClickable }
            btn.performClick()
        }
        for (dark in listOf(false, true)) {
            MainActivity::class.java.getDeclaredMethod("setDarkMode", Boolean::class.javaPrimitiveType).apply {
                isAccessible = true
            }.invoke(activity, dark)
            val mode = if (dark) "dark" else "light"
            for ((index, _) in listOf("홈", "기록", "통계", "설정").withIndex()) {
                MainActivity::class.java.getDeclaredField("tab").apply { isAccessible = true }.setInt(activity, index)
                MainActivity::class.java.getDeclaredMethod("renderTab").apply { isAccessible = true }.invoke(activity)
                capture("$index-$mode")
                if (index == 2) {
                    val diary = descendants(root).filterIsInstance<TextView>().first { it.text == "근무 다이어리" }
                    val scroll = descendants(root).filterIsInstance<ScrollView>().first()
                    val section = diary.parent as View
                    scroll.scrollTo(0, section.top)
                    capture("diary-$mode")
                }
            }
        }

        // Capture interactive graph mode preview too.
        MainActivity::class.java.getDeclaredMethod("setDarkMode", Boolean::class.javaPrimitiveType).apply {
            isAccessible = true
        }.invoke(activity, false)
        MainActivity::class.java.getDeclaredField("tab").apply { isAccessible = true }.setInt(activity, 0)
        MainActivity::class.java.getDeclaredMethod("renderTab").apply { isAccessible = true }.invoke(activity)
        clickText("그래프")
        layout()
        val flowHeader = descendants(root).filterIsInstance<TextView>().first { it.text == "이번 달 근무 흐름" }
        val homeScroll = descendants(root).filterIsInstance<ScrollView>().first()
        val scrollChild = homeScroll.getChildAt(0)
        var targetY = 0
        var cursor: View? = flowHeader.parent as? View
        while (cursor != null && cursor != scrollChild) {
            targetY += cursor.top
            cursor = cursor.parent as? View
        }
        homeScroll.scrollTo(0, targetY)
        capture("home-graph-light")

        controller.pause().stop().destroy()
        CollectionSession.close()
    }

    @Test fun renderSplashAndClickedInteractions() {
        CollectionSession.close()
        val splashController = Robolectric.buildActivity(
            MainActivity::class.java,
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        ).setup()
        val activity = splashController.get()
        val output = File("build/reports/ui-preview").apply { mkdirs() }
        fun descendants(view: View): List<View> = listOf(view) + if (view is ViewGroup)
            (0 until view.childCount).flatMap { descendants(view.getChildAt(it)) } else emptyList()
        val rootContainer = MainActivity::class.java.getDeclaredField("rootContainer").apply { isAccessible = true }.get(activity) as ViewGroup
        fun layoutView(v: View, w: Int = 393, h: Int = 852) {
            v.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.EXACTLY))
            v.layout(0, 0, w, h)
            v.viewTreeObserver.dispatchOnPreDraw()
            descendants(v).forEach {
                it.animate().cancel(); it.alpha = 1f; it.translationY = 0f; it.scaleX = 1f; it.scaleY = 1f
            }
        }
        fun savePng(name: String, v: View, w: Int = 393, h: Int = 852) {
            layoutView(v, w, h)
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            v.draw(Canvas(bmp))
            File(output, "$name.png").outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            bmp.recycle()
        }
        val attachSplash = MainActivity::class.java.getDeclaredMethod("attachLaunchOverlay").apply {
            isAccessible = true
        }
        val setDark = MainActivity::class.java.getDeclaredMethod("setDarkMode", Boolean::class.javaPrimitiveType).apply {
            isAccessible = true
        }
        val dismissSplash = MainActivity::class.java.getDeclaredMethod("dismissLaunchSplashOverlay", Boolean::class.javaPrimitiveType).apply {
            isAccessible = true
        }
        // Unregister pre-draw auto-dismiss listener before capturing actual Splash overlays in light & dark mode.
        val drawField = MainActivity::class.java.getDeclaredField("launchDrawListener").apply { isAccessible = true }
        (drawField.get(activity) as? android.view.ViewTreeObserver.OnPreDrawListener)?.let {
            rootContainer.viewTreeObserver.removeOnPreDrawListener(it)
        }
        drawField.set(activity, null)
        attachSplash.invoke(activity)
        savePng("splash-light", rootContainer)
        setDark.invoke(activity, true)
        attachSplash.invoke(activity)
        savePng("splash-dark", rootContainer)
        setDark.invoke(activity, false)

        RecordStore.setSelectedMonth(activity, YearMonth.of(2026, 11))
        RecordStore.add(activity, listOf(2, 4, 6, 9, 11).map { day ->
            WorkRecord("2026-11-${day.toString().padStart(2, '0')}", "09:00", "18:00", 480, "기관확인 완료", "12:00", "13:00")
        })
        dismissSplash.invoke(activity, true)
        val shell = MainActivity::class.java.getDeclaredField("shell").apply { isAccessible = true }.get(activity) as ViewGroup
        fun click(text: String) {
            layoutView(shell)
            descendants(shell).filterIsInstance<TextView>().first { it.text.toString() == text && it.isClickable }.performClick()
        }
        fun scrollToSection(titleText: String, topOffset: Int = 20) {
            layoutView(shell)
            val scroll = descendants(shell).filterIsInstance<ScrollView>().first()
            var cursor: View? = descendants(shell).filterIsInstance<TextView>().first { it.text.toString() == titleText }
            var targetY = 0
            while (cursor != null && cursor !== scroll) {
                targetY += cursor.top
                cursor = cursor.parent as? View
            }
            scroll.scrollTo(0, (targetY - topOffset).coerceAtLeast(0))
        }

        // Click through Home goal preset -> active monthly goal progress gauge card
        descendants(shell).first { it.contentDescription?.toString()?.startsWith("홈 탭") == true }.performClick()
        click("60시간")
        scrollToSection("월 목표 · 한도 시간", topOffset = 36)
        savePng("home-goal-light", shell)

        // Click through Settings -> 4-step guide (already expanded) -> 조회 기간 선택하기
        descendants(shell).first { it.contentDescription?.toString()?.startsWith("설정 탭") == true }.performClick()
        click("조회 기간 선택하기")
        scrollToSection("조회 기간", topOffset = 20)
        savePng("home-period-light", shell)

        // Invalid date warning dialog click
        descendants(shell).filterIsInstance<EditText>().first().setText("1999")
        click("이 연도 · 월 적용")
        ShadowDialog.getLatestDialog()?.window?.decorView?.let { dlgView ->
            dlgView.measure(
                View.MeasureSpec.makeMeasureSpec(360, View.MeasureSpec.AT_MOST),
                View.MeasureSpec.makeMeasureSpec(760, View.MeasureSpec.AT_MOST)
            )
            val w = dlgView.measuredWidth.coerceAtLeast(330)
            val h = dlgView.measuredHeight.coerceAtLeast(240)
            savePng("dialog-date-warning-light", dlgView, w, h)
        }
        ShadowDialog.getLatestDialog()?.dismiss()

        // Records tab inline edit & export expanded click screen
        descendants(shell).first { it.contentDescription?.toString()?.startsWith("기록 탭") == true }.performClick()
        click("내보내기 · 기록 관리  ⌄")
        click("수정하기")
        scrollToSection("추출 결과 · 복사", topOffset = 20)
        savePng("records-edit-light", shell)

        // Accessibility disclosure dialog click screen
        descendants(shell).first { it.contentDescription?.toString()?.startsWith("설정 탭") == true }.performClick()
        click("접근성 설정 열기")
        ShadowAlertDialog.getLatestAlertDialog()?.window?.decorView?.let { dlgView ->
            dlgView.measure(
                View.MeasureSpec.makeMeasureSpec(360, View.MeasureSpec.AT_MOST),
                View.MeasureSpec.makeMeasureSpec(760, View.MeasureSpec.AT_MOST)
            )
            val w = dlgView.measuredWidth.coerceAtLeast(330)
            val h = dlgView.measuredHeight.coerceAtLeast(240)
            savePng("dialog-a11y-light", dlgView, w, h)
        }
        ShadowAlertDialog.getLatestAlertDialog()?.dismiss()

        // Floating accessibility overlay states (expanded complete light/dark + compact 164dp light)
        val manager = activity.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val task = ShadowAppTask.newInstance()
        shadowOf(task).setTaskInfo(ActivityManager.RecentTaskInfo().apply {
            id = activity.taskId
            if (Build.VERSION.SDK_INT >= 29) taskId = activity.taskId
        })
        shadowOf(manager).setAppTasks(listOf(task))
        CollectionSession.open(activity)
        RecordStore.setConsent(activity, true)

        fun captureOverlay(name: String, zoom: Float, dark: Boolean) {
            activity.getSharedPreferences("attendance_display", Context.MODE_PRIVATE).edit()
                .putBoolean("dark_mode", dark).apply()
            activity.getSharedPreferences("floating_menu_position", Context.MODE_PRIVATE).edit()
                .putFloat("pinch_zoom", zoom)
                .putBoolean("collapsed", zoom < 0.98f)
                .apply()
            activity.getSharedPreferences("collection_ui", Context.MODE_PRIVATE).edit()
                .putString("last_status", "수집 완료 · 총 9건 / 신규 2건 · 통계 탭에서 확인하세요")
                .apply()
            val svc = Robolectric.buildService(CollectorAccessibilityService::class.java).create().get()
            shadowOf(svc).setRootInActiveWindow(AccessibilityNodeInfo.obtain().apply {
                packageName = "com.kosaf.gpsAttendance"
            })
            CollectorAccessibilityService::class.java.getDeclaredMethod("onServiceConnected").apply {
                isAccessible = true
            }.invoke(svc)
            val wrap = CollectorAccessibilityService::class.java.getDeclaredField("overlay").apply {
                isAccessible = true
            }.get(svc) as LinearLayout
            val params = CollectorAccessibilityService::class.java.getDeclaredField("overlayLayout").apply {
                isAccessible = true
            }.get(svc) as WindowManager.LayoutParams
            (svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeViewImmediate(wrap)
            val backdrop = FrameLayout(activity).apply {
                setBackgroundColor(Color.parseColor(if (dark) "#0E1322" else "#E6ECF7"))
                setPadding(18, 18, 18, 18)
                addView(wrap, FrameLayout.LayoutParams(params.width, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
            backdrop.measure(
                View.MeasureSpec.makeMeasureSpec(params.width + 36, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(800, View.MeasureSpec.AT_MOST)
            )
            val bw = backdrop.measuredWidth
            val bh = backdrop.measuredHeight
            savePng(name, backdrop, bw, bh)
            val outline = Outline()
            wrap.background.getOutline(outline)
            org.junit.Assert.assertFalse("Native graphics outline should be populated for rounded panel", outline.isEmpty)
            svc.onDestroy()
            shadowOf(Looper.getMainLooper()).idle()
        }

        captureOverlay("overlay-complete-light", 1.15f, dark = false)
        captureOverlay("overlay-complete-dark", 1.15f, dark = true)
        captureOverlay("overlay-compact-light", 0.40f, dark = false)
        activity.getSharedPreferences("attendance_display", Context.MODE_PRIVATE).edit()
            .putBoolean("dark_mode", false).apply()

        splashController.pause().stop().destroy()
        CollectionSession.close()
    }
}
