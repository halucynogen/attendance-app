package io.local.attendance

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.os.Build

/** Process-local authorization. Accessibility reconnection alone cannot open a session. */
object CollectionSession {
    private var openedTaskId: Int? = null

    fun open(activity: Activity) {
        openedTaskId = activity.taskId
    }

    fun close() {
        openedTaskId = null
        RecordStore.clearUndo()
    }

    @Suppress("DEPRECATION")
    fun isOpen(context: Context): Boolean {
        val expected = openedTaskId ?: return false
        val exists = runCatching {
            val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            manager.appTasks.any {
                val task = it.taskInfo
                (if (Build.VERSION.SDK_INT >= 29) task.taskId else task.id) == expected
            }
        }.getOrDefault(false)
        if (!exists) close()
        return exists
    }
}
