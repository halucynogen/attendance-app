package io.local.attendance

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

internal enum class OrbitCardKind {
    SOLAR_HELIO,
    TERRA_ORBIT,
    MARS_ARCHIVE,
    SATURN_RINGS,
    NEPTUNE_DEEP,
    QUANTUM_LATTICE
}

/**
 * Isolated visual layer for the "Spatial Quantum HUD" Solar-System aesthetic.
 * Keeps graphics/animation concerns cleanly separated from business and storage logic.
 */
internal object SpatialQuantumHudVisuals {

    fun adjustAlpha(color: Int, factor: Float): Int {
        val alpha = (Color.alpha(color) * factor).toInt().coerceIn(0, 255)
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))
    }

    private fun dp(context: Context, value: Int): Int =
        (context.resources.displayMetrics.density * value).toInt()

    /** Deep cosmic void in dark mode; luminous sky-aurora + golden solar corona in light mode. */
    fun canvasBackgroundDrawable(context: Context, isDark: () -> Boolean): Drawable = object : Drawable() {
        private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val starPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var lastW = -1f
        private var lastH = -1f
        private var lastDark = isDark()
        private var solarShader: Shader? = null
        private var cyanShader: Shader? = null
        private var violetShader: Shader? = null

        override fun draw(canvas: Canvas) {
            val w = bounds.width().toFloat()
            val h = bounds.height().toFloat()
            if (w <= 0f || h <= 0f) return
            val dark = isDark()
            if (w != lastW || h != lastH || dark != lastDark || bgPaint.shader == null) {
                lastW = w; lastH = h; lastDark = dark
                bgPaint.shader = LinearGradient(
                    0f, 0f, w, h,
                    if (dark) intArrayOf(
                        Color.parseColor("#060A17"),
                        Color.parseColor("#0B1329"),
                        Color.parseColor("#080D1F")
                    ) else intArrayOf(
                        Color.parseColor("#DDE9FF"),
                        Color.parseColor("#EDF3FF"),
                        Color.parseColor("#E3ECFF")
                    ),
                    null,
                    Shader.TileMode.CLAMP
                )
                solarShader = RadialGradient(
                    w * 0.50f, h * 0.14f, w * 0.62f,
                    intArrayOf(
                        Color.argb(if (dark) 44 else 62, 245, 158, 11),
                        Color.argb(if (dark) 22 else 28, 251, 146, 60),
                        Color.TRANSPARENT
                    ),
                    null,
                    Shader.TileMode.CLAMP
                )
                cyanShader = RadialGradient(
                    w * 0.12f, h * 0.24f, w * 0.60f,
                    intArrayOf(
                        Color.argb(if (dark) 42 else 48, 56, 189, 248),
                        Color.TRANSPARENT
                    ),
                    null,
                    Shader.TileMode.CLAMP
                )
                violetShader = RadialGradient(
                    w * 0.88f, h * 0.52f, w * 0.62f,
                    intArrayOf(
                        Color.argb(if (dark) 38 else 42, 139, 92, 246),
                        Color.TRANSPARENT
                    ),
                    null,
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawRect(0f, 0f, w, h, bgPaint)
            glowPaint.shader = cyanShader
            canvas.drawCircle(w * 0.12f, h * 0.24f, w * 0.60f, glowPaint)
            glowPaint.shader = violetShader
            canvas.drawCircle(w * 0.88f, h * 0.52f, w * 0.62f, glowPaint)
            glowPaint.shader = solarShader
            canvas.drawCircle(w * 0.50f, h * 0.14f, w * 0.62f, glowPaint)

            // Subtle cosmic starlight dust
            starPaint.color = if (dark) Color.argb(95, 186, 230, 253) else Color.argb(115, 255, 255, 255)
            val step = dp(context, 48).toFloat().coerceAtLeast(24f)
            var idx = 0
            var sy = dp(context, 24).toFloat()
            while (sy < h * 0.72f) {
                val sx = ((idx * 97 + 31) % 88 + 6) / 100f * w
                canvas.drawCircle(sx, sy, dp(context, if (idx % 3 == 0) 2 else 1).toFloat(), starPaint)
                sy += step
                idx++
            }
        }

        override fun setAlpha(alpha: Int) {}
        override fun setColorFilter(colorFilter: ColorFilter?) {}
        @Suppress("OVERRIDE_DEPRECATION")
        @Deprecated("Deprecated in Java")
        override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
    }

    fun topBarDrawable(context: Context, isDark: () -> Boolean): Drawable = object : Drawable() {
        private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var lastW = -1f
        private var lastDark = isDark()

        override fun draw(canvas: Canvas) {
            val w = bounds.width().toFloat()
            val h = bounds.height().toFloat()
            if (w <= 0f || h <= 0f) return
            val dark = isDark()
            if (w != lastW || dark != lastDark || bgPaint.shader == null) {
                lastW = w; lastDark = dark
                bgPaint.shader = LinearGradient(
                    0f, 0f, w, h,
                    if (dark) intArrayOf(Color.parseColor("#0A1024"), Color.parseColor("#111936"))
                    else intArrayOf(Color.parseColor("#EAF1FF"), Color.parseColor("#F5F8FF")),
                    null,
                    Shader.TileMode.CLAMP
                )
                linePaint.shader = LinearGradient(
                    0f, 0f, w, 0f,
                    intArrayOf(
                        adjustAlpha(Color.parseColor("#F59E0B"), if (dark) 0.55f else 0.45f),
                        adjustAlpha(Color.parseColor("#38BDF8"), if (dark) 0.65f else 0.50f),
                        adjustAlpha(Color.parseColor("#818CF8"), if (dark) 0.55f else 0.45f)
                    ),
                    null,
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawRect(0f, 0f, w, h, bgPaint)
            canvas.drawRect(0f, h - dp(context, 1).toFloat(), w, h, linePaint)
        }

        override fun setAlpha(alpha: Int) {}
        override fun setColorFilter(colorFilter: ColorFilter?) {}
        @Suppress("OVERRIDE_DEPRECATION")
        @Deprecated("Deprecated in Java")
        override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
    }

    fun bottomNavDrawable(context: Context, isDark: () -> Boolean): Drawable = object : Drawable() {
        private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var lastW = -1f
        private var lastDark = isDark()

        override fun draw(canvas: Canvas) {
            val w = bounds.width().toFloat()
            val h = bounds.height().toFloat()
            if (w <= 0f || h <= 0f) return
            val dark = isDark()
            if (w != lastW || dark != lastDark || bgPaint.shader == null) {
                lastW = w; lastDark = dark
                bgPaint.shader = LinearGradient(
                    0f, 0f, w, 0f,
                    if (dark) intArrayOf(Color.parseColor("#0B1126"), Color.parseColor("#131C3A"), Color.parseColor("#0B1126"))
                    else intArrayOf(Color.parseColor("#F2F7FF"), Color.parseColor("#FFFFFF"), Color.parseColor("#EEF4FF")),
                    null,
                    Shader.TileMode.CLAMP
                )
                linePaint.shader = LinearGradient(
                    0f, 0f, w, 0f,
                    intArrayOf(
                        adjustAlpha(Color.parseColor("#38BDF8"), if (dark) 0.55f else 0.40f),
                        adjustAlpha(Color.parseColor("#818CF8"), if (dark) 0.60f else 0.45f),
                        adjustAlpha(Color.parseColor("#F59E0B"), if (dark) 0.45f else 0.35f)
                    ),
                    null,
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawRect(0f, 0f, w, h, bgPaint)
            canvas.drawRect(0f, 0f, w, dp(context, 1).toFloat(), linePaint)
        }

        override fun setAlpha(alpha: Int) {}
        override fun setColorFilter(colorFilter: ColorFilter?) {}
        @Suppress("OVERRIDE_DEPRECATION")
        @Deprecated("Deprecated in Java")
        override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
    }

    /** Spatial Quantum HUD stage card with intense golden solar corona in both Light and Dark modes. */
    fun heroMeshDrawable(context: Context, isDark: () -> Boolean, radiusDp: Int = 26): Drawable = object : Drawable() {
        private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val bloomPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val topBarPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val clipPath = Path()
        private var lastW = -1f
        private var lastH = -1f
        private var lastDark = isDark()
        private var coronaShader: Shader? = null
        private var leftNebulaShader: Shader? = null
        private var rightNebulaShader: Shader? = null

        override fun draw(canvas: Canvas) {
            val w = bounds.width().toFloat()
            val h = bounds.height().toFloat()
            if (w <= 0f || h <= 0f) return
            val dark = isDark()
            val rad = dp(context, radiusDp).toFloat()
            if (w != lastW || h != lastH || dark != lastDark || basePaint.shader == null) {
                lastW = w; lastH = h; lastDark = dark
                basePaint.shader = LinearGradient(
                    0f, 0f, w, h,
                    if (dark) intArrayOf(
                        Color.parseColor("#0A1229"),
                        Color.parseColor("#131D42"),
                        Color.parseColor("#0C1530")
                    ) else intArrayOf(
                        Color.parseColor("#DCE8FF"),
                        Color.parseColor("#EEF4FF"),
                        Color.parseColor("#E1ECFF")
                    ),
                    null,
                    Shader.TileMode.CLAMP
                )
                coronaShader = RadialGradient(
                    w * 0.50f, h * 0.48f, w * 0.46f,
                    if (dark) intArrayOf(
                        Color.argb(72, 245, 158, 11),
                        Color.argb(38, 139, 92, 246),
                        Color.TRANSPARENT
                    ) else intArrayOf(
                        Color.argb(120, 253, 224, 71),
                        Color.argb(74, 251, 146, 60),
                        Color.argb(36, 99, 102, 241),
                        Color.TRANSPARENT
                    ),
                    null,
                    Shader.TileMode.CLAMP
                )
                leftNebulaShader = RadialGradient(
                    w * 0.14f, h * 0.36f, w * 0.44f,
                    intArrayOf(
                        Color.argb(if (dark) 54 else 66, 56, 189, 248),
                        Color.TRANSPARENT
                    ),
                    null,
                    Shader.TileMode.CLAMP
                )
                rightNebulaShader = RadialGradient(
                    w * 0.88f, h * 0.44f, w * 0.44f,
                    intArrayOf(
                        Color.argb(if (dark) 48 else 56, 168, 85, 247),
                        Color.TRANSPARENT
                    ),
                    null,
                    Shader.TileMode.CLAMP
                )
                topBarPaint.shader = LinearGradient(
                    0f, 0f, w, 0f,
                    intArrayOf(
                        Color.parseColor("#38BDF8"),
                        Color.parseColor("#F59E0B"),
                        Color.parseColor("#818CF8")
                    ),
                    null,
                    Shader.TileMode.CLAMP
                )
                borderPaint.shader = LinearGradient(
                    0f, 0f, w, h,
                    intArrayOf(
                        adjustAlpha(Color.parseColor("#38BDF8"), if (dark) 0.52f else 0.48f),
                        adjustAlpha(Color.parseColor("#818CF8"), if (dark) 0.42f else 0.36f),
                        adjustAlpha(Color.parseColor("#F59E0B"), if (dark) 0.44f else 0.38f)
                    ),
                    null,
                    Shader.TileMode.CLAMP
                )
            }

            clipPath.reset()
            clipPath.addRoundRect(0f, 0f, w, h, rad, rad, Path.Direction.CW)
            canvas.save()
            canvas.clipPath(clipPath)
            canvas.drawRect(0f, 0f, w, h, basePaint)
            bloomPaint.shader = leftNebulaShader
            canvas.drawCircle(w * 0.14f, h * 0.36f, w * 0.44f, bloomPaint)
            bloomPaint.shader = rightNebulaShader
            canvas.drawCircle(w * 0.88f, h * 0.44f, w * 0.44f, bloomPaint)
            bloomPaint.shader = coronaShader
            canvas.drawCircle(w * 0.50f, h * 0.48f, w * 0.46f, bloomPaint)
            if (rad > 0f) {
                canvas.drawRect(0f, 0f, w, dp(context, 2).toFloat(), topBarPaint)
            }
            canvas.restore()

            if (rad > 0f) {
                borderPaint.strokeWidth = dp(context, 1).toFloat() * 1.25f
                val inset = borderPaint.strokeWidth * 0.5f
                canvas.drawRoundRect(
                    inset, inset, w - inset, h - inset,
                    (rad - inset).coerceAtLeast(1f), (rad - inset).coerceAtLeast(1f),
                    borderPaint
                )
            }
        }

        override fun setAlpha(alpha: Int) {}
        override fun setColorFilter(colorFilter: ColorFilter?) {}
        @Suppress("OVERRIDE_DEPRECATION")
        @Deprecated("Deprecated in Java")
        override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
    }

    /** Frosted Spatial Glass card with subtle Solar-System planetary & quantized accents. */
    fun patternedCardDrawable(
        context: Context,
        isDark: () -> Boolean,
        fill: Int,
        stroke: Int,
        accent: Int,
        secondary: Int,
        kind: OrbitCardKind,
        radiusDp: Int = 22,
        topStripColors: IntArray? = null,
        bottomAccentBar: Boolean = false
    ): Drawable = object : Drawable() {
        private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val patternPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val orbitPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            pathEffect = DashPathEffect(floatArrayOf(dp(context, 5).toFloat(), dp(context, 3).toFloat()), 0f)
        }
        private val stripPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val bottomBarPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val clip = Path()
        private val oval = RectF()
        private var lastW = -1f
        private var lastH = -1f
        private var lastDark = isDark()

        override fun draw(canvas: Canvas) {
            val w = bounds.width().toFloat()
            val h = bounds.height().toFloat()
            if (w <= 0f || h <= 0f) return
            val dark = isDark()
            val rad = dp(context, radiusDp).toFloat()

            if (w != lastW || h != lastH || lastDark != dark || fillPaint.shader == null) {
                lastW = w; lastH = h; lastDark = dark
                val endTint = if (dark) {
                    Color.argb(Color.alpha(fill),
                        (Color.red(fill) + 8).coerceAtMost(255),
                        (Color.green(fill) + 12).coerceAtMost(255),
                        (Color.blue(fill) + 24).coerceAtMost(255))
                } else {
                    Color.argb(Color.alpha(fill),
                        (Color.red(fill) - 8).coerceAtLeast(226),
                        (Color.green(fill) - 4).coerceAtLeast(234),
                        Color.blue(fill))
                }
                fillPaint.shader = LinearGradient(0f, 0f, w, h, fill, endTint, Shader.TileMode.CLAMP)
                if (topStripColors != null && topStripColors.isNotEmpty()) {
                    val colors = if (topStripColors.size == 1) intArrayOf(topStripColors[0], topStripColors[0]) else topStripColors
                    val softTop = colors.map { adjustAlpha(it, if (dark) 0.16f else 0.11f) }.toIntArray()
                    stripPaint.shader = LinearGradient(0f, 0f, w, 0f, softTop, null, Shader.TileMode.CLAMP)
                    val borderColors = colors.map { adjustAlpha(it, if (dark) 0.46f else 0.36f) }.toIntArray()
                    strokePaint.shader = LinearGradient(0f, 0f, w, h * 0.45f, borderColors, null, Shader.TileMode.CLAMP)
                }
                if (bottomAccentBar) {
                    bottomBarPaint.shader = LinearGradient(
                        0f, 0f, w, 0f,
                        intArrayOf(accent, secondary),
                        null,
                        Shader.TileMode.CLAMP
                    )
                }
            }

            clip.reset()
            clip.addRoundRect(0f, 0f, w, h, rad, rad, Path.Direction.CW)
            canvas.save()
            canvas.clipPath(clip)
            canvas.drawRect(0f, 0f, w, h, fillPaint)

            val cx = w - dp(context, 18).toFloat()
            val cy = dp(context, 22).toFloat()
            patternPaint.shader = null
            when (kind) {
                OrbitCardKind.SOLAR_HELIO -> {
                    patternPaint.style = Paint.Style.FILL
                    patternPaint.color = adjustAlpha(accent, if (dark) 0.14f else 0.09f)
                    canvas.drawCircle(cx, cy, dp(context, 26).toFloat(), patternPaint)
                    orbitPaint.strokeWidth = dp(context, 1).toFloat()
                    orbitPaint.color = adjustAlpha(secondary, if (dark) 0.24f else 0.18f)
                    canvas.drawCircle(cx, cy, dp(context, 34).toFloat(), orbitPaint)
                    patternPaint.color = adjustAlpha(secondary, if (dark) 0.35f else 0.25f)
                    canvas.drawCircle(cx - dp(context, 28), cy + dp(context, 18), dp(context, 3).toFloat(), patternPaint)
                }
                OrbitCardKind.TERRA_ORBIT -> {
                    orbitPaint.strokeWidth = dp(context, 1).toFloat()
                    orbitPaint.color = adjustAlpha(accent, if (dark) 0.22f else 0.16f)
                    canvas.drawCircle(cx, cy, dp(context, 24).toFloat(), orbitPaint)
                    canvas.drawCircle(cx, cy, dp(context, 38).toFloat(), orbitPaint)
                    patternPaint.style = Paint.Style.FILL
                    patternPaint.color = adjustAlpha(secondary, if (dark) 0.24f else 0.18f)
                    canvas.drawCircle(cx, cy, dp(context, 9).toFloat(), patternPaint)
                }
                OrbitCardKind.MARS_ARCHIVE -> {
                    orbitPaint.strokeWidth = dp(context, 1).toFloat()
                    orbitPaint.color = adjustAlpha(accent, if (dark) 0.22f else 0.16f)
                    canvas.drawCircle(cx, cy, dp(context, 22).toFloat(), orbitPaint)
                    patternPaint.style = Paint.Style.FILL
                    patternPaint.color = adjustAlpha(accent, if (dark) 0.16f else 0.11f)
                    canvas.drawCircle(cx, cy, dp(context, 10).toFloat(), patternPaint)
                    patternPaint.color = adjustAlpha(secondary, if (dark) 0.28f else 0.22f)
                    canvas.drawCircle(cx - dp(context, 20), cy + dp(context, 10), dp(context, 3).toFloat(), patternPaint)
                }
                OrbitCardKind.SATURN_RINGS -> {
                    patternPaint.style = Paint.Style.FILL
                    patternPaint.color = adjustAlpha(accent, if (dark) 0.15f else 0.10f)
                    canvas.drawCircle(cx, cy, dp(context, 10).toFloat(), patternPaint)
                    canvas.save()
                    canvas.rotate(-22f, cx, cy)
                    orbitPaint.strokeWidth = dp(context, 1).toFloat() * 1.3f
                    orbitPaint.color = adjustAlpha(secondary, if (dark) 0.28f else 0.22f)
                    oval.set(cx - dp(context, 22), cy - dp(context, 6), cx + dp(context, 22), cy + dp(context, 6))
                    canvas.drawOval(oval, orbitPaint)
                    canvas.restore()
                }
                OrbitCardKind.NEPTUNE_DEEP -> {
                    orbitPaint.strokeWidth = dp(context, 1).toFloat()
                    orbitPaint.color = adjustAlpha(accent, if (dark) 0.20f else 0.15f)
                    oval.set(cx - dp(context, 34), cy - dp(context, 18), cx + dp(context, 34), cy + dp(context, 18))
                    canvas.drawArc(oval, 10f, 175f, false, orbitPaint)
                    patternPaint.style = Paint.Style.FILL
                    patternPaint.color = adjustAlpha(secondary, if (dark) 0.18f else 0.12f)
                    canvas.drawCircle(cx, cy, dp(context, 8).toFloat(), patternPaint)
                }
                OrbitCardKind.QUANTUM_LATTICE -> {
                    patternPaint.style = Paint.Style.FILL
                    patternPaint.color = adjustAlpha(accent, if (dark) 0.18f else 0.12f)
                    for (bar in 0..3) {
                        val bx = cx - dp(context, 26) + bar * dp(context, 7)
                        val bh = dp(context, 6 + (bar % 3) * 4).toFloat()
                        canvas.drawRoundRect(bx, cy + dp(context, 6) - bh, bx + dp(context, 4), cy + dp(context, 6), 4f, 4f, patternPaint)
                    }
                }
            }

            if (topStripColors != null && topStripColors.isNotEmpty()) {
                canvas.drawRect(0f, 0f, w, dp(context, 8).toFloat(), stripPaint)
            }
            // Subtle top specular highlight along the upper glass rim
            patternPaint.style = Paint.Style.STROKE
            patternPaint.strokeWidth = dp(context, 1).toFloat()
            patternPaint.color = Color.argb(if (dark) 30 else 170, 255, 255, 255)
            canvas.drawLine(rad * 0.65f, dp(context, 1).toFloat(),
                (w - rad * 0.65f).coerceAtLeast(rad * 0.65f), dp(context, 1).toFloat(), patternPaint)

            if (bottomAccentBar) {
                val barMargin = dp(context, 12).toFloat()
                val barBottom = h - dp(context, 6).toFloat()
                val barTop = barBottom - dp(context, 3).toFloat()
                if (w > barMargin * 2f) {
                    canvas.drawRoundRect(barMargin, barTop, w - barMargin, barBottom, 6f, 6f, bottomBarPaint)
                }
            }
            canvas.restore()

            if (topStripColors != null && topStripColors.isNotEmpty()) {
                strokePaint.strokeWidth = dp(context, 1).toFloat() * 1.25f
                val inset = strokePaint.strokeWidth * 0.5f
                canvas.drawRoundRect(inset, inset, w - inset, h - inset,
                    (rad - inset).coerceAtLeast(1f), (rad - inset).coerceAtLeast(1f), strokePaint)
            } else if (stroke != Color.TRANSPARENT) {
                strokePaint.shader = null
                strokePaint.color = stroke
                strokePaint.strokeWidth = dp(context, 1).toFloat()
                val inset = dp(context, 1).toFloat() * 0.5f
                canvas.drawRoundRect(inset, inset, w - inset, h - inset, rad, rad, strokePaint)
            }
        }

        override fun setAlpha(alpha: Int) {}
        override fun setColorFilter(colorFilter: ColorFilter?) {}
        @Suppress("OVERRIDE_DEPRECATION")
        @Deprecated("Deprecated in Java")
        override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
    }

    fun splashSpinnerDrawable(context: Context, isDark: () -> Boolean): Drawable = object : Drawable() {
        private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
        }
        private val arcRect = RectF()
        private var lastSize = -1f
        private var lastDark = isDark()

        override fun draw(canvas: Canvas) {
            val w = bounds.width().toFloat()
            val h = bounds.height().toFloat()
            val size = minOf(w, h)
            if (size <= 0f) return
            val dark = isDark()
            val strokeW = (size * 0.13f).coerceAtLeast(dp(context, 3).toFloat())
            val pad = strokeW * 0.6f
            val cx = bounds.exactCenterX()
            val cy = bounds.exactCenterY()
            val radius = (size * 0.5f - pad).coerceAtLeast(1f)
            arcRect.set(cx - radius, cy - radius, cx + radius, cy + radius)

            trackPaint.strokeWidth = strokeW
            trackPaint.color = if (dark) Color.parseColor("#1E2C54") else Color.parseColor("#DBE6FF")
            canvas.drawCircle(cx, cy, radius, trackPaint)

            if (size != lastSize || lastDark != dark || arcPaint.shader == null) {
                lastSize = size; lastDark = dark
                arcPaint.shader = SweepGradient(
                    cx, cy,
                    intArrayOf(
                        Color.parseColor("#F59E0B"),
                        Color.parseColor("#38BDF8"),
                        Color.parseColor("#818CF8"),
                        Color.parseColor("#34D399"),
                        Color.parseColor("#F59E0B")
                    ),
                    null
                )
            }
            arcPaint.strokeWidth = strokeW
            canvas.drawArc(arcRect, -90f, 260f, false, arcPaint)
        }

        override fun setAlpha(alpha: Int) {}
        override fun setColorFilter(colorFilter: ColorFilter?) {}
        @Suppress("OVERRIDE_DEPRECATION")
        @Deprecated("Deprecated in Java")
        override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
    }
}

/**
 * Centerpiece Holographic Quantum Solar System View modeled after the user's preferred
 * "Spatial Quantum HUD" design:
 *  - Blazing Solar Core with white quantum-atom core glyph
 *  - 3 intersecting quantum atom ellipses
 *  - 72-tick graduated HUD reticle ring (slowly rotating orbit when animations are enabled)
 *  - Tilted planetary ecliptic orbits with shaded Mercury, Earth+Moon, Mars, and ringed Saturn/Jupiter
 *  - Holographic projection pedestal beneath
 */
internal class QuantumSolarSystemView(
    context: Context,
    private val darkMode: Boolean
) : View(context) {

    private var orbitPhaseDeg = 0f
    private var orbitAnimator: ValueAnimator? = null
    private var hostActive = true

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val dashPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val ringRect = RectF()
    private val beamPath = Path()

    private val pedestalRxMul = floatArrayOf(1.12f, 0.84f, 0.54f)
    private val pedestalRyMul = floatArrayOf(0.14f, 0.10f, 0.06f)
    private val pedestalColors = intArrayOf(
        Color.argb(if (darkMode) 170 else 205, 56, 189, 248),
        Color.argb(if (darkMode) 175 else 195, 192, 132, 252),
        Color.argb(if (darkMode) 210 else 230, 217, 119, 6)
    )
    private val ellipseAngles = floatArrayOf(0f, 58f, -58f)
    private val ellipseColors = intArrayOf(
        Color.argb(if (darkMode) 195 else 210, 14, 165, 233),
        Color.argb(if (darkMode) 190 else 205, 168, 85, 247),
        Color.argb(if (darkMode) 185 else 200, 99, 102, 241)
    )
    private val innerAtomAngles = floatArrayOf(0f, 60f, -60f)

    private var cachedW = -1f
    private var cachedH = -1f
    private var stageBackdropShader: Shader? = null
    private var coronaShader: Shader? = null
    private var sunSphereShader: Shader? = null
    private var beamShader: Shader? = null
    private var mercuryShader: Shader? = null
    private var earthShader: Shader? = null
    private var moonShader: Shader? = null
    private var marsShader: Shader? = null
    private var jupiterShader: Shader? = null

    private fun dpF(value: Float): Float = resources.displayMetrics.density * value

    fun setAnimationActive(active: Boolean) {
        if (hostActive == active) return
        hostActive = active
        if (active && isAttachedToWindow && visibility == VISIBLE && windowVisibility == VISIBLE) {
            startOrbitIfEnabled()
        } else {
            stopOrbit()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (hostActive && visibility == VISIBLE && windowVisibility == VISIBLE) startOrbitIfEnabled()
    }

    override fun onDetachedFromWindow() {
        stopOrbit()
        super.onDetachedFromWindow()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (hostActive && visibility == VISIBLE && windowVisibility == VISIBLE && isAttachedToWindow) {
            startOrbitIfEnabled()
        } else {
            stopOrbit()
        }
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (hostActive && visibility == VISIBLE && this.visibility == VISIBLE && isAttachedToWindow) {
            startOrbitIfEnabled()
        } else {
            stopOrbit()
        }
    }

    private fun startOrbitIfEnabled() {
        if (!hostActive || orbitAnimator != null || !ValueAnimator.areAnimatorsEnabled()) return
        orbitAnimator = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 28000L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { anim ->
                orbitPhaseDeg = anim.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun stopOrbit() {
        orbitAnimator?.cancel()
        orbitAnimator = null
    }

    private fun localPlanetShader(r: Float, lightHex: String, darkHex: String): Shader = RadialGradient(
        -r * 0.3f, -r * 0.3f, r * 1.35f,
        intArrayOf(Color.parseColor(lightHex), Color.parseColor(darkHex)),
        null,
        Shader.TileMode.CLAMP
    )

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val cx = w * 0.50f
        val cy = h * 0.44f
        val scale = minOf(w * 0.44f, h * 0.44f)
        val sunR = (scale * 0.34f).coerceAtLeast(dpF(18f))
        val hudR = scale * 0.86f
        val pedY = h * 0.87f

        if (w != cachedW || h != cachedH) {
            cachedW = w; cachedH = h
            stageBackdropShader = RadialGradient(
                cx, cy, hudR * 1.45f,
                if (darkMode) intArrayOf(
                    Color.argb(120, 30, 58, 138),
                    Color.argb(46, 56, 189, 248),
                    Color.TRANSPARENT
                ) else intArrayOf(
                    Color.argb(150, 30, 64, 175),
                    Color.argb(82, 79, 70, 229),
                    Color.argb(0, 147, 197, 253)
                ),
                null,
                Shader.TileMode.CLAMP
            )
            // Softened light-mode corona prevents glare washout while keeping golden warmth intact
            coronaShader = RadialGradient(
                cx, cy, sunR * 2.55f,
                if (darkMode) intArrayOf(
                    Color.argb(235, 251, 191, 36),
                    Color.argb(145, 249, 115, 22),
                    Color.argb(65, 168, 85, 247),
                    Color.TRANSPARENT
                ) else intArrayOf(
                    Color.argb(200, 245, 158, 11),
                    Color.argb(130, 234, 88, 12),
                    Color.argb(68, 30, 64, 175),
                    Color.TRANSPARENT
                ),
                null,
                Shader.TileMode.CLAMP
            )
            sunSphereShader = RadialGradient(
                cx - sunR * 0.22f, cy - sunR * 0.22f, sunR * 1.15f,
                if (darkMode) intArrayOf(
                    Color.parseColor("#FFFFFF"),
                    Color.parseColor("#FEF08A"),
                    Color.parseColor("#F59E0B"),
                    Color.parseColor("#EA580C")
                ) else intArrayOf(
                    Color.parseColor("#FFFBEB"),
                    Color.parseColor("#FDE047"),
                    Color.parseColor("#F59E0B"),
                    Color.parseColor("#C2410C")
                ),
                null,
                Shader.TileMode.CLAMP
            )
            beamShader = LinearGradient(
                cx, cy + sunR * 0.7f, cx, pedY,
                intArrayOf(
                    Color.argb(if (darkMode) 165 else 135, 245, 158, 11),
                    Color.argb(if (darkMode) 115 else 100, 139, 92, 246),
                    Color.argb(if (darkMode) 90 else 85, 14, 165, 233)
                ),
                null,
                Shader.TileMode.CLAMP
            )
            mercuryShader = localPlanetShader(dpF(5.2f), "#F8FAFC", "#475569")
            marsShader = localPlanetShader(dpF(6.2f), "#FDBA74", "#9A3412")
            earthShader = localPlanetShader(dpF(11.5f), "#7DD3FC", "#1E3A8A")
            moonShader = localPlanetShader(dpF(3.0f), "#F1F5F9", "#64748B")
            jupiterShader = localPlanetShader(dpF(12.2f), "#FEF08A", "#92400E")
            dashPaint.pathEffect = DashPathEffect(floatArrayOf(dpF(4f), dpF(3f)), 0f)
        }

        // 1. Celestial Nebula Stage Glow behind the Solar System
        fillPaint.shader = stageBackdropShader
        canvas.drawCircle(cx, cy, hudR * 1.45f, fillPaint)

        // 2. Holographic Projection Pedestal at bottom
        fillPaint.shader = beamShader
        beamPath.reset()
        beamPath.moveTo(cx - sunR * 0.34f, cy + sunR * 0.75f)
        beamPath.lineTo(cx + sunR * 0.34f, cy + sunR * 0.75f)
        beamPath.lineTo(cx + hudR * 0.56f, pedY)
        beamPath.lineTo(cx - hudR * 0.56f, pedY)
        beamPath.close()
        canvas.drawPath(beamPath, fillPaint)

        fillPaint.shader = null
        strokePaint.shader = null
        for (i in pedestalRxMul.indices) {
            strokePaint.strokeWidth = dpF(1.4f)
            strokePaint.color = pedestalColors[i]
            val rxMul = pedestalRxMul[i]
            val ryMul = pedestalRyMul[i]
            ringRect.set(cx - hudR * rxMul, pedY - hudR * ryMul, cx + hudR * rxMul, pedY + hudR * ryMul)
            canvas.drawOval(ringRect, strokePaint)
        }

        // 3. Graduated 72-tick HUD Reticle Ring (rotates gently with orbitPhaseDeg)
        canvas.save()
        canvas.rotate(orbitPhaseDeg * 0.35f, cx, cy)
        strokePaint.color = Color.argb(if (darkMode) 110 else 155, 14, 165, 233)
        strokePaint.strokeWidth = dpF(1.1f)
        canvas.drawCircle(cx, cy, hudR, strokePaint)
        for (i in 0 until 72) {
            val angle = i * 5.0 * PI / 180.0
            val major = i % 6 == 0
            val inner = hudR - dpF(if (major) 6f else 3f)
            val outer = hudR + dpF(if (major) 2f else 0f)
            strokePaint.strokeWidth = dpF(if (major) 1.5f else 0.9f)
            strokePaint.color = Color.argb(
                if (major) (if (darkMode) 190 else 220) else (if (darkMode) 90 else 120),
                56, 189, 248
            )
            canvas.drawLine(
                (cx + cos(angle) * inner).toFloat(), (cy + sin(angle) * inner).toFloat(),
                (cx + cos(angle) * outer).toFloat(), (cy + sin(angle) * outer).toFloat(),
                strokePaint
            )
        }
        // Highlighted HUD orbital brackets
        strokePaint.strokeWidth = dpF(2.6f)
        strokePaint.color = Color.parseColor(if (darkMode) "#38BDF8" else "#0284C7")
        ringRect.set(cx - hudR - dpF(4f), cy - hudR - dpF(4f), cx + hudR + dpF(4f), cy + hudR + dpF(4f))
        canvas.drawArc(ringRect, -125f, 70f, false, strokePaint)
        strokePaint.color = Color.parseColor(if (darkMode) "#A855F7" else "#6366F1")
        canvas.drawArc(ringRect, 45f, 65f, false, strokePaint)
        canvas.restore()

        // 4. Wide Tilted Planetary Ecliptic Orbits
        val wideRx = (w * 0.41f).coerceAtLeast(hudR * 1.1f)
        val wideRy = hudR * 0.38f
        canvas.save()
        canvas.rotate(-10f, cx, cy)
        strokePaint.strokeWidth = dpF(1.2f)
        strokePaint.color = Color.argb(if (darkMode) 130 else 165, 56, 189, 248)
        ringRect.set(cx - wideRx, cy - wideRy, cx + wideRx, cy + wideRy)
        canvas.drawOval(ringRect, strokePaint)
        dashPaint.strokeWidth = dpF(1.0f)
        dashPaint.color = Color.argb(if (darkMode) 105 else 140, 168, 85, 247)
        ringRect.set(cx - wideRx * 0.72f, cy - wideRy * 0.70f, cx + wideRx * 0.72f, cy + wideRy * 0.70f)
        canvas.drawOval(ringRect, dashPaint)
        canvas.restore()

        // 5. Three Intersecting Quantum Atom Ellipses
        val atomRx = sunR * 2.20f
        val atomRy = sunR * 0.78f
        for (idx in ellipseAngles.indices) {
            canvas.save()
            canvas.rotate(ellipseAngles[idx] + orbitPhaseDeg * 0.15f, cx, cy)
            strokePaint.strokeWidth = dpF(2.8f)
            strokePaint.color = SpatialQuantumHudVisuals.adjustAlpha(ellipseColors[idx], 0.35f)
            ringRect.set(cx - atomRx, cy - atomRy, cx + atomRx, cy + atomRy)
            canvas.drawOval(ringRect, strokePaint)
            strokePaint.strokeWidth = dpF(1.5f)
            strokePaint.color = ellipseColors[idx]
            canvas.drawOval(ringRect, strokePaint)
            canvas.restore()
        }

        // 6. Blazing Solar Core (with crisp bronze-indigo rim contrast in light mode)
        fillPaint.shader = coronaShader
        canvas.drawCircle(cx, cy, sunR * 2.55f, fillPaint)
        if (!darkMode) {
            strokePaint.strokeWidth = dpF(1.6f)
            strokePaint.color = Color.argb(120, 180, 83, 9)
            canvas.drawCircle(cx, cy, sunR * 1.03f, strokePaint)
        }
        fillPaint.shader = sunSphereShader
        canvas.drawCircle(cx, cy, sunR, fillPaint)

        // Inner White Quantum Atom Emblem inside Sun Core
        fillPaint.shader = null
        val innerR = sunR * 0.56f
        val innerRy = sunR * 0.22f
        strokePaint.strokeWidth = dpF(1.25f)
        strokePaint.color = if (darkMode) Color.argb(235, 255, 255, 255) else Color.argb(245, 255, 251, 235)
        for (idx in innerAtomAngles.indices) {
            canvas.save()
            canvas.rotate(innerAtomAngles[idx], cx, cy)
            ringRect.set(cx - innerR, cy - innerRy, cx + innerR, cy + innerRy)
            canvas.drawOval(ringRect, strokePaint)
            canvas.restore()
        }
        fillPaint.color = Color.WHITE
        canvas.drawCircle(cx, cy, dpF(2.2f), fillPaint)

        // 7. Four Shaded 3D Planets along the Ecliptic Orbits (zero per-frame shader allocations)
        val drift = orbitPhaseDeg * PI / 180.0
        val mercX = cx - wideRx * 0.54f + (cos(drift) * dpF(4f)).toFloat()
        val mercY = cy - hudR * 0.32f + (sin(drift) * dpF(2f)).toFloat()
        drawShadedPlanet(canvas, mercX, mercY, dpF(5.2f), mercuryShader)

        val marsX = cx + wideRx * 0.50f - (cos(drift) * dpF(4f)).toFloat()
        val marsY = cy + hudR * 0.28f - (sin(drift) * dpF(2f)).toFloat()
        drawShadedPlanet(canvas, marsX, marsY, dpF(6.2f), marsShader)

        val earthX = cx - wideRx * 0.72f + (sin(drift) * dpF(5f)).toFloat()
        val earthY = cy + hudR * 0.36f + (cos(drift) * dpF(2.5f)).toFloat()
        drawShadedPlanet(canvas, earthX, earthY, dpF(11.5f), earthShader)
        fillPaint.shader = null
        fillPaint.color = Color.argb(190, 52, 211, 153)
        canvas.drawCircle(earthX - dpF(2.5f), earthY - dpF(1.5f), dpF(4.2f), fillPaint)
        canvas.drawCircle(earthX + dpF(3.5f), earthY + dpF(2.5f), dpF(3.0f), fillPaint)
        drawShadedPlanet(canvas, earthX + dpF(14.5f), earthY - dpF(8f), dpF(3.0f), moonShader)

        val jupX = cx + wideRx * 0.76f - (sin(drift) * dpF(5f)).toFloat()
        val jupY = cy - hudR * 0.16f - (cos(drift) * dpF(2.5f)).toFloat()
        drawShadedPlanet(canvas, jupX, jupY, dpF(12.2f), jupiterShader)
        fillPaint.shader = null
        strokePaint.strokeWidth = dpF(1.6f)
        strokePaint.color = Color.argb(165, 254, 243, 199)
        canvas.drawLine(jupX - dpF(9.5f), jupY - dpF(2.5f), jupX + dpF(9.5f), jupY - dpF(2.5f), strokePaint)
        strokePaint.color = Color.argb(135, 180, 83, 9)
        canvas.drawLine(jupX - dpF(10.5f), jupY + dpF(2.5f), jupX + dpF(10.5f), jupY + dpF(2.5f), strokePaint)
        canvas.save()
        canvas.rotate(-22f, jupX, jupY)
        strokePaint.strokeWidth = dpF(1.8f)
        strokePaint.color = Color.argb(if (darkMode) 195 else 215, 14, 165, 233)
        ringRect.set(jupX - dpF(20f), jupY - dpF(5.5f), jupX + dpF(20f), jupY + dpF(5.5f))
        canvas.drawOval(ringRect, strokePaint)
        canvas.restore()
    }

    private fun drawShadedPlanet(canvas: Canvas, x: Float, y: Float, r: Float, shader: Shader?) {
        canvas.save()
        canvas.translate(x, y)
        fillPaint.shader = shader
        canvas.drawCircle(0f, 0f, r, fillPaint)
        canvas.restore()
    }
}

/**
 * Solar System Planetary Telemetry Strip for Statistics tab:
 * Maps weekly progress proportionally onto Mercury -> Venus -> Earth -> Mars -> Jupiter -> Saturn.
 */
internal class PlanetaryOrbitStripView(
    context: Context,
    private val weeks: List<CalendarWeek>,
    private val darkMode: Boolean
) : View(context) {

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val dashPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(10f, 8f), 0f)
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    }
    private val ovalRect = RectF()
    private val planetLightColors = intArrayOf(
        Color.parseColor("#BAE6FD"), // Mercury
        Color.parseColor("#FDE68A"), // Venus
        Color.parseColor("#7DD3FC"), // Earth
        Color.parseColor("#FCA5A5"), // Mars
        Color.parseColor("#FDBA74"), // Jupiter
        Color.parseColor("#E9D5FF")  // Saturn
    )
    private val planetDarkColors = intArrayOf(
        Color.parseColor("#0284C7"),
        Color.parseColor("#D97706"),
        Color.parseColor("#1D4ED8"),
        Color.parseColor("#E11D48"),
        Color.parseColor("#B45309"),
        Color.parseColor("#7C3AED")
    )
    private val planetRingColor = Color.parseColor(if (darkMode) "#E9D5FF" else "#7C3AED")
    private val labelColor = Color.parseColor(if (darkMode) "#D3DEEF" else "#3F4D63")
    private val count = weeks.size.coerceIn(4, 12)
    private val planetShaders = arrayOfNulls<Shader>(count)
    private val planetRadii = FloatArray(count)
    private var cachedW = -1f
    private var cachedH = -1f
    private var sunShader: Shader? = null

    private fun dpF(value: Float): Float = resources.displayMetrics.density * value

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val sunX = dpF(24f)
        val centerY = h * 0.46f
        val sunR = dpF(15f)
        val startX = dpF(58f)
        val endX = w - dpF(20f)
        val span = (endX - startX).coerceAtLeast(dpF(80f))

        if (w != cachedW || h != cachedH || sunShader == null) {
            cachedW = w
            cachedH = h
            sunShader = RadialGradient(
                sunX - dpF(4f), centerY - dpF(4f), sunR * 1.4f,
                intArrayOf(
                    Color.parseColor("#FFFFFF"),
                    Color.parseColor("#FEF08A"),
                    Color.parseColor("#F59E0B"),
                    Color.parseColor("#EA580C")
                ),
                null,
                Shader.TileMode.CLAMP
            )
            for (i in 0 until count) {
                val px = startX + span * (i + 0.5f) / count
                val week = weeks.getOrNull(i)
                val ratio = ((week?.sharePercent ?: 0.0) / 45.0).toFloat().coerceIn(0f, 1f)
                val radius = dpF(5.5f + ratio * 6.5f)
                planetRadii[i] = radius
                val paletteIdx = i % planetLightColors.size
                planetShaders[i] = RadialGradient(
                    px - radius * 0.3f, centerY - radius * 0.3f, radius * 1.3f,
                    intArrayOf(planetLightColors[paletteIdx], planetDarkColors[paletteIdx]),
                    null,
                    Shader.TileMode.CLAMP
                )
            }
        }

        // Quantized concentric orbit arcs radiating from the Sun
        dashPaint.strokeWidth = dpF(1.1f)
        for (i in 0 until count) {
            val px = startX + span * (i + 0.5f) / count
            val orbitRadius = (px - sunX)
            dashPaint.color = Color.argb(if (darkMode) 65 else 85, 14, 165, 233)
            ovalRect.set(sunX - orbitRadius, centerY - orbitRadius * 0.55f, sunX + orbitRadius, centerY + orbitRadius * 0.55f)
            canvas.drawArc(ovalRect, -40f, 80f, false, dashPaint)

            val radius = planetRadii[i]
            fillPaint.shader = planetShaders[i]
            canvas.drawCircle(px, centerY, radius, fillPaint)
            if (i % planetLightColors.size == 5) {
                fillPaint.shader = null
                canvas.save()
                canvas.rotate(-22f, px, centerY)
                strokePaint.strokeWidth = dpF(1.5f)
                strokePaint.color = planetRingColor
                ovalRect.set(px - radius * 1.65f, centerY - radius * 0.45f, px + radius * 1.65f, centerY + radius * 0.45f)
                canvas.drawOval(ovalRect, strokePaint)
                canvas.restore()
            }
            fillPaint.shader = null
            textPaint.textSize = dpF(9.5f)
            textPaint.color = labelColor
            val week = weeks.getOrNull(i)
            val lbl = week?.let { "${it.number}주" } ?: "P${i + 1}"
            canvas.drawText(lbl, px, h - dpF(6f), textPaint)
        }

        // Solar core on the left focus
        fillPaint.shader = null
        fillPaint.color = Color.argb(if (darkMode) 70 else 90, 245, 158, 11)
        canvas.drawCircle(sunX, centerY, sunR * 1.45f, fillPaint)
        fillPaint.shader = sunShader
        canvas.drawCircle(sunX, centerY, sunR, fillPaint)
    }
}
