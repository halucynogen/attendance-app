package io.local.attendance

/** Status-to-label mapping shared by the expanded and collapsed accessibility toolbar.
 * Pure Kotlin so success/error states can be regression-tested without Android UI.
 */
internal enum class CollectionDisplayPhase { IDLE, RUNNING, COMPLETE, WARNING }

internal data class CollectionDisplay(
    val phase: CollectionDisplayPhase,
    val badge: String,
    val compactText: String
)

internal object FloatingCollectionStatus {
    fun from(message: String, running: Boolean): CollectionDisplay {
        val status = message.trim().ifEmpty { "대기 중 · 목록 수집을 눌러 주세요" }
        return when {
            status.startsWith("수집 완료") -> {
                val summary = status.removePrefix("수집 완료")
                    .trim().trimStart('·', ' ').trim()
                    .substringBefore(" · 통계").trim()
                CollectionDisplay(CollectionDisplayPhase.COMPLETE, "✓ 수집 완료",
                    if (summary.isEmpty()) "✓ 수집 완료" else "✓ 수집 완료 · $summary")
            }
            running -> CollectionDisplay(CollectionDisplayPhase.RUNNING, "● 수집 중", "● ${status.take(70)}")
            status.contains("실패") || status.contains("중지") || status.contains("확인 필요") ||
                status.contains("오류") || status.contains("불가능") || status.contains("미확인") ->
                CollectionDisplay(CollectionDisplayPhase.WARNING, "! 확인 필요", "! ${status.take(70)}")
            else -> CollectionDisplay(CollectionDisplayPhase.IDLE, "○ 대기", "○ ${status.take(70)}")
        }
    }
}
