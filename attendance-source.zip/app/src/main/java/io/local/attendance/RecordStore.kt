package io.local.attendance

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import android.util.Log
import java.time.YearMonth

/** Stores only parsed shifts and user consent; never raw screen text or images. */
object RecordStore {
    private const val PREFS = "attendance_local_only"
    private const val KEY = "records"
    private const val CONSENT = "accessibility_consent"
    private const val DISCLOSURE_VERSION = "accessibility_disclosure_version"
    private const val SELECTED_MONTH = "selected_month"
    private const val LAST_COLLECTION_MONTH = "last_collection_month"
    private const val LAST_COLLECTION_TOTAL = "last_collection_total"
    private const val LAST_COLLECTION_NEW = "last_collection_new"
    private const val LAST_COLLECTION_MESSAGE = "last_collection_message"
    data class CollectionInfo(val month: String, val recordCount: Int, val newCount: Int, val message: String)
    fun setLastCollection(c: Context, month: YearMonth?, total: Int, added: Int, message: String) {
        if (month == null) return
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(LAST_COLLECTION_MONTH, month.toString())
            .putInt(LAST_COLLECTION_TOTAL, total.coerceAtLeast(0))
            .putInt(LAST_COLLECTION_NEW, added.coerceAtLeast(0))
            .putString(LAST_COLLECTION_MESSAGE, message.take(180)).apply()
    }
    fun lastCollection(c: Context): CollectionInfo? {
        val prefs = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val month = prefs.getString(LAST_COLLECTION_MONTH, null) ?: return null
        return CollectionInfo(month, prefs.getInt(LAST_COLLECTION_TOTAL, 0),
            prefs.getInt(LAST_COLLECTION_NEW, 0), prefs.getString(LAST_COLLECTION_MESSAGE, "").orEmpty())
    }

    fun selectedMonth(c: Context): YearMonth =
        runCatching {
            YearMonth.parse(c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(SELECTED_MONTH, null) ?: YearMonth.now().toString())
        }.getOrDefault(YearMonth.now()).let { ym ->
            if (MonthlyWeekStats.supported(ym)) ym else YearMonth.now()
        }
    fun setSelectedMonth(c: Context, value: YearMonth) {
        require(MonthlyWeekStats.supported(value)) { "Calendar year out of range: $value" }
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(SELECTED_MONTH, value.toString()).apply()
    }
    /** An earlier checkbox is not consent to this version's expanded, explicit disclosure. */
    fun refreshDisclosureConsent(c: Context) {
        val prefs = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.getInt(DISCLOSURE_VERSION, 0) < 2) {
            prefs.edit().putBoolean(CONSENT, false).putInt(DISCLOSURE_VERSION, 2).commit()
        }
    }
    fun consent(c: Context): Boolean = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(CONSENT, false)
    fun setConsent(c: Context, value: Boolean) {
        // Commit before Android may connect the accessibility service in another process.
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(CONSENT, value).commit()
    }
    /** Never overwrite a damaged JSON store with an accidental empty list. */
    private fun storedRecordsJson(c: Context): String? {
        val raw = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        return runCatching { JSONArray(raw); raw }.onFailure {
            Log.e("AttendanceStore", "Records JSON damaged; retaining existing bytes", it)
        }.getOrNull()
    }

    private fun parseRecords(json: String): List<WorkRecord> {
        val array = JSONArray(json)
        return (0 until array.length()).mapNotNull { index ->
            val v = array.optJSONObject(index) ?: return@mapNotNull null
            WorkRecord(v.optString("date"), v.optString("start"), v.optString("end"),
                if (v.has("reportedMinutes") && !v.isNull("reportedMinutes")) v.optInt("reportedMinutes") else null,
                v.optString("status"),
                if (v.isNull("breakStart")) null else v.optString("breakStart").takeIf { it.isNotBlank() },
                if (v.isNull("breakEnd")) null else v.optString("breakEnd").takeIf { it.isNotBlank() }).takeIf { it.valid }
        }
    }

    fun read(c: Context): List<WorkRecord> = storedRecordsJson(c)?.let { json ->
        runCatching { parseRecords(json) }.onFailure {
            Log.e("AttendanceStore", "Records could not be read", it)
        }.getOrNull()
    } ?: emptyList()

    @Synchronized fun add(c: Context, entries: List<WorkRecord>): Boolean {
        val before = storedRecordsJson(c) ?: return false
        val previous = parseRecords(before)
        if (previous.size != JSONArray(before).length()) {
            Log.e("AttendanceStore", "Unreadable legacy record detected: refusing to overwrite data")
            return false
        }
        return save(c, AttendanceParser.unique(previous + entries.filter { it.valid }))
    }

    @Synchronized fun replaceMonth(c: Context, month: YearMonth, entries: List<WorkRecord>): Boolean {
        val before = storedRecordsJson(c) ?: return false
        val previous = parseRecords(before)
        if (previous.size != JSONArray(before).length()) {
            Log.e("AttendanceStore", "Unreadable legacy record detected: refusing to replace month")
            return false
        }
        if (entries.any { !it.valid || !it.date.startsWith(month.toString()) }) return false
        return save(c, AttendanceParser.unique(previous.filterNot { it.date.startsWith(month.toString()) } + entries))
    }

    private fun save(c: Context, entries: List<WorkRecord>): Boolean {
        return runCatching {
            val array = JSONArray()
            for (e in entries) {
                array.put(JSONObject().put("date", e.date).put("start", e.start).put("end", e.end)
                    .put("reportedMinutes", e.reportedMinutes ?: JSONObject.NULL).put("status", e.status)
                    .put("breakStart", e.breakStart ?: JSONObject.NULL).put("breakEnd", e.breakEnd ?: JSONObject.NULL))
            }
            c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, array.toString()).commit()
        }.onFailure { Log.e("AttendanceStore", "Could not save attendance records", it) }
            .getOrDefault(false).also { if (!it) Log.e("AttendanceStore", "Record save was not committed") }
    }
    fun clear(c: Context) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }
}
