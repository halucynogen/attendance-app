package io.local.attendance

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.YearMonth

/** Stores only parsed shifts and user consent; never raw screen text or images. */
object RecordStore {
    private const val PREFS = "attendance_local_only"
    private const val KEY = "records"
    private const val CONSENT = "accessibility_consent"
    fun consent(c: Context): Boolean = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(CONSENT, false)
    fun setConsent(c: Context, value: Boolean) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(CONSENT, value).apply()
    }
    fun read(c: Context): List<WorkRecord> = runCatching {
        val json = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val array = JSONArray(json)
        (0 until array.length()).mapNotNull { index ->
            val v = array.optJSONObject(index) ?: return@mapNotNull null
            WorkRecord(v.optString("date"), v.optString("start"), v.optString("end"),
                if (v.has("reportedMinutes") && !v.isNull("reportedMinutes")) v.optInt("reportedMinutes") else null,
                v.optString("status")).takeIf { it.valid }
        }
    }.getOrDefault(emptyList())

    @Synchronized fun add(c: Context, entries: List<WorkRecord>) {
        save(c, AttendanceParser.unique(read(c) + entries))
    }
    @Synchronized fun replaceMonth(c: Context, month: YearMonth, entries: List<WorkRecord>) {
        save(c, AttendanceParser.unique(read(c).filterNot { it.date.startsWith(month.toString()) } + entries))
    }
    private fun save(c: Context, entries: List<WorkRecord>) {
        val array = JSONArray()
        for (e in entries) {
            array.put(JSONObject().put("date", e.date).put("start", e.start).put("end", e.end)
                .put("reportedMinutes", e.reportedMinutes ?: JSONObject.NULL).put("status", e.status))
        }
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, array.toString()).commit()
    }
    fun clear(c: Context) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }
}
