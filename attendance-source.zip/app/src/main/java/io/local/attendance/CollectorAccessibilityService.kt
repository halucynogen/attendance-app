package io.local.attendance

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.animation.ValueAnimator
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.view.View
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.time.YearMonth
import kotlin.math.max

/**
 * User-initiated, read-only monthly LIST collector.
 * Never taps attendance modification, approval, submit, login or individual dates.
 * Accessibility text only: never uses screenshot capture or OCR.
 */
class CollectorAccessibilityService : AccessibilityService() {
    companion object {
        // Google Play listing for the official Korean Scholarship Foundation attendance app.
        // Restrict all automatic inspection to this package, never to unrelated apps.
        private const val OFFICIAL_ATTENDANCE_PACKAGE = "com.kosaf.gpsAttendance"
        // Permission stays enabled until the user explicitly chooses to switch it off.
        // Collection lifecycle is entirely separate from Android's service permission.
        private var connected: CollectorAccessibilityService? = null
        fun isReady(): Boolean = connected != null
        fun disableFromApp(): Boolean {
            val service = connected ?: return false
            service.disableByUser()
            return true
        }
    }
    private val handler = Handler(Looper.getMainLooper())
    private var overlay: LinearLayout? = null
    private var info: TextView? = null
    private var wm: WindowManager? = null
    private var overlayLayout: WindowManager.LayoutParams? = null
    private var overlayDetails: LinearLayout? = null
    private var overlayExpanded = true
    private var overlayToggle: Button? = null
    private var overlayHandle: TextView? = null
    private var overlayActionButtons: List<Button> = emptyList()
    private var active = false
    private var runId = 0
    private var targetPackage = ""
    private var month: YearMonth? = null
    private var pages = 0
    private var collected = 0
    private var repeated = 0
    private var previousSignature = ""
    private var previousPageText = ""
    private var startCheckInProgress = false
    private var startCheckToken = 0
    private var zeroRecordPages = 0
    private var diagnostic = ""
    private var startPending = false
    private var startAttempts = 0
    private var startRequestToken = 0
    private var startAttemptQueued = false
    private var transientRootRetries = 0
    private var overlayAttachQueued = false
    private var overlayAttachAttempts = 0
    private var lastOverlayRetryAt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        // Android's accessibility switch is not a substitute for the app's own
        // prominent disclosure and consent. Refuse the service when it was
        // enabled directly from Settings without that explicit consent.
        connected = this
        if (!RecordStore.consent(this)) {
            // Leave the OS-owned accessibility switch alone. No collection or
            // floating control is allowed until the user's in-app consent.
            Toast.makeText(this, "근무로그 앱에서 접근성 수집 안내에 동의한 뒤 이용하세요", Toast.LENGTH_LONG).show()
            return
        }
        // Do not display a floating control on login, bank or unrelated application screens.
        if (appRoot() != null) {
            attachControls()
            ensureOverlay()
        }
    }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val sourceApp = event?.packageName?.toString()
        if (!RecordStore.consent(this)) {
            // Security: never read or inspect any third-party window without consent.
            if (active || startPending || startCheckInProgress) cancelCollection("접근성 수집 동의가 필요합니다")
            overlay?.visibility = View.GONE
            return
        }
        if (sourceApp == packageName) {
            // An overlay itself emits our package name. Hide the controls only
            // when an actual MainActivity window opens, not on overlay taps.
            val ownActivityVisible = event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
                event.className?.toString() == MainActivity::class.java.name
            if (ownActivityVisible) {
                overlay?.visibility = View.GONE
                if (active) cancelCollection("근무로그 앱으로 이동하여 수집 일시 중지")
            }
            return
        }
        if (sourceApp != OFFICIAL_ATTENDANCE_PACKAGE) {
            overlay?.visibility = View.GONE
            // Leaving the official app stops ONLY the current read, not accessibility.
            // Android/system popups must not revoke an already granted permission.
            if (active && sourceApp != null && appRoot() == null) {
                cancelCollection("다른 앱으로 이동하여 수집 중지")
            }
            return  // Never inspect screens from unrelated packages.
        }
        if (overlay == null) {
            if (android.os.SystemClock.elapsedRealtime() - lastOverlayRetryAt > 10000L) {
                overlayAttachAttempts = 0
                lastOverlayRetryAt = android.os.SystemClock.elapsedRealtime()
            }
            ensureOverlay()
        } else overlay?.visibility = View.VISIBLE
        // Only resume an explicit user request. Enabling accessibility does NOT start capture.
        if (startPending && !active && !startCheckInProgress) {
            scheduleStartCheck(startRequestToken, 120L)
        }
    }
    override fun onInterrupt() {
        // Interrupts may be temporary (screen lock, system permission dialog).
        // They must never call disableSelf().
        cancelCollection("화면 접근이 일시 중단되어 수집을 멈췄습니다")
        overlay?.visibility = View.GONE
    }
    override fun onDestroy() {
        active = false; runId++; startCheckToken++; startRequestToken++
        startPending = false
        detachControls()
        if (connected === this) connected = null
        super.onDestroy()
    }

    private fun detachControls() {
        overlay?.animate()?.cancel()
        overlay?.let { runCatching { wm?.removeView(it) } }
        overlay = null
        info = null
        overlayDetails = null
        overlayToggle = null
        overlayHandle = null
        overlayActionButtons = emptyList()
        overlayLayout = null
    }

    private fun cancelCollection(reason: String) {
        val wasCollecting = active || startPending || startCheckInProgress
        val selected = month
        val total = selected?.let { ym ->
            RecordStore.read(this).count { it.date.startsWith(ym.toString()) }
        } ?: 0
        active = false; runId++
        startCheckToken++; startCheckInProgress = false
        startPending = false; startRequestToken++
        startAttemptQueued = false
        handler.removeCallbacksAndMessages(null)
        if (wasCollecting && selected != null) {
            RecordStore.setLastCollection(this, selected, total, collected, reason)
        }
        status(reason)
        if (wasCollecting) toast("수집 중지 · ${total}건 저장됨. $reason")
    }

    private fun disableByUser() {
        cancelCollection("사용자가 접근성 서비스 끄기를 선택함")
        detachControls()
        if (connected === this) connected = null
        // Only the explicit settings action may switch the system service off.
        disableSelf()
    }

    private fun ensureOverlay() {
        if (overlay != null || overlayAttachQueued || overlayAttachAttempts >= 5) return
        overlayAttachQueued = true
        handler.postDelayed({
            overlayAttachQueued = false
            if (overlay == null && connected === this) {
                overlayAttachAttempts++
                attachControls()
                ensureOverlay()
            }
        }, 450L)
    }

    /** Compact mode keeps ALL three controls usable, instead of hiding them. */
    private fun attachControls() {
        if (overlay != null || appRoot() == null) return
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val prefs = getSharedPreferences("floating_menu_position", MODE_PRIVATE)
        // Prefer the compact floating toolbar on first use. Previous preference is respected.
        overlayExpanded = !prefs.getBoolean("collapsed", true)

        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(7), dp(5), dp(7), dp(7))
            background = panelBackground(Color.parseColor("#FAF8FF"), Color.parseColor("#C9D8F6"), radiusDp = 16)
            elevation = dp(4).toFloat()
            contentDescription = "근무로그 목록 수집 메뉴. 손잡이로 이동할 수 있습니다"
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val dragHandle = TextView(this).apply {
            text = "↕ 이동"
            textSize = 11.5f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#6043BE"))
            setPadding(dp(7), 0, dp(3), 0)
            gravity = Gravity.CENTER_VERTICAL
            contentDescription = "떠 있는 메뉴 이동 손잡이. 손가락으로 드래그하세요"
        }
        overlayHandle = dragHandle
        header.addView(dragHandle, LinearLayout.LayoutParams(0, dp(32), 1f))
        val toggleButton = Button(this).apply {
            isAllCaps = false
            textSize = 11f
            minWidth = 0
            minHeight = 0
            setPadding(0, 0, 0, 0)
            background = panelBackground(Color.parseColor("#EAE7FF"), Color.TRANSPARENT, radiusDp = 10)
            setTextColor(Color.parseColor("#533F9E"))
            setOnClickListener { toggleFloatingMenu() }
        }
        overlayToggle = toggleButton
        header.addView(toggleButton, LinearLayout.LayoutParams(dp(60), dp(31)))
        wrap.addView(header)

        val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val status = TextView(this).apply {
            text = "공식 출근부 조회 목록에서만 수집 · ↕ 손잡이로 이동"
            textSize = 11f
            maxLines = 2
            setTextColor(Color.parseColor("#344054"))
            setPadding(dp(7), dp(2), dp(7), dp(5))
        }
        info = status
        details.addView(status)
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val collect = overlayButton("목록 수집", Color.parseColor("#4F58E9"), Color.WHITE) { begin() }
        val changeDate = overlayButton("날짜 수정", Color.parseColor("#FFE16B"), Color.parseColor("#694B00")) {
            openDateEditor()
        }
        val stopButton = overlayButton("수집 중지", Color.parseColor("#FFF0F4"), Color.parseColor("#B52A57")) {
            cancelCollection("사용자가 수집 중지")
        }
        buttons.addView(collect)
        buttons.addView(changeDate.apply { (layoutParams as LinearLayout.LayoutParams).marginStart = dp(5) })
        buttons.addView(stopButton.apply { (layoutParams as LinearLayout.LayoutParams).marginStart = dp(5) })
        overlayActionButtons = listOf(collect, changeDate, stopButton)
        details.addView(buttons)
        wrap.addView(details)
        overlayDetails = details
        // Never set details GONE: compact mode must retain the yellow date button.
        applyFloatingMenuSize(wrap)

        val width = resources.displayMetrics.widthPixels
        val height = resources.displayMetrics.heightPixels
        val savedX = prefs.getInt("x", (width - floatingMenuWidth()) / 2)
        val savedY = prefs.getInt("y", (height * 0.64f).toInt())
        val params = WindowManager.LayoutParams(
            floatingMenuWidth(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = savedX
            y = savedY
        }
        clampOverlayPosition(params, estimatedFloatingMenuHeight())
        overlayLayout = params
        dragHandle.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0f
            private var startY = 0f
            private var initialX = 0
            private var initialY = 0
            private val slop = ViewConfiguration.get(this@CollectorAccessibilityService).scaledTouchSlop
            private var dragging = false
            override fun onTouch(view: View, event: MotionEvent): Boolean {
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = event.rawX; startY = event.rawY
                        initialX = params.x; initialY = params.y
                        dragging = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX - startX
                        val dy = event.rawY - startY
                        if (kotlin.math.abs(dx) > slop || kotlin.math.abs(dy) > slop) dragging = true
                        if (dragging) {
                            params.x = initialX + dx.toInt()
                            params.y = initialY + dy.toInt()
                            clampOverlayPosition(params, wrap.height.coerceAtLeast(estimatedFloatingMenuHeight()))
                            runCatching { wm?.updateViewLayout(wrap, params) }
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        if (dragging) {
                            prefs.edit().putInt("x", params.x).putInt("y", params.y).apply()
                        } else if (event.actionMasked == MotionEvent.ACTION_UP) {
                            view.performClick()
                        }
                        return true
                    }
                }
                return false
            }
        })
        dragHandle.setOnClickListener { toggleFloatingMenu() }
        try {
            wm?.addView(wrap, params)
            overlay = wrap
            if (ValueAnimator.areAnimatorsEnabled()) {
                wrap.alpha = 0.8f
                wrap.animate().alpha(1f).setDuration(150L).start()
            }
        } catch (error: Exception) {
            overlayLayout = null
            overlayDetails = null
            overlayToggle = null
            overlayHandle = null
            overlayActionButtons = emptyList()
            toast("메뉴 표시 실패: ${error.localizedMessage}")
        }
    }

    private fun floatingMenuWidth(): Int {
        val available = (resources.displayMetrics.widthPixels - dp(16)).coerceAtLeast(dp(1))
        return minOf(available, dp(if (overlayExpanded) 358 else 296))
    }

    private fun estimatedFloatingMenuHeight(): Int = dp(if (overlayExpanded) 126 else 87)

    private fun updateToggleLabel() {
        overlayToggle?.text = if (overlayExpanded) "작게 −" else "크게 +"
        overlayToggle?.contentDescription = if (overlayExpanded) "떠 있는 메뉴 작게 줄이기" else "떠 있는 메뉴 크게 펼치기"
    }

    private fun applyFloatingMenuSize(wrap: LinearLayout) {
        val expanded = overlayExpanded
        wrap.setPadding(dp(if (expanded) 9 else 7), dp(if (expanded) 7 else 5),
            dp(if (expanded) 9 else 7), dp(if (expanded) 9 else 6))
        overlayHandle?.let { handle ->
            handle.text = if (expanded) "↕  근무로그 · 이동" else "↕ 이동"
            handle.textSize = if (expanded) 12.5f else 11.5f
            handle.layoutParams = (handle.layoutParams as LinearLayout.LayoutParams).apply {
                height = dp(if (expanded) 38 else 32)
            }
        }
        overlayToggle?.let { button ->
            button.textSize = if (expanded) 11.5f else 11f
            button.layoutParams = (button.layoutParams as LinearLayout.LayoutParams).apply {
                width = dp(if (expanded) 66 else 60)
                height = dp(if (expanded) 36 else 31)
            }
        }
        info?.visibility = if (expanded) View.VISIBLE else View.GONE
        overlayDetails?.visibility = View.VISIBLE
        overlayActionButtons.forEach { button ->
            button.textSize = if (expanded) 12f else 11f
            button.setPadding(dp(1), 0, dp(1), 0)
            button.layoutParams = (button.layoutParams as LinearLayout.LayoutParams).apply {
                height = dp(if (expanded) 46 else 43)
            }
        }
        updateToggleLabel()
    }

    private fun toggleFloatingMenu() {
        val params = overlayLayout ?: return
        val wrap = overlay ?: return
        overlayExpanded = !overlayExpanded
        // Both sizes keep collect / date / stop buttons enabled and visible.
        wrap.animate().cancel()
        applyFloatingMenuSize(wrap)
        params.width = floatingMenuWidth()
        clampOverlayPosition(params, estimatedFloatingMenuHeight())
        runCatching { wm?.updateViewLayout(wrap, params) }
        getSharedPreferences("floating_menu_position", MODE_PRIVATE).edit()
            .putBoolean("collapsed", !overlayExpanded)
            .putInt("x", params.x).putInt("y", params.y).apply()
        if (ValueAnimator.areAnimatorsEnabled()) {
            wrap.alpha = 0.92f
            wrap.animate().alpha(1f).setDuration(130L).start()
        }
    }

    /** Keep the floating controls inside the usable screen on Samsung 3-button navigation. */
    private fun clampOverlayPosition(params: WindowManager.LayoutParams, guessedHeight: Int) {
        val metrics = resources.displayMetrics
        val w = metrics.widthPixels
        val h = metrics.heightPixels
        params.x = params.x.coerceIn(0, (w - params.width).coerceAtLeast(0))
        val minY = dp(32)
        val maxY = (h - guessedHeight - dp(72)).coerceAtLeast(minY)
        params.y = params.y.coerceIn(minY, maxY)
    }

    private fun overlayButton(label: String, fill: Int, textColor: Int, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(textColor)
            background = if (label == "날짜 수정") {
                GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    intArrayOf(Color.parseColor("#FFF3A6"), Color.parseColor("#FFD44C"))).apply {
                    cornerRadius = dp(14).toFloat()
                }
            } else panelBackground(fill, Color.TRANSPARENT, radiusDp = 14)
            textSize = 11f
            setSingleLine(true)
            minWidth = 0
            minHeight = 0
            setPadding(dp(1), 0, dp(1), 0)
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(0, dp(43), 1f)
        }
    }

    private fun panelBackground(fill: Int, stroke: Int, radiusDp: Int = 18) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(radiusDp).toFloat()
        setColor(fill)
        if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }

    /** Open only our own Activity after the user explicitly presses the yellow button. */
    private fun openDateEditor() {
        if (active || startPending || startCheckInProgress) {
            status("수집을 먼저 완료하거나 중지한 뒤 날짜를 수정해 주세요")
            toast("수집 중에는 날짜를 바꿀 수 없습니다. 먼저 중지해 주세요")
            return
        }
        overlay?.visibility = View.GONE
        try {
            startActivity(Intent(this, MainActivity::class.java).apply {
                action = MainActivity.ACTION_EDIT_PERIOD
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            })
        } catch (e: RuntimeException) {
            // OEM background-start policy can differ; never weaken system protection.
            overlay?.visibility = View.VISIBLE
            status("화면 이동에 실패했습니다. 근무로그 앱을 직접 열어 주세요")
            toast("날짜 화면을 열 수 없습니다: ${e.localizedMessage}")
        }
    }

    private fun begin() {
        if (active) return status("이미 목록 수집 중입니다")
        if (startPending || startCheckInProgress) return status("목록 화면 준비 확인 중 · 잠시 후 다시 확인합니다")
        if (!RecordStore.consent(this)) return toast("먼저 근무로그 앱에서 접근성 사용 안내에 동의하세요.")
        if (appRoot()?.packageName?.toString() != OFFICIAL_ATTENDANCE_PACKAGE) {
            return status("한국장학재단 출근부 앱에서만 수집할 수 있습니다")
        }
        startPending = true
        startAttempts = 0
        val token = ++startRequestToken
        status("목록 화면 준비 확인 중 · 자동 재확인")
        scheduleStartCheck(token, 60L)
    }

    private fun scheduleStartCheck(token: Int, delayMs: Long) {
        if (!startPending || token != startRequestToken || startAttemptQueued) return
        startAttemptQueued = true
        handler.postDelayed({
            startAttemptQueued = false
            if (startPending && !active && token == startRequestToken && !startCheckInProgress) {
                attemptStart(token)
            }
        }, delayMs)
    }

    private fun startFailed(message: String) {
        startPending = false
        startCheckInProgress = false
        val visibleMonth = RecordStore.selectedMonth(this)
        val storedCount = RecordStore.read(this).count { it.date.startsWith(visibleMonth.toString()) }
        RecordStore.setLastCollection(this, visibleMonth, storedCount, 0, message)
        status(message)
        toast(message)
    }

    private fun attemptStart(token: Int) {
        if (!startPending || active || token != startRequestToken) return
        startAttempts++
        val root = appRoot()
        val candidatePackage = root?.packageName?.toString().orEmpty()
        if (candidatePackage != OFFICIAL_ATTENDANCE_PACKAGE) {
            if (startAttempts < 10) {
                status("공식 앱 화면 확인 대기 · ${startAttempts}/10")
                scheduleStartCheck(token, 550L)
            } else {
                startFailed("목록 화면 미확인 · 장학재단 조회 목록에서 수집 버튼을 다시 누르세요")
            }
            return
        }
        val text = root?.let { mergedAccessibilityText(it) }.orEmpty()
        val selected = RecordStore.selectedMonth(this)
        val visibleMonth = AttendanceParser.monthHeader(text)
        // When the official list clearly contains records for a different month,
        // match the dashboard to that verified list. Never guess without records.
        val effectiveMonth = if (visibleMonth != null && visibleMonth != selected &&
            AttendanceParser.fromListPage(text, visibleMonth).isNotEmpty()) visibleMonth else selected
        if (visibleMonth != null && visibleMonth != selected && effectiveMonth != visibleMonth) {
            startFailed("월 불일치: 앱 $selected / 화면 $visibleMonth · 날짜 설정을 확인하세요")
            return
        }
        val rows = AttendanceParser.fromListPage(text, effectiveMonth)
        if (rows.isNotEmpty()) {
            startPending = false
            if (selected != effectiveMonth) {
                RecordStore.setSelectedMonth(this, effectiveMonth)
                toast("공식 출근부 조회 목록에 맞춰 ${effectiveMonth.monthValue}월을 표시합니다")
            }
            startCollection(candidatePackage, effectiveMonth)
            return
        }
        // WebView often populates its accessibility nodes after the list is visible.
        if (startAttempts < 6) {
            status("목록 내용 로딩 확인 중 · ${startAttempts}/6")
            scheduleStartCheck(token, 500L)
            return
        }
        startFailed("접근성에서 근무 텍스트를 읽지 못했습니다. 원본 목록이 표시되는지 확인하세요")
    }

    private fun startCollection(appPackage: String, ym: YearMonth) {
        if (active) return
        if (appPackage != OFFICIAL_ATTENDANCE_PACKAGE) {
            startPending = false
            return status("수집 대상 앱을 확인할 수 없습니다")
        }
        active = true
        startPending = false
        startRequestToken++
        transientRootRetries = 0
        runId++
        targetPackage = appPackage
        month = ym
        pages = 0; collected = 0; repeated = 0; zeroRecordPages = 0
        previousSignature = ""; previousPageText = ""
        status("${ym.year}.${ym.monthValue} 목록 수집 중")
        val id = runId
        handler.postDelayed({ processPage(id) }, 300)
    }

    private fun processPage(id: Int) {
        if (!active || id != runId) return
        if (pages >= 80) return stop("최대 80페이지 도달. 지금까지 기록을 확인하세요.")
        val visiblePackage = appRoot()?.packageName?.toString()
        if (visiblePackage != null && visiblePackage != targetPackage) {
            return stop("다른 앱으로 이동하여 수집을 중단했습니다")
        }
        val root = verifiedRoot()
        if (root == null) {
            transientRootRetries++
            if (transientRootRetries <= 4) {
                status("목록 화면 갱신 중 · 다시 확인 ${transientRootRetries}/4")
                handler.postDelayed({ processPage(id) }, 450L)
                return
            }
            return stop("화면 접근이 불가능하여 수집을 중단했습니다")
        }
        transientRootRetries = 0
        val ym = month ?: return stop("월 정보를 찾을 수 없습니다.")
        val text = mergedAccessibilityText(root)
        val visibleMonth = AttendanceParser.monthHeader(text)
        if (visibleMonth != null && visibleMonth != ym) return stop("조회 월이 바뀌었습니다. 중지합니다.")
        val entries = AttendanceParser.fromOverlappingPages(previousPageText, text, ym)
        if (entries.isNotEmpty() && (AttendanceParser.fromListPage(text, ym).isNotEmpty() || text.contains(":"))) {
            processParsed(id, entries, text)
        } else {
            return finish("화면에 읽을 수 있는 기록이 없습니다. 날짜·목록을 확인하세요.")
        }
    }

    private fun processParsed(id: Int, records: List<WorkRecord>, signatureText: String) {
        if (!active || id != runId) return
        val root = verifiedRoot() ?: return stop("대상 앱이 바뀌었습니다.")
        val ym = month ?: return stop("월 정보 오류")
        pages++
        val before = RecordStore.read(this).count { it.date.startsWith(ym.toString()) }
        if (!RecordStore.add(this, AttendanceParser.fromOverlappingPages(previousPageText, signatureText, ym) + records)) {
            return stop("저장 공간 오류 · 기존 기록 보호를 위해 수집 중지")
        }
        previousPageText = signatureText.takeLast(2800)
        val after = RecordStore.read(this).count { it.date.startsWith(ym.toString()) }
        collected += after - before
        zeroRecordPages = if (records.isEmpty()) zeroRecordPages + 1 else 0
        if (zeroRecordPages >= 2 && after == 0) {
            return finish("두 화면에서 근무기록을 하나도 읽지 못했습니다. 조회 월/원본 화면을 확인하세요.")
        }
        val signature = signatureText.replace(Regex("\\s+"), " ").trim().takeLast(850)
        repeated = if (signature == previousSignature) repeated + 1 else 0
        previousSignature = signature
        status("${ym.monthValue}월: ${pages}화면 / 전체 ${after}건 (신규 ${collected}건)")
        if (repeated >= 2) return finish("화면이 더 이상 변하지 않아 종료했습니다.")
        scroll(root) { didScroll ->
            if (!active || id != runId) return@scroll
            if (!didScroll) finish("더 내려갈 수 없는 화면입니다.")
            else handler.postDelayed({ processPage(id) }, 1400)
        }
    }

    private fun scroll(root: AccessibilityNodeInfo, next: (Boolean) -> Unit) {
        val scrollers = mutableListOf<AccessibilityNodeInfo>()
        walk(root) { node ->
            if (node.isScrollable && node.isVisibleToUser) {
                val r = Rect().also { node.getBoundsInScreen(it) }
                if (r.width() > dp(200) && r.height() > dp(180)) scrollers += node
            }
        }
        val candidates = scrollers.sortedBy { node ->
            Rect().also { node.getBoundsInScreen(it) }.let { it.width().toLong() * it.height() }
        }
        for (n in candidates) {
            if (n.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) return next(true)
        }
        // Some WebViews are scrollable only via a swipe. This gesture only moves the list.
        val size = resources.displayMetrics
        val w = size.widthPixels.toFloat(); val h = size.heightPixels.toFloat()
        val path = Path().apply { moveTo(w * .50f, h * .84f); lineTo(w * .50f, h * .28f) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 460)).build()
        val ok = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { next(true) }
            override fun onCancelled(gestureDescription: GestureDescription?) { next(false) }
        }, handler)
        if (!ok) next(false)
    }

    /** Checks both user consent and the exact foreground package immediately before reading the accessibility tree. */
    private fun authorizedTargetVisible(): Boolean =
        RecordStore.consent(this) &&
            appRoot()?.packageName?.toString() == OFFICIAL_ATTENDANCE_PACKAGE

    private fun appRoot(): AccessibilityNodeInfo? {
        // Strict foreground whitelist. Avoid reading any other app's accessibility tree.
        val active = rootInActiveWindow
        if (active != null) return active.takeIf {
            it.packageName?.toString() == OFFICIAL_ATTENDANCE_PACKAGE
        }
        return windows.asSequence()
            .filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION && (it.isActive || it.isFocused) }
            .mapNotNull { it.root }
            .firstOrNull { it.packageName?.toString() == OFFICIAL_ATTENDANCE_PACKAGE }
    }

    private fun verifiedRoot(): AccessibilityNodeInfo? {
        val root = appRoot() ?: return null
        if (root.packageName?.toString() != targetPackage) return null
        val text = mergedAccessibilityText(root)
        // Lists can scroll so that the toolbar's '조회' or a shift row is off screen.
        // The same verified package and matching visible month are sufficient here.
        val visibleMonth = AttendanceParser.monthHeader(text)
        if (visibleMonth != null && visibleMonth != month) return null
        return root
    }

    private fun mergedAccessibilityText(root: AccessibilityNodeInfo): String {
        val all = readText(root)
        val focusedNodes = mutableListOf<AccessibilityNodeInfo>()
        walk(root) { node ->
            val r = Rect().also { node.getBoundsInScreen(it) }
            if (node.isVisibleToUser && r.height() > dp(120) && r.width() > dp(140)) {
                if (node.isScrollable || node.className?.toString()?.contains("Recycler", true) == true || node.className?.toString()?.contains("List", true) == true) {
                    focusedNodes += node
                }
            }
        }
        val listArea = focusedNodes.maxByOrNull { node ->
            Rect().also { node.getBoundsInScreen(it) }.let { it.width().toLong() * it.height() }
        }?.let { readText(it) }.orEmpty()
        return listOf(all, listArea)
            .filter { it.isNotBlank() }
            .distinct()
            .joinToString("\n")
    }

    private fun readText(root: AccessibilityNodeInfo): String {
        data class Line(val y: Int, val x: Int, val value: String)
        val lines = mutableListOf<Line>()
        val seen = hashSetOf<String>()
        walk(root) { n ->
            val value = (n.text ?: n.contentDescription)?.toString()?.trim().orEmpty()
            if (value.isBlank()) return@walk
            val r = Rect().also { n.getBoundsInScreen(it) }
            if (!n.isVisibleToUser || r.width() <= 0 || r.height() <= 0) return@walk
            val key = "${r.left}|${r.top}|${r.right}|${r.bottom}|$value"
            if (seen.add(key)) lines += Line(r.centerY(), r.left, value)
        }
        val sorted = lines.sortedWith(compareBy(Line::y, Line::x))
        val bands = mutableListOf<MutableList<Line>>()
        for (line in sorted) {
            val band = bands.lastOrNull()
            if (band != null && kotlin.math.abs(band.first().y - line.y) <= dp(14)) band.add(line)
            else bands.add(mutableListOf(line))
        }
        return bands.joinToString("\n") { band ->
            band.sortedBy { it.x }.joinToString(" ") { it.value }
        }
    }
    private fun walk(root: AccessibilityNodeInfo, action: (AccessibilityNodeInfo) -> Unit) {
        var count = 0
        fun visit(n: AccessibilityNodeInfo, depth: Int) {
            if (++count > 3200 || depth > 55) return
            action(n)
            for (i in 0 until n.childCount) n.getChild(i)?.let { visit(it, depth + 1) }
        }
        visit(root, 0)
    }
    private fun finish(reason: String) {
        if (!active) return
        val ym = month
        val total = ym?.let { selected -> RecordStore.read(this).count { it.date.startsWith(selected.toString()) } } ?: 0
        RecordStore.setLastCollection(this, ym, total, collected, reason)
        active = false; runId++; startCheckToken++; startRequestToken++
        startPending = false; startCheckInProgress = false
        handler.removeCallbacksAndMessages(null)
        status("수집 완료 · 총 ${total}건 / 신규 ${collected}건 · 통계 탭에서 확인하세요")
        toast("수집 완료: 전체 ${total}건 / 새 ${collected}건 · ${pages}화면. $reason")
    }
    private fun stop(reason: String) {
        if (!active && !startCheckInProgress) return
        cancelCollection(reason)
    }
    private fun status(message: String) {
        info?.text = message
        info?.setTextColor(Color.parseColor(if (active) "#087762" else "#344054"))
    }
    private fun toast(message: String) { Toast.makeText(this, message, Toast.LENGTH_LONG).show() }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
