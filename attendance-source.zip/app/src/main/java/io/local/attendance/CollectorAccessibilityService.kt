package io.local.attendance

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.view.View
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.ViewConfiguration
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.time.YearMonth
import kotlin.math.max

/**
 * User-initiated, read-only monthly LIST collector.
 * Never taps attendance modification, approval, submit, login or individual dates.
 * Accessibility text only: never uses screenshot capture or OCR.
 */
class CollectorAccessibilityService : AccessibilityService() {
    companion object {
        // Google Play listing for the official Korean Scholarship Foundation attendance app.
        // Restrict all automatic inspection to this package, never to unrelated apps.
        private const val OFFICIAL_ATTENDANCE_PACKAGE = "com.kosaf.gpsAttendance"
        // Permission stays enabled until the user explicitly chooses to switch it off.
        // Collection lifecycle is entirely separate from Android's service permission.
        private var connected: CollectorAccessibilityService? = null
        fun isReady(): Boolean = connected != null
        fun onAppClosed() {
            connected?.suspendSession()
        }
        fun disableFromApp(): Boolean {
            val service = connected ?: return false
            service.disableByUser()
            return true
        }
    }
    private val handler = Handler(Looper.getMainLooper())
    private var overlay: LinearLayout? = null
    private var info: TextView? = null
    private var compactStatus: TextView? = null
    private var overlayStateBadge: TextView? = null
    private var latestStatus = "○ 대기 중 · 목록 수집을 눌러 주세요"
    private var wm: WindowManager? = null
    private var overlayLayout: WindowManager.LayoutParams? = null
    private var overlayDetails: LinearLayout? = null
    private var overlayExpanded = false
    // Continuous two-finger pinch size; never controlled by +/- buttons.
    private var overlayZoom = 0.72f
    private var overlayDarkMode = false
    private var overlayHandle: TextView? = null
    private var overlayActionButtons: List<Button> = emptyList()
    // Pinch takes priority over actions. Ignore ghost taps shortly after resizing.
    private var overlayPinchInProgress = false
    private var overlayBlockTapsUntil = 0L
    private var active = false
    private var runId = 0
    private var targetPackage = ""
    private var month: YearMonth? = null
    private var pages = 0
    private var collected = 0
    private var repeated = 0
    private var previousSignature = ""
    private var previousPageText = ""
    private var previousListText = ""
    private var startCheckInProgress = false
    private var startCheckToken = 0
    private var zeroRecordPages = 0
    private var emptyPageRetries = 0
    private var diagnostic = ""
    private var startPending = false
    private var startAttempts = 0
    private var startRequestToken = 0
    private var startAttemptQueued = false
    private var transientRootRetries = 0
    private var overlayAttachQueued = false
    private var overlayAttachAttempts = 0
    private var lastOverlayRetryAt = 0L
    private var wasOfficialInForeground = false
    private var overlaySwipePassthrough = false
    // Android/OEMs may omit window-change events when returning from Settings,
    // recents or a background app. Check only the foreground package periodically;
    // never read its text or start collection in the recovery loop.
    private val overlayRecovery = object : Runnable {
        override fun run() {
            if (connected !== this@CollectorAccessibilityService) return
            try {
                if (!CollectionSession.isOpen(this@CollectorAccessibilityService)) {
                    suspendSession()
                } else if (RecordStore.consent(this@CollectorAccessibilityService) && appRoot() != null) {
                    restoreOverlayForOfficialApp()
                } else {
                    overlay?.visibility = View.GONE
                    wasOfficialInForeground = false
                }
            } catch (error: Exception) {
                android.util.Log.w("AttendanceOverlay", "Foreground overlay check failed", error)
            }
            handler.removeCallbacks(this)
            handler.postDelayed(this, 1000L)
        }
    }

    private fun scheduleOverlayRecovery() {
        handler.removeCallbacks(overlayRecovery)
        handler.postDelayed(overlayRecovery, 700L)
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        // Android's accessibility switch is not a substitute for the app's own
        // prominent disclosure and consent. Refuse the service when it was
        // enabled directly from Settings without that explicit consent.
        connected = this
        scheduleOverlayRecovery()
        if (!CollectionSession.isOpen(this)) return
        if (!RecordStore.consent(this)) {
            // Leave the OS-owned accessibility switch alone. No collection or
            // floating control is allowed until the user's in-app consent.
            Toast.makeText(this, "근무로그 앱에서 접근성 수집 안내에 동의한 뒤 이용하세요", Toast.LENGTH_LONG).show()
            return
        }
        // Do not display a floating control on login, bank or unrelated application screens.
        if (appRoot() != null) {
            wasOfficialInForeground = true
            resetOverlayRetry()
            attachControls()
            ensureOverlay()
        }
    }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!CollectionSession.isOpen(this)) {
            suspendSession()
            return
        }
        val sourceApp = event?.packageName?.toString()
        if (!RecordStore.consent(this)) {
            // Security: never read or inspect any third-party window without consent.
            if (active || startPending || startCheckInProgress) cancelCollection("접근성 수집 동의가 필요합니다")
            overlay?.visibility = View.GONE
            wasOfficialInForeground = false
            return
        }
        if (sourceApp == packageName) {
            // An overlay itself emits our package name. Hide the controls only
            // when an actual MainActivity window opens, not on overlay taps.
            val ownActivityVisible = event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
                event.className?.toString() == MainActivity::class.java.name
            if (ownActivityVisible) {
                overlay?.visibility = View.GONE
                wasOfficialInForeground = false
                if (active || startPending || startCheckInProgress) cancelCollection("근무로그 앱으로 이동하여 수집 일시 중지")
            }
            return
        }
        if (sourceApp != OFFICIAL_ATTENDANCE_PACKAGE) {
            // Transient accessibility events from toasts, notifications or the system
            // are not foreground app changes. In particular, don't hide a SUCCESS
            // banner right after the collection-complete toast is shown.
            val foregroundChanged = event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
                event?.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED
            if (foregroundChanged && appRoot() == null) {
                overlay?.visibility = View.GONE
                wasOfficialInForeground = false
                // Never revoke accessibility permission when leaving the official app.
                if (active) cancelCollection("다른 앱으로 이동하여 수집 중지")
            } else if (foregroundChanged && appRoot() != null) {
                // System overlays and transient toasts can emit non-target events
                // while the official app remains in front. Restore the idle toolbar.
                restoreOverlayForOfficialApp()
            }
            return  // Never inspect screens from unrelated packages.
        }
        restoreOverlayForOfficialApp()
        if (overlay != null && overlayDarkMode != themeDark()) {
            // Settings changed while the accessibility service remained running.
            // Recreate ONLY the overlay; never touch collection state or records.
            overlayLayout?.let { lp ->
                getSharedPreferences("floating_menu_position", MODE_PRIVATE).edit()
                    .putInt("x", lp.x).putInt("y", lp.y).apply()
            }
            detachControls()
        }
        if (overlay == null) {
            if (android.os.SystemClock.elapsedRealtime() - lastOverlayRetryAt > 10000L) {
                overlayAttachAttempts = 0
                lastOverlayRetryAt = android.os.SystemClock.elapsedRealtime()
            }
            ensureOverlay()
        } else overlay?.visibility = View.VISIBLE
        // Only resume an explicit user request. Enabling accessibility does NOT start capture.
        if (startPending && !active && !startCheckInProgress) {
            scheduleStartCheck(startRequestToken, 120L)
        }
    }
    override fun onInterrupt() {
        // Android may interrupt an IDLE service after displaying a toast/dialog.
        // Preserve a previously completed result; only an in-flight run can stop.
        if (active || startPending || startCheckInProgress) {
            cancelCollection("화면 접근이 일시 중단되어 수집을 멈췄습니다")
        }
        overlay?.visibility = View.GONE
    }
    override fun onDestroy() {
        active = false; runId++; startCheckToken++; startRequestToken++
        startPending = false
        detachControls()
        handler.removeCallbacks(overlayRecovery)
        wasOfficialInForeground = false
        if (connected === this) connected = null
        super.onDestroy()
    }

    private fun detachControls() {
        overlay?.animate()?.cancel()
        overlay?.let { runCatching { wm?.removeView(it) } }
        overlay = null
        info = null
        overlayDetails = null
        compactStatus = null
        overlayStateBadge = null
        // Pinch state is owned by the View and resets upon reattachment.
        overlayHandle = null
        overlayActionButtons = emptyList()
        overlayPinchInProgress = false
        overlayBlockTapsUntil = 0L
        overlaySwipePassthrough = false
        overlayAttachQueued = false
        overlayLayout = null
    }

    private fun setOverlayTouchable(touchable: Boolean) {
        val view = overlay ?: return
        val params = overlayLayout ?: return
        val wantPassthrough = !touchable
        if (overlaySwipePassthrough == wantPassthrough) return
        overlaySwipePassthrough = wantPassthrough
        params.flags = if (wantPassthrough) {
            params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        } else {
            params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        }
        runCatching { wm?.updateViewLayout(view, params) }
    }

    private fun suspendSession() {
        if (active || startPending || startCheckInProgress) {
            cancelCollection("근무로그 실행이 종료되어 수집 중지")
        }
        detachControls()
        wasOfficialInForeground = false
    }

    private fun cancelCollection(reason: String) {
        val wasCollecting = active || startPending || startCheckInProgress
        val selected = month
        val total = selected?.let { ym ->
            RecordStore.read(this).count { it.date.startsWith(ym.toString()) }
        } ?: 0
        active = false; runId++
        startCheckToken++; startCheckInProgress = false
        startPending = false; startRequestToken++
        startAttemptQueued = false
        emptyPageRetries = 0
        setOverlayTouchable(true)
        handler.removeCallbacksAndMessages(null)
        // Keep the foreground recovery loop running even after a user stops
        // one collection; otherwise the menu disappears on the next app visit.
        scheduleOverlayRecovery()
        // removeCallbacksAndMessages also cancels delayed overlay attachment.
        // Clear its latch so the next visit to the official app can recreate it.
        resetOverlayRetry()
        if (wasCollecting && selected != null) {
            RecordStore.setLastCollection(this, selected, total, collected, reason)
        }
        status(reason)
        if (wasCollecting) toast("수집 중지 · ${total}건 저장됨. $reason")
    }

    private fun disableByUser() {
        cancelCollection("사용자가 접근성 서비스 끄기를 선택함")
        detachControls()
        if (connected === this) connected = null
        // Only the explicit settings action may switch the system service off.
        disableSelf()
    }

    private fun resetOverlayRetry() {
        overlayAttachQueued = false
        overlayAttachAttempts = 0
        lastOverlayRetryAt = SystemClock.elapsedRealtime()
    }

    private fun restoreOverlayForOfficialApp() {
        if (!RecordStore.consent(this) || appRoot() == null) return
        if (overlay != null && overlayDarkMode != themeDark()) {
            overlayLayout?.let { lp ->
                getSharedPreferences("floating_menu_position", MODE_PRIVATE).edit()
                    .putInt("x", lp.x).putInt("y", lp.y).apply()
            }
            detachControls()
        }
        if (!wasOfficialInForeground) {
            // A fresh official-app visit is a fresh opportunity even if the
            // previous visit exhausted a manufacturer's overlay attach retries.
            resetOverlayRetry()
            wasOfficialInForeground = true
        }
        if (overlay == null) {
            if (overlayAttachAttempts >= 5 && SystemClock.elapsedRealtime() - lastOverlayRetryAt >= 5000L) {
                resetOverlayRetry()
            }
            ensureOverlay()
        } else overlay?.visibility = View.VISIBLE
    }

    private fun ensureOverlay() {
        if (overlay != null || overlayAttachQueued || overlayAttachAttempts >= 5) return
        overlayAttachQueued = true
        handler.postDelayed({
            overlayAttachQueued = false
            if (overlay == null && connected === this && RecordStore.consent(this) && appRoot() != null) {
                overlayAttachAttempts++
                attachControls()
                ensureOverlay()
            }
        }, 450L)
    }

    /** Compact mode keeps ALL three controls usable, instead of hiding them. */
    private fun attachControls() {
        if (overlay != null || appRoot() == null) return
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val prefs = getSharedPreferences("floating_menu_position", MODE_PRIVATE)
        // Keep old saved zoom levels, but allow a dramatically smaller new minimum.
        overlayZoom = prefs.getFloat("pinch_zoom",
            if (prefs.getBoolean("collapsed", true)) 0.68f else 1.2f).coerceIn(0.4f, 1.45f)
        overlayExpanded = overlayZoom >= 0.98f
        overlayDarkMode = themeDark()
        overlayPinchInProgress = false

        // Intercept only multi-touch gestures. Single-touch drag and all three
        // buttons keep their normal Android accessibility/click semantics.
        lateinit var zoomDetector: ScaleGestureDetector
        var pinching = false
        val wrap = object : LinearLayout(this) {
            override fun dispatchTouchEvent(event: MotionEvent): Boolean {
                if (event.actionMasked == MotionEvent.ACTION_DOWN) pinching = false
                if (event.pointerCount >= 2 && !pinching) {
                    pinching = true
                    overlayPinchInProgress = true
                    overlayBlockTapsUntil = SystemClock.uptimeMillis() + 420L
                    // Cancel a possible first-finger button press before scaling.
                    val cancel = MotionEvent.obtain(event)
                    cancel.action = MotionEvent.ACTION_CANCEL
                    super.dispatchTouchEvent(cancel)
                    cancel.recycle()
                }
                // The detector also sees DOWN so its second-pointer span is valid.
                zoomDetector.onTouchEvent(event)
                if (event.pointerCount >= 2 || pinching) {
                    if (event.actionMasked == MotionEvent.ACTION_UP ||
                        event.actionMasked == MotionEvent.ACTION_CANCEL) {
                        pinching = false
                        overlayPinchInProgress = false
                        overlayBlockTapsUntil = SystemClock.uptimeMillis() + 420L
                    }
                    return true
                }
                return super.dispatchTouchEvent(event)
            }
        }.apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(9), dp(6), dp(9), dp(8))
            background = overlayPanelDrawable(overlayDarkMode)
            clipToOutline = true
            elevation = dp(6).toFloat()
            contentDescription = "근무로그 수집 메뉴. 두 손가락을 벌려 확대하고 모아 축소하세요. 손잡이로 이동할 수 있습니다"
        }
        zoomDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                // More responsive zoom; this still needs a deliberate two-finger gesture.
                val factor = detector.scaleFactor * detector.scaleFactor
                val next = (overlayZoom * factor).coerceIn(0.4f, 1.45f)
                if (kotlin.math.abs(next - overlayZoom) < 0.003f) return true
                val oldWidth = floatingMenuWidth()
                val wasExpanded = overlayExpanded
                overlayZoom = next
                overlayExpanded = overlayZoom >= 0.98f
                // Avoid resetting text/layout on every move; only switch the two layouts once.
                if (wasExpanded != overlayExpanded) applyFloatingMenuSize(wrap)
                overlayLayout?.let { params ->
                    val newWidth = floatingMenuWidth()
                    if (kotlin.math.abs(newWidth - oldWidth) >= dp(2) || wasExpanded != overlayExpanded) {
                        params.width = newWidth
                        clampOverlayPosition(params, estimatedFloatingMenuHeight())
                        runCatching { wm?.updateViewLayout(wrap, params) }
                    }
                }
                return true
            }
            override fun onScaleEnd(detector: ScaleGestureDetector) {
                getSharedPreferences("floating_menu_position", MODE_PRIVATE).edit()
                    .putFloat("pinch_zoom", overlayZoom)
                    .putBoolean("collapsed", !overlayExpanded).apply()
            }
        })
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val dragHandle = TextView(this).apply {
            text = "↕ 이동 · 두 손가락"
            textSize = 11.5f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(if (overlayDarkMode) Color.parseColor("#B1BDCF") else Color.parseColor("#5E6B7E"))
            setPadding(dp(7), 0, dp(3), 0)
            gravity = Gravity.CENTER_VERTICAL
            contentDescription = "떠 있는 메뉴 이동 손잡이. 손가락으로 드래그하세요"
        }
        overlayHandle = dragHandle
        header.addView(dragHandle, LinearLayout.LayoutParams(0, dp(32), 1f))
        // This short badge stays in the header in BOTH sizes: the success state
        // is still obvious even if the long one-line summary is ellipsized.
        val stateBadge = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 10f
            setTypeface(typeface, Typeface.BOLD)
            setSingleLine(true)
            setPadding(dp(6), 0, dp(6), 0)
            contentDescription = "수집 상태"
        }
        overlayStateBadge = stateBadge
        header.addView(stateBadge, LinearLayout.LayoutParams(-2, dp(27)).apply {
            marginEnd = dp(5)
        })
        // No '+' / '-' toggle. Pinch on any free part of the toolbar to resize.
        wrap.addView(header)
        // Always visible, including the collapsed 3-button toolbar. A successful
        // collection must remain readable without expanding the menu.
        val compact = TextView(this).apply {
            textSize = 11.5f
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(dp(8), dp(6), dp(8), dp(6))
            isFocusable = true
        }
        compactStatus = compact
        wrap.addView(compact)
        latestStatus = getSharedPreferences("collection_ui", MODE_PRIVATE)
            .getString("last_status", latestStatus).orEmpty().ifBlank { "○ 대기 중 · 목록 수집을 눌러 주세요" }
        if (!active && !startPending && (latestStatus.contains("수집 중") ||
                latestStatus.contains("준비 확인 중") || latestStatus.contains("로딩 확인 중"))) {
            latestStatus = "이전 수집이 종료되었습니다 · 목록 수집을 다시 눌러 주세요"
            getSharedPreferences("collection_ui", MODE_PRIVATE).edit()
                .putString("last_status", latestStatus).apply()
        }
        updateCompactStatus()

        val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val status = TextView(this).apply {
            text = latestStatus
            textSize = 12.5f
            maxLines = 3
            setTextColor(if (overlayDarkMode) Color.parseColor("#E1E9FA") else Color.parseColor("#344054"))
            setPadding(dp(8), dp(6), dp(8), dp(10))
        }
        info = status
        details.addView(status)
        // Inset the actual hit targets from the curved panel edge. The blank rim
        // is safe to touch when starting a two-finger pinch.
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(3), dp(6), dp(3), dp(3))
        }
        val collect = overlayButton("목록 수집", Color.parseColor("#365BC5"), Color.WHITE) { begin() }
        val changeDate = overlayButton("날짜 수정", Color.parseColor("#EEF1F6"), Color.parseColor("#365175")) {
            openDateEditor()
        }
        val stopButton = overlayButton("수집 중지", Color.parseColor("#FFF0F4"), Color.parseColor("#B52A57")) {
            cancelCollection("사용자가 수집 중지")
        }
        buttons.addView(collect)
        buttons.addView(changeDate.apply { (layoutParams as LinearLayout.LayoutParams).marginStart = dp(7) })
        buttons.addView(stopButton.apply { (layoutParams as LinearLayout.LayoutParams).marginStart = dp(7) })
        overlayActionButtons = listOf(collect, changeDate, stopButton)
        details.addView(buttons)
        wrap.addView(details)
        overlayDetails = details
        // Never set details GONE: compact mode must retain the yellow date button.
        applyFloatingMenuSize(wrap)

        val width = resources.displayMetrics.widthPixels
        val height = resources.displayMetrics.heightPixels
        val savedX = prefs.getInt("x", (width - floatingMenuWidth()) / 2)
        val savedY = prefs.getInt("y", (height * 0.64f).toInt())
        val params = WindowManager.LayoutParams(
            floatingMenuWidth(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = savedX
            y = savedY
        }
        clampOverlayPosition(params, estimatedFloatingMenuHeight())
        overlayLayout = params
        dragHandle.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0f
            private var startY = 0f
            private var initialX = 0
            private var initialY = 0
            private val slop = ViewConfiguration.get(this@CollectorAccessibilityService).scaledTouchSlop
            private var dragging = false
            override fun onTouch(view: View, event: MotionEvent): Boolean {
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = event.rawX; startY = event.rawY
                        initialX = params.x; initialY = params.y
                        dragging = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX - startX
                        val dy = event.rawY - startY
                        if (kotlin.math.abs(dx) > slop || kotlin.math.abs(dy) > slop) dragging = true
                        if (dragging) {
                            params.x = initialX + dx.toInt()
                            params.y = initialY + dy.toInt()
                            clampOverlayPosition(params, wrap.height.coerceAtLeast(estimatedFloatingMenuHeight()))
                            runCatching { wm?.updateViewLayout(wrap, params) }
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        if (dragging) {
                            prefs.edit().putInt("x", params.x).putInt("y", params.y).apply()
                        } else if (event.actionMasked == MotionEvent.ACTION_UP) {
                            view.performClick()
                        }
                        return true
                    }
                }
                return false
            }
        })
        dragHandle.setOnClickListener { toast("두 손가락을 벌려 확대하고 모아 축소하세요. ↕ 손잡이는 이동합니다") }
        try {
            wm?.addView(wrap, params)
            overlay = wrap
            wrap.post {
                if (overlay === wrap) {
                    clampOverlayPosition(params, wrap.height.coerceAtLeast(estimatedFloatingMenuHeight()))
                    runCatching { wm?.updateViewLayout(wrap, params) }
                }
            }
        } catch (error: Exception) {
            overlayLayout = null
            overlayDetails = null
            compactStatus = null
            overlayStateBadge = null
            // The pinch detector is recreated on each overlay attachment.
            overlayHandle = null
            overlayActionButtons = emptyList()
            toast("메뉴 표시 실패: ${error.localizedMessage}")
        }
    }

    private fun floatingMenuWidth(): Int {
        val available = (resources.displayMetrics.widthPixels - dp(16)).coerceAtLeast(dp(1))
        // 164dp mini ↔ 340dp expanded: a real size difference, not just text resizing.
        val progress = ((overlayZoom - 0.4f) / 1.05f).coerceIn(0f, 1f)
        return minOf(available, dp(164 + (progress * 176f).toInt()))
    }

    private fun estimatedFloatingMenuHeight(): Int = dp(if (overlayExpanded) 180 else 126)

    private fun themeDark(): Boolean = getSharedPreferences("attendance_display", MODE_PRIVATE)
        .getBoolean("dark_mode", false)

    /** Three legible actions stay visible even in the tiny 164dp floating toolbar. */
    private fun applyFloatingMenuSize(wrap: LinearLayout) {
        val expanded = overlayExpanded
        wrap.setPadding(dp(if (expanded) 12 else 8), dp(if (expanded) 11 else 8),
            dp(if (expanded) 12 else 8), dp(if (expanded) 11 else 8))
        overlayHandle?.let { handle ->
            handle.text = if (expanded) "↕ 이동 · 두 손가락 확대/축소" else "↕ 이동"
            handle.textSize = if (expanded) 11.5f else 9.5f
            handle.layoutParams = (handle.layoutParams as LinearLayout.LayoutParams).apply {
                height = dp(if (expanded) 35 else 27)
            }
        }
        info?.visibility = if (expanded) View.VISIBLE else View.GONE
        compactStatus?.visibility = if (expanded) View.GONE else View.VISIBLE
        compactStatus?.textSize = if (expanded) 11.5f else 10f
        overlayStateBadge?.textSize = if (expanded) 10f else 9f
        overlayDetails?.visibility = View.VISIBLE
        overlayActionButtons.forEachIndexed { index, button ->
            val longLabel = arrayOf("목록 수집", "날짜 수정", "수집 중지")
            val smallLabel = arrayOf("수집", "날짜", "중지")
            button.text = if (expanded) longLabel[index] else smallLabel[index]
            button.contentDescription = longLabel[index]
            button.textSize = if (expanded) 12f else 10f
            button.setPadding(dp(1), 0, dp(1), 0)
            button.layoutParams = (button.layoutParams as LinearLayout.LayoutParams).apply {
                height = dp(if (expanded) 48 else 42)
            }
        }
        updateCompactStatus()
    }

    /** Keep the floating controls inside the usable screen on Samsung 3-button navigation. */
    private fun clampOverlayPosition(params: WindowManager.LayoutParams, guessedHeight: Int) {
        val metrics = resources.displayMetrics
        val w = metrics.widthPixels
        val h = metrics.heightPixels
        params.x = params.x.coerceIn(0, (w - params.width).coerceAtLeast(0))
        val minY = dp(32)
        val maxY = (h - guessedHeight - dp(72)).coerceAtLeast(minY)
        params.y = params.y.coerceIn(minY, maxY)
    }

    private fun overlayButton(label: String, fill: Int, textColor: Int, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(if (overlayDarkMode && label == "날짜 수정") Color.parseColor("#FFE49E")
                else if (overlayDarkMode && label == "수집 중지") Color.parseColor("#FFC1D4")
                else textColor)
            background = when (label) {
                "날짜 수정" -> GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    if (overlayDarkMode) intArrayOf(Color.parseColor("#4B3720"), Color.parseColor("#6A4922"))
                    else intArrayOf(Color.parseColor("#FFE16B"), Color.parseColor("#FFD45D"))).apply {
                    cornerRadius = dp(25).toFloat()
                    setStroke(dp(1), Color.parseColor(if (overlayDarkMode) "#8E6530" else "#F2B938"))
                }
                "목록 수집" -> GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    if (overlayDarkMode) intArrayOf(Color.parseColor("#4F46E5"), Color.parseColor("#DB2777"))
                    else intArrayOf(Color.parseColor("#5B4BFF"), Color.parseColor("#EC4899"))).apply {
                    cornerRadius = dp(25).toFloat()
                }
                else -> panelBackground(if (overlayDarkMode) Color.parseColor("#452337") else Color.parseColor("#FFE8F0"),
                    if (overlayDarkMode) Color.parseColor("#9D4770") else Color.parseColor("#F5B0C7"), radiusDp = 25)
            }
            textSize = 11f
            setSingleLine(true)
            minWidth = 0
            minHeight = 0
            setPadding(dp(1), 0, dp(1), 0)
            setOnClickListener {
                if (!overlayPinchInProgress && SystemClock.uptimeMillis() >= overlayBlockTapsUntil) {
                    action()
                }
            }
            layoutParams = LinearLayout.LayoutParams(0, dp(43), 1f)
        }
    }

    private fun overlayPanelDrawable(dark: Boolean): Drawable {
        val fill = Color.parseColor(if (dark) "#171B2E" else "#FFFFFF")
        val stroke = Color.parseColor(if (dark) "#4C4B86" else "#DCD5FF")
        val dots = Color.parseColor(if (dark) "#3B82F6" else "#EC4899")
        val radius = dp(22).toFloat()
        return object : Drawable() {
            private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = fill }
            private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeWidth = dp(1).toFloat(); color = stroke
            }
            private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
            private val rect = android.graphics.RectF()
            private val clip = Path()
            override fun draw(canvas: Canvas) {
                rect.set(bounds)
                clip.reset()
                clip.addRoundRect(rect, radius, radius, Path.Direction.CW)
                canvas.save()
                canvas.clipPath(clip)
                canvas.drawRoundRect(rect, radius, radius, bgPaint)
                // Colorful corner pattern dots + top pastel ribbon.
                val stripeColors = intArrayOf(
                    Color.parseColor("#5B4BFF"), Color.parseColor("#EC4899"),
                    Color.parseColor("#F59E0B"), Color.parseColor("#10B981")
                )
                val segW = rect.width() / stripeColors.size
                stripeColors.forEachIndexed { idx, c ->
                    dotPaint.color = c
                    dotPaint.alpha = if (dark) 210 else 230
                    canvas.drawRect(rect.left + idx * segW, rect.top, rect.left + (idx + 1) * segW + 1f, rect.top + dp(4), dotPaint)
                }
                dotPaint.color = dots
                dotPaint.alpha = if (dark) 30 else 22
                val step = dp(10).toFloat()
                for (row in 0..2) {
                    for (col in 0..3) {
                        canvas.drawCircle(rect.right - dp(12) - col * step, rect.top + dp(14) + row * step, dp(2).toFloat(), dotPaint)
                    }
                }
                canvas.restore()
                canvas.drawRoundRect(rect, radius, radius, borderPaint)
            }
            override fun setAlpha(alpha: Int) { bgPaint.alpha = alpha; borderPaint.alpha = alpha }
            override fun setColorFilter(cf: android.graphics.ColorFilter?) {
                bgPaint.colorFilter = cf; borderPaint.colorFilter = cf
            }
            @Suppress("OVERRIDE_DEPRECATION")
            override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
        }
    }

    private fun panelBackground(fill: Int, stroke: Int, radiusDp: Int = 18) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(radiusDp).toFloat()
        setColor(fill)
        if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }

    /** Open only our own Activity after the user explicitly presses the yellow button. */
    private fun openDateEditor() {
        if (active || startPending || startCheckInProgress) {
            status("수집을 먼저 완료하거나 중지한 뒤 날짜를 수정해 주세요")
            toast("수집 중에는 날짜를 바꿀 수 없습니다. 먼저 중지해 주세요")
            return
        }
        overlay?.visibility = View.GONE
        try {
            startActivity(Intent(this, MainActivity::class.java).apply {
                action = MainActivity.ACTION_EDIT_PERIOD
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            })
        } catch (e: RuntimeException) {
            // OEM background-start policy can differ; never weaken system protection.
            overlay?.visibility = View.VISIBLE
            status("화면 이동에 실패했습니다. 근무로그 앱을 직접 열어 주세요")
            toast("날짜 화면을 열 수 없습니다: ${e.localizedMessage}")
        }
    }

    private fun begin() {
        if (active) return status("이미 목록 수집 중입니다")
        if (startPending || startCheckInProgress) return status("목록 화면 준비 확인 중 · 잠시 후 다시 확인합니다")
        if (!RecordStore.consent(this)) return toast("먼저 근무로그 앱에서 접근성 사용 안내에 동의하세요.")
        if (appRoot()?.packageName?.toString() != OFFICIAL_ATTENDANCE_PACKAGE) {
            return status("한국장학재단 출근부 앱에서만 수집할 수 있습니다")
        }
        startPending = true
        startAttempts = 0
        val token = ++startRequestToken
        status("목록 화면 준비 확인 중 · 자동 재확인")
        scheduleStartCheck(token, 60L)
    }

    private fun scheduleStartCheck(token: Int, delayMs: Long) {
        if (!startPending || token != startRequestToken || startAttemptQueued) return
        startAttemptQueued = true
        handler.postDelayed({
            startAttemptQueued = false
            if (startPending && !active && token == startRequestToken && !startCheckInProgress) {
                attemptStart(token)
            }
        }, delayMs)
    }

    private fun startFailed(message: String) {
        startPending = false
        startCheckInProgress = false
        val visibleMonth = RecordStore.selectedMonth(this)
        val storedCount = RecordStore.read(this).count { it.date.startsWith(visibleMonth.toString()) }
        RecordStore.setLastCollection(this, visibleMonth, storedCount, 0, message)
        status(message)
        toast(message)
    }

    private fun attemptStart(token: Int) {
        if (!startPending || active || token != startRequestToken) return
        startAttempts++
        val root = appRoot()
        val candidatePackage = root?.packageName?.toString().orEmpty()
        if (candidatePackage != OFFICIAL_ATTENDANCE_PACKAGE) {
            if (startAttempts < 10) {
                status("공식 앱 화면 확인 대기 · ${startAttempts}/10")
                scheduleStartCheck(token, 550L)
            } else {
                startFailed("목록 화면 미확인 · 장학재단 조회 목록에서 수집 버튼을 다시 누르세요")
            }
            return
        }
        val text = root?.let { mergedAccessibilityText(it) }.orEmpty()
        val selected = RecordStore.selectedMonth(this)
        val visibleMonth = AttendanceParser.monthHeader(text)
        // When the official list clearly contains records for a different month,
        // match the dashboard to that verified list. Never guess without records.
        val effectiveMonth = if (visibleMonth != null && visibleMonth != selected &&
            AttendanceParser.fromListPage(text, visibleMonth).isNotEmpty()) visibleMonth else selected
        if (visibleMonth != null && visibleMonth != selected && effectiveMonth != visibleMonth) {
            startFailed("월 불일치: 앱 $selected / 화면 $visibleMonth · 날짜 설정을 확인하세요")
            return
        }
        val rows = AttendanceParser.fromListPage(text, effectiveMonth)
        if (rows.isNotEmpty()) {
            startPending = false
            if (selected != effectiveMonth) {
                RecordStore.setSelectedMonth(this, effectiveMonth)
                toast("공식 출근부 조회 목록에 맞춰 ${effectiveMonth.monthValue}월을 표시합니다")
            }
            startCollection(candidatePackage, effectiveMonth)
            return
        }
        // WebView often populates its accessibility nodes after the list is visible.
        if (startAttempts < 6) {
            status("목록 내용 로딩 확인 중 · ${startAttempts}/6")
            scheduleStartCheck(token, 500L)
            return
        }
        startFailed("접근성에서 근무 텍스트를 읽지 못했습니다. 원본 목록이 표시되는지 확인하세요")
    }

    private data class ScreenText(
        val fullText: String,
        val listText: String,
        val listBounds: Rect?
    )

    private fun startCollection(appPackage: String, ym: YearMonth) {
        if (active) return
        if (appPackage != OFFICIAL_ATTENDANCE_PACKAGE) {
            startPending = false
            return status("수집 대상 앱을 확인할 수 없습니다")
        }
        active = true
        startPending = false
        startRequestToken++
        transientRootRetries = 0
        emptyPageRetries = 0
        runId++
        targetPackage = appPackage
        month = ym
        pages = 0; collected = 0; repeated = 0; zeroRecordPages = 0
        previousSignature = ""; previousPageText = ""; previousListText = ""
        status("${ym.year}.${ym.monthValue} 목록 수집 중")
        val id = runId
        handler.postDelayed({ processPage(id) }, 300)
    }

    private fun processPage(id: Int) {
        if (!active || id != runId) return
        if (!CollectionSession.isOpen(this)) return suspendSession()
        if (pages >= 80) return stop("최대 80페이지 도달. 지금까지 기록을 확인하세요.")
        val visiblePackage = appRoot()?.packageName?.toString()
        if (visiblePackage != null && visiblePackage != targetPackage) {
            return stop("다른 앱으로 이동하여 수집을 중단했습니다")
        }
        val root = verifiedRoot()
        if (root == null) {
            transientRootRetries++
            if (transientRootRetries <= 4) {
                status("목록 화면 갱신 중 · 다시 확인 ${transientRootRetries}/4")
                handler.postDelayed({ processPage(id) }, 450L)
                return
            }
            return stop("화면 접근이 불가능하여 수집을 중단했습니다")
        }
        transientRootRetries = 0
        val ym = month ?: return stop("월 정보를 찾을 수 없습니다.")
        val screen = readScreenText(root)
        val fullText = screen.fullText
        val listChunk = screen.listText.ifBlank { fullText }
        val visibleMonth = AttendanceParser.monthHeader(fullText)
        // Once scrolling has started, only stop for month change if actual records
        // for a different month are shown (avoid stray notice dates mid-scroll).
        if (visibleMonth != null && visibleMonth != ym &&
            (pages == 0 || AttendanceParser.fromListPage(fullText, visibleMonth).isNotEmpty())) {
            return stop("조회 월이 바뀌었습니다. 중지합니다.")
        }
        val currentFullRows = AttendanceParser.fromListPage(fullText, ym)
        val bridgedListRows = AttendanceParser.fromOverlappingPages(previousListText, listChunk, ym)
        val previousListRows = if (previousListText.isBlank()) emptyList() else AttendanceParser.fromListPage(previousListText, ym)
        val previousPageBridged = AttendanceParser.fromOverlappingPages(previousPageText, fullText, ym)
        val entries = AttendanceParser.unique(currentFullRows + bridgedListRows + previousPageBridged)
        val hasCurrentContent = currentFullRows.isNotEmpty() ||
            bridgedListRows.size > previousListRows.size ||
            (listChunk.contains(":") && AttendanceParser.fromOverlappingPages(previousListText, listChunk, ym).isNotEmpty())
        if (entries.isNotEmpty() && (hasCurrentContent || pages == 0)) {
            emptyPageRetries = 0
            processParsed(id, root, entries, fullText, listChunk, screen.listBounds)
        } else if (pages > 0 && emptyPageRetries < 2) {
            emptyPageRetries++
            status("목록 내용 불러오는 중 · 재확인 ${emptyPageRetries}/2")
            handler.postDelayed({ processPage(id) }, 550L)
        } else if (pages > 0) {
            return finish("목록 끝까지 확인하여 종료했습니다.")
        } else {
            return finish("화면에 읽을 수 있는 기록이 없습니다. 날짜·목록을 확인하세요.")
        }
    }

    private fun processParsed(
        id: Int,
        root: AccessibilityNodeInfo,
        records: List<WorkRecord>,
        fullText: String,
        listChunk: String,
        listBounds: Rect?
    ) {
        if (!active || id != runId) return
        val ym = month ?: return stop("월 정보 오류")
        pages++
        val before = RecordStore.read(this).count { it.date.startsWith(ym.toString()) }
        if (!RecordStore.add(this, records)) {
            return stop("저장 공간 오류 · 기존 기록 보호를 위해 수집 중지")
        }
        previousPageText = fullText.takeLast(2800)
        previousListText = listChunk.takeLast(2800)
        val after = RecordStore.read(this).count { it.date.startsWith(ym.toString()) }
        collected += after - before
        zeroRecordPages = if (records.isEmpty()) zeroRecordPages + 1 else 0
        if (zeroRecordPages >= 2 && after == 0) {
            return finish("두 화면에서 근무기록을 하나도 읽지 못했습니다. 조회 월/원본 화면을 확인하세요.")
        }
        val signature = listChunk.replace(Regex("\\s+"), " ").trim()
        repeated = if (signature == previousSignature) repeated + 1 else 0
        previousSignature = signature
        status("${ym.monthValue}월: ${pages}화면 / 전체 ${after}건 (신규 ${collected}건)")
        if (repeated >= 2) return finish("화면이 더 이상 변하지 않아 종료했습니다.")
        // If a node scroll action left the screen unchanged (repeated >= 1), force a touch swipe.
        scroll(root, listBounds, allowNodeAction = (repeated == 0)) { didScroll ->
            if (!active || id != runId) return@scroll
            if (!didScroll) finish("더 내려갈 수 없는 화면입니다.")
            else handler.postDelayed({ processPage(id) }, 1400)
        }
    }

    private fun scroll(
        root: AccessibilityNodeInfo,
        listBounds: Rect?,
        allowNodeAction: Boolean,
        next: (Boolean) -> Unit
    ) {
        if (!authorizedTargetVisible()) return next(false)
        if (allowNodeAction) {
            val scrollers = mutableListOf<AccessibilityNodeInfo>()
            walk(root) { node ->
                if (node.isScrollable && node.isVisibleToUser) {
                    val r = Rect().also { node.getBoundsInScreen(it) }
                    if (r.width() > dp(200) && r.height() > dp(180)) scrollers += node
                }
            }
            // Prefer large vertical scrollable areas over small inner horizontal strips.
            val candidates = scrollers.sortedWith(
                compareByDescending<AccessibilityNodeInfo> { node ->
                    Rect().also { node.getBoundsInScreen(it) }.let { it.height() >= it.width() }
                }.thenByDescending { node ->
                    Rect().also { node.getBoundsInScreen(it) }.let { it.width().toLong() * it.height() }
                }
            )
            val scrollDownId = AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN.id
            for (n in candidates) {
                val supportsDown = n.actionList.any { it.id == scrollDownId }
                if (supportsDown && n.performAction(scrollDownId)) return next(true)
                if (n.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) return next(true)
            }
        }
        // Swipe inside safe vertical bounds of the list without letting the floating overlay swallow the touch.
        val size = resources.displayMetrics
        val w = size.widthPixels.toFloat().coerceAtLeast(200f)
        val h = size.heightPixels.toFloat().coerceAtLeast(300f)
        val leftMin = dp(16).toFloat().coerceAtMost(w * 0.30f)
        val leftMax = maxOf(leftMin, w - dp(72))
        val safeLeft = (listBounds?.left?.toFloat() ?: 0f).coerceIn(leftMin, leftMax)
        val rightMin = (safeLeft + dp(40)).coerceAtMost(w - dp(8))
        val rightMax = maxOf(rightMin, w - dp(8))
        val safeRight = (listBounds?.right?.toFloat() ?: w).coerceIn(rightMin, rightMax)
        val topMin = (h * 0.12f)
        val topMax = maxOf(topMin, h * 0.50f)
        val safeTop = (listBounds?.top?.toFloat() ?: (h * 0.14f)).coerceIn(topMin, topMax)
        val bottomMin = (safeTop + dp(96)).coerceAtMost(h * 0.84f)
        val bottomMax = maxOf(bottomMin, h * 0.84f)
        val safeBottom = (listBounds?.bottom?.toFloat() ?: (h * 0.80f)).coerceIn(bottomMin, bottomMax)
        val startYMin = (h * 0.25f)
        val startYMax = maxOf(startYMin, h * 0.84f)
        val startY = (safeTop + (safeBottom - safeTop) * 0.80f).coerceIn(startYMin, startYMax)
        val endCeiling = (startY - dp(80)).coerceAtLeast(16f)
        val endFloor = minOf(h * 0.14f, endCeiling)
        val endY = (safeTop + (safeBottom - safeTop) * 0.20f).coerceIn(endFloor, endCeiling)
        var swipeX = ((safeLeft + safeRight) * 0.50f).coerceIn(8f, (w - 8f).coerceAtLeast(8f))
        var needsPassthrough = false
        val lp = overlayLayout
        if (lp != null && overlay?.visibility == View.VISIBLE) {
            val ovH = (overlay?.height ?: 0).coerceAtLeast(estimatedFloatingMenuHeight())
            val ovTop = lp.y.toFloat()
            val ovBottom = ovTop + ovH
            if (startY >= ovTop - dp(12) && endY <= ovBottom + dp(12)) {
                val ovLeft = lp.x.toFloat() - dp(16)
                val ovRight = lp.x + lp.width.toFloat() + dp(16)
                if (swipeX in ovLeft..ovRight) {
                    swipeX = when {
                        ovLeft - safeLeft >= dp(36) -> (safeLeft + ovLeft) * 0.5f
                        safeRight - ovRight >= dp(36) -> (ovRight + safeRight) * 0.5f
                        else -> {
                            needsPassthrough = true
                            swipeX
                        }
                    }.coerceIn(8f, (w - 8f).coerceAtLeast(8f))
                }
            }
        }
        if (needsPassthrough) setOverlayTouchable(false)
        val path = Path().apply { moveTo(swipeX, startY); lineTo(swipeX, endY) }
        val gesture = runCatching {
            GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 460)).build()
        }.getOrNull()
        val ok = if (gesture != null) {
            runCatching {
                dispatchGesture(gesture, object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        setOverlayTouchable(true)
                        next(true)
                    }
                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        setOverlayTouchable(true)
                        next(false)
                    }
                }, handler)
            }.getOrDefault(false)
        } else false
        if (!ok) {
            setOverlayTouchable(true)
            next(false)
        }
    }

    /** Checks both user consent and the exact foreground package immediately before reading the accessibility tree. */
    private fun authorizedTargetVisible(): Boolean =
        RecordStore.consent(this) &&
            appRoot()?.packageName?.toString() == OFFICIAL_ATTENDANCE_PACKAGE

    private fun appRoot(): AccessibilityNodeInfo? {
        // Check before touching any third-party accessibility tree, including retries.
        if (!CollectionSession.isOpen(this) || !RecordStore.consent(this)) return null
        // The accessibility overlay or keyboard may temporarily become the active
        // root. Do not return null before checking the focused application window.
        val activeRoot = runCatching { rootInActiveWindow }.getOrNull()
        if (activeRoot?.packageName?.toString() == OFFICIAL_ATTENDANCE_PACKAGE) return activeRoot
        return runCatching {
            windows.asSequence()
                .filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION && (it.isActive || it.isFocused) }
                .mapNotNull { it.root }
                .firstOrNull { it.packageName?.toString() == OFFICIAL_ATTENDANCE_PACKAGE }
        }.getOrNull()
    }

    private fun verifiedRoot(): AccessibilityNodeInfo? {
        val root = appRoot() ?: return null
        if (root.packageName?.toString() != targetPackage) return null
        return root
    }

    private fun readScreenText(root: AccessibilityNodeInfo): ScreenText {
        val focusedNodes = mutableListOf<AccessibilityNodeInfo>()
        walk(root) { node ->
            val r = Rect().also { node.getBoundsInScreen(it) }
            if (node.isVisibleToUser && r.height() > dp(120) && r.width() > dp(140)) {
                if (node.isScrollable || node.className?.toString()?.contains("Recycler", true) == true || node.className?.toString()?.contains("List", true) == true) {
                    focusedNodes += node
                }
            }
        }
        val mainList = focusedNodes.maxByOrNull { node ->
            Rect().also { node.getBoundsInScreen(it) }.let { it.width().toLong() * it.height() }
        }
        val listBounds = mainList?.let { Rect().also { r -> it.getBoundsInScreen(r) } }
        val all = readText(root)
        val listArea = mainList?.let { readText(it) }.orEmpty()
        return ScreenText(all, listArea, listBounds)
    }

    private fun mergedAccessibilityText(root: AccessibilityNodeInfo): String {
        val screen = readScreenText(root)
        return listOf(screen.fullText, screen.listText)
            .filter { it.isNotBlank() }
            .distinct()
            .joinToString("\n")
    }

    private fun readText(root: AccessibilityNodeInfo): String {
        data class Line(val y: Int, val x: Int, val value: String)
        val lines = mutableListOf<Line>()
        val seen = hashSetOf<String>()
        walk(root) { n ->
            val value = (n.text ?: n.contentDescription)?.toString()?.trim().orEmpty()
            if (value.isBlank()) return@walk
            val r = Rect().also { n.getBoundsInScreen(it) }
            if (!n.isVisibleToUser || r.width() <= 0 || r.height() <= 0) return@walk
            val key = "${r.left}|${r.top}|${r.right}|${r.bottom}|$value"
            if (seen.add(key)) lines += Line(r.centerY(), r.left, value)
        }
        val sorted = lines.sortedWith(compareBy(Line::y, Line::x))
        val bands = mutableListOf<MutableList<Line>>()
        for (line in sorted) {
            val band = bands.lastOrNull()
            if (band != null && kotlin.math.abs(band.first().y - line.y) <= dp(14)) band.add(line)
            else bands.add(mutableListOf(line))
        }
        return bands.joinToString("\n") { band ->
            band.sortedBy { it.x }.joinToString(" ") { it.value }
        }
    }
    private fun walk(root: AccessibilityNodeInfo, action: (AccessibilityNodeInfo) -> Unit) {
        var count = 0
        fun visit(n: AccessibilityNodeInfo, depth: Int) {
            if (++count > 3200 || depth > 55) return
            action(n)
            for (i in 0 until n.childCount) {
                runCatching { n.getChild(i) }.getOrNull()?.let { visit(it, depth + 1) }
            }
        }
        visit(root, 0)
    }
    private fun finish(reason: String) {
        if (!active) return
        val ym = month
        val total = ym?.let { selected -> RecordStore.read(this).count { it.date.startsWith(selected.toString()) } } ?: 0
        RecordStore.setLastCollection(this, ym, total, collected, reason)
        active = false; runId++; startCheckToken++; startRequestToken++
        startPending = false; startCheckInProgress = false
        emptyPageRetries = 0
        setOverlayTouchable(true)
        handler.removeCallbacksAndMessages(null)
        scheduleOverlayRecovery()
        resetOverlayRetry()
        if (total > 0) {
            status("수집 완료 · 총 ${total}건 / 신규 ${collected}건 · 통계 탭에서 확인하세요")
            compactStatus?.announceForAccessibility("수집 완료. 전체 ${total}건, 신규 ${collected}건")
            toast("수집 완료: 전체 ${total}건 / 새 ${collected}건 · ${pages}화면. $reason")
        } else {
            status("확인 필요 · 읽은 기록 0건 · 조회 월과 화면을 확인하세요")
            toast("근무기록 0건: $reason")
        }
    }
    private fun stop(reason: String) {
        if (!active && !startCheckInProgress) return
        cancelCollection(reason)
    }
    private fun status(message: String) {
        latestStatus = message
        // Store only an operational status string, never raw accessibility content.
        getSharedPreferences("collection_ui", MODE_PRIVATE).edit().putString("last_status", message).apply()
        info?.text = message
        info?.setTextColor(if (overlayDarkMode) Color.parseColor(
            if (message.startsWith("수집 완료")) "#8FF4CC" else "#E1E9FA") else Color.parseColor(
            if (message.startsWith("수집 완료")) "#075E50" else "#344054"))
        updateCompactStatus()
    }

    private fun updateCompactStatus() {
        val appearance = FloatingCollectionStatus.from(
            latestStatus, active || startPending || startCheckInProgress)
        val textColor: Int
        val badgeBackground: Int
        val summaryBackground: Int
        when (appearance.phase) {
            CollectionDisplayPhase.COMPLETE -> {
                textColor = Color.parseColor(if (overlayDarkMode) "#9FF7D5" else "#075E50")
                badgeBackground = Color.parseColor(if (overlayDarkMode) "#174B3C" else "#D7F5E5")
                summaryBackground = Color.parseColor(if (overlayDarkMode) "#203F37" else "#E5F8EC")
            }
            CollectionDisplayPhase.RUNNING -> {
                textColor = Color.parseColor(if (overlayDarkMode) "#B9C5FF" else "#293C96")
                badgeBackground = Color.parseColor(if (overlayDarkMode) "#293B70" else "#DFE4FF")
                summaryBackground = Color.parseColor(if (overlayDarkMode) "#253453" else "#EBEEFF")
            }
            CollectionDisplayPhase.WARNING -> {
                textColor = Color.parseColor(if (overlayDarkMode) "#FFAAC1" else "#992448")
                badgeBackground = Color.parseColor(if (overlayDarkMode) "#503045" else "#FFE1E8")
                summaryBackground = Color.parseColor(if (overlayDarkMode) "#402638" else "#FFF0F3")
            }
            CollectionDisplayPhase.IDLE -> {
                textColor = Color.parseColor(if (overlayDarkMode) "#F8D898" else "#72511D")
                badgeBackground = Color.parseColor(if (overlayDarkMode) "#4D3C2A" else "#F5EEDB")
                summaryBackground = Color.parseColor(if (overlayDarkMode) "#3D342C" else "#FFF8E9")
            }
        }
        // Visible even if the toolbar is collapsed, independently of detail text.
        overlayStateBadge?.apply {
            text = appearance.badge
            contentDescription = appearance.badge
            setTextColor(textColor)
            background = panelBackground(badgeBackground, Color.TRANSPARENT, radiusDp = 14)
        }
        info?.apply {
            background = panelBackground(summaryBackground, Color.TRANSPARENT, radiusDp = 16)
            setTextColor(textColor)
        }
        compactStatus?.apply {
            text = appearance.compactText
            contentDescription = latestStatus
            setTextColor(textColor)
            background = panelBackground(summaryBackground, Color.TRANSPARENT, radiusDp = 16)
        }
    }
    private fun toast(message: String) {
        runCatching { Toast.makeText(applicationContext, message, Toast.LENGTH_LONG).show() }
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
