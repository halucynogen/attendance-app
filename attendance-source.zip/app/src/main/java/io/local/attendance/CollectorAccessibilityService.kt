package io.local.attendance

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.time.YearMonth
import kotlin.math.abs
import kotlin.math.hypot

/**
 * User-initiated, read-only monthly LIST collector (Lunar Satellite HUD Pod).
 * Never taps attendance modification, approval, submit, login or individual dates.
 * Accessibility text only: never uses screenshot capture or OCR.
 */
class CollectorAccessibilityService : AccessibilityService() {
    companion object {
        // Google Play listing for the official Korean Scholarship Foundation attendance app.
        // Restrict all automatic inspection to this package, never to unrelated apps.
        private const val OFFICIAL_ATTENDANCE_PACKAGE = "com.kosaf.gpsAttendance"
        // Permission stays enabled until the user explicitly chooses to switch it off.
        // Collection lifecycle is entirely separate from Android's service permission.
        @Volatile private var connected: CollectorAccessibilityService? = null
        fun isReady(): Boolean = connected != null
        fun onAppClosed() {
            connected?.suspendSession()
        }
        fun disableFromApp(): Boolean {
            val service = connected ?: return false
            service.disableByUser()
            return true
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var overlay: LinearLayout? = null
    private var info: TextView? = null
    private var compactStatus: TextView? = null
    private var overlayStateBadge: TextView? = null
    private var latestStatus = "○ 대기 중 · 목록 수집을 눌러 주세요"
    private var wm: WindowManager? = null
    private var overlayLayout: WindowManager.LayoutParams? = null
    private var overlayDetails: LinearLayout? = null
    private var overlayExpanded = false
    // Continuous two-finger pinch size; never controlled by +/- buttons.
    private var overlayZoom = 0.72f
    private var overlayDarkMode = false
    private var overlayHandle: TextView? = null
    private var overlayHideButton: TextView? = null
    private var overlayActionButtons: List<Button> = emptyList()
    // Pinch takes priority over actions. Ignore ghost taps shortly after resizing.
    private var overlayPinchInProgress = false
    private var overlayCornerResizing = false
    private var overlayUserHiddenThisVisit = false
    private var overlayBlockTapsUntil = 0L
    private var active = false
    private var runId = 0
    private var targetPackage = ""
    private var month: YearMonth? = null
    private var pages = 0
    private var collected = 0
    private var repeated = 0
    private var previousSignature = ""
    private var previousPageText = ""
    private var previousListText = ""
    private var startCheckInProgress = false
    private var startCheckToken = 0
    private var zeroRecordPages = 0
    private var emptyPageRetries = 0
    private var diagnostic = ""
    private var startPending = false
    private var startAttempts = 0
    private var startRequestToken = 0
    private var startAttemptQueued = false
    private var transientRootRetries = 0
    private var overlayAttachQueued = false
    private var overlayAttachAttempts = 0
    private var lastOverlayRetryAt = 0L
    private var wasOfficialInForeground = false
    private var overlaySwipePassthrough = false

    // Android/OEMs may omit window-change events when returning from Settings,
    // recents or a background app. Check only the foreground package periodically (~1s);
    // never read its text or start collection in the recovery loop.
    // (Supersedes older handler.postDelayed(this, 1600L) cadence for faster task removal detection.)
    private val overlayRecovery = object : Runnable {
        override fun run() {
            if (connected !== this@CollectorAccessibilityService) return
            try {
                if (!CollectionSession.isOpen(this@CollectorAccessibilityService)) {
                    suspendSession()
                } else if (RecordStore.consent(this@CollectorAccessibilityService) && appRoot() != null) {
                    restoreOverlayForOfficialApp()
                } else {
                    overlay?.visibility = View.GONE
                    wasOfficialInForeground = false
                    overlayUserHiddenThisVisit = false
                }
            } catch (error: Exception) {
                android.util.Log.w("AttendanceOverlay", "Foreground overlay check failed", error)
            }
            handler.removeCallbacks(this)
            handler.postDelayed(this, 1000L)
        }
    }

    private fun scheduleOverlayRecovery() {
        handler.removeCallbacks(overlayRecovery)
        handler.postDelayed(overlayRecovery, 700L)
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        // Android's accessibility switch is not a substitute for the app's own
        // prominent disclosure and consent. Refuse the service when it was
        // enabled directly from Settings without that explicit consent.
        connected = this
        overlayUserHiddenThisVisit = false
        scheduleOverlayRecovery()
        if (!CollectionSession.isOpen(this)) return
        if (!RecordStore.consent(this)) {
            // Leave the OS-owned accessibility switch alone. No collection or
            // floating control is allowed until the user's in-app consent.
            Toast.makeText(this, "근무로그 앱에서 접근성 수집 안내에 동의한 뒤 이용하세요", Toast.LENGTH_LONG).show()
            return
        }
        // Do not display a floating control on login, bank or unrelated application screens.
        if (appRoot() != null) {
            wasOfficialInForeground = true
            resetOverlayRetry()
            attachControls()
            ensureOverlay()
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!CollectionSession.isOpen(this)) {
            suspendSession()
            return
        }
        val sourceApp = event?.packageName?.toString()
        if (!RecordStore.consent(this)) {
            // Security: never read or inspect any third-party window without consent.
            if (active || startPending || startCheckInProgress) cancelCollection("접근성 수집 동의가 필요합니다")
            overlay?.visibility = View.GONE
            wasOfficialInForeground = false
            return
        }
        if (sourceApp == packageName) {
            // An overlay itself emits our package name. Hide the controls only
            // when an actual MainActivity window opens, not on overlay taps.
            val ownActivityVisible = event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
                event.className?.toString() == MainActivity::class.java.name
            if (ownActivityVisible) {
                overlay?.visibility = View.GONE
                wasOfficialInForeground = false
                overlayUserHiddenThisVisit = false
                if (active || startPending || startCheckInProgress) cancelCollection("근무로그 앱으로 이동하여 수집 일시 중지")
            }
            return
        }
        if (sourceApp != OFFICIAL_ATTENDANCE_PACKAGE) {
            // Transient accessibility events from toasts, notifications or the system
            // are not foreground app changes. In particular, don't hide a SUCCESS
            // banner right after the collection-complete toast is shown.
            val foregroundChanged = event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
                event?.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED
            if (foregroundChanged && appRoot() == null) {
                overlay?.visibility = View.GONE
                wasOfficialInForeground = false
                overlayUserHiddenThisVisit = false
                // Never revoke accessibility permission when leaving the official app.
                if (active) cancelCollection("다른 앱으로 이동하여 수집 중지")
            } else if (foregroundChanged && appRoot() != null) {
                // System overlays and transient toasts can emit non-target events
                // while the official app remains in front. Restore the idle toolbar.
                restoreOverlayForOfficialApp()
            }
            return  // Never inspect screens from unrelated packages.
        }
        restoreOverlayForOfficialApp()
        if (overlay != null && overlayDarkMode != themeDark()) {
            // Settings changed while the accessibility service remained running.
            // Recreate ONLY the overlay; never touch collection state or records.
            overlayLayout?.let { lp ->
                getSharedPreferences("floating_menu_position", MODE_PRIVATE).edit()
                    .putInt("x", lp.x).putInt("y", lp.y).apply()
            }
            detachControls()
        }
        if (overlay == null) {
            if (!overlayUserHiddenThisVisit) {
                if (SystemClock.elapsedRealtime() - lastOverlayRetryAt > 10000L) {
                    overlayAttachAttempts = 0
                    lastOverlayRetryAt = SystemClock.elapsedRealtime()
                }
                ensureOverlay()
            }
        } else if (!overlayUserHiddenThisVisit) {
            overlay?.visibility = View.VISIBLE
        }
        // Only resume an explicit user request. Enabling accessibility does NOT start capture.
        if (startPending && !active && !startCheckInProgress) {
            scheduleStartCheck(startRequestToken, 120L)
        }
    }

    override fun onInterrupt() {
        // Android may interrupt an IDLE service after displaying a toast/dialog.
        // Preserve a previously completed result; only an in-flight run can stop.
        if (active || startPending || startCheckInProgress) {
            cancelCollection("화면 접근이 일시 중단되어 수집을 멈췄습니다")
        }
        overlay?.visibility = View.GONE
    }

    override fun onDestroy() {
        active = false; runId++; startCheckToken++; startRequestToken++
        startPending = false
        detachControls()
        handler.removeCallbacks(overlayRecovery)
        wasOfficialInForeground = false
        overlayUserHiddenThisVisit = false
        if (connected === this) connected = null
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val nextDark = themeDark()
        if (overlay != null && nextDark != overlayDarkMode) {
            val wasVisible = overlay?.visibility == View.VISIBLE
            detachControls()
            if (wasVisible || wasOfficialInForeground) {
                ensureOverlay()
                if (!wasVisible) overlay?.visibility = View.GONE
            }
        }
    }

    private fun detachControls() {
        overlay?.animate()?.cancel()
        overlay?.let { runCatching { wm?.removeView(it) } }
        overlay = null
        info = null
        overlayDetails = null
        compactStatus = null
        overlayStateBadge = null
        // Pinch state is owned by the View and resets upon reattachment.
        overlayHandle = null
        overlayHideButton = null
        overlayActionButtons = emptyList()
        overlayPinchInProgress = false
        overlayCornerResizing = false
        overlayBlockTapsUntil = 0L
        overlaySwipePassthrough = false
        overlayAttachQueued = false
        overlayLayout = null
    }

    private fun setOverlayTouchable(touchable: Boolean) {
        val view = overlay ?: return
        val params = overlayLayout ?: return
        val wantPassthrough = !touchable
        if (overlaySwipePassthrough == wantPassthrough) return
        overlaySwipePassthrough = wantPassthrough
        params.flags = if (wantPassthrough) {
            params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        } else {
            params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        }
        runCatching { wm?.updateViewLayout(view, params) }
    }

    private fun suspendSession() {
        if (active || startPending || startCheckInProgress) {
            cancelCollection("근무로그 실행이 종료되어 수집 중지")
        }
        detachControls()
        wasOfficialInForeground = false
        overlayUserHiddenThisVisit = false
    }

    private fun cancelCollection(reason: String) {
        val wasCollecting = active || startPending || startCheckInProgress
        val selected = month
        val total = selected?.let { ym ->
            RecordStore.read(this).count { it.date.startsWith(ym.toString()) }
        } ?: 0
        active = false; runId++
        startCheckToken++; startCheckInProgress = false
        startPending = false; startRequestToken++
        startAttemptQueued = false
        emptyPageRetries = 0
        setOverlayTouchable(true)
        handler.removeCallbacksAndMessages(null)
        // Keep the foreground recovery loop running even after a user stops
        // one collection; otherwise the menu disappears on the next app visit.
        scheduleOverlayRecovery()
        // removeCallbacksAndMessages also cancels delayed overlay attachment.
        // Clear its latch so the next visit to the official app can recreate it.
        resetOverlayRetry()
        if (wasCollecting && selected != null) {
            RecordStore.setLastCollection(this, selected, total, collected, reason)
        }
        status(reason)
        if (wasCollecting) toast("수집 중지 · ${total}건 저장됨. $reason")
    }

    private fun disableByUser() {
        cancelCollection("사용자가 접근성 서비스 끄기를 선택함")
        detachControls()
        if (connected === this) connected = null
        // Only the explicit settings action may switch the system service off.
        disableSelf()
    }

    private fun resetOverlayRetry() {
        overlayAttachQueued = false
        overlayAttachAttempts = 0
        lastOverlayRetryAt = SystemClock.elapsedRealtime()
    }

    private fun restoreOverlayForOfficialApp() {
        if (!RecordStore.consent(this) || appRoot() == null) return
        if (overlay != null && overlayDarkMode != themeDark()) {
            overlayLayout?.let { lp ->
                getSharedPreferences("floating_menu_position", MODE_PRIVATE).edit()
                    .putInt("x", lp.x).putInt("y", lp.y).apply()
            }
            detachControls()
        }
        if (!wasOfficialInForeground) {
            // A fresh official-app visit is a fresh opportunity even if the
            // previous visit exhausted a manufacturer's overlay attach retries.
            resetOverlayRetry()
            wasOfficialInForeground = true
            overlayUserHiddenThisVisit = false
        }
        if (overlayUserHiddenThisVisit) return
        if (overlay == null) {
            if (overlayAttachAttempts >= 5 && SystemClock.elapsedRealtime() - lastOverlayRetryAt >= 5000L) {
                resetOverlayRetry()
            }
            ensureOverlay()
        } else overlay?.visibility = View.VISIBLE
    }

    private fun ensureOverlay() {
        if (overlay != null || overlayAttachQueued || overlayAttachAttempts >= 5 || overlayUserHiddenThisVisit) return
        overlayAttachQueued = true
        handler.postDelayed({
            overlayAttachQueued = false
            if (overlay == null && connected === this && !overlayUserHiddenThisVisit &&
                RecordStore.consent(this) && appRoot() != null) {
                overlayAttachAttempts++
                attachControls()
                ensureOverlay()
            }
        }, 450L)
    }

    private fun dismissOverlayForVisit() {
        if (active || startPending || startCheckInProgress) {
            cancelCollection("사용자가 플로팅 메뉴를 닫아 수집을 중지했어요")
        }
        overlayUserHiddenThisVisit = true
        overlay?.visibility = View.GONE
        toast("메뉴를 잠시 숨겼어요 · 화면을 이동했다 돌아오면 다시 열려요")
    }

    /** Compact Lunar Satellite Pod: ALL three controls remain usable, with full-surface drag & pinch/rim resize. */
    private fun attachControls() {
        if (overlay != null || appRoot() == null) return
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val prefs = getSharedPreferences("floating_menu_position", MODE_PRIVATE)
        // Keep old saved zoom levels, but allow a dramatically smaller new minimum.
        overlayZoom = prefs.getFloat("pinch_zoom",
            if (prefs.getBoolean("collapsed", true)) 0.68f else 1.2f).coerceIn(0.4f, 1.45f)
        overlayExpanded = overlayZoom >= 0.98f
        overlayDarkMode = themeDark()
        overlayPinchInProgress = false
        overlayCornerResizing = false

        val screenWidth = resources.displayMetrics.widthPixels
        val screenHeight = resources.displayMetrics.heightPixels
        val savedX = prefs.getInt("x", (screenWidth - floatingMenuWidth()) / 2)
        val savedY = prefs.getInt("y", (screenHeight * 0.64f).toInt())
        val params = WindowManager.LayoutParams(
            floatingMenuWidth(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = savedX
            y = savedY
        }
        clampOverlayPosition(params, estimatedFloatingMenuHeight())
        overlayLayout = params

        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        var dragStartX = 0f
        var dragStartY = 0f
        var dragInitialX = 0
        var dragInitialY = 0
        var draggingWindow = false
        var longPressMoveActive = false
        var childCancelSent = false
        var edgeResizeCandidate = false
        var edgeStartZoom = overlayZoom
        var edgeHorizontalSign = 1f
        var downTimeMs = 0L
        var lastHeaderTapUpTime = 0L
        lateinit var wrap: LinearLayout
        lateinit var zoomDetector: ScaleGestureDetector
        var pinching = false
        var lastPinchSpan = 0f
        var customPinchScaled = false

        fun beginDrag(rawX: Float, rawY: Float) {
            dragStartX = rawX
            dragStartY = rawY
            dragInitialX = params.x
            dragInitialY = params.y
            draggingWindow = false
        }

        fun updateDrag(rawX: Float, rawY: Float): Boolean {
            val dx = rawX - dragStartX
            val dy = rawY - dragStartY
            if (!draggingWindow && (longPressMoveActive || hypot(dx.toDouble(), dy.toDouble()) > touchSlop)) {
                draggingWindow = true
            }
            if (draggingWindow) {
                params.x = dragInitialX + dx.toInt()
                params.y = dragInitialY + dy.toInt()
                clampOverlayPosition(params, wrap.height.coerceAtLeast(estimatedFloatingMenuHeight()))
                runCatching { wm?.updateViewLayout(wrap, params) }
            }
            return draggingWindow
        }

        fun finishDrag() {
            if (draggingWindow) {
                draggingWindow = false
                prefs.edit().putInt("x", params.x).putInt("y", params.y).apply()
            }
        }

        val longPressRunnable = Runnable {
            if (!pinching && !overlayCornerResizing && overlay != null) {
                longPressMoveActive = true
                edgeResizeCandidate = false
                draggingWindow = true
                overlayBlockTapsUntil = SystemClock.uptimeMillis() + 320L
            }
        }

        fun cancelLongPress() {
            this@CollectorAccessibilityService.handler.removeCallbacks(longPressRunnable)
        }

        fun scheduleLongPress() {
            this@CollectorAccessibilityService.handler.removeCallbacks(longPressRunnable)
            this@CollectorAccessibilityService.handler.postDelayed(longPressRunnable, 260L)
        }

        fun isInViewBounds(target: View?, x: Float, y: Float): Boolean {
            if (target == null || target.visibility != View.VISIBLE || overlay == null) return false
            var left = 0f
            var top = 0f
            var cur: View? = target
            while (cur != null && cur !== wrap) {
                left += cur.left
                top += cur.top
                cur = cur.parent as? View
            }
            return x >= left && x <= left + target.width && y >= top && y <= top + target.height
        }

        fun isActionOrCloseTarget(x: Float, y: Float): Boolean {
            if (isInViewBounds(overlayHideButton, x, y)) return true
            return overlayActionButtons.any { isInViewBounds(it, x, y) }
        }

        wrap = object : LinearLayout(this) {
            private var interceptDownX = 0f
            private var interceptDownY = 0f

            private fun dispatchCancelToChildren(event: MotionEvent) {
                if (!childCancelSent) {
                    childCancelSent = true
                    val cancel = MotionEvent.obtain(event)
                    cancel.action = MotionEvent.ACTION_CANCEL
                    super.dispatchTouchEvent(cancel)
                    cancel.recycle()
                }
            }

            override fun dispatchTouchEvent(event: MotionEvent): Boolean {
                if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                    pinching = false
                    lastPinchSpan = 0f
                    customPinchScaled = false
                    longPressMoveActive = false
                    childCancelSent = false
                    overlayCornerResizing = false
                    downTimeMs = SystemClock.uptimeMillis()
                    beginDrag(event.rawX, event.rawY)
                    val rim = dp(16).toFloat()
                    val viewW = this.width
                    val viewH = this.height
                    val onRim = viewW > 0 && viewH > 0 &&
                        (event.x <= rim || event.x >= viewW - rim || event.y >= viewH - rim)
                    edgeResizeCandidate = onRim && !isInViewBounds(overlayHideButton, event.x, event.y)
                    edgeStartZoom = overlayZoom
                    edgeHorizontalSign = if (viewW > 0 && event.x < viewW * 0.35f) -1f else 1f
                    scheduleLongPress()
                }
                if (event.pointerCount >= 2 && !pinching) {
                    cancelLongPress()
                    pinching = true
                    longPressMoveActive = false
                    draggingWindow = false
                    overlayCornerResizing = false
                    edgeResizeCandidate = false
                    overlayPinchInProgress = true
                    overlayBlockTapsUntil = SystemClock.uptimeMillis() + 420L
                    lastPinchSpan = hypot(
                        (event.getX(1) - event.getX(0)).toDouble(),
                        (event.getY(1) - event.getY(0)).toDouble()
                    ).toFloat()
                    // Cancel a possible first-finger button press before scaling.
                    val cancel = MotionEvent.obtain(event)
                    cancel.action = MotionEvent.ACTION_CANCEL
                    super.dispatchTouchEvent(cancel)
                    cancel.recycle()
                    childCancelSent = true
                }
                // The detector also sees DOWN so its second-pointer span is valid.
                zoomDetector.onTouchEvent(event)
                if (event.pointerCount >= 2) {
                    val span = hypot(
                        (event.getX(1) - event.getX(0)).toDouble(),
                        (event.getY(1) - event.getY(0)).toDouble()
                    ).toFloat()
                    // Bridge small two-finger spans inside compact windows where Android's mMinSpan blocks scaling.
                    if (!zoomDetector.isInProgress && lastPinchSpan >= dp(8) && span >= dp(8)) {
                        if (abs(span - lastPinchSpan) >= dp(2)) {
                            val deltaRatio = (span / lastPinchSpan).coerceIn(0.90f, 1.12f)
                            applyOverlayZoom(overlayZoom * deltaRatio, this)
                            customPinchScaled = true
                            lastPinchSpan = span
                        }
                    } else {
                        lastPinchSpan = span
                    }
                    return true
                }
                if (pinching) {
                    if (event.actionMasked == MotionEvent.ACTION_UP ||
                        event.actionMasked == MotionEvent.ACTION_CANCEL) {
                        cancelLongPress()
                        pinching = false
                        overlayPinchInProgress = false
                        overlayBlockTapsUntil = SystemClock.uptimeMillis() + 420L
                        if (customPinchScaled) {
                            customPinchScaled = false
                            saveOverlayZoomAndPosition()
                        }
                    }
                    return true
                }
                if (event.actionMasked == MotionEvent.ACTION_MOVE) {
                    val dx = event.rawX - dragStartX
                    val dy = event.rawY - dragStartY
                    val moved = hypot(dx.toDouble(), dy.toDouble()) > touchSlop
                    if (longPressMoveActive) {
                        dispatchCancelToChildren(event)
                        updateDrag(event.rawX, event.rawY)
                        return true
                    }
                    if (edgeResizeCandidate && moved) {
                        cancelLongPress()
                        edgeResizeCandidate = false
                        overlayCornerResizing = true
                        overlayBlockTapsUntil = SystemClock.uptimeMillis() + 300L
                        dispatchCancelToChildren(event)
                    }
                    if (overlayCornerResizing) {
                        val dragDelta = ((dx * edgeHorizontalSign) + dy * 0.35f) /
                            dp(160).toFloat().coerceAtLeast(1f)
                        applyOverlayZoom(edgeStartZoom + dragDelta, this)
                        return true
                    }
                    if (moved) {
                        cancelLongPress()
                    }
                }
                if (event.actionMasked == MotionEvent.ACTION_UP ||
                    event.actionMasked == MotionEvent.ACTION_CANCEL) {
                    cancelLongPress()
                    edgeResizeCandidate = false
                    if (overlayCornerResizing) {
                        overlayCornerResizing = false
                        overlayBlockTapsUntil = SystemClock.uptimeMillis() + 260L
                        saveOverlayZoomAndPosition()
                        return true
                    }
                    if (longPressMoveActive) {
                        longPressMoveActive = false
                        dispatchCancelToChildren(event)
                        finishDrag()
                        overlayBlockTapsUntil = SystemClock.uptimeMillis() + 240L
                        return true
                    }
                    // Double-tap on header badge or status area toggles compact <-> expanded size immediately.
                    val totalMove = hypot((event.rawX - dragStartX).toDouble(), (event.rawY - dragStartY).toDouble())
                    if (event.actionMasked == MotionEvent.ACTION_UP &&
                        !draggingWindow &&
                        totalMove <= touchSlop &&
                        SystemClock.uptimeMillis() - downTimeMs <= 250L &&
                        !isActionOrCloseTarget(event.x, event.y)) {
                        val now = SystemClock.uptimeMillis()
                        if (now - lastHeaderTapUpTime <= 320L) {
                            lastHeaderTapUpTime = 0L
                            val targetZoom = if (overlayExpanded) 0.68f else 1.18f
                            applyOverlayZoom(targetZoom, this)
                            saveOverlayZoomAndPosition()
                            return true
                        } else {
                            lastHeaderTapUpTime = now
                        }
                    }
                }
                return super.dispatchTouchEvent(event)
            }

            override fun onInterceptTouchEvent(event: MotionEvent): Boolean {
                if (pinching || overlayCornerResizing || longPressMoveActive || event.pointerCount >= 2) return false
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        interceptDownX = event.rawX
                        interceptDownY = event.rawY
                        return false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX - interceptDownX
                        val dy = event.rawY - interceptDownY
                        if (hypot(dx.toDouble(), dy.toDouble()) > touchSlop) {
                            cancelLongPress()
                            updateDrag(event.rawX, event.rawY)
                            return true
                        }
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        draggingWindow = false
                    }
                }
                return false
            }

            @android.annotation.SuppressLint("ClickableViewAccessibility")
            override fun onTouchEvent(event: MotionEvent): Boolean {
                if (pinching || overlayCornerResizing) return true
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> return true
                    MotionEvent.ACTION_MOVE -> {
                        updateDrag(event.rawX, event.rawY)
                        return true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        finishDrag()
                        return true
                    }
                }
                return super.onTouchEvent(event)
            }
        }.apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(9), dp(10), dp(10))
            background = overlayPanelDrawable(overlayDarkMode, radiusDp = 28)
            clipToOutline = true
            elevation = dp(10).toFloat()
            contentDescription = "근무로그 수집 메뉴. 길게 누르거나 끌어 이동하고, 두 손가락 핀치·더블 탭·테두리 드래그로 크기를 조절하세요"
        }

        zoomDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                // Smooth pinch scaling; preserve double-factor formula compatibility.
                val factor = detector.scaleFactor * detector.scaleFactor
                val next = (overlayZoom * factor).coerceIn(0.4f, 1.45f)
                applyOverlayZoom(next, wrap)
                return true
            }
            override fun onScaleEnd(detector: ScaleGestureDetector) {
                getSharedPreferences("floating_menu_position", MODE_PRIVATE).edit()
                    .putFloat("pinch_zoom", overlayZoom)
                    .putBoolean("collapsed", !overlayExpanded).apply()
            }
        })

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val stateBadge = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 10.5f
            setTypeface(typeface, Typeface.BOLD)
            maxLines = 1
            setHorizontallyScrolling(false)
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(dp(10), 0, dp(10), 0)
            contentDescription = "수집 상태"
        }
        val dragHandle = stateBadge
        overlayHandle = dragHandle
        overlayStateBadge = stateBadge
        header.addView(stateBadge, LinearLayout.LayoutParams(0, dp(28), 1f).apply {
            marginEnd = dp(6)
        })
        val hideButton = TextView(this).apply {
            text = "✕"
            textSize = 11f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(if (overlayDarkMode) Color.parseColor("#CBD5E1") else Color.parseColor("#334155"))
            background = panelBackground(
                Color.parseColor(if (overlayDarkMode) "#1C2747" else "#EBF2FF"),
                Color.parseColor(if (overlayDarkMode) "#3B5288" else "#BFD2F5"),
                radiusDp = 12
            )
            contentDescription = "떠 있는 메뉴 잠시 닫기"
            setOnClickListener {
                if (!overlayPinchInProgress && !overlayCornerResizing &&
                    SystemClock.uptimeMillis() >= overlayBlockTapsUntil) {
                    dismissOverlayForVisit()
                }
            }
        }
        overlayHideButton = hideButton
        header.addView(hideButton, LinearLayout.LayoutParams(dp(28), dp(28)))
        wrap.addView(header)

        // Always visible, including the collapsed 3-button toolbar.
        val compact = TextView(this).apply {
            textSize = 10.5f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
            minHeight = dp(34)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            isFocusable = true
        }
        compactStatus = compact
        wrap.addView(compact)
        compact.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topSpace(6) }
        latestStatus = getSharedPreferences("collection_ui", MODE_PRIVATE)
            .getString("last_status", latestStatus).orEmpty().ifBlank { "○ 대기 중 · 목록 수집을 눌러 주세요" }
        if (!active && !startPending && (latestStatus.contains("수집 중") ||
                latestStatus.contains("준비 확인 중") || latestStatus.contains("로딩 확인 중"))) {
            latestStatus = "이전 수집이 종료되었습니다 · 목록 수집을 다시 눌러 주세요"
            getSharedPreferences("collection_ui", MODE_PRIVATE).edit()
                .putString("last_status", latestStatus).apply()
        }
        updateCompactStatus()

        val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val status = TextView(this).apply {
            text = latestStatus
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
            minHeight = dp(40)
            setLineSpacing(dp(2).toFloat(), 1.06f)
            setTextColor(if (overlayDarkMode) Color.parseColor("#E2ECFF") else Color.parseColor("#1E293B"))
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        info = status
        details.addView(status, LinearLayout.LayoutParams(-1, -2).apply { topSpace(6) })
        // Inset the actual hit targets from the curved panel edge. The blank rim
        // is safe to touch when starting a two-finger pinch or rim resize.
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(3), dp(6), dp(3), dp(3))
        }
        val collect = overlayButton("목록 수집", Color.parseColor("#3B5BDB"), Color.WHITE) { begin() }
        val changeDate = overlayButton("날짜 수정", Color.parseColor("#FFE16B"), Color.parseColor("#4F3400")) {
            openDateEditor()
        }
        val stopButton = overlayButton("수집 중지", Color.parseColor("#FFF0F4"), Color.parseColor("#B52A57")) {
            cancelCollection("사용자가 수집 중지")
        }
        buttons.addView(collect)
        buttons.addView(changeDate.apply { (layoutParams as LinearLayout.LayoutParams).marginStart = dp(7) })
        buttons.addView(stopButton.apply { (layoutParams as LinearLayout.LayoutParams).marginStart = dp(7) })
        overlayActionButtons = listOf(collect, changeDate, stopButton)
        details.addView(buttons)
        wrap.addView(details)
        overlayDetails = details
        // Never set details GONE: compact mode must retain the 3 action buttons.
        applyFloatingMenuSize(wrap)

        dragHandle.setOnTouchListener(object : View.OnTouchListener {
            override fun onTouch(view: View, event: MotionEvent): Boolean {
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        beginDrag(event.rawX, event.rawY)
                        return false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (updateDrag(event.rawX, event.rawY)) {
                            return true
                        }
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        if (draggingWindow) {
                            finishDrag()
                            return true
                        }
                    }
                }
                return false
            }
        })

        try {
            wm?.addView(wrap, params)
            overlay = wrap
            wrap.post {
                if (overlay === wrap) {
                    clampOverlayPosition(params, wrap.height.coerceAtLeast(estimatedFloatingMenuHeight()))
                    runCatching { wm?.updateViewLayout(wrap, params) }
                }
            }
        } catch (error: Exception) {
            overlayLayout = null
            overlayDetails = null
            compactStatus = null
            overlayStateBadge = null
            overlayHandle = null
            overlayHideButton = null
            overlayActionButtons = emptyList()
            toast("메뉴 표시 실패: ${error.localizedMessage}")
        }
    }

    private fun LinearLayout.LayoutParams.topSpace(dpValue: Int) {
        topMargin = dp(dpValue)
    }

    private fun applyOverlayZoom(nextZoom: Float, wrap: LinearLayout) {
        val next = nextZoom.coerceIn(0.4f, 1.45f)
        if (abs(next - overlayZoom) < 0.003f) return
        val oldWidth = floatingMenuWidth()
        val wasExpanded = overlayExpanded
        overlayZoom = next
        // Hysteresis prevents compact/expanded layout snapping when zooming near the boundary.
        overlayExpanded = if (overlayExpanded) overlayZoom >= 0.90f else overlayZoom >= 1.00f
        if (wasExpanded != overlayExpanded) applyFloatingMenuSize(wrap)
        overlayLayout?.let { params ->
            val newWidth = floatingMenuWidth()
            if (abs(newWidth - oldWidth) >= dp(2) || wasExpanded != overlayExpanded) {
                params.width = newWidth
                clampOverlayPosition(params, wrap.height.coerceAtLeast(estimatedFloatingMenuHeight()))
                runCatching { wm?.updateViewLayout(wrap, params) }
                if (wasExpanded != overlayExpanded) {
                    wrap.post {
                        if (overlay === wrap && overlayLayout === params) {
                            clampOverlayPosition(params, wrap.height.coerceAtLeast(estimatedFloatingMenuHeight()))
                            runCatching { wm?.updateViewLayout(wrap, params) }
                        }
                    }
                }
            }
        }
    }

    private fun saveOverlayZoomAndPosition() {
        val ed = getSharedPreferences("floating_menu_position", MODE_PRIVATE).edit()
            .putFloat("pinch_zoom", overlayZoom)
            .putBoolean("collapsed", !overlayExpanded)
        overlayLayout?.let { ed.putInt("x", it.x).putInt("y", it.y) }
        ed.apply()
    }

    private fun floatingMenuWidth(): Int {
        val available = (resources.displayMetrics.widthPixels - dp(16)).coerceAtLeast(dp(1))
        // 164dp mini <-> 340dp expanded: a real size difference, not just text resizing.
        val progress = ((overlayZoom - 0.4f) / 1.05f).coerceIn(0f, 1f)
        return minOf(available, dp(164 + (progress * 176f).toInt()))
    }

    private fun estimatedFloatingMenuHeight(): Int = dp(if (overlayExpanded) 176 else 124)

    private fun themeDark(): Boolean {
        val prefs = getSharedPreferences("attendance_display", MODE_PRIVATE)
        return when (prefs.getString("theme_mode", null)) {
            "dark" -> true
            "light" -> false
            "system" -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
            else -> prefs.getBoolean("dark_mode", false)
        }
    }

    /** Clean 3-tier Lunar Satellite Pod: [status badge + X] + [status box] + [3 uniform action buttons]. */
    private fun applyFloatingMenuSize(wrap: LinearLayout) {
        val expanded = overlayExpanded
        wrap.setPadding(dp(if (expanded) 12 else 9), dp(if (expanded) 10 else 8),
            dp(if (expanded) 12 else 9), dp(if (expanded) 10 else 8))
        val headerH = dp(if (expanded) 30 else 26)
        info?.visibility = if (expanded) View.VISIBLE else View.GONE
        compactStatus?.visibility = if (expanded) View.GONE else View.VISIBLE
        compactStatus?.textSize = if (expanded) 11.5f else 10.5f
        overlayStateBadge?.textSize = if (expanded) 10.5f else 9.5f
        overlayStateBadge?.apply {
            setPadding(dp(if (expanded) 10 else 8), 0, dp(if (expanded) 10 else 8), 0)
            layoutParams = (layoutParams as LinearLayout.LayoutParams).apply {
                height = headerH
            }
        }
        overlayHideButton?.apply {
            textSize = if (expanded) 11.5f else 10f
            layoutParams = (layoutParams as LinearLayout.LayoutParams).apply {
                width = headerH
                height = headerH
            }
        }
        overlayDetails?.visibility = View.VISIBLE
        overlayActionButtons.forEachIndexed { index, button ->
            val longLabel = arrayOf("목록 수집", "날짜 수정", "수집 중지")
            val smallLabel = arrayOf("수집", "날짜", "중지")
            button.text = if (expanded) longLabel[index] else smallLabel[index]
            button.contentDescription = longLabel[index]
            button.textSize = if (expanded) 12f else 10.5f
            button.setPadding(dp(if (expanded) 4 else 2), 0, dp(if (expanded) 4 else 2), 0)
            button.layoutParams = (button.layoutParams as LinearLayout.LayoutParams).apply {
                height = dp(if (expanded) 48 else 42)
            }
        }
        updateCompactStatus()
    }

    /** Keep the floating controls inside the usable screen while allowing generous travel. */
    private fun clampOverlayPosition(params: WindowManager.LayoutParams, guessedHeight: Int) {
        val metrics = resources.displayMetrics
        val w = metrics.widthPixels
        val h = metrics.heightPixels
        params.x = params.x.coerceIn(0, (w - params.width).coerceAtLeast(0))
        val minY = dp(24)
        val maxY = (h - guessedHeight - dp(40)).coerceAtLeast(minY)
        params.y = params.y.coerceIn(minY, maxY)
    }

    private fun overlayButton(label: String, fill: Int, textColor: Int, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(if (overlayDarkMode && label == "날짜 수정") Color.parseColor("#FFE49E")
                else if (overlayDarkMode && label == "수집 중지") Color.parseColor("#FDA4AF")
                else textColor)
            background = when (label) {
                "날짜 수정" -> GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    if (overlayDarkMode) intArrayOf(Color.parseColor("#4B3720"), Color.parseColor("#6A4922"))
                    else intArrayOf(Color.parseColor("#FFE16B"), Color.parseColor("#FFD45D"))).apply {
                    cornerRadius = dp(25).toFloat()
                    setStroke(dp(1), Color.parseColor(if (overlayDarkMode) "#A37233" else "#EAB308"))
                }
                "목록 수집" -> GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    if (overlayDarkMode) intArrayOf(Color.parseColor("#2563EB"), Color.parseColor("#0891B2"))
                    else intArrayOf(Color.parseColor("#3B5BDB"), Color.parseColor("#0284C7"))).apply {
                    cornerRadius = dp(25).toFloat()
                    setStroke(dp(1), Color.parseColor(if (overlayDarkMode) "#38BDF8" else "#2563EB"))
                }
                else -> panelBackground(
                    if (overlayDarkMode) Color.parseColor("#432133") else fill,
                    if (overlayDarkMode) Color.parseColor("#9D4770") else Color.parseColor("#F4AFBF"),
                    radiusDp = 25
                )
            }
            gravity = Gravity.CENTER
            textSize = 11f
            maxLines = 1
            setHorizontallyScrolling(false)
            ellipsize = android.text.TextUtils.TruncateAt.END
            minWidth = 0
            minHeight = 0
            setPadding(dp(2), 0, dp(2), 0)
            @android.annotation.SuppressLint("ClickableViewAccessibility")
            setOnTouchListener { v, event ->
                if (android.animation.ValueAnimator.areAnimatorsEnabled()) {
                    when (event.actionMasked) {
                        MotionEvent.ACTION_DOWN -> {
                            v.animate().cancel()
                            v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(80L).start()
                        }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                            v.animate().cancel()
                            v.animate().scaleX(1f).scaleY(1f).setDuration(150L)
                                .setInterpolator(android.view.animation.OvershootInterpolator(1.5f)).start()
                        }
                    }
                }
                false
            }
            setOnClickListener {
                if (!overlayPinchInProgress && SystemClock.uptimeMillis() >= overlayBlockTapsUntil) {
                    if (!overlayCornerResizing) action()
                }
            }
            layoutParams = LinearLayout.LayoutParams(0, dp(43), 1f)
        }
    }

    private fun overlayPanelDrawable(dark: Boolean, radiusDp: Int = 28): Drawable {
        val radius = dp(radiusDp).toFloat()
        val gradColors = if (dark) {
            intArrayOf(Color.parseColor("#0B1124"), Color.parseColor("#111B36"), Color.parseColor("#0A1022"))
        } else {
            intArrayOf(Color.parseColor("#FFFFFF"), Color.parseColor("#F4F8FF"), Color.parseColor("#EAF2FF"))
        }
        val strokeColor = Color.parseColor(if (dark) "#354B82" else "#C5D7F7")
        val accentStops = intArrayOf(
            Color.parseColor("#F59E0B"),
            Color.parseColor("#38BDF8"),
            Color.parseColor("#818CF8"),
            Color.parseColor("#34D399")
        )
        return object : Drawable() {
            private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
            private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeWidth = dp(1).toFloat(); color = strokeColor
            }
            private val decorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
            private val orbitPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = dp(1).toFloat()
                pathEffect = DashPathEffect(floatArrayOf(dp(4).toFloat(), dp(3).toFloat()), 0f)
            }
            private val rect = RectF()
            private val clip = Path()
            private var cachedW = 0f
            private var cachedH = 0f
            private var solarGlowShader: Shader? = null
            private var cyanGlowShader: Shader? = null
            private var topAccentShader: Shader? = null

            override fun draw(canvas: Canvas) {
                rect.set(bounds)
                if (rect.width() <= 0f || rect.height() <= 0f) return
                if (rect.width() != cachedW || rect.height() != cachedH || bgPaint.shader == null) {
                    cachedW = rect.width()
                    cachedH = rect.height()
                    bgPaint.shader = LinearGradient(
                        rect.left, rect.top, rect.right, rect.bottom,
                        gradColors, null, Shader.TileMode.CLAMP
                    )
                    solarGlowShader = RadialGradient(
                        rect.left + dp(28), rect.top + dp(20), dp(70).toFloat(),
                        intArrayOf(
                            Color.argb(if (dark) 36 else 22, 245, 158, 11),
                            Color.argb(0, 245, 158, 11)
                        ), null, Shader.TileMode.CLAMP
                    )
                    cyanGlowShader = RadialGradient(
                        rect.right - dp(26), rect.bottom - dp(18), dp(68).toFloat(),
                        intArrayOf(
                            Color.argb(if (dark) 32 else 20, 56, 189, 248),
                            Color.argb(0, 56, 189, 248)
                        ), null, Shader.TileMode.CLAMP
                    )
                    topAccentShader = LinearGradient(
                        rect.left, rect.top, rect.right, rect.top,
                        accentStops, null, Shader.TileMode.CLAMP
                    )
                }
                clip.reset()
                clip.addRoundRect(rect, radius, radius, Path.Direction.CW)
                canvas.save()
                canvas.clipPath(clip)
                canvas.drawRoundRect(rect, radius, radius, bgPaint)

                // Subtle Lunar-Solar nebula radial glow + quantized orbital arc.
                decorPaint.alpha = 255
                decorPaint.shader = solarGlowShader
                canvas.drawCircle(rect.left + dp(28), rect.top + dp(20), dp(70).toFloat(), decorPaint)
                decorPaint.shader = cyanGlowShader
                canvas.drawCircle(rect.right - dp(26), rect.bottom - dp(18), dp(68).toFloat(), decorPaint)

                orbitPaint.color = Color.argb(if (dark) 44 else 28, 56, 189, 248)
                canvas.drawCircle(rect.right - dp(18), rect.top + dp(26), dp(34).toFloat(), orbitPaint)

                // Top quantum spectrum laser bar + inner glass highlight.
                decorPaint.shader = topAccentShader
                decorPaint.alpha = if (dark) 225 else 240
                canvas.drawRect(rect.left, rect.top, rect.right, rect.top + dp(2).toFloat(), decorPaint)
                decorPaint.shader = null
                decorPaint.color = Color.argb(if (dark) 26 else 160, 255, 255, 255)
                canvas.drawRect(rect.left + radius * 0.55f, rect.top + dp(2).toFloat(),
                    (rect.right - radius * 0.55f).coerceAtLeast(rect.left + radius * 0.55f),
                    rect.top + dp(3).toFloat(), decorPaint)

                canvas.restore()
                canvas.drawRoundRect(rect, radius, radius, borderPaint)
            }

            override fun getOutline(outline: Outline) {
                outline.setRoundRect(bounds, radius)
                outline.alpha = 0.96f
            }

            override fun setAlpha(alpha: Int) { bgPaint.alpha = alpha; borderPaint.alpha = alpha }
            override fun setColorFilter(cf: android.graphics.ColorFilter?) {
                bgPaint.colorFilter = cf; borderPaint.colorFilter = cf
            }
            @Suppress("OVERRIDE_DEPRECATION")
            @Deprecated("Deprecated in Java")
            override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
        }
    }

    private fun panelBackground(fill: Int, stroke: Int, radiusDp: Int = 25) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(radiusDp).toFloat()
        setColor(fill)
        if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }

    /** Open only our own Activity after the user explicitly presses the yellow button. */
    private fun openDateEditor() {
        if (active || startPending || startCheckInProgress) {
            status("수집을 먼저 완료하거나 중지한 뒤 날짜를 수정해 주세요")
            toast("수집 중에는 날짜를 바꿀 수 없습니다. 먼저 중지해 주세요")
            return
        }
        overlay?.visibility = View.GONE
        try {
            startActivity(Intent(this, MainActivity::class.java).apply {
                action = MainActivity.ACTION_EDIT_PERIOD
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            })
        } catch (e: RuntimeException) {
            // OEM background-start policy can differ; never weaken system protection.
            overlay?.visibility = View.VISIBLE
            status("화면 이동에 실패했습니다. 근무로그 앱을 직접 열어 주세요")
            toast("날짜 화면을 열 수 없습니다: ${e.localizedMessage}")
        }
    }

    private fun begin() {
        if (active) return status("이미 목록 수집 중입니다")
        if (startPending || startCheckInProgress) return status("목록 화면 준비 확인 중 · 잠시 후 다시 확인합니다")
        if (!RecordStore.consent(this)) return toast("먼저 근무로그 앱에서 접근성 사용 안내에 동의하세요.")
        if (appRoot()?.packageName?.toString() != OFFICIAL_ATTENDANCE_PACKAGE) {
            return status("한국장학재단 출근부 앱에서만 수집할 수 있습니다")
        }
        startPending = true
        startAttempts = 0
        val token = ++startRequestToken
        status("목록 화면 준비 확인 중 · 자동 재확인")
        scheduleStartCheck(token, 60L)
    }

    private fun scheduleStartCheck(token: Int, delayMs: Long) {
        if (!startPending || token != startRequestToken || startAttemptQueued) return
        startAttemptQueued = true
        handler.postDelayed({
            startAttemptQueued = false
            if (startPending && !active && token == startRequestToken && !startCheckInProgress) {
                attemptStart(token)
            }
        }, delayMs)
    }

    private fun startFailed(message: String) {
        startPending = false
        startCheckInProgress = false
        val visibleMonth = RecordStore.selectedMonth(this)
        val storedCount = RecordStore.read(this).count { it.date.startsWith(visibleMonth.toString()) }
        RecordStore.setLastCollection(this, visibleMonth, storedCount, 0, message)
        status(message)
        toast(message)
    }

    private fun attemptStart(token: Int) {
        if (!startPending || active || token != startRequestToken) return
        startAttempts++
        val root = appRoot()
        val candidatePackage = root?.packageName?.toString().orEmpty()
        if (candidatePackage != OFFICIAL_ATTENDANCE_PACKAGE) {
            if (startAttempts < 10) {
                status("공식 앱 화면 확인 대기 · ${startAttempts}/10")
                scheduleStartCheck(token, 550L)
            } else {
                startFailed("목록 화면 미확인 · 장학재단 조회 목록에서 수집 버튼을 다시 누르세요")
            }
            return
        }
        val text = root?.let { mergedAccessibilityText(it) }.orEmpty()
        val selected = RecordStore.selectedMonth(this)
        val visibleMonth = AttendanceParser.monthHeader(text)
        // When the official list clearly contains records for a different month,
        // match the dashboard to that verified list. Never guess without records.
        val effectiveMonth = if (visibleMonth != null && visibleMonth != selected &&
            AttendanceParser.fromListPage(text, visibleMonth).isNotEmpty()) visibleMonth else selected
        if (visibleMonth != null && visibleMonth != selected && effectiveMonth != visibleMonth) {
            startFailed("월 불일치: 앱 $selected / 화면 $visibleMonth · 날짜 설정을 확인하세요")
            return
        }
        val rows = AttendanceParser.fromListPage(text, effectiveMonth)
        if (rows.isNotEmpty()) {
            startPending = false
            if (selected != effectiveMonth) {
                RecordStore.setSelectedMonth(this, effectiveMonth)
                toast("공식 출근부 조회 목록에 맞춰 ${effectiveMonth.monthValue}월을 표시합니다")
            }
            startCollection(candidatePackage, effectiveMonth)
            return
        }
        // WebView often populates its accessibility nodes after the list is visible.
        if (startAttempts < 6) {
            status("목록 내용 로딩 확인 중 · ${startAttempts}/6")
            scheduleStartCheck(token, 500L)
            return
        }
        startFailed("접근성에서 근무 텍스트를 읽지 못했습니다. 원본 목록이 표시되는지 확인하세요")
    }

    private data class ScreenText(
        val fullText: String,
        val listText: String,
        val listBounds: Rect?
    )

    private fun startCollection(appPackage: String, ym: YearMonth) {
        if (active) return
        if (appPackage != OFFICIAL_ATTENDANCE_PACKAGE) {
            startPending = false
            return status("수집 대상 앱을 확인할 수 없습니다")
        }
        active = true
        startPending = false
        startRequestToken++
        transientRootRetries = 0
        emptyPageRetries = 0
        runId++
        targetPackage = appPackage
        month = ym
        pages = 0; collected = 0; repeated = 0; zeroRecordPages = 0
        previousSignature = ""; previousPageText = ""; previousListText = ""
        status("${ym.year}.${ym.monthValue} 목록 수집 중")
        val id = runId
        handler.postDelayed({ processPage(id) }, 300)
    }

    private fun processPage(id: Int) {
        if (!active || id != runId) return
        if (!CollectionSession.isOpen(this)) return suspendSession()
        if (pages >= 80) return stop("최대 80페이지 도달. 지금까지 기록을 확인하세요.")
        val visiblePackage = appRoot()?.packageName?.toString()
        if (visiblePackage != null && visiblePackage != targetPackage) {
            return stop("다른 앱으로 이동하여 수집을 중단했습니다")
        }
        val root = verifiedRoot()
        if (root == null) {
            transientRootRetries++
            if (transientRootRetries <= 4) {
                status("목록 화면 갱신 중 · 다시 확인 ${transientRootRetries}/4")
                handler.postDelayed({ processPage(id) }, 450L)
                return
            }
            return stop("화면 접근이 불가능하여 수집을 중단했습니다")
        }
        transientRootRetries = 0
        val ym = month ?: return stop("월 정보를 찾을 수 없습니다.")
        val screen = readScreenText(root)
        val fullText = screen.fullText
        val listChunk = screen.listText.ifBlank { fullText }
        val visibleMonth = AttendanceParser.monthHeader(fullText)
        // Once scrolling has started, only stop for month change if actual records
        // for a different month are shown (avoid stray notice dates mid-scroll).
        if (visibleMonth != null && visibleMonth != ym &&
            (pages == 0 || AttendanceParser.fromListPage(fullText, visibleMonth).isNotEmpty())) {
            return stop("조회 월이 바뀌었습니다. 중지합니다.")
        }
        val currentFullRows = AttendanceParser.fromListPage(fullText, ym)
        val bridgedListRows = AttendanceParser.fromOverlappingPages(previousListText, listChunk, ym)
        val previousListRows = if (previousListText.isBlank()) emptyList() else AttendanceParser.fromListPage(previousListText, ym)
        val previousPageBridged = AttendanceParser.fromOverlappingPages(previousPageText, fullText, ym)
        val entries = AttendanceParser.unique(currentFullRows + bridgedListRows + previousPageBridged)
        val hasCurrentContent = currentFullRows.isNotEmpty() ||
            bridgedListRows.size > previousListRows.size ||
            (listChunk.contains(":") && AttendanceParser.fromOverlappingPages(previousListText, listChunk, ym).isNotEmpty())
        if (entries.isNotEmpty() && (hasCurrentContent || pages == 0)) {
            emptyPageRetries = 0
            processParsed(id, root, entries, fullText, listChunk, screen.listBounds)
        } else if (pages > 0 && emptyPageRetries < 2) {
            emptyPageRetries++
            status("목록 내용 불러오는 중 · 재확인 ${emptyPageRetries}/2")
            handler.postDelayed({ processPage(id) }, 550L)
        } else if (pages > 0) {
            return finish("목록 끝까지 확인하여 종료했습니다.")
        } else {
            return finish("화면에 읽을 수 있는 기록이 없습니다. 날짜·목록을 확인하세요.")
        }
    }

    private fun processParsed(
        id: Int,
        root: AccessibilityNodeInfo,
        records: List<WorkRecord>,
        fullText: String,
        listChunk: String,
        listBounds: Rect?
    ) {
        if (!active || id != runId) return
        val ym = month ?: return stop("월 정보 오류")
        pages++
        val before = RecordStore.read(this).count { it.date.startsWith(ym.toString()) }
        if (!RecordStore.add(this, AttendanceParser.fromOverlappingPages(previousListText, listChunk, ym) + records)) {
            return stop("저장 공간 오류 · 기존 기록 보호를 위해 수집 중지")
        }
        previousPageText = fullText.takeLast(2800)
        previousListText = listChunk.takeLast(2800)
        val after = RecordStore.read(this).count { it.date.startsWith(ym.toString()) }
        collected += after - before
        zeroRecordPages = if (records.isEmpty()) zeroRecordPages + 1 else 0
        if (zeroRecordPages >= 2 && after == 0) {
            return finish("두 화면에서 근무기록을 하나도 읽지 못했습니다. 조회 월/원본 화면을 확인하세요.")
        }
        val signature = listChunk.replace(Regex("\\s+"), " ").trim()
        repeated = if (signature == previousSignature) repeated + 1 else 0
        previousSignature = signature
        status("${ym.monthValue}월: ${pages}화면 / 전체 ${after}건 (신규 ${collected}건)")
        if (repeated >= 2) return finish("화면이 더 이상 변하지 않아 종료했습니다.")
        // If a node scroll action left the screen unchanged (repeated >= 1), force a touch swipe.
        scroll(root, listBounds, allowNodeAction = (repeated == 0)) { didScroll ->
            if (!active || id != runId) return@scroll
            if (!didScroll) finish("더 내려갈 수 없는 화면입니다.")
            else handler.postDelayed({ processPage(id) }, 1400)
        }
    }

    private fun scroll(
        root: AccessibilityNodeInfo,
        listBounds: Rect?,
        allowNodeAction: Boolean,
        next: (Boolean) -> Unit
    ) {
        if (!authorizedTargetVisible()) return next(false)
        if (allowNodeAction) {
            val scrollers = mutableListOf<AccessibilityNodeInfo>()
            walk(root) { node ->
                if (node.isScrollable && node.isVisibleToUser) {
                    val r = Rect().also { node.getBoundsInScreen(it) }
                    if (r.width() > dp(200) && r.height() > dp(180)) scrollers += node
                }
            }
            // Prefer large vertical scrollable areas over small inner horizontal strips.
            val candidates = scrollers.sortedWith(
                compareByDescending<AccessibilityNodeInfo> { node ->
                    Rect().also { node.getBoundsInScreen(it) }.let { it.height() >= it.width() }
                }.thenByDescending { node ->
                    Rect().also { node.getBoundsInScreen(it) }.let { it.width().toLong() * it.height() }
                }
            )
            val scrollDownId = AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN.id
            for (n in candidates) {
                val supportsDown = n.actionList.any { it.id == scrollDownId }
                if (supportsDown && n.performAction(scrollDownId)) return next(true)
                if (n.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) return next(true)
            }
        }
        // Swipe inside safe vertical bounds of the list without letting the floating overlay swallow the touch.
        val size = resources.displayMetrics
        val w = size.widthPixels.toFloat().coerceAtLeast(200f)
        val h = size.heightPixels.toFloat().coerceAtLeast(300f)
        val leftMin = dp(16).toFloat().coerceAtMost(w * 0.30f)
        val leftMax = maxOf(leftMin, w - dp(72))
        val safeLeft = (listBounds?.left?.toFloat() ?: 0f).coerceIn(leftMin, leftMax)
        val rightMin = (safeLeft + dp(40)).coerceAtMost(w - dp(8))
        val rightMax = maxOf(rightMin, w - dp(8))
        val safeRight = (listBounds?.right?.toFloat() ?: w).coerceIn(rightMin, rightMax)
        val topMin = (h * 0.12f)
        val topMax = maxOf(topMin, h * 0.50f)
        val safeTop = (listBounds?.top?.toFloat() ?: (h * 0.14f)).coerceIn(topMin, topMax)
        val bottomMin = (safeTop + dp(96)).coerceAtMost(h * 0.84f)
        val bottomMax = maxOf(bottomMin, h * 0.84f)
        val safeBottom = (listBounds?.bottom?.toFloat() ?: (h * 0.80f)).coerceIn(bottomMin, bottomMax)
        val startYMin = (h * 0.25f)
        val startYMax = maxOf(startYMin, h * 0.84f)
        val startY = (safeTop + (safeBottom - safeTop) * 0.80f).coerceIn(startYMin, startYMax)
        val endCeiling = (startY - dp(80)).coerceAtLeast(16f)
        val endFloor = minOf(h * 0.14f, endCeiling)
        val endY = (safeTop + (safeBottom - safeTop) * 0.20f).coerceIn(endFloor, endCeiling)
        var swipeX = ((safeLeft + safeRight) * 0.50f).coerceIn(8f, (w - 8f).coerceAtLeast(8f))
        var needsPassthrough = false
        val lp = overlayLayout
        if (lp != null && overlay?.visibility == View.VISIBLE) {
            val ovH = (overlay?.height ?: 0).coerceAtLeast(estimatedFloatingMenuHeight())
            val ovTop = lp.y.toFloat()
            val ovBottom = ovTop + ovH
            if (startY >= ovTop - dp(12) && endY <= ovBottom + dp(12)) {
                val ovLeft = lp.x.toFloat() - dp(16)
                val ovRight = lp.x + lp.width.toFloat() + dp(16)
                if (swipeX in ovLeft..ovRight) {
                    swipeX = when {
                        ovLeft - safeLeft >= dp(36) -> (safeLeft + ovLeft) * 0.5f
                        safeRight - ovRight >= dp(36) -> (ovRight + safeRight) * 0.5f
                        else -> {
                            needsPassthrough = true
                            swipeX
                        }
                    }.coerceIn(8f, (w - 8f).coerceAtLeast(8f))
                }
            }
        }
        if (needsPassthrough) setOverlayTouchable(false)
        val path = Path().apply { moveTo(swipeX, startY); lineTo(swipeX, endY) }
        val gesture = runCatching {
            GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 460)).build()
        }.getOrNull()
        val ok = if (gesture != null) {
            runCatching {
                dispatchGesture(gesture, object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        setOverlayTouchable(true)
                        next(true)
                    }
                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        setOverlayTouchable(true)
                        next(false)
                    }
                }, handler)
            }.getOrDefault(false)
        } else false
        if (!ok) {
            setOverlayTouchable(true)
            next(false)
        }
    }

    /** Checks both user consent and the exact foreground package immediately before reading the accessibility tree. */
    private fun authorizedTargetVisible(): Boolean =
        RecordStore.consent(this) &&
            appRoot()?.packageName?.toString() == OFFICIAL_ATTENDANCE_PACKAGE

    private fun appRoot(): AccessibilityNodeInfo? {
        // Check before touching any third-party accessibility tree, including retries.
        if (!CollectionSession.isOpen(this) || !RecordStore.consent(this)) return null
        // The accessibility overlay or keyboard may temporarily become the active
        // root. Do not return null before checking the focused application window.
        val activeRoot = runCatching { rootInActiveWindow }.getOrNull()
        if (activeRoot?.packageName?.toString() == OFFICIAL_ATTENDANCE_PACKAGE) return activeRoot
        return runCatching {
            windows.asSequence()
                .filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION && (it.isActive || it.isFocused) }
                .mapNotNull { it.root }
                .firstOrNull { it.packageName?.toString() == OFFICIAL_ATTENDANCE_PACKAGE }
        }.getOrNull()
    }

    private fun verifiedRoot(): AccessibilityNodeInfo? {
        val root = appRoot() ?: return null
        if (root.packageName?.toString() != targetPackage) return null
        return root
    }

    private fun readScreenText(root: AccessibilityNodeInfo): ScreenText {
        val focusedNodes = mutableListOf<AccessibilityNodeInfo>()
        walk(root) { node ->
            val r = Rect().also { node.getBoundsInScreen(it) }
            if (node.isVisibleToUser && r.height() > dp(120) && r.width() > dp(140)) {
                if (node.isScrollable || node.className?.toString()?.contains("Recycler", true) == true || node.className?.toString()?.contains("List", true) == true) {
                    focusedNodes += node
                }
            }
        }
        val mainList = focusedNodes.maxByOrNull { node ->
            Rect().also { node.getBoundsInScreen(it) }.let { it.width().toLong() * it.height() }
        }
        val listBounds = mainList?.let { Rect().also { r -> it.getBoundsInScreen(r) } }
        val all = readText(root)
        val listArea = mainList?.let { readText(it) }.orEmpty()
        return ScreenText(all, listArea, listBounds)
    }

    private fun mergedAccessibilityText(root: AccessibilityNodeInfo): String {
        val screen = readScreenText(root)
        return listOf(screen.fullText, screen.listText)
            .filter { it.isNotBlank() }
            .distinct()
            .joinToString("\n")
    }

    private fun readText(root: AccessibilityNodeInfo): String {
        data class Line(val y: Int, val x: Int, val value: String)
        val lines = mutableListOf<Line>()
        val seen = hashSetOf<String>()
        walk(root) { n ->
            val value = (n.text ?: n.contentDescription)?.toString()?.trim().orEmpty()
            if (value.isBlank()) return@walk
            val r = Rect().also { n.getBoundsInScreen(it) }
            if (!n.isVisibleToUser || r.width() <= 0 || r.height() <= 0) return@walk
            val key = "${r.left}|${r.top}|${r.right}|${r.bottom}|$value"
            if (seen.add(key)) lines += Line(r.centerY(), r.left, value)
        }
        val sorted = lines.sortedWith(compareBy(Line::y, Line::x))
        val bands = mutableListOf<MutableList<Line>>()
        for (line in sorted) {
            val band = bands.lastOrNull()
            if (band != null && abs(band.first().y - line.y) <= dp(14)) band.add(line)
            else bands.add(mutableListOf(line))
        }
        return bands.joinToString("\n") { band ->
            band.sortedBy { it.x }.joinToString(" ") { it.value }
        }
    }

    private fun walk(root: AccessibilityNodeInfo, action: (AccessibilityNodeInfo) -> Unit) {
        var count = 0
        fun visit(n: AccessibilityNodeInfo, depth: Int) {
            if (++count > 3200 || depth > 55) return
            action(n)
            for (i in 0 until n.childCount) {
                runCatching { n.getChild(i) }.getOrNull()?.let { visit(it, depth + 1) }
            }
        }
        visit(root, 0)
    }

    private fun finish(reason: String) {
        if (!active) return
        val ym = month
        val total = ym?.let { selected -> RecordStore.read(this).count { it.date.startsWith(selected.toString()) } } ?: 0
        RecordStore.setLastCollection(this, ym, total, collected, reason)
        active = false; runId++; startCheckToken++; startRequestToken++
        startPending = false; startCheckInProgress = false
        emptyPageRetries = 0
        setOverlayTouchable(true)
        handler.removeCallbacksAndMessages(null)
        scheduleOverlayRecovery()
        resetOverlayRetry()
        if (total > 0) {
            status("수집 완료 · 총 ${total}건 / 신규 ${collected}건 · 통계 탭에서 확인하세요")
            compactStatus?.announceForAccessibility("수집 완료. 전체 ${total}건, 신규 ${collected}건")
            toast("수집 완료: 전체 ${total}건 / 새 ${collected}건 · ${pages}화면. $reason")
        } else {
            status("확인 필요 · 읽은 기록 0건 · 조회 월과 화면을 확인하세요")
            toast("근무기록 0건: $reason")
        }
    }

    private fun stop(reason: String) {
        if (!active && !startCheckInProgress) return
        cancelCollection(reason)
    }

    private fun status(message: String) {
        latestStatus = message
        // Store only an operational status string, never raw accessibility content.
        getSharedPreferences("collection_ui", MODE_PRIVATE).edit().putString("last_status", message).apply()
        info?.text = message
        info?.setTextColor(if (overlayDarkMode) Color.parseColor(
            if (message.startsWith("수집 완료")) "#8FF4CC" else "#E2ECFF") else Color.parseColor(
            if (message.startsWith("수집 완료")) "#075E50" else "#1E293B"))
        updateCompactStatus()
    }

    private fun updateCompactStatus() {
        val appearance = FloatingCollectionStatus.from(
            latestStatus, active || startPending || startCheckInProgress)
        val badgeTextColor: Int
        val badgeGradient: IntArray
        val badgeStroke: Int
        val cardTextColor: Int
        val cardGradient: IntArray
        val cardStroke: Int
        when (appearance.phase) {
            CollectionDisplayPhase.COMPLETE -> {
                badgeTextColor = Color.WHITE
                badgeGradient = if (overlayDarkMode) intArrayOf(Color.parseColor("#059669"), Color.parseColor("#0891B2"))
                    else intArrayOf(Color.parseColor("#10B981"), Color.parseColor("#06B6D4"))
                badgeStroke = Color.parseColor(if (overlayDarkMode) "#34D399" else "#6EE7B7")
                cardTextColor = Color.parseColor(if (overlayDarkMode) "#A7F3D0" else "#065F46")
                cardGradient = if (overlayDarkMode) intArrayOf(Color.parseColor("#0D2B27"), Color.parseColor("#0E233A"))
                    else intArrayOf(Color.parseColor("#ECFDF5"), Color.parseColor("#E0F7FA"))
                cardStroke = Color.parseColor(if (overlayDarkMode) "#10B981" else "#34D399")
            }
            CollectionDisplayPhase.RUNNING -> {
                badgeTextColor = Color.WHITE
                badgeGradient = if (overlayDarkMode) intArrayOf(Color.parseColor("#2563EB"), Color.parseColor("#7C3AED"))
                    else intArrayOf(Color.parseColor("#3B5BDB"), Color.parseColor("#7C3AED"))
                badgeStroke = Color.parseColor(if (overlayDarkMode) "#38BDF8" else "#818CF8")
                cardTextColor = Color.parseColor(if (overlayDarkMode) "#BAE6FD" else "#1E3A8A")
                cardGradient = if (overlayDarkMode) intArrayOf(Color.parseColor("#162347"), Color.parseColor("#221C47"))
                    else intArrayOf(Color.parseColor("#EFF6FF"), Color.parseColor("#F5F3FF"))
                cardStroke = Color.parseColor(if (overlayDarkMode) "#38BDF8" else "#60A5FA")
            }
            CollectionDisplayPhase.WARNING -> {
                badgeTextColor = Color.WHITE
                badgeGradient = if (overlayDarkMode) intArrayOf(Color.parseColor("#E11D48"), Color.parseColor("#D97706"))
                    else intArrayOf(Color.parseColor("#F43F5E"), Color.parseColor("#F59E0B"))
                badgeStroke = Color.parseColor(if (overlayDarkMode) "#FB7185" else "#FDA4AF")
                cardTextColor = Color.parseColor(if (overlayDarkMode) "#FECDD3" else "#9F1239")
                cardGradient = if (overlayDarkMode) intArrayOf(Color.parseColor("#3B1826"), Color.parseColor("#382318"))
                    else intArrayOf(Color.parseColor("#FFF1F2"), Color.parseColor("#FFF7ED"))
                cardStroke = Color.parseColor(if (overlayDarkMode) "#F43F5E" else "#FB7185")
            }
            CollectionDisplayPhase.IDLE -> {
                badgeTextColor = Color.parseColor(if (overlayDarkMode) "#BAE6FD" else "#1E3A8A")
                badgeGradient = if (overlayDarkMode) intArrayOf(Color.parseColor("#1C274B"), Color.parseColor("#262250"))
                    else intArrayOf(Color.parseColor("#EEF4FF"), Color.parseColor("#EDE9FE"))
                badgeStroke = Color.parseColor(if (overlayDarkMode) "#3B5288" else "#BFD2F5")
                cardTextColor = Color.parseColor(if (overlayDarkMode) "#CBD5E1" else "#1E293B")
                cardGradient = if (overlayDarkMode) intArrayOf(Color.parseColor("#131D38"), Color.parseColor("#1B1F3F"))
                    else intArrayOf(Color.parseColor("#F4F8FF"), Color.parseColor("#F7F3FF"))
                cardStroke = Color.parseColor(if (overlayDarkMode) "#334778" else "#CBD8F6")
            }
        }
        fun pillGradient(colors: IntArray, stroke: Int, radius: Int): GradientDrawable =
            GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply {
                cornerRadius = dp(radius).toFloat()
                setStroke(dp(1), stroke)
            }
        // Visible even if the toolbar is collapsed, independently of detail text.
        overlayStateBadge?.apply {
            text = appearance.badge
            contentDescription = appearance.badge
            setTextColor(badgeTextColor)
            background = pillGradient(badgeGradient, badgeStroke, 14)
        }
        info?.apply {
            background = pillGradient(cardGradient, cardStroke, 14)
            setTextColor(cardTextColor)
        }
        compactStatus?.apply {
            text = appearance.compactText
            contentDescription = latestStatus
            setTextColor(cardTextColor)
            background = pillGradient(cardGradient, cardStroke, 14)
        }
    }

    private fun toast(message: String) {
        runCatching { Toast.makeText(applicationContext, message, Toast.LENGTH_LONG).show() }
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
