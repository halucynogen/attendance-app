package io.local.attendance

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import java.time.YearMonth
import kotlin.math.max

/**
 * User-initiated, read-only monthly LIST collector.
 * Never taps attendance modification, approval, submit, login or individual dates.
 * A11y text preferred; one-page OCR fallback requires Android 11+ and a permitted screenshot.
 */
class CollectorAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var overlay: LinearLayout? = null
    private var info: TextView? = null
    private var wm: WindowManager? = null
    private var active = false
    private var runId = 0
    private var targetPackage = ""
    private var month: YearMonth? = null
    private var pages = 0
    private var collected = 0
    private var repeated = 0
    private var previousSignature = ""
    private var screenshotTried = 0
    private var previousPageText = ""
    private var startCheckInProgress = false
    private var startCheckToken = 0
    private var startedByOcr = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        attachControls()
    }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // No unsolicited collection; only the user presses the visible Start button.
    }
    override fun onInterrupt() = stop("서비스가 중단됐습니다.")
    override fun onDestroy() {
        stop("서비스 종료")
        overlay?.let { runCatching { wm?.removeView(it) } }
        overlay = null
        super.onDestroy()
    }

    private fun attachControls() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(5), dp(3), dp(5), dp(3))
            setBackgroundColor(0xEDFFFFFF.toInt())
        }
        val status = TextView(this).apply { text = "목록 화면에서 시작"; textSize = 12f; maxLines = 3; setTextColor(0xFF222222.toInt()) }
        info = status
        wrap.addView(status)
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(Button(this).apply { text = "목록 수집"; setOnClickListener { begin() } })
        buttons.addView(Button(this).apply { text = "중지"; setOnClickListener { stop("사용자 중지") } })
        wrap.addView(buttons)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(5); y = dp(80) }
        try { wm?.addView(wrap, params); overlay = wrap }
        catch (e: Exception) { toast("표시 실패: ${e.localizedMessage}") }
    }

    private fun begin() {
        if (active || startCheckInProgress) return
        if (!RecordStore.consent(this)) return toast("먼저 수집 앱에서 권한 안내에 동의하세요.")
        val root = rootInActiveWindow ?: return toast("현재 화면 텍스트에 접근할 수 없습니다.")
        val candidatePackage = root.packageName?.toString().orEmpty()
        if (candidatePackage.isBlank() || candidatePackage == packageName) {
            return toast("한국장학재단 조회 목록 화면에서 실행하세요.")
        }
        val text = readText(root)
        val ym = AttendanceParser.monthHeader(text)
        if (ym != null && text.contains("국가근로장학금") && text.contains("조회")) {
            startCollection(candidatePackage, ym, false)
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // If the official app hides the accessibility text, verify the visible screen
            // via on-device OCR BEFORE allowing collection. A failed check never starts it.
            verifyStartScreenshot(candidatePackage)
        } else {
            toast("목록 화면/조회 월을 읽지 못했습니다. 저장된 스크린샷 OCR을 사용하세요.")
        }
    }

    private fun startCollection(appPackage: String, ym: YearMonth, viaOcr: Boolean) {
        if (active) return
        active = true
        runId++
        targetPackage = appPackage
        month = ym
        startedByOcr = viaOcr
        pages = 0; collected = 0; repeated = 0
        previousSignature = ""; screenshotTried = 0; previousPageText = ""
        status("${ym.year}.${ym.monthValue} 목록 수집 중")
        val id = runId
        handler.postDelayed({ processPage(id) }, if (viaOcr) 1500 else 300)
    }

    private fun verifyStartScreenshot(candidatePackage: String) {
        startCheckInProgress = true
        val checkId = ++startCheckToken
        status("목록 화면 확인용 OCR 진행 중")
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onFailure(errorCode: Int) {
                    if (checkId != startCheckToken) return
                    startCheckInProgress = false
                    toast("목록 확인용 화면 캡처 실패($errorCode). 수집을 시작하지 않았습니다.")
                }
                override fun onSuccess(screenshot: ScreenshotResult) {
                    if (checkId != startCheckToken) { screenshot.hardwareBuffer.close(); return }
                    val hardware = screenshot.hardwareBuffer
                    val image = try {
                        Bitmap.wrapHardwareBuffer(hardware, screenshot.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                    } catch (_: Exception) { null } finally { hardware.close() }
                    if (image == null) {
                        startCheckInProgress = false
                        return toast("목록 화면을 읽지 못해 수집을 시작하지 않았습니다.")
                    }
                    val recognizer = TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
                    recognizer.process(InputImage.fromBitmap(image, 0))
                        .addOnSuccessListener { result ->
                            if (checkId != startCheckToken) return@addOnSuccessListener
                            startCheckInProgress = false
                            val stillSameApp = rootInActiveWindow?.packageName?.toString() == candidatePackage
                            val ym = AttendanceParser.monthHeader(result.text)
                            if (stillSameApp && ym != null && result.text.contains("국가근로장학금") &&
                                (result.text.contains("근무") || result.text.contains("조회"))) {
                                startCollection(candidatePackage, ym, true)
                            } else {
                                toast("조회 목록/월을 확인하지 못해 수집을 시작하지 않았습니다.")
                            }
                        }
                        .addOnFailureListener {
                            if (checkId == startCheckToken) {
                                startCheckInProgress = false
                                toast("화면 확인 OCR 실패. 수집을 시작하지 않았습니다.")
                            }
                        }
                        .addOnCompleteListener { recognizer.close(); image.recycle() }
                }
            })
        } catch (_: Exception) {
            if (checkId == startCheckToken) {
                startCheckInProgress = false
                toast("화면 확인용 캡처를 할 수 없어 수집을 시작하지 않았습니다.")
            }
        }
    }

    private fun processPage(id: Int) {
        if (!active || id != runId) return
        if (pages >= 60) return stop("최대 60페이지 도달. 지금까지 기록을 확인하세요.")
        val root = verifiedRoot() ?: return stop("대상 앱을 벗어났거나 화면 정보가 차단됐습니다.")
        val ym = month ?: return stop("월 정보를 찾을 수 없습니다.")
        val text = readText(root)
        val visibleMonth = AttendanceParser.monthHeader(text)
        if (visibleMonth != null && visibleMonth != ym) return stop("조회 월이 바뀌었습니다. 중지합니다.")
        val entries = AttendanceParser.fromOverlappingPages(previousPageText, text, ym)
        if (entries.isNotEmpty() && (AttendanceParser.fromListPage(text, ym).isNotEmpty() || text.contains(":"))) {
            processParsed(id, entries, text)
        } else {
            // A WebView may hide text from accessibility. Try OS screenshot once per page.
            readPageWithOcr(id, text)
        }
    }

    private fun readPageWithOcr(id: Int, accessibilityText: String) {
        if (!active || id != runId) return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return stop("텍스트를 읽을 수 없고, 이 기기는 자동 OCR을 지원하지 않습니다.")
        screenshotTried++
        status("$pages 페이지 · 접근성 텍스트 없음 → OCR 시도")
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onFailure(errorCode: Int) {
                    if (active && id == runId) stop("화면 캡처가 허용되지 않습니다($errorCode). 저장된 캡처 OCR을 사용하세요.")
                }
                override fun onSuccess(screenshot: ScreenshotResult) {
                    if (!active || id != runId) { screenshot.hardwareBuffer.close(); return }
                    val hardware = screenshot.hardwareBuffer
                    val image: Bitmap? = try {
                        Bitmap.wrapHardwareBuffer(hardware, screenshot.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                    } catch (_: Exception) { null } finally { hardware.close() }
                    if (image == null) return stop("캡처 이미지를 처리할 수 없습니다.")
                    val recognizer = TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
                    recognizer.process(InputImage.fromBitmap(image, 0))
                        .addOnSuccessListener { result ->
                            if (!active || id != runId) return@addOnSuccessListener
                            val ym = month ?: return@addOnSuccessListener
                            if (startedByOcr && (AttendanceParser.monthHeader(result.text) != ym ||
                                    !result.text.contains("국가근로장학금"))) {
                                stop("대상 월/출근부 화면을 확인할 수 없습니다. 수집을 중지했습니다.")
                                return@addOnSuccessListener
                            }
                            val rows = AttendanceParser.fromOverlappingPages(previousPageText, result.text, ym)
                            // Use the OCR text as page fingerprint so hidden WebView scrolls can be detected.
                            processParsed(id, rows, result.text.ifBlank { accessibilityText })
                        }
                        .addOnFailureListener { if (active && id == runId) stop("OCR 실패: ${it.localizedMessage}") }
                        .addOnCompleteListener { recognizer.close(); image.recycle() }
                }
            })
        } catch (e: Exception) { stop("캡처에 접근할 수 없습니다: ${e.localizedMessage}") }
    }

    private fun processParsed(id: Int, records: List<WorkRecord>, signatureText: String) {
        if (!active || id != runId) return
        val root = verifiedRoot() ?: return stop("대상 앱이 바뀌었습니다.")
        val ym = month ?: return stop("월 정보 오류")
        pages++
        val before = RecordStore.read(this).count { it.date.startsWith(ym.toString()) }
        RecordStore.add(this, AttendanceParser.fromOverlappingPages(previousPageText, signatureText, ym) + records)
        previousPageText = signatureText.takeLast(1600)
        val after = RecordStore.read(this).count { it.date.startsWith(ym.toString()) }
        collected += after - before
        val signature = signatureText.replace(Regex("\\s+"), " ").trim().takeLast(850)
        repeated = if (signature == previousSignature) repeated + 1 else 0
        previousSignature = signature
        status("${ym.monthValue}월: ${pages}화면 / 새 기록 ${collected}건")
        if (repeated >= 2) return finish("화면이 더 이상 변하지 않아 종료했습니다.")
        scroll(root) { didScroll ->
            if (!active || id != runId) return@scroll
            if (!didScroll) finish("더 내려갈 수 없는 화면입니다.")
            else handler.postDelayed({ processPage(id) }, 1400)
        }
    }

    private fun scroll(root: AccessibilityNodeInfo, next: (Boolean) -> Unit) {
        val scrollers = mutableListOf<AccessibilityNodeInfo>()
        walk(root) { node ->
            if (node.isScrollable && node.isVisibleToUser) {
                val r = Rect().also { node.getBoundsInScreen(it) }
                if (r.width() > dp(200) && r.height() > dp(180)) scrollers += node
            }
        }
        val candidates = scrollers.sortedBy { node ->
            Rect().also { node.getBoundsInScreen(it) }.let { it.width().toLong() * it.height() }
        }
        for (n in candidates) {
            if (n.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) return next(true)
        }
        // Some WebViews are scrollable only via a swipe. This gesture only moves the list.
        val size = resources.displayMetrics
        val w = size.widthPixels.toFloat(); val h = size.heightPixels.toFloat()
        val path = Path().apply { moveTo(w * .50f, h * .78f); lineTo(w * .50f, h * .37f) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 460)).build()
        val ok = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { next(true) }
            override fun onCancelled(gestureDescription: GestureDescription?) { next(false) }
        }, handler)
        if (!ok) next(false)
    }

    private fun verifiedRoot(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        if (root.packageName?.toString() != targetPackage) return null
        val text = readText(root)
        if (!text.contains("조회") && !startedByOcr) return null
        val visibleMonth = AttendanceParser.monthHeader(text)
        if (visibleMonth != null && visibleMonth != month) return null
        return root
    }

    private fun readText(root: AccessibilityNodeInfo): String {
        data class Line(val y: Int, val x: Int, val value: String)
        val lines = mutableListOf<Line>()
        val seen = hashSetOf<String>()
        walk(root) { n ->
            val value = (n.text ?: n.contentDescription)?.toString()?.trim().orEmpty()
            if (value.isBlank()) return@walk
            val r = Rect().also { n.getBoundsInScreen(it) }
            if (!n.isVisibleToUser || r.width() <= 0 || r.height() <= 0) return@walk
            val key = "${r.left}|${r.top}|${r.right}|${r.bottom}|$value"
            if (seen.add(key)) lines += Line(r.centerY(), r.left, value)
        }
        val sorted = lines.sortedWith(compareBy(Line::y, Line::x))
        val bands = mutableListOf<MutableList<Line>>()
        for (line in sorted) {
            val band = bands.lastOrNull()
            if (band != null && kotlin.math.abs(band.first().y - line.y) <= dp(14)) band.add(line)
            else bands.add(mutableListOf(line))
        }
        return bands.joinToString("\n") { band ->
            band.sortedBy { it.x }.joinToString(" ") { it.value }
        }
    }
    private fun walk(root: AccessibilityNodeInfo, action: (AccessibilityNodeInfo) -> Unit) {
        var count = 0
        fun visit(n: AccessibilityNodeInfo, depth: Int) {
            if (++count > 1500 || depth > 45) return
            action(n)
            for (i in 0 until n.childCount) n.getChild(i)?.let { visit(it, depth + 1) }
        }
        visit(root, 0)
    }
    private fun finish(reason: String) {
        if (!active) return
        active = false; runId++
        val message = "종료: ${collected}건 새로 저장 · ${pages}화면. $reason 수집 누락을 원본과 대조하세요."
        status(message); toast(message)
    }
    private fun stop(reason: String) {
        active = false; runId++
        startCheckToken++; startCheckInProgress = false
        status("중지: $reason (기존에 저장한 기록은 유지)")
        if (reason != "서비스 종료") toast(reason)
    }
    private fun status(message: String) { info?.text = message }
    private fun toast(message: String) { Toast.makeText(this, message, Toast.LENGTH_LONG).show() }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
