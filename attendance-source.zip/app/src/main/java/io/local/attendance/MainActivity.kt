package io.local.attendance

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import java.time.YearMonth

/** Native, dependency-light personal dashboard. No credentials or network permissions. */
class MainActivity : Activity() {
    private val openImage = 1101
    private val saveTxt = 1102
    private val saveCsv = 1103

    private val navy = Color.parseColor("#0F1E42")
    private val blue = Color.parseColor("#3460F6")
    private val blueDeep = Color.parseColor("#2948C2")
    private val blueSoft = Color.parseColor("#EEF3FF")
    private val aqua = Color.parseColor("#139785")
    private val greenSoft = Color.parseColor("#E8FBF4")
    private val amber = Color.parseColor("#B76B10")
    private val amberSoft = Color.parseColor("#FFF5E2")
    private val red = Color.parseColor("#B1373C")
    private val redSoft = Color.parseColor("#FFEFEF")
    private val surface = Color.parseColor("#F6F8FC")
    private val border = Color.parseColor("#E1E7F2")
    private val ink = Color.parseColor("#19243F")
    private val muted = Color.parseColor("#68748B")
    private val cardGray = Color.parseColor("#FBFCFE")

    private lateinit var shell: LinearLayout
    private lateinit var host: FrameLayout
    private lateinit var navigation: LinearLayout
    private lateinit var topBar: LinearLayout

    private var tab = 0
    private lateinit var month: YearMonth
    private var yearField: EditText? = null
    private var monthField: EditText? = null
    private var exportField: EditText? = null
    private var pasteField: EditText? = null
    private var draftMonth: YearMonth? = null
    private var draftText: String? = null

    private val versionName = "v0.8"
    private val minAndroidText = "Android 8.0 이상 (API 26+)"
    private val targetAndroidText = "권장: Android 13~15 / 갤럭시 One UI 환경"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        month = RecordStore.selectedMonth(this)

        shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(surface)
            clipToPadding = false
        }
        setContentView(shell)

        topBar = toolbar()
        shell.addView(topBar)
        host = FrameLayout(this)
        shell.addView(host, LinearLayout.LayoutParams(-1, 0, 1f))
        navigation = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.WHITE)
            elevation = dp(10).toFloat()
            setPadding(dp(10), dp(8), dp(10), dp(8))
            clipToPadding = false
        }
        shell.addView(navigation, LinearLayout.LayoutParams(-1, dp(76)))

        shell.setOnApplyWindowInsetsListener { _, insets ->
            applyInsets(insets)
            insets
        }
        shell.requestApplyInsets()
        renderTab()
    }

    override fun onResume() {
        super.onResume()
        if (::host.isInitialized) renderTab()
    }

    override fun onDestroy() {
        if (isFinishing) CollectorAccessibilityService.shutdownFromApp()
        super.onDestroy()
    }

    @Deprecated("Android back behavior across API levels")
    override fun onBackPressed() {
        CollectorAccessibilityService.shutdownFromApp()
        super.onBackPressed()
    }

    @Deprecated("For this small self-contained Android project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        if (requestCode == saveTxt || requestCode == saveCsv) {
            val text = if (requestCode == saveCsv) {
                AttendanceParser.csv(RecordStore.read(this), month)
            } else {
                draftText ?: AttendanceParser.export(currentRecords(), month)
            }
            try {
                contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                toast("파일 저장 완료")
            } catch (e: Exception) {
                toast("파일 저장 실패: ${e.localizedMessage}")
            }
            return
        }
        if (requestCode != openImage) return
        val capturedMonth = month
        val recognizer = TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        try {
            recognizer.process(InputImage.fromFilePath(this, uri))
                .addOnSuccessListener { ocr ->
                    val parsed = AttendanceParser.fromListPage(ocr.text, capturedMonth)
                    if (parsed.isNotEmpty()) RecordStore.add(this, parsed)
                    toast("OCR ${parsed.size}건 추출 · 원본과 대조해 주세요")
                    if (month == capturedMonth) {
                        tab = 2
                        renderTab()
                        pasteField?.setText(ocr.text)
                    }
                }
                .addOnFailureListener { toast("OCR 인식 실패: ${it.localizedMessage}") }
                .addOnCompleteListener { recognizer.close() }
        } catch (e: Exception) {
            recognizer.close()
            toast("이미지 열기 실패: ${e.localizedMessage}")
        }
    }

    private fun applyInsets(insets: WindowInsets) {
        val top = insets.systemWindowInsetTop
        val bottom = insets.systemWindowInsetBottom
        topBar.setPadding(dp(18), dp(16) + top, dp(18), dp(16))
        navigation.setPadding(dp(10), dp(8), dp(10), dp(8) + bottom)
        navigation.layoutParams = (navigation.layoutParams as LinearLayout.LayoutParams).apply {
            height = dp(76) + bottom
        }
    }

    private fun toolbar(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setBackgroundColor(navy)
        setPadding(dp(18), dp(16), dp(18), dp(16))
        addView(label("근", 19f, Color.WHITE, bold = true).apply {
            gravity = Gravity.CENTER
            background = shape(blue, radius = 16)
        }, LinearLayout.LayoutParams(dp(44), dp(44)))
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
            addView(label("근무로그", 21f, Color.WHITE, bold = true))
            addView(label("개인 출근부 기록 도우미", 11.5f, Color.parseColor("#B2C4EC")))
        }, LinearLayout.LayoutParams(0, -2, 1f))
        addView(label(versionName, 11f, Color.parseColor("#D3E0FF")).apply {
            background = shape(Color.parseColor("#2B3B5C"), radius = 20)
            setPadding(dp(12), dp(6), dp(12), dp(6))
        })
    }

    private fun renderTab() {
        if (!::host.isInitialized) return
        if (tab == 1) saveDraft()
        host.removeAllViews()
        yearField = null
        monthField = null
        exportField = null
        pasteField = null

        val scroll = ScrollView(this).apply {
            clipToPadding = false
            setBackgroundColor(surface)
            setPadding(0, 0, 0, dp(20))
            isFillViewport = true
        }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(18))
            clipToPadding = false
        }
        scroll.addView(column, ViewGroup.LayoutParams(-1, -2))
        host.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        when (tab) {
            0 -> renderHome(column)
            1 -> renderRecords(column)
            2 -> renderTools(column)
            else -> renderInfo(column)
        }
        renderBottomNav()
    }

    private fun renderBottomNav() {
        navigation.removeAllViews()
        val tabs = listOf("홈", "기록", "가져오기", "정보")
        tabs.forEachIndexed { i, title ->
            val active = i == tab
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                background = shape(if (active) blueSoft else Color.WHITE, radius = 18)
                setPadding(dp(4), dp(7), dp(4), dp(7))
                setOnClickListener {
                    if (i != tab) {
                        if (tab == 1) saveDraft()
                        tab = i
                        renderTab()
                    }
                }
            }
            val dot = View(this).apply {
                background = shape(if (active) blue else Color.parseColor("#D6DCE8"), radius = 100)
            }
            item.addView(dot, LinearLayout.LayoutParams(dp(8), dp(8)))
            item.addView(label(title, 12.5f, if (active) blueDeep else muted, bold = active).apply {
                gravity = Gravity.CENTER
                topSpace(5)
            })
            navigation.addView(item, LinearLayout.LayoutParams(0, -1, 1f).apply {
                marginStart = dp(3)
                marginEnd = dp(3)
            })
        }
    }

    private fun renderHome(root: LinearLayout) {
        val rows = currentRecords()
        val total = rows.sumOf { it.minutes }
        val mismatch = rows.count { it.differentFromReported }

        root.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = gradient(intArrayOf(navy, blueDeep, blue), radius = 26)
            setPadding(dp(20), dp(20), dp(20), dp(20))
            addView(label("${month.year}년 ${month.monthValue}월 · 나의 근무", 13f, Color.parseColor("#DCE6FF")))
            addView(label("${total / 60}시간 ${total % 60}분", 31f, Color.WHITE, bold = true).apply { topSpace(6) })
            addView(label("등록된 근무 ${rows.size}건  ·  확인 필요 ${mismatch}건", 13f, Color.parseColor("#E4ECFF")).apply { topSpace(4) })
            addView(horizontal().apply {
                topSpace(14)
                addView(heroMetric("출퇴근 기준 합계", "${total / 60}h ${total % 60}m"), LinearLayout.LayoutParams(0, -2, 1f))
                addView(heroMetric("저장된 근무", "${rows.size}건"), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
                addView(heroMetric("점검 필요", "${mismatch}건"), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
            })
            addView(label("장학재단 인정시간 · 제외예정시간과 차이가 있을 수 있어요", 11.5f, Color.parseColor("#C3D4FF")).apply { topSpace(12) })
        }.withMargin(0, 0, 0, 14))

        root.addView(section("조회 기간", "원하는 연도와 월을 직접 입력해 조회할 수 있습니다.").apply {
            val row = horizontal()
            val yearBox = fieldBox("연도", month.year.toString().padStart(4, '0'), 4)
            val monthBox = fieldBox("월", month.monthValue.toString(), 2)
            row.addView(yearBox, LinearLayout.LayoutParams(0, -2, 2f))
            row.addView(monthBox, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10) })
            addView(row)
            addView(action("이 연도 · 월 적용", primary = true) { applyFields() }.apply { topSpace(10) })
            val quick = horizontal().apply { topSpace(9) }
            quick.addView(action("〈 이전 달") { changeMonth(-1) }, LinearLayout.LayoutParams(0, dp(48), 1f))
            quick.addView(action("이번 달") { changeMonth(0) }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(8) })
            quick.addView(action("다음 달 〉") { changeMonth(1) }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(8) })
            addView(quick)
            addView(chip("앱 내부 제한 없음", blueSoft, blueDeep).apply { topSpace(10) })
            addView(label("※ 앱 자체에 특정 연도 제한은 없습니다. 다만 공식 앱에 표시된 기간만 자동 수집할 수 있습니다.", 11.5f, muted).apply { topSpace(8) })
        })

        val serviceEnabled = isAccessibilityEnabled()
        val connected = CollectorAccessibilityService.isReady()
        root.addView(section("목록 수집", "접근성을 켠 후 장학재단 앱의 조회 → 목록에서 시작합니다.").apply {
            val statusBg = if (connected) greenSoft else if (serviceEnabled) amberSoft else Color.parseColor("#EEF1FA")
            val statusColor = if (connected) aqua else if (serviceEnabled) amber else muted
            val statusMsg = when {
                connected -> "● 접근성 연결됨 · 목록에서 시작 가능"
                serviceEnabled -> "● 접근성 활성화됨 · 연결 준비 중"
                else -> "● 접근성 꺼짐 · 사용 시 활성화하세요"
            }
            addView(label(statusMsg, 13f, statusColor, bold = true).apply {
                background = shape(statusBg, radius = 12)
                setPadding(dp(12), dp(12), dp(12), dp(12))
            }, LinearLayout.LayoutParams(-1, -2))
            val consentBox = CheckBox(this@MainActivity).apply {
                text = "목록을 읽고 스크롤하며 근무기록만 저장하는 것에 동의합니다."
                textSize = 13f
                setTextColor(ink)
                isChecked = RecordStore.consent(this@MainActivity)
                setOnCheckedChangeListener { _, isChecked -> RecordStore.setConsent(this@MainActivity, isChecked) }
            }
            addView(consentBox.apply { topSpace(8) })
            addView(action("접근성 서비스 설정 열기", primary = true) {
                if (!RecordStore.consent(this@MainActivity)) toast("접근성 동의 체크를 먼저 해주세요")
                else startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }.apply { topSpace(8) })
            addView(action("중지하고 접근성 끄기") {
                CollectorAccessibilityService.shutdownFromApp()
                toast("접근성 해제를 요청했습니다")
                renderTab()
            }.apply { topSpace(9) })
            addView(label("갤럭시 하단 시스템 버튼 영역을 피하도록 하단 메뉴 여백을 늘렸습니다.", 11.5f, muted).apply { topSpace(10) })
        })

        root.addView(section("3단계 사용 방법", "시작 버튼은 장학재단 앱 화면에 나타납니다.").apply {
            addView(step("01", "장학재단 앱에서 근무 목록 열기", "로그인 → 조회 → 오른쪽 위 목록 보기"))
            addView(step("02", "파란색 ‘목록 수집’ 버튼 누르기", "화면 로딩 중이면 자동으로 다시 확인합니다"))
            addView(step("03", "완료되면 기록 탭 확인", "수집 종료 시 접근성 서비스는 자동으로 꺼집니다"))
        })
        root.addView(label("개인 기기 내 저장 · 로그인 정보 수집 없음 · 공식 기관과 무관한 개인용 앱", 11f, muted).apply {
            gravity = Gravity.CENTER
            topSpace(3)
        })
    }

    private fun renderRecords(root: LinearLayout) {
        val items = currentRecords()
        val total = items.sumOf { it.minutes }
        val mismatch = items.count { it.differentFromReported }
        root.addView(label("근무기록", 26f, ink, bold = true))
        root.addView(label("${month.year}년 ${month.monthValue}월 · ${items.size}건 · ${total / 60}시간 ${total % 60}분", 13f, muted).apply { topSpace(4) })
        root.addView(horizontal().apply {
            topSpace(12)
            addView(statCard("총 근무", "${total / 60}h ${total % 60}m"), LinearLayout.LayoutParams(0, -2, 1f))
            addView(statCard("표시 차이", "${mismatch}건"), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
        }.withMargin(0, 0, 0, 14))
        root.addView(section("추출 결과", "내용을 수정하고 복사하거나 TXT/CSV로 저장할 수 있습니다.").apply {
            val textBox = EditText(this@MainActivity).apply {
                gravity = Gravity.TOP
                minLines = 12
                maxLines = 26
                textSize = 13f
                setTextColor(ink)
                background = shape(cardGray, radius = 14, stroke = border)
                setPadding(dp(12), dp(14), dp(12), dp(14))
                setText(if (draftMonth == month) draftText ?: AttendanceParser.export(items, month) else AttendanceParser.export(items, month))
            }
            exportField = textBox
            addView(textBox)
            addView(action("현재 내용 복사", primary = true) {
                val value = exportField?.text?.toString().orEmpty()
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("근로시간", value))
                toast("복사했어요")
            }.apply { topSpace(10) })
            addView(action("TXT 파일로 저장") {
                saveDraft(); createFile(saveTxt, "text/plain", "근무기록_${month}.txt")
            }.apply { topSpace(9) })
            addView(action("CSV 파일로 저장") { createFile(saveCsv, "text/csv", "근무기록_${month}.csv") }.apply { topSpace(9) })
        })
        root.addView(section("기록 편집", "직접 수정한 시간표를 저장하거나 해당 월 기록을 삭제할 수 있습니다.").apply {
            addView(action("수정한 날짜·시각으로 월 기록 교체") {
                val corrected = AttendanceParser.fromEditableText(exportField?.text?.toString().orEmpty(), month)
                if (corrected.isEmpty()) {
                    toast("YYYY-MM-DD 09:00 ~ 11:00 형식을 확인하세요")
                    return@action
                }
                AlertDialog.Builder(this@MainActivity).setTitle("${month} 기록 교체")
                    .setMessage("현재 월의 저장 기록을 ${corrected.size}건으로 교체할까요? 표시시간과 기관확인 상태는 편집본에서 복구되지 않습니다.")
                    .setNegativeButton("취소", null)
                    .setPositiveButton("교체") { _, _ ->
                        RecordStore.replaceMonth(this@MainActivity, month, corrected)
                        clearDraft(); renderTab()
                    }.show()
            })
            addView(action("이 달 저장 기록 삭제", destructive = true) {
                AlertDialog.Builder(this@MainActivity).setTitle("${month} 기록 삭제")
                    .setMessage("선택한 월에 저장된 기록만 삭제합니다. 계속할까요?")
                    .setNegativeButton("취소", null)
                    .setPositiveButton("삭제") { _, _ ->
                        RecordStore.replaceMonth(this@MainActivity, month, emptyList())
                        clearDraft(); renderTab()
                    }.show()
            }.apply { topSpace(9) })
            addView(label("※ 원본 화면의 근무 건수와 인정시간을 반드시 대조해 주세요.", 11.5f, muted).apply { topSpace(10) })
        })
    }

    private fun renderTools(root: LinearLayout) {
        root.addView(label("가져오기", 26f, ink, bold = true))
        root.addView(label("자동 수집이 어려우면 수동 입력이나 이미지 OCR을 사용할 수 있어요.", 13f, muted).apply { topSpace(4) })
        root.addView(section("목록 텍스트 분석", "조회 월: ${month} · 목록의 날짜와 시간을 그대로 붙여넣으세요.").apply {
            val field = EditText(this@MainActivity).apply {
                gravity = Gravity.TOP
                minLines = 9
                maxLines = 18
                textSize = 13f
                hint = "예시\n11.02 2시간 0분\n기관확인 전\n근무 09:00 ~ 11:00"
                background = shape(cardGray, radius = 14, stroke = border)
                setPadding(dp(12), dp(14), dp(12), dp(14))
            }
            pasteField = field
            addView(field)
            addView(action("텍스트에서 근무기록 추출", primary = true) {
                val records = AttendanceParser.fromListPage(field.text.toString(), month)
                if (records.isEmpty()) toast("근무 시각을 찾지 못했습니다. 조회 연도·월을 확인하세요")
                else {
                    RecordStore.add(this@MainActivity, records)
                    toast("${records.size}건 저장 · 기록 탭에서 확인")
                }
            }.apply { topSpace(10) })
        })
        root.addView(section("사진에서 읽기", "목록 스크린샷을 선택하면 기기 내 OCR로 분석합니다.").apply {
            addView(action("스크린샷 선택 · 한국어 OCR", primary = true) {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "image/*"
                }, openImage)
            })
            addView(chip("서버 업로드 없음", blueSoft, blueDeep).apply { topSpace(10) })
            addView(label("사진을 서버에 업로드하지 않습니다. 캡처가 차단된 화면은 우회하지 않아요.", 11.5f, muted).apply { topSpace(8) })
        })
    }

    private fun renderInfo(root: LinearLayout) {
        root.addView(label("정보", 26f, ink, bold = true))
        root.addView(label("앱 버전, 지원 환경, 변경 내역을 확인할 수 있어요.", 13f, muted).apply { topSpace(4) })
        root.addView(section("앱 정보", "현재 버전과 지원 환경입니다.").apply {
            addView(infoRow("앱 이름", "근무로그"))
            addView(infoRow("현재 버전", versionName))
            addView(infoRow("최소 지원", minAndroidText))
            addView(infoRow("권장 환경", targetAndroidText))
            addView(infoRow("저장 방식", "기기 내부 저장 / 서버 전송 없음"))
        })
        root.addView(section("버전 기록", "최근 변경 내용을 요약합니다.").apply {
            addView(changeLogItem("v0.8", "갤럭시 하단 시스템 버튼 영역 대응, 정보 탭 추가, UI 여백/카드/하단 탭 정리"))
            addView(changeLogItem("v0.7", "연도 제한 제거, 접근성 초기 재시도 안정화, 앱형 디자인 1차 적용"))
            addView(changeLogItem("v0.5~0.6", "검사 영역 확대, 다중 OCR 보강, 접근성 자동 해제, 0건 인식 문제 보완"))
            addView(changeLogItem("v0.1~0.4", "목록 파싱, OCR 보조, TXT/CSV 저장, GitHub 빌드용 구조 정리"))
        })
        root.addView(section("사용 팁", "실제 사용 시 도움이 되는 점을 정리했습니다.").apply {
            addView(changeLogItem("접근성 설정 직후", "한국장학재단 앱의 조회 → 목록 화면을 먼저 띄운 뒤 수집 버튼을 누르세요."))
            addView(changeLogItem("수집 결과 확인", "기록 수가 0건이면 목록 상단에서 다시 시작하거나 OCR 가져오기를 병행하세요."))
            addView(changeLogItem("업데이트 설치 전", "기존 기록을 TXT 또는 CSV로 백업하면 안전합니다."))
        })
    }

    private fun applyFields() {
        val year = yearField?.text?.toString()?.trim()?.toIntOrNull()
        val monthNumber = monthField?.text?.toString()?.trim()?.toIntOrNull()
        if (year == null || year !in 1..9999 || monthNumber == null || monthNumber !in 1..12) {
            toast("연도는 1~9999, 월은 1~12 사이의 숫자로 입력해 주세요")
            return
        }
        changeTo(YearMonth.of(year, monthNumber))
    }

    private fun changeMonth(direction: Int) {
        val next = if (direction == 0) YearMonth.now() else runCatching { month.plusMonths(direction.toLong()) }.getOrNull()
        if (next == null || next.year !in 1..9999) {
            toast("연도는 0001~9999까지 선택할 수 있습니다")
            return
        }
        changeTo(next)
    }

    private fun changeTo(value: YearMonth) {
        month = value
        RecordStore.setSelectedMonth(this, value)
        clearDraft()
        renderTab()
    }

    private fun currentRecords(): List<WorkRecord> = RecordStore.read(this).filter { it.date.startsWith(month.toString()) }

    private fun saveDraft() {
        val field = exportField ?: return
        draftMonth = month
        draftText = field.text.toString()
    }

    private fun clearDraft() { draftMonth = null; draftText = null }

    private fun isAccessibilityEnabled(): Boolean {
        val component = ComponentName(this, CollectorAccessibilityService::class.java).flattenToString()
        return (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "")
            .split(":")
            .any { it.equals(component, ignoreCase = true) }
    }

    private fun createFile(request: Int, mime: String, filename: String) {
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
            putExtra(Intent.EXTRA_TITLE, filename)
        }, request)
    }

    private fun heroMetric(title: String, value: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = shape(Color.parseColor("#23469C"), radius = 16)
        setPadding(dp(10), dp(10), dp(10), dp(10))
        addView(label(title, 11f, Color.parseColor("#C9D8FF")))
        addView(label(value, 16f, Color.WHITE, bold = true).apply { topSpace(4) })
    }

    private fun statCard(title: String, value: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = shape(Color.WHITE, radius = 18, stroke = border)
        setPadding(dp(14), dp(14), dp(14), dp(14))
        addView(label(title, 12f, muted, bold = true))
        addView(label(value, 20f, ink, bold = true).apply { topSpace(4) })
    }

    private fun chip(textValue: String, bg: Int, fg: Int): TextView = label(textValue, 11.5f, fg, bold = true).apply {
        background = shape(bg, radius = 100)
        setPadding(dp(10), dp(6), dp(10), dp(6))
    }

    private fun infoRow(title: String, value: String): LinearLayout = horizontal().apply {
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(6), 0, dp(6))
        addView(label(title, 13f, muted, bold = true), LinearLayout.LayoutParams(0, -2, 0.9f))
        addView(label(value, 13f, ink, bold = true), LinearLayout.LayoutParams(0, -2, 1.1f))
    }

    private fun changeLogItem(title: String, desc: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        setPadding(0, dp(7), 0, dp(7))
        addView(label(title, 12.5f, blueDeep, bold = true).apply {
            gravity = Gravity.CENTER
            background = shape(blueSoft, radius = 12)
            setPadding(dp(10), dp(8), dp(10), dp(8))
        })
        addView(label(desc, 12.5f, ink).apply { setPadding(dp(10), dp(4), 0, dp(4)) }, LinearLayout.LayoutParams(0, -2, 1f))
    }

    private fun fieldBox(title: String, value: String, digits: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(label(title, 12f, muted, bold = true))
        addView(EditText(this@MainActivity).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            filters = arrayOf(InputFilter.LengthFilter(digits))
            setSingleLine(true)
            setText(value)
            selectAll()
            textSize = 19f
            setTextColor(ink)
            background = shape(cardGray, radius = 12, stroke = border)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }.also { if (digits == 4) yearField = it else monthField = it })
    }

    private fun section(title: String, description: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = shape(Color.WHITE, radius = 22, stroke = border)
        setPadding(dp(17), dp(17), dp(17), dp(17))
        addView(label(title, 18f, ink, bold = true))
        addView(label(description, 12.5f, muted).apply { topSpace(4) })
        addView(space(13))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(13) }
    }

    private fun step(index: String, title: String, sub: String): LinearLayout = horizontal().apply {
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(7), 0, dp(7))
        addView(label(index, 13f, blue, bold = true).apply {
            gravity = Gravity.CENTER
            background = shape(blueSoft, radius = 12)
        }, LinearLayout.LayoutParams(dp(42), dp(42)))
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
            addView(label(title, 13.5f, ink, bold = true))
            addView(label(sub, 11.5f, muted).apply { topSpace(3) })
        }, LinearLayout.LayoutParams(0, -2, 1f))
    }

    private fun label(value: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        includeFontPadding = true
    }

    private fun action(textValue: String, primary: Boolean = false, destructive: Boolean = false, onClick: () -> Unit): Button = Button(this).apply {
        text = textValue
        isAllCaps = false
        textSize = 13.5f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(when { primary -> Color.WHITE; destructive -> red; else -> blueDeep })
        background = shape(when {
            primary -> blue
            destructive -> redSoft
            else -> blueSoft
        }, radius = 14, stroke = if (destructive) Color.parseColor("#F3C4C5") else Color.TRANSPARENT)
        minHeight = dp(48)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(48))
    }

    private fun horizontal(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    private fun space(height: Int): View = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }

    private fun <T : View> T.topSpace(dpSize: Int): T = apply {
        val params = (layoutParams as? LinearLayout.LayoutParams) ?: LinearLayout.LayoutParams(-1, -2)
        params.topMargin = dp(dpSize)
        layoutParams = params
    }

    private fun <T : View> T.withMargin(left: Int, top: Int, right: Int, bottom: Int): T = apply {
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(left), dp(top), dp(right), dp(bottom)) }
    }

    private fun shape(fill: Int, radius: Int = 16, stroke: Int = Color.TRANSPARENT): GradientDrawable = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }

    private fun gradient(colors: IntArray, radius: Int): GradientDrawable = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply {
        cornerRadius = dp(radius).toFloat()
    }

    private fun toast(message: String) { Toast.makeText(this, message, Toast.LENGTH_LONG).show() }
    private fun dp(value: Int): Int = (resources.displayMetrics.density * value).toInt()
}
