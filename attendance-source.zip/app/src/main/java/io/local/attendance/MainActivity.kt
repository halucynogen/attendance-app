package io.local.attendance

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import java.time.YearMonth

class MainActivity : Activity() {
    private val openImage = 1101
    private val saveTxt = 1102
    private val saveCsv = 1103
    private lateinit var monthInput: EditText
    private lateinit var pasteInput: EditText
    private lateinit var exportInput: EditText
    private lateinit var countText: TextView
    private lateinit var checkConsent: CheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(40))
        }
        setContentView(ScrollView(this).apply { addView(content) })
        content.addView(text("출근부 목록 자동 정리", 23f))
        content.addView(text("개인용 · 공식 앱 비밀번호/API 사용 안 함 · 저장은 기기 내부만", 13f))
        content.addView(text("① 한국장학재단 공식 앱에서 직접 로그인 → 조회 → 오른쪽 위 목록 아이콘을 누르세요.", 15f))
        content.addView(text("② 이 앱에서 접근성 동의 후 서비스를 켜세요. 공식 앱 목록에서 떠 있는 '목록 수집' 버튼을 누르면 스크롤하며 읽습니다.", 15f))
        content.addView(text("③ 끝난 뒤 이 앱으로 돌아와 결과 확인, 수정, 복사 또는 TXT/CSV 저장을 하세요.", 15f))

        checkConsent = CheckBox(this).apply {
            text = "동의: 내가 '목록 수집'을 누르면 접근성 서비스가 공식 앱의 화면 글자에 접근하고, 목록을 스크롤하며 날짜·출퇴근시각·표시시간·상태만 내 휴대폰에 저장합니다. 글자를 읽지 못한 화면은 캡처해 기기 내 OCR을 시도하며, 캡처 이미지는 저장하지 않습니다. 다른 앱으로 이동하면 수집을 중단하며 언제든 중지할 수 있습니다."
            isChecked = RecordStore.consent(this@MainActivity)
            setOnCheckedChangeListener { _, checked -> RecordStore.setConsent(this@MainActivity, checked) }
        }
        content.addView(checkConsent)
        content.addView(button("접근성 서비스 설정 열기") {
            if (!checkConsent.isChecked) toast("안내를 읽고 동의해야 활성화할 수 있습니다.")
            else startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        content.addView(text("확인할 월 (YYYY-MM)", 18f))
        monthInput = EditText(this).apply {
            setSingleLine(true)
            setText(YearMonth.now().toString())
            hint = "2026-11"
            inputType = android.text.InputType.TYPE_CLASS_DATETIME
        }
        content.addView(monthInput)
        content.addView(button("이 달 저장 기록 보기") { refresh() })

        content.addView(text("자동 수집이 불가능할 때: 목록 텍스트 붙여넣기", 18f))
        pasteInput = EditText(this).apply {
            gravity = Gravity.TOP
            minLines = 4; maxLines = 10
            hint = "2026. 11\n11.02\n2시간 0분\n근무 09:00 ~ 11:00"
        }
        content.addView(pasteInput)
        content.addView(button("붙여넣은 목록에서 근무 내역 추출") {
            val ym = chosenMonth() ?: return@button
            val records = AttendanceParser.fromListPage(pasteInput.text.toString(), ym)
            if (records.isEmpty()) return@button toast("유효한 근무시간이 없습니다. 월과 인식 원문을 확인하세요.")
            RecordStore.add(this, records)
            refresh()
            toast("${records.size}건을 찾았습니다. 원본과 비교하세요.")
        })
        content.addView(button("저장한 목록 스크린샷에서 한국어 OCR") {
            if (chosenMonth() == null) return@button
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "image/*"
            }, openImage)
        })
        countText = text("", 14f); content.addView(countText)

        content.addView(text("결과 (수정 후 복사 가능)", 18f))
        exportInput = EditText(this).apply { gravity = Gravity.TOP; minLines = 8; maxLines = 25 }
        content.addView(exportInput)
        content.addView(button("현재 텍스트 복사") {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(
                ClipData.newPlainText("근로시간", exportInput.text.toString()))
            toast("복사했습니다.")
        })
        content.addView(button("현재 텍스트 TXT 파일로 저장") { createFile(saveTxt, "text/plain", "근로시간_${chosenMonth() ?: return@button}.txt") })
        content.addView(button("저장된 근무기록 CSV 파일로 저장") { createFile(saveCsv, "text/csv", "근로시간_${chosenMonth() ?: return@button}.csv") })
        content.addView(button("수정된 날짜·시각을 이 달의 기록으로 저장") {
            val ym = chosenMonth() ?: return@button
            val corrected = AttendanceParser.fromEditableText(exportInput.text.toString(), ym)
            if (corrected.isEmpty()) return@button toast("'2026-11-02 09:00 ~ 11:00' 형식의 기록이 없습니다.")
            AlertDialog.Builder(this).setTitle("수정한 기록 저장")
                .setMessage("${ym}의 저장 내역을 ${corrected.size}건으로 교체합니다. 표시시간/상태는 수정 텍스트에서 복구되지 않습니다. 계속할까요?")
                .setNegativeButton("취소", null)
                .setPositiveButton("교체") { _, _ -> RecordStore.replaceMonth(this, ym, corrected); refresh() }.show()
        })
        content.addView(button("이 달 저장 기록 삭제") {
            val ym = chosenMonth() ?: return@button
            AlertDialog.Builder(this).setTitle("$ym 삭제")
                .setMessage("이 달의 저장된 기록만 지울까요?")
                .setNegativeButton("취소", null)
                .setPositiveButton("삭제") { _, _ -> RecordStore.replaceMonth(this, ym, emptyList()); refresh() }.show()
        })
        content.addView(text("※ 읽기에 실패한 기록은 추측해서 생성하지 않습니다. 목록에서 일부가 누락될 수 있으므로 원본의 날짜별 항목 수와 합계를 반드시 대조하세요. 출퇴근 시각 차이는 휴게/제외/인정시간과 다를 수 있습니다.", 13f))
        refresh()
    }

    override fun onResume() { super.onResume(); if (::exportInput.isInitialized) refresh() }

    @Deprecated("For this small self-contained Android MVP")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        if (requestCode == saveTxt || requestCode == saveCsv) {
            val ym = chosenMonth() ?: return
            val text = if (requestCode == saveCsv) AttendanceParser.csv(RecordStore.read(this), ym) else exportInput.text.toString()
            try {
                contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                toast("저장 완료")
            } catch (e: Exception) { toast("파일 저장 실패: ${e.localizedMessage}") }
            return
        }
        if (requestCode != openImage) return
        val ym = chosenMonth() ?: return
        val recognizer = TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        try {
            recognizer.process(InputImage.fromFilePath(this, uri))
                .addOnSuccessListener { ocr ->
                    pasteInput.setText(ocr.text)
                    val parsed = AttendanceParser.fromListPage(ocr.text, ym)
                    if (parsed.isNotEmpty()) RecordStore.add(this, parsed)
                    refresh(); toast("OCR에서 ${parsed.size}건 추출. 내용을 검토하세요.")
                }
                .addOnFailureListener { toast("OCR 실패: ${it.localizedMessage}") }
                .addOnCompleteListener { recognizer.close() }
        } catch (e: Exception) { recognizer.close(); toast("이미지 열기 실패: ${e.localizedMessage}") }
    }

    private fun chosenMonth(): YearMonth? {
        return try { YearMonth.parse(monthInput.text.toString().trim()) }
        catch (_: Exception) { toast("월을 2026-11처럼 입력하세요."); null }
    }
    private fun refresh() {
        val ym = chosenMonth() ?: return
        val items = RecordStore.read(this).filter { it.date.startsWith(ym.toString()) }
        countText.text = "$ym 저장 내역 ${items.size}건 / 시각과 표시시간 차이 ${items.count { it.differentFromReported }}건"
        exportInput.setText(AttendanceParser.export(items, ym))
    }
    private fun createFile(request: Int, mime: String, title: String) {
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = mime
            putExtra(Intent.EXTRA_TITLE, title)
        }, request)
    }
    private fun button(title: String, action: () -> Unit) = Button(this).apply {
        text = title; setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }
    private fun text(value: String, size: Float) = TextView(this).apply {
        text = value; textSize = size; setPadding(0, dp(12), 0, dp(8))
    }
    private fun dp(i: Int) = (i * resources.displayMetrics.density).toInt()
    private fun toast(msg: String) { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
}
