package io.local.attendance

import android.app.Activity
import android.app.AlertDialog
import android.animation.ValueAnimator
import android.content.ActivityNotFoundException
import android.content.pm.PackageManager
import android.net.Uri
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Rect
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.os.SystemClock
import android.os.Handler
import android.os.Looper
import java.io.IOException
import android.graphics.Color
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.os.Build
import android.util.Log
import android.provider.Settings
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.time.YearMonth
import java.time.LocalDate

/** Native, dependency-light personal dashboard. No credentials or network permissions. */
class MainActivity : Activity() {
    companion object {
        const val ACTION_EDIT_PERIOD = "io.local.attendance.action.EDIT_PERIOD"
    }
    private val saveTxt = 1102
    private val saveCsv = 1103
    private val targetAttendancePackage = "com.kosaf.gpsAttendance"

    // Prism palette: bright accents with readable contrast and the same four-tab layout.
    private val navy = Color.parseColor("#14234B")
    private val blue = Color.parseColor("#4269F5")
    private val blueDeep = Color.parseColor("#3946BB")
    private val blueSoft = Color.parseColor("#EEF2FF")
    private val violet = Color.parseColor("#854EDC")
    private val violetSoft = Color.parseColor("#F1EEFF")
    private val aqua = Color.parseColor("#007E76")
    private val greenSoft = Color.parseColor("#E4F8F3")
    private val amber = Color.parseColor("#9D6208")
    private val amberSoft = Color.parseColor("#FFF3D9")
    private val red = Color.parseColor("#BB285A")
    private val redSoft = Color.parseColor("#FFF1F5")
    private val surface = Color.parseColor("#F6F8FC")
    private val border = Color.parseColor("#E7ECF4")
    private val ink = Color.parseColor("#18253E")
    private val muted = Color.parseColor("#77849A")
    private val cardGray = Color.parseColor("#FAFBFE")
    private val coral = Color.parseColor("#E8477A")
    private val coralSoft = Color.parseColor("#FFF1F5")
    private val sky = Color.parseColor("#0786CC")
    private val skySoft = Color.parseColor("#E9F7FF")
    private val peach = Color.parseColor("#FFF2E5")
    private val lemon = Color.parseColor("#FFF8D9")

    private lateinit var shell: LinearLayout
    private lateinit var host: FrameLayout
    private lateinit var navigation: LinearLayout
    private lateinit var topBar: LinearLayout
    // Avoid repeatedly rebuilding the dashboard after startup errors.
    private var startupFailed = false
    private var firstResume = true
    // The floating date shortcut keeps the complete home dashboard visible
    // and aligns the existing date form to the scroll viewport after layout.
    private var periodEditorMode = false
    private var periodEditorSection: View? = null
    private var lastRenderedRecordsHash: Int? = null
    private var pendingFileRequest: Int? = null
    private var pendingFileContent: String? = null

    private var tab = 0
    // Zero = vertical bar chart, one = trend line graph; kept across rotations.
    private var flowDisplayMode = 0
    private var splashOverlay: FrameLayout? = null
    private val splashHandler = Handler(Looper.getMainLooper())
    private var splashRemoval: Runnable? = null
    private var showAllRows = false
    private lateinit var month: YearMonth
    private var yearField: EditText? = null
    private var monthField: EditText? = null
    private var exportField: EditText? = null
    private var pasteField: EditText? = null
    private var draftMonth: YearMonth? = null
    private var draftText: String? = null
    private var draftPasteText: String? = null

    private val versionName = "v1.4"
    private val minAndroidText = "Android 8.0 이상 (API 26+)"
    private val targetAndroidText = "Android 8.0~16 지원 · Android 16 (API 36) 대응"

    override fun onCreate(savedInstanceState: Bundle?) {
        // Keep the icon-based OS launch splash, then switch to the normal app theme.
        setTheme(R.style.AttendanceTheme)
        super.onCreate(savedInstanceState)
        // Startup failures should show a minimal diagnostic screen instead of an
        // unexplained immediate close. User attendance records are never deleted.
        try {
            // Saved UI state wins over a previously consumed intent on rotation.
            periodEditorMode = savedInstanceState?.getBoolean("period_editor_mode")
                ?: (intent?.action == ACTION_EDIT_PERIOD)
            tab = savedInstanceState?.getInt("selected_tab", 0)?.coerceIn(0, 3) ?: 0
            flowDisplayMode = (savedInstanceState?.getInt("flow_display_mode")
                ?: getSharedPreferences("attendance_display", MODE_PRIVATE).getInt("flow_mode", 0)).coerceIn(0, 1)
            showAllRows = savedInstanceState?.getBoolean("show_all_rows", false) ?: false
            draftMonth = savedInstanceState?.getString("draft_month")?.let { runCatching { YearMonth.parse(it) }.getOrNull() }
            draftText = savedInstanceState?.getString("draft_text")
            draftPasteText = savedInstanceState?.getString("draft_paste_text")
            pendingFileRequest = savedInstanceState?.getInt("pending_file_request", -1)?.takeIf { it > 0 }
            pendingFileContent = savedInstanceState?.getString("pending_file_content")
            initializeDashboard()
            if (savedInstanceState == null && intent?.action != ACTION_EDIT_PERIOD) showLaunchSplash()
            if (!periodEditorMode && savedInstanceState != null) {
                restoreScroll(savedInstanceState.getInt("scroll_position", 0))
            }
        } catch (error: Exception) {
            startupFailed = true
            Log.e("AttendanceStartup", "Failed to initialize the dashboard", error)
            showStartupError(error)
        }
    }

    private fun initializeDashboard() {
        // Edge-to-edge is mandatory for targetSdk 36. Keep the gradient behind the
        // status bar and the bottom navigation behind gesture/three-button insets.
        // Using system-bar colors alone on Android 16 no longer protects content.
        configureSystemBars()
        month = RecordStore.selectedMonth(this)
        RecordStore.refreshDisclosureConsent(this)

        shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(surface)
            clipToPadding = false
        }
        setContentView(shell)
        shell.isFocusableInTouchMode = true
        shell.requestFocus()

        topBar = toolbar()
        shell.addView(topBar)
        host = FrameLayout(this)
        shell.addView(host, LinearLayout.LayoutParams(-1, 0, 1f))
        navigation = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = shape(Color.WHITE, radius = 0, stroke = border)
            elevation = dp(4).toFloat()
            setPadding(dp(14), dp(5), dp(14), dp(5))
            clipToPadding = false
        }
        shell.addView(navigation, LinearLayout.LayoutParams(-1, dp(65)))

        shell.setOnApplyWindowInsetsListener { _, insets ->
            // Insets may arrive while the Activity is still being initialized.
            // Never let a transient insets issue terminate the application.
            try {
                if (::topBar.isInitialized && ::navigation.isInitialized && ::host.isInitialized) {
                    applyInsets(insets)
                }
            } catch (error: Exception) {
                Log.e("AttendanceStartup", "Could not apply window insets", error)
            }
            insets
        }
        renderTab()
        // Layout/insets are requested only after the entire view hierarchy is built.
        shell.post {
            if (!startupFailed) {
                updateSystemBarIconsSafely()
                shell.requestApplyInsets()
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putBoolean("period_editor_mode", periodEditorMode)
        outState.putInt("selected_tab", tab)
        outState.putInt("flow_display_mode", flowDisplayMode)
        outState.putBoolean("show_all_rows", showAllRows)
        outState.putInt("scroll_position", currentScrollY())
        if (tab == 1) saveDraft()
        // Avoid oversized Binder state from a pasted multi-page record export.
        draftText?.takeIf { it.length <= 70000 }?.let { outState.putString("draft_text", it) }
        draftMonth?.let { outState.putString("draft_month", it.toString()) }
        draftPasteText?.takeIf { it.length <= 50000 }?.let { outState.putString("draft_paste_text", it) }
        pendingFileRequest?.let { outState.putInt("pending_file_request", it) }
        pendingFileContent?.takeIf { it.length <= 70000 }?.let { outState.putString("pending_file_content", it) }
        super.onSaveInstanceState(outState)
    }

    override fun onNewIntent(newIntent: Intent) {
        super.onNewIntent(newIntent)
        setIntent(newIntent)
        if (newIntent.action != ACTION_EDIT_PERIOD) {
            // Reopening from the launcher should not trap the user in shortcut mode.
            if (newIntent.action == Intent.ACTION_MAIN && periodEditorMode) {
                periodEditorMode = false
                if (!startupFailed && ::host.isInitialized) renderTab()
            }
            return
        }
        // This intent may arrive while the Activity is already on top: singleTop.
        // Never queue a scroll on an old ScrollView that onResume will replace.
        periodEditorMode = true
        if (!startupFailed && ::host.isInitialized) {
            try {
                if (tab == 1) saveDraft()
                tab = 0
                renderTab()
                showPeriodEditorImmediately()
            } catch (error: Exception) {
                startupFailed = true
                Log.e("AttendanceNavigation", "Could not open date editor", error)
                showStartupError(error)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (firstResume) {
            firstResume = false
            if (periodEditorMode) showPeriodEditorImmediately()
            return
        }
        if (!startupFailed && ::host.isInitialized) {
            try {
                if (periodEditorMode) {
                    // Keep the date editor aligned after returning from Settings.
                    if (tab != 0 || periodEditorSection == null) {
                        tab = 0
                        renderTab()
                    }
                    showPeriodEditorImmediately()
                } else if (tab == 3 || lastRenderedRecordsHash != RecordStore.read(this).hashCode()) {
                    // Always refresh permission state on the Settings tab. Refresh data
                    // views only when attendance records actually changed.
                    // clipboard or document provider momentarily pauses this Activity.
                    val previousY = currentScrollY()
                    renderTab()
                    restoreScroll(previousY)
                }
            } catch (error: Exception) {
                startupFailed = true
                Log.e("AttendanceStartup", "Failed to resume dashboard", error)
                showStartupError(error)
            }
        }
    }

    override fun onPause() {
        if (::host.isInitialized && tab == 1) saveDraft()
        super.onPause()
    }

    override fun onDestroy() {
        splashRemoval?.let { splashHandler.removeCallbacks(it) }
        splashRemoval = null
        splashOverlay?.animate()?.cancel()
        splashOverlay?.let { (it.parent as? ViewGroup)?.removeView(it) }
        splashOverlay = null
        if (isFinishing) CollectorAccessibilityService.shutdownFromApp()
        super.onDestroy()
    }

    @Deprecated("Android back behavior across API levels")
    override fun onBackPressed() {
        if (periodEditorMode) {
            periodEditorMode = false
            renderTab()
            return
        }
        CollectorAccessibilityService.shutdownFromApp()
        super.onBackPressed()
    }

    @Deprecated("For this small self-contained Android project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == saveTxt || requestCode == saveCsv) {
            // Capture file content BEFORE opening the system picker so a resume or
            // selected-month change never exports a different snapshot by accident.
            val snapshot = if (pendingFileRequest == requestCode) pendingFileContent else null
            pendingFileRequest = null
            pendingFileContent = null
            if (resultCode != RESULT_OK || data?.data == null) return
            try {
                val content = snapshot ?: throw IOException("저장할 파일 내용이 없습니다")
                val output = contentResolver.openOutputStream(data.data!!)
                    ?: throw IOException("저장 위치에 파일을 열 수 없습니다")
                output.use { it.write(content.toByteArray(Charsets.UTF_8)) }
                toast("파일 저장 완료")
            } catch (e: Exception) {
                Log.e("AttendanceFile", "Document write failed", e)
                toast("파일 저장 실패: ${e.localizedMessage}")
            }
            return
        }
    }

    /**
     * Avoid querying Window.getInsetsController() before the window is attached.
     * Some Android 16/OEM framework builds throw inside that platform call,
     * even when the caller uses Kotlin's null-safe operator.
     */
    @Suppress("DEPRECATION")
    private fun configureSystemBars() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
            // Do not access window.insetsController during Activity.onCreate().
        } else {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR or
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Three-button Samsung navigation needs a system-owned, legible region.
            // Do not obscure its controls with a completely transparent bar.
            window.isNavigationBarContrastEnforced = true
            window.isStatusBarContrastEnforced = false
        }
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
    }

    /** Optional decoration only. UI still works if the OS cannot supply a controller. */
    private fun updateSystemBarIconsSafely() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        try {
            val controller = window.decorView.windowInsetsController ?: return
            controller.setSystemBarsAppearance(
                WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS or
                    WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS,
                WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS or
                    WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
            )
        } catch (error: Exception) {
            Log.w("AttendanceStartup", "System bar icon styling skipped", error)
        }
    }

    /** Protect interactive content from notches and 3-button/gesture navigation. */
    @Suppress("DEPRECATION")
    private fun applyInsets(insets: WindowInsets) {
        val bars = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
        } else null
        val tappableBottom = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            insets.getInsets(WindowInsets.Type.tappableElement()).bottom
        } else 0
        val top = bars?.top ?: insets.systemWindowInsetTop
        val bottom = maxOf(bars?.bottom ?: insets.systemWindowInsetBottom, tappableBottom)
        val left = bars?.left ?: insets.systemWindowInsetLeft
        val right = bars?.right ?: insets.systemWindowInsetRight
        val barLeft = dp(16) + left
        val barTop = dp(9) + top
        val barRight = dp(16) + right
        if (topBar.paddingLeft != barLeft || topBar.paddingTop != barTop ||
            topBar.paddingRight != barRight || topBar.paddingBottom != dp(10)) {
            topBar.setPadding(barLeft, barTop, barRight, dp(10))
        }
        val navLeft = dp(10) + left
        val navRight = dp(10) + right
        val navBottom = dp(5) + bottom
        if (navigation.paddingLeft != navLeft || navigation.paddingBottom != navBottom ||
            navigation.paddingRight != navRight) {
            navigation.setPadding(navLeft, dp(5), navRight, navBottom)
        }
        // Landscape and foldables can have camera cutouts on the side.
        if (host.paddingLeft != left || host.paddingRight != right) host.setPadding(left, 0, right, 0)
        val targetHeight = dp(65) + bottom
        val params = navigation.layoutParams as? LinearLayout.LayoutParams
        if (params != null && params.height != targetHeight) {
            params.height = targetHeight
            navigation.layoutParams = params
        }
        // Insets are applied to the visible controls, not to the scroll host:
        // no double padding when the system switches gesture/3-button navigation.
    }

    /** A crash-safe, native-only fallback; contains no OCR or accessibility initialization. */
    private fun showStartupError(error: Exception) {
        val diagnostic = buildString {
            append("근무로그 v1.4 / Android SDK ")
            append(Build.VERSION.SDK_INT)
            append("\n")
            append(error.javaClass.name)
            append("\n")
            error.stackTrace.firstOrNull { it.className.startsWith("io.local.attendance") }
                ?.let { append(it.className).append(":").append(it.lineNumber) }
        }
        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(dp(24), dp(48), dp(24), dp(24))
        }
        wrapper.addView(TextView(this).apply {
            text = "근무로그를 시작하지 못했어요"
            textSize = 22f
            setTextColor(Color.rgb(24, 39, 74))
            typeface = Typeface.DEFAULT_BOLD
        })
        wrapper.addView(TextView(this).apply {
            text = "저장된 근무기록은 삭제되지 않았습니다. 아래의 진단 정보를 복사해 개발자에게 전달해 주세요."
            textSize = 15f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(14), 0, dp(12))
        })
        wrapper.addView(TextView(this).apply {
            text = diagnostic
            textSize = 12f
            setTextColor(Color.DKGRAY)
        })
        wrapper.addView(Button(this).apply {
            text = "진단 정보 복사"
            isAllCaps = false
            setOnClickListener {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("근무로그 시작 오류", diagnostic))
                Toast.makeText(this@MainActivity, "진단 정보를 복사했습니다", Toast.LENGTH_SHORT).show()
            }
        })
        wrapper.addView(Button(this).apply {
            text = "다시 시작"
            isAllCaps = false
            setOnClickListener { recreate() }
        })
        setContentView(wrapper)
    }

    private fun toolbar(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        background = shape(Color.WHITE, radius = 0)
        setPadding(dp(16), dp(9), dp(16), dp(10))
        addView(ImageView(this@MainActivity).apply {
            setImageResource(R.mipmap.ic_launcher)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "근무로그 앱 아이콘"
        }, LinearLayout.LayoutParams(dp(36), dp(36)))
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, 0, 0)
            addView(label("근무로그", 17f, ink, bold = true))
            addView(label("나의 근무시간을 한눈에", 10.5f, muted))
        }, LinearLayout.LayoutParams(0, -2, 1f))
        addView(chip(versionName, blueSoft, blueDeep))
    }

    /** A calm, in-app splash overlay held for approximately three seconds. */
    private fun showLaunchSplash() {
        val content = findViewById<FrameLayout>(android.R.id.content) ?: return
        val overlay = FrameLayout(this).apply {
            background = gradient(intArrayOf(Color.parseColor("#F6F8FF"), Color.parseColor("#E9EEFF")), radius = 0)
            isClickable = true // Ignore accidental taps while the app is opening.
            isFocusable = true
        }
        val contents = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(20), dp(28), dp(20))
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.mipmap.ic_launcher)
                contentDescription = "근무로그 시작 화면"
                scaleType = ImageView.ScaleType.FIT_CENTER
                background = shape(Color.WHITE, radius = 28)
                elevation = dp(3).toFloat()
                setPadding(dp(13), dp(13), dp(13), dp(13))
            }, LinearLayout.LayoutParams(dp(98), dp(98)))
            addView(label("근무로그", 25f, ink, true).apply {
                gravity = Gravity.CENTER
                topSpace(18)
            })
            addView(label("매일의 근무를 더 가볍게", 13f, muted).apply {
                gravity = Gravity.CENTER
                topSpace(7)
            })
            addView(label("●  ●  ●", 16f, blue).apply {
                gravity = Gravity.CENTER
                topSpace(24)
            })
        }
        overlay.addView(contents, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        content.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        splashOverlay = overlay
        val dismiss = Runnable {
            if (!isFinishing && !isDestroyed && overlay.parent != null) {
                overlay.animate().alpha(0f).setDuration(170L).withEndAction {
                    (overlay.parent as? ViewGroup)?.removeView(overlay)
                    if (splashOverlay === overlay) splashOverlay = null
                }.start()
            }
            splashRemoval = null
        }
        splashRemoval = dismiss
        splashHandler.postDelayed(dismiss, 3000L)
    }

    private fun renderTab() {
        if (!::host.isInitialized) return
        host.removeAllViews()
        yearField = null
        monthField = null
        periodEditorSection = null
        exportField = null
        pasteField = null

        val scroll = ScrollView(this).apply {
            clipToPadding = false
            setBackgroundColor(surface)
            setPadding(0, 0, 0, dp(20))
            isFillViewport = true
        }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(14), dp(15), dp(12))
            clipToPadding = false
        }
        scroll.addView(column, ViewGroup.LayoutParams(-1, -2))
        host.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        when (tab) {
            0 -> renderHome(column)
            1 -> renderRecords(column)
            2 -> renderStats(column)
            else -> renderSettings(column)
        }
        renderBottomNav()
        lastRenderedRecordsHash = RecordStore.read(this).hashCode()
        // Subtle entrance motion for the dashboard sections. System-level reduced
        // animations are respected, and content never depends on animation.
        if (ValueAnimator.areAnimatorsEnabled() && !periodEditorMode) {
            // Only animate the visible header cards. Off-screen children must stay
            // fully opaque or jumping directly to a lower section can show blanks.
            for (index in 0 until minOf(2, column.childCount)) {
                animateEntrance(column.getChildAt(index), index * 60L)
            }
        }
    }

    /**
     * The normal home stays visible. Align the entire period editor card to the
     * visible ScrollView viewport instead of showing an isolated date-only page.
     * A post-layout Rect accounts for margins and dynamically sized cards.
     */
    private fun showPeriodEditorImmediately() {
        if (!periodEditorMode || !::host.isInitialized || startupFailed) return
        val scroll = host.getChildAt(0) as? ScrollView ?: return
        val editor = periodEditorSection ?: return
        shell.requestFocus() // Do not unexpectedly open the keyboard.
        scroll.post {
            if (!periodEditorMode || host.getChildAt(0) !== scroll ||
                editor.parent !== scroll.getChildAt(0)) return@post
            val rectangle = Rect()
            editor.getDrawingRect(rectangle)
            scroll.offsetDescendantRectToMyCoords(editor, rectangle)
            val topInset = dp(12)
            val scrollRange = ((scroll.getChildAt(0)?.height ?: 0) - scroll.height + scroll.paddingBottom)
                .coerceAtLeast(0)
            // Prefer top-aligning the card; at the end of a short page this clamps
            // to a safe reachable value without jumping to a blank bottom area.
            val destination = (scroll.scrollY + rectangle.top - topInset)
                .coerceIn(0, scrollRange)
            scroll.scrollTo(0, destination)
            editor.announceForAccessibility("조회 기간 날짜 수정 영역으로 이동했습니다")
        }
    }

    private fun renderBottomNav() {
        navigation.removeAllViews()
        val tabs = listOf("홈", "기록", "통계", "설정")
        val icons = listOf(R.drawable.nav_home, R.drawable.nav_records, R.drawable.nav_stats, R.drawable.nav_settings)
        val accents = listOf(blue, blue, blue, blue)
        val pastels = listOf(blueSoft, blueSoft, blueSoft, blueSoft)
        tabs.forEachIndexed { i, title ->
            val active = i == tab
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                background = if (active) shape(pastels[i], radius = 13) else shape(Color.TRANSPARENT, radius = 13)
                setPadding(dp(3), dp(5), dp(3), dp(5))
                contentDescription = if (active) "$title 탭, 선택됨" else "$title 탭"
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    if (i != tab || periodEditorMode) {
                        if (tab == 1) saveDraft()
                        periodEditorMode = false
                        tab = i
                        renderTab()
                    }
                }
            }
            val tint = if (active) accents[i] else Color.parseColor("#A8B1C7")
            item.addView(ImageView(this).apply {
                setImageResource(icons[i])
                imageTintList = ColorStateList.valueOf(tint)
                contentDescription = null
            }, LinearLayout.LayoutParams(dp(20), dp(20)))
            item.addView(label(title, 12f, if (active) accents[i] else muted, bold = active).apply {
                gravity = Gravity.CENTER
                topSpace(3)
            })
            navigation.addView(item, LinearLayout.LayoutParams(0, -1, 1f).apply {
                marginStart = dp(3)
                marginEnd = dp(3)
            })
        }
    }

    private fun renderHome(root: LinearLayout) {
        // Always render the complete dashboard. The accessibility shortcut
        // scrolls to the original date editor in this same home screen.
        val rows = currentRecords()
        val total = rows.sumOf { it.minutes }
        val mismatch = rows.count { it.differentFromReported }

        val gross = rows.sumOf { it.grossMinutes }
        val deducted = rows.sumOf { it.breakMinutes }
        val displayed = rows.sumOf { it.reportedMinutes ?: it.minutes }
        val withDisplayed = rows.count { it.reportedMinutes != null }

        val heroCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = gradient(intArrayOf(Color.parseColor("#273A75"), Color.parseColor("#5169D5")), radius = 20)
            setPadding(dp(17), dp(16), dp(17), dp(15))
            addView(horizontal().apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(label("${month.year}년 ${month.monthValue}월의 기록", 12f, Color.parseColor("#DCE5FF"), true))
                    addView(label("${total / 60}시간 ${total % 60}분", 29f, Color.WHITE, true).apply { topSpace(5) })
                    addView(label("휴게 차감 후 근무시간", 11f, Color.parseColor("#E5EAFE")).apply { topSpace(2) })
                }, LinearLayout.LayoutParams(0, -2, 1f))
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(R.drawable.dashboard_illustration)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    contentDescription = null
                }, LinearLayout.LayoutParams(dp(68), dp(70)))
            })
            addView(horizontal().apply {
                topSpace(13)
                addView(heroMetric("총 기록", "${rows.size}건", Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f))
                addView(heroMetric("휴게", "${deducted / 60}h ${deducted % 60}m", Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(7) })
                addView(heroMetric("확인 필요", "${mismatch}건", Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(7) })
            })
        }.withMargin(0, 0, 0, 11)
        root.addView(heroCard)

        if (rows.isNotEmpty() && withDisplayed > 0) {
            val warning = mismatch > 0
            root.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = shape(if (warning) amberSoft else greenSoft, radius = 18)
                setPadding(dp(15), dp(13), dp(15), dp(13))
                addView(label(if (warning) "⚠  표시시간과 차이가 있어요" else "✓  표시시간과 일치해요",
                    14f, if (warning) amber else aqua, bold = true))
                addView(label("목록 항목 표시시간 합계 ${displayed / 60}시간 ${displayed % 60}분  ·  계산 ${total / 60}시간 ${total % 60}분",
                    12.5f, ink).apply { topSpace(5) })
                addView(label(if (warning)
                    "식사시간이 저장되지 않은 기존 기록일 수 있어요. 원본 목록을 다시 수집해 확인하세요."
                    else "원본에 명시된 식사·휴게시간만 차감했어요. 공식 월간 인정시간과는 별도로 대조하세요.",
                    11.5f, muted).apply { topSpace(4) })
            }.withMargin(0, 0, 0, 14))
        }

        root.addView(section("오늘의 루틴", "자주 사용하는 기능만 간편하게").apply {
            val first = horizontal()
            first.addView(lifestyleCard("자동 수집", "목록 수집 시작", R.drawable.home_automation_illustration, blueSoft, blue) {
                if (isAccessibilityEnabled()) openOfficialAttendanceApp()
                else showAccessibilityDisclosure(openSettings = true)
            }, LinearLayout.LayoutParams(0, -2, 1f))
            first.addView(lifestyleCard("내 근무기록", "날짜별 상세 내역", R.drawable.nav_records, greenSoft, aqua) {
                tab = 1; renderTab()
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
            addView(first)
            val second = horizontal().apply { topSpace(8) }
            second.addView(lifestyleCard("월간 공유", "전체 날짜·시간", R.drawable.monthly_share_illustration, violetSoft, violet) {
                shareSummary()
            }, LinearLayout.LayoutParams(0, -2, 1f))
            second.addView(lifestyleCard("접근성 설정", "권한 바로 열기", R.drawable.nav_settings, skySoft, sky) {
                showAccessibilityDisclosure(openSettings = true)
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
            addView(second)
        })
        renderWeeklyChart(root, rows)
        root.addView(horizontal().apply {
            addView(action("전체 날짜·시각 복사") { copyMonthDetails() }, LinearLayout.LayoutParams(0, dp(43), 1f))
            addView(action("기록 확인") { tab = 1; renderTab() }, LinearLayout.LayoutParams(0, dp(43), 1f).apply { marginStart = dp(8) })
        }.withMargin(0, 0, 0, 12))

        root.addView(createPeriodEditorCard())

        root.addView(section("처음 사용하시나요?", "설치·제한된 설정·자동 수집 3단계 안내").apply {
            addView(action("사용 방법 자세히 보기", primary = true) { tab = 3; renderTab() })
        })
        root.addView(label("개인 기기 내 저장 · 공식 기관이 제공하거나 승인한 앱이 아닌 개인용 도우미", 11f, muted).apply {
            gravity = Gravity.CENTER
            topSpace(3)
        })
    }

    /** One shared form, used in-place on the home page or as the first card on direct entry. */
    private fun createPeriodEditorCard(): LinearLayout {
        val dateEditor = section("조회 기간", "원하는 연도와 월을 직접 입력해 조회할 수 있습니다.").apply {
            addView(chip("◉ 현재 선택  ${month.year}년 ${month.monthValue}월", Color.parseColor("#FFF1CA"), Color.parseColor("#80560A")).apply { topSpace(2) })
            val row = horizontal().apply { topSpace(9) }
            val yearBox = fieldBox("연도", month.year.toString().padStart(4, '0'), 4)
            val monthBox = fieldBox("월", month.monthValue.toString(), 2)
            row.addView(yearBox, LinearLayout.LayoutParams(0, -2, 2f))
            row.addView(monthBox, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10) })
            addView(row)
            addView(action("이 연도 · 월 적용", primary = true) { applyFields() }.apply { topSpace(10) })
            val quick = horizontal().apply { topSpace(9) }
            quick.addView(action("〈 이전 달") { changeMonth(-1) }, LinearLayout.LayoutParams(0, dp(48), 1f))
            quick.addView(action("이번 달") { changeMonth(0) }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(8) })
            quick.addView(action("다음 달 〉") { changeMonth(1) }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(8) })
            addView(quick)
            // Handy when opening this editor from the official app's floating menu.
            addView(action("날짜 설정 후 출근부로 돌아가기") { openOfficialAttendanceApp() }.apply { topSpace(9) })
            if (periodEditorMode) {
                addView(action("홈 맨 위로 이동") {
                    periodEditorMode = false
                    (host.getChildAt(0) as? ScrollView)?.smoothScrollTo(0, 0)
                }.apply { topSpace(9) })
            }
            addView(chip("앱 내부 제한 없음", blueSoft, blueDeep).apply { topSpace(10) })
            addView(label("※ 여기서 선택한 조회 월은 근무로그에만 적용됩니다. 공식 출근부 앱의 조회 월은 그 앱에서 별도로 선택하세요.", 11.5f, muted).apply { topSpace(8) })
        }
        periodEditorSection = dateEditor
        return dateEditor
    }

    /** The same weekly totals can be viewed as bars (차트) or a line (그래프). */
    private fun renderWeeklyChart(root: LinearLayout, rows: List<WorkRecord>) {
        val weeks = IntArray(5)
        rows.forEach { record ->
            val date = runCatching { LocalDate.parse(record.date) }.getOrNull()
            if (date != null && YearMonth.from(date) == month) {
                weeks[(date.dayOfMonth - 1) / 7] += record.minutes
            }
        }
        root.addView(section("이번 달 근무 흐름", "주차별 근무시간 · 버튼을 눌러 전환").apply {
            val modeRow = horizontal().apply { gravity = Gravity.CENTER_VERTICAL }
            val barsBtn = action("차트", primary = flowDisplayMode == 0) { switchFlowMode(0) }
            val lineBtn = action("그래프", primary = flowDisplayMode == 1) { switchFlowMode(1) }
            modeRow.addView(barsBtn, LinearLayout.LayoutParams(0, dp(40), 1f))
            modeRow.addView(lineBtn, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(8) })
            addView(modeRow)
            addView(WeeklyFlowView(weeks, flowDisplayMode).apply {
                contentDescription = weeks.mapIndexed { i, mins -> "${i + 1}주차 ${mins / 60}시간 ${mins % 60}분" }.joinToString(", ")
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
                tag = "weekly_flow_display"
            }, LinearLayout.LayoutParams(-1, dp(155)).apply { topMargin = dp(9) })
            val days = rows.map { it.date }.distinct().size
            val longest = rows.groupBy { it.date }.values.maxOfOrNull { shift -> shift.sumOf { it.minutes } } ?: 0
            addView(horizontal().apply {
                topSpace(5)
                addView(chip("근무 ${days}일", greenSoft, aqua))
                addView(chip("최대 ${longest / 60}h ${longest % 60}m/일", violetSoft, violet).apply {
                    layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(7) }
                })
            })
            if (rows.isEmpty()) addView(label("기록이 쌓이면 여기에 흐름이 표시돼요.", 12f, muted).apply { topSpace(9) })
        })
    }

    private fun switchFlowMode(next: Int) {
        if (next == flowDisplayMode) return
        val y = currentScrollY()
        flowDisplayMode = next
        getSharedPreferences("attendance_display", MODE_PRIVATE).edit().putInt("flow_mode", next).apply()
        renderTab()
        restoreScroll(y)
    }

    private inner class WeeklyFlowView(private val minutes: IntArray, private val mode: Int): View(this@MainActivity) {
        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val left = dp(12).toFloat(); val right = width - dp(12).toFloat()
            val top = dp(21).toFloat(); val bottom = height - dp(26).toFloat()
            val max = (minutes.maxOrNull() ?: 0).coerceAtLeast(60).toFloat()
            stroke.style = Paint.Style.STROKE; stroke.strokeWidth = dp(1).toFloat()
            stroke.color = border
            for (i in 0..3) {
                val y = top + (bottom - top) * i / 3f
                canvas.drawLine(left, y, right, y, stroke)
            }
            val step = (right - left) / 5f
            fun yFor(v: Int) = bottom - (v / max) * (bottom - top)
            if (mode == 0) {
                for (i in 0..4) {
                    val x = left + (i + 0.5f) * step
                    val t = yFor(minutes[i])
                    stroke.style = Paint.Style.FILL
                    stroke.color = if (i == 4) aqua else blue
                    val h = (bottom - t).coerceAtLeast(dp(3).toFloat())
                    canvas.drawRoundRect(x - step * .25f, bottom - h, x + step * .25f, bottom, dp(5).toFloat(), dp(5).toFloat(), stroke)
                }
            } else {
                val path = Path()
                for (i in 0..4) {
                    val x = left + (i + 0.5f) * step
                    val y = yFor(minutes[i])
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                stroke.style = Paint.Style.STROKE; stroke.strokeWidth = dp(3).toFloat(); stroke.color = blue
                canvas.drawPath(path, stroke)
                for (i in 0..4) {
                    val x = left + (i + 0.5f) * step
                    val y = yFor(minutes[i])
                    stroke.color = Color.WHITE; stroke.style = Paint.Style.FILL
                    canvas.drawCircle(x, y, dp(6).toFloat(), stroke)
                    stroke.color = if (i == 4) aqua else blue
                    canvas.drawCircle(x, y, dp(4).toFloat(), stroke)
                }
            }
            for (i in 0..4) {
                val x = left + (i + 0.5f) * step
                stroke.style = Paint.Style.FILL; stroke.textSize = dp(10).toFloat()
                stroke.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                stroke.textAlign = Paint.Align.CENTER; stroke.color = muted
                canvas.drawText("${i + 1}주", x, bottom + dp(18), stroke)
                stroke.color = ink
                canvas.drawText(if (minutes[i] == 0) "-" else "${minutes[i] / 60}h", x, (yFor(minutes[i]) - dp(7)).coerceAtLeast(dp(11).toFloat()), stroke)
            }
        }
    }

    private fun renderRecords(root: LinearLayout) {
        val items = currentRecords()
        val total = items.sumOf { it.minutes }
        val gross = items.sumOf { it.grossMinutes }
        val rest = items.sumOf { it.breakMinutes }
        val mismatch = items.count { it.differentFromReported }
        root.addView(heading("근무기록", "${month.year}년 ${month.monthValue}월 · ${items.size}건의 출근부 기록", violet))
        root.addView(horizontal().apply {
            topSpace(12)
            addView(statCard("✦ 계산 근무", "${total / 60}h ${total % 60}m", skySoft, sky), LinearLayout.LayoutParams(0, -2, 1f))
            addView(statCard("☘ 휴게 차감", "${rest / 60}h ${rest % 60}m", greenSoft, aqua), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
            addView(statCard("◈ 표시 차이", "${mismatch}건", if (mismatch == 0) violetSoft else amberSoft, if (mismatch == 0) violet else amber), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
        }.withMargin(0, 0, 0, 14))
        if (items.isNotEmpty()) {
            root.addView(section("일자별 한눈에 보기", "출퇴근 ${gross / 60}시간 · 명시된 식사/휴게 ${rest / 60}시간 차감").apply {
                val descending = items.sortedWith(compareByDescending<WorkRecord> { it.date }.thenBy { it.start })
                val visible = if (showAllRows) descending else descending.take(5)
                visible.forEach { addView(recordPreview(it)) }
                if (descending.size > 5) addView(action(if (showAllRows) "간략히 접기" else "전체 ${descending.size}건 펼쳐보기") {
                    val oldPosition = (host.getChildAt(0) as? ScrollView)?.scrollY ?: 0
                    saveDraft()
                    showAllRows = !showAllRows
                    renderTab()
                    (host.getChildAt(0) as? ScrollView)?.let { view ->
                        view.post { view.scrollTo(0, oldPosition) }
                    }
                }.apply { topSpace(9) })
            })
        }
        root.addView(section("텍스트 붙여넣기", "인식이 어려운 항목은 목록 텍스트를 붙여넣어 추가하세요.").apply {
            val field = EditText(this@MainActivity).apply {
                minLines = 3; maxLines = 9; gravity = Gravity.TOP
                textSize = 13f; setTextColor(ink)
                hint = "예: 11.05 근무 09:00 ~ 18:00 / 식사 12:00 ~ 13:00"
                background = shape(cardGray, radius = 11, stroke = border)
                setPadding(dp(11), dp(11), dp(11), dp(11))
                setText(draftPasteText.orEmpty())
            }
            pasteField = field
            addView(field)
            addView(action("텍스트에서 기록 추가") {
                val entries = AttendanceParser.fromListPage(field.text.toString(), month)
                if (entries.isEmpty()) toast("근무 날짜·시간을 찾지 못했습니다")
                else if (RecordStore.add(this@MainActivity, entries)) {
                    toast("${entries.size}건 확인 · 목록을 새로 고칩니다")
                    draftPasteText = null
                    renderTab()
                } else toast("저장 실패 · 기존 기록을 보존했어요")
            }.apply { topSpace(8) })
        })
        root.addView(section("추출 결과 · 편집", "식사/휴게 내역을 유지한 채 수정하거나 TXT/CSV로 저장하세요.").apply {
            val textBox = EditText(this@MainActivity).apply {
                gravity = Gravity.TOP
                minLines = 7
                maxLines = 15
                textSize = 13f
                typeface = Typeface.create("sans-serif", Typeface.NORMAL)
                setTextColor(ink)
                background = shape(cardGray, radius = 14, stroke = Color.parseColor("#D9DFF3"))
                setPadding(dp(12), dp(14), dp(12), dp(14))
                setText(if (draftMonth == month) draftText ?: AttendanceParser.export(items, month) else AttendanceParser.export(items, month))
            }
            exportField = textBox
            addView(textBox)
            addView(action("현재 내용 복사", primary = true) {
                val value = exportField?.text?.toString().orEmpty()
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("근로시간", value))
                toast("복사했어요")
            }.apply { topSpace(10) })
            addView(action("TXT 파일로 저장") {
                saveDraft(); createFile(saveTxt, "text/plain", "근무기록_${month}.txt")
            }.apply { topSpace(9) })
            addView(action("CSV 파일로 저장") { createFile(saveCsv, "text/csv", "근무기록_${month}.csv") }.apply { topSpace(9) })
        })
        root.addView(section("기록 편집", "직접 수정한 시간표를 저장하거나 해당 월 기록을 삭제할 수 있습니다.").apply {
            addView(action("수정한 날짜·시각으로 월 기록 교체") {
                val corrected = AttendanceParser.fromEditableText(exportField?.text?.toString().orEmpty(), month)
                if (corrected.isEmpty()) {
                    toast("YYYY-MM-DD 09:00 ~ 11:00 형식을 확인하세요")
                    return@action
                }
                AlertDialog.Builder(this@MainActivity).setTitle("${month} 기록 교체")
                    .setMessage("현재 월의 저장 기록을 ${corrected.size}건으로 교체할까요? 편집본에 적힌 표시시간·기관확인·식사시간도 함께 복구합니다.")
                    .setNegativeButton("취소", null)
                    .setPositiveButton("교체") { _, _ ->
                        if (RecordStore.replaceMonth(this@MainActivity, month, corrected)) {
                            clearDraft(); renderTab()
                        } else toast("기록 저장 실패 · 기존 기록을 유지했어요")
                    }.show()
            })
            addView(action("이 달 저장 기록 삭제", destructive = true) {
                AlertDialog.Builder(this@MainActivity).setTitle("${month} 기록 삭제")
                    .setMessage("선택한 월에 저장된 기록만 삭제합니다. 계속할까요?")
                    .setNegativeButton("취소", null)
                    .setPositiveButton("삭제") { _, _ ->
                        if (RecordStore.replaceMonth(this@MainActivity, month, emptyList())) {
                            clearDraft(); renderTab()
                        } else toast("기록 삭제 실패 · 기존 기록을 유지했어요")
                    }.show()
            }.apply { topSpace(9) })
            addView(label("※ 식사 12:00 ~ 13:00처럼 명시된 시간만 차감합니다. 누락되면 원본에서 확인해 주세요.", 11.5f, muted).apply { topSpace(10) })
        })
    }

    private fun renderStats(root: LinearLayout) {
        val rows = currentRecords()
        val minutes = rows.sumOf { it.minutes }
        root.addView(heading("근무 통계", "${month.year}년 ${month.monthValue}월 · 기록을 한눈에", blue))
        root.addView(horizontal().apply {
            addView(statCard("계산 근무", "${minutes / 60}h ${minutes % 60}m", blueSoft, blue), LinearLayout.LayoutParams(0, -2, 1f))
            addView(statCard("근무 일수", "${rows.map { it.date }.distinct().size}일", greenSoft, aqua), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
        }.withMargin(0, 12, 0, 11))
        renderWeeklyChart(root, rows)
        val all = RecordStore.read(this)
        val last = (5 downTo 0).mapNotNull { steps ->
            runCatching { month.minusMonths(steps.toLong()) }.getOrNull()
        }.map { ym ->
            ym to all.filter { it.date.startsWith(ym.toString()) }.sumOf { it.minutes }
        }
        val max = (last.maxOfOrNull { it.second } ?: 0).coerceAtLeast(1)
        root.addView(section("최근 6개월 비교", "저장된 날짜별 기록을 기준으로 계산해요").apply {
            last.forEach { (ym, value) ->
                addView(horizontal().apply {
                    gravity = Gravity.CENTER_VERTICAL
                    addView(label("${ym.monthValue}월", 12f, ink, true), LinearLayout.LayoutParams(dp(36), -2))
                    addView(FrameLayout(this@MainActivity).apply {
                        background = shape(blueSoft, radius = 5)
                        addView(View(this@MainActivity).apply {
                            background = shape(if (ym == month) blue else Color.parseColor("#A8B9F9"), radius = 5)
                        }, FrameLayout.LayoutParams(0, -1).apply { width = 0 })
                        post {
                            val bar = getChildAt(0)
                            bar.layoutParams = FrameLayout.LayoutParams(
                                (width * (value.toFloat() / max)).toInt().coerceAtLeast(if (value > 0) dp(3) else 0), -1)
                        }
                    }, LinearLayout.LayoutParams(0, dp(9), 1f).apply { marginStart = dp(8) })
                    addView(label("${value / 60}h ${value % 60}m", 11f, muted).apply { gravity = Gravity.END }, LinearLayout.LayoutParams(dp(76), -2))
                }.apply { topSpace(11) })
            }
        })
        root.addView(section("기록 확인", "합계가 공식 인정시간과 다르면 원본을 대조하세요").apply {
            addView(action("기록에서 상세 확인", primary = true) { tab = 1; renderTab() })
        })
    }

    /** Device-owned permission screens. We never change security settings ourselves. */
    private fun renderSettings(root: LinearLayout) {
        root.addView(heading("설정", "자동 수집 권한과 설치 안내", blue))
        root.addView(section("접근성 자동 수집", "${if (isAccessibilityEnabled()) "현재 사용 중" else "현재 사용 안 함"} · 공식 출근부 목록만 읽어요").apply {
            addView(chip(if (isAccessibilityEnabled()) "● 접근성 켜짐" else "○ 접근성 꺼짐",
                if (isAccessibilityEnabled()) greenSoft else amberSoft,
                if (isAccessibilityEnabled()) aqua else amber))
            addView(label("목록 수집 버튼을 누른 경우에만 날짜와 근무시각을 읽어요. 스크린샷 인식은 사용하지 않습니다.", 12f, muted).apply { topSpace(9) })
            addView(action("접근성 설정 바로 열기", primary = true) { showAccessibilityDisclosure(true) }.apply { topSpace(9) })
            addView(action("근무로그 앱 설정 열기") { openOwnAppDetails() }.apply { topSpace(8) })
        })
        root.addView(section("처음 시작하기 · 3단계", "설치부터 권한 허용까지 차례대로 확인하세요").apply {
            addView(guideRow("01", "APK 설치 확인", "신뢰하는 출처의 설치 파일인지 확인하세요. Play Protect 경고가 뜨면 검사 결과부터 확인하세요.", "Google Play", "com.android.vending") { openPlayStore() })
            addView(guideRow("02", "제한된 설정 허용", "Android 13 이상: 설정 › 앱 › 근무로그 › 우측 상단 ⋮ › 제한된 설정 허용. 본인이 신뢰하는 앱에만 허용하세요.", "Android 설정", "com.android.settings") { openOwnAppDetails() })
            addView(guideRow("03", "접근성 서비스 켜기", "설정 › 접근성 › 설치된 앱 › 근무로그 › 사용. 승인 후 공식 출근부의 목록 수집 버튼을 누르세요.", "접근성", "com.android.settings") { showAccessibilityDisclosure(true) })
            addView(action("제한된 설정 안내 · Google 공식 문서") {
                openHelpUrl("https://support.google.com/android/answer/12623953?hl=ko")
            }.apply { topSpace(10) })
        })
        root.addView(section("Google Play 프로텍트", "Google Play 아이콘과 공식 도움말에서 보호 상태를 확인하세요").apply {
            addView(guideRow("✓", "Google Play에서 확인", "Play 스토어 › 프로필 › Play 프로텍트 › 설정(톱니바퀴) › 'Play 프로텍트로 앱 검사'. 해제도 가능하지만 보안을 위해 항상 켜 두는 것을 권장합니다.", "Google Play", "com.android.vending") { openPlayStore() })
            addView(label("설치 경고가 나올 때 무조건 보호 기능을 끄지 마세요. 인증된 서명본과 설치 출처를 확인하고, 오탐이면 Google에 재검토를 요청하세요.", 12f, muted).apply { topSpace(8) })
            addView(action("Google 공식 Play 프로텍트 안내") {
                openHelpUrl("https://support.google.com/googleplay/answer/2812853?hl=ko")
            }.apply { topSpace(9) })
        })
        root.addView(section("기록 관리", "앱 버전 유지 · 데이터는 기기 내부에 저장").apply {
            addView(infoRow("현재 버전", versionName))
            addView(infoRow("Android 지원", minAndroidText))
            addView(action("기록 백업·편집으로 이동") { tab = 1; renderTab() }.apply { topSpace(9) })
            addView(action("접근성 수집 범위 설명") { showAccessibilityDisclosure(false) }.apply { topSpace(8) })
        })
    }

    private fun guideRow(number: String, title: String, content: String, iconLabel: String, pkg: String, onClick: () -> Unit): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(cardGray, radius = 13, stroke = border)
            setPadding(dp(12), dp(11), dp(12), dp(11))
            addView(horizontal().apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(label(number, 11f, blue, true).apply {
                    gravity = Gravity.CENTER; background = shape(blueSoft, radius = 9)
                }, LinearLayout.LayoutParams(dp(30), dp(30)))
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(9), 0, 0, 0)
                    addView(label(title, 13.5f, ink, true))
                    addView(label(iconLabel, 10f, muted))
                }, LinearLayout.LayoutParams(0, -2, 1f))
                addView(ImageView(this@MainActivity).apply {
                    try { setImageDrawable(packageManager.getApplicationIcon(pkg)) }
                    catch (_: Exception) { setImageResource(R.mipmap.ic_launcher) }
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    contentDescription = "$iconLabel 아이콘"
                }, LinearLayout.LayoutParams(dp(29), dp(29)))
            })
            addView(label(content, 12f, ink).apply { topSpace(8) })
            addView(action("설정/안내 열기", onClick = onClick).apply { topSpace(8) })
        }.withMargin(0, 0, 0, 8)

    private fun openOwnAppDetails() {
        try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.parse("package:$packageName"))) }
        catch (_: Exception) { toast("앱 설정 화면을 열 수 없습니다") }
    }
    private fun openPlayStore() {
        try {
            val launch = packageManager.getLaunchIntentForPackage("com.android.vending")
            if (launch != null) startActivity(launch) else openHelpUrl("https://play.google.com/store")
        } catch (_: Exception) { toast("Google Play를 열 수 없습니다") }
    }
    private fun openHelpUrl(address: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(address))) }
        catch (_: Exception) { toast("안내 링크를 열 수 없습니다") }
    }

    /** One clear, separate disclosure immediately before directing the user to Android's settings. */
    private fun showAccessibilityDisclosure(openSettings: Boolean) {
        // A previous acceptance never silently authorizes a new permissions flow.
        // Dismissing the dialog is not treated as consent.
        if (openSettings) RecordStore.setConsent(this, false)
        val disclosure = "이 앱은 한국장학재단의 공식 앱이 아닌 개인용 근무기록 도우미입니다.\n\n" +
            "• 접근 대상: 한국장학재단 출근부 앱(com.kosaf.gpsAttendance)\n" +
            "• 읽는 내용: 조회 목록에 표시된 근무 날짜, 출퇴근 시각, 식사·휴게시간, 기관 확인 상태\n" +
            "• 동작: 사용자가 ‘목록 수집’을 누르면 접근성에 표시된 텍스트를 읽고 목록만 스크롤합니다. 스크린샷/OCR은 하지 않습니다.\n" +
            "• 보관: 추출한 근무기록은 이 휴대전화의 앱 내부에만 저장합니다. 로그인 정보는 수집·저장하지 않으며 서버로 전송하지 않습니다.\n" +
            "• 사용 중지: 떠 있는 ‘중지’ 버튼이나 앱의 ‘접근성 끄기’ 버튼을 사용하세요. 완료 시 자동 해제를 요청합니다.\n\n" +
            "이 권한은 강력한 화면 접근 권한입니다. 반드시 내용을 확인한 뒤 동의해 주세요. 거절해도 기록 탭에서 직접 편집하거나 텍스트를 붙여넣을 수 있습니다."
        AlertDialog.Builder(this)
            .setTitle("접근성 권한 · 수집 범위 안내")
            .setMessage(disclosure)
            .setNegativeButton(if (openSettings) "동의하지 않음" else "닫기") { _, _ ->
                if (openSettings) RecordStore.setConsent(this, false)
            }
            .setPositiveButton(if (openSettings) "동의하고 설정 열기" else "확인") { _, _ ->
                if (openSettings) {
                    try {
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        RecordStore.setConsent(this, true)
                    } catch (_: Exception) {
                        toast("접근성 설정을 열 수 없습니다")
                        RecordStore.setConsent(this, false)
                    }
                }
            }
            .show()
    }

    private fun applyFields() {
        val year = yearField?.text?.toString()?.trim()?.toIntOrNull()
        val monthNumber = monthField?.text?.toString()?.trim()?.toIntOrNull()
        if (year == null || year !in 1..9999 || monthNumber == null || monthNumber !in 1..12) {
            toast("연도는 1~9999, 월은 1~12 사이의 숫자로 입력해 주세요")
            return
        }
        changeTo(YearMonth.of(year, monthNumber), preserveScroll = true)
    }

    private fun changeMonth(direction: Int) {
        val next = if (direction == 0) YearMonth.now() else runCatching { month.plusMonths(direction.toLong()) }.getOrNull()
        if (next == null || next.year !in 1..9999) {
            toast("연도는 0001~9999까지 선택할 수 있습니다")
            return
        }
        changeTo(next, preserveScroll = true)
    }

    private fun changeTo(value: YearMonth, preserveScroll: Boolean = false) {
        val scrollY = if (preserveScroll) currentScrollY() else 0
        month = value
        RecordStore.setSelectedMonth(this, value)
        clearDraft()
        showAllRows = false
        renderTab()
        if (periodEditorMode) showPeriodEditorImmediately()
        else if (preserveScroll) restoreScroll(scrollY)
    }

    private fun currentScrollY(): Int = (host.getChildAt(0) as? ScrollView)?.scrollY ?: 0

    private fun restoreScroll(scrollY: Int) {
        val scrollView = host.getChildAt(0) as? ScrollView ?: return
        scrollView.post { scrollView.scrollTo(0, scrollY) }
    }

    private fun monthlySummaryText(rows: List<WorkRecord> = currentRecords()): String {
        val total = rows.sumOf { it.minutes }
        val breakTotal = rows.sumOf { it.breakMinutes }
        val mismatch = rows.count { it.differentFromReported }
        return "${month.year}년 ${month.monthValue}월 근무 ${total / 60}시간 ${total % 60}분 · 휴게 차감 ${breakTotal / 60}시간 ${breakTotal % 60}분 · 확인 필요 ${mismatch}건"
    }

    private fun fullMonthText(): String = AttendanceParser.monthlyShareText(currentRecords(), month)

    private fun copyText(label: String, value: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText(label, value))
    }

    private fun copyMonthDetails() {
        runCatching { copyText("${month} 날짜·출퇴근 시각", fullMonthText()) }
            .onSuccess { toast("전체 날짜·출퇴근 시각을 복사했어요") }
            .onFailure { Log.e("AttendanceShare", "Copy failed", it); toast("복사할 수 없습니다") }
    }

    /** A single tap opens the Android share sheet with ALL dated shift details. */
    private fun shareSummary() {
        try {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, fullMonthText())
            }, "월간 날짜·시각 공유"))
        } catch (e: Exception) {
            Log.e("AttendanceShare", "Could not open share sheet", e)
            toast("공유 화면을 열 수 없습니다")
        }
    }

    /**
     * Uses the verified official Play package (com.kosaf.gpsAttendance).
     * Package visibility is declared narrowly in AndroidManifest.xml.
     * Never request QUERY_ALL_PACKAGES or an elevated permission.
     */
    private fun openOfficialAttendanceApp() {
        val launcher = try {
            packageManager.getLaunchIntentForPackage(targetAttendancePackage)
                ?: Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_LAUNCHER)
                    setPackage(targetAttendancePackage)
                }.let { intent ->
                    val info = packageManager.resolveActivity(intent, 0)
                    if (info != null) intent else null
                }
        } catch (error: Exception) {
            Log.w("AttendanceLauncher", "Could not resolve official app", error)
            null
        }
        if (launcher != null) {
            try {
                startActivity(launcher.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            } catch (error: ActivityNotFoundException) {
                Log.w("AttendanceLauncher", "Official app is not launchable", error)
            } catch (error: SecurityException) {
                Log.w("AttendanceLauncher", "Launch restricted by device", error)
            }
        }
        AlertDialog.Builder(this)
            .setTitle("공식 출근부 앱을 열 수 없어요")
            .setMessage("한국장학재단 출근부 앱이 설치되지 않았거나, 사용 중지·보안 정책으로 실행할 수 없습니다. Play 스토어의 공식 앱 페이지를 확인할까요?")
            .setNegativeButton("닫기", null)
            .setPositiveButton("공식 앱 확인") { _, _ -> openOfficialAppStorePage() }
            .show()
    }

    private fun openOfficialAppStorePage() {
        val storeUrl = "https://play.google.com/store/apps/details?id=$targetAttendancePackage"
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$targetAttendancePackage")))
        } catch (error: ActivityNotFoundException) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(storeUrl)))
            } catch (fallbackError: Exception) {
                toast("공식 앱 페이지를 열 수 없습니다")
            }
        } catch (error: SecurityException) {
            toast("기기 정책에 따라 앱 스토어를 열 수 없습니다")
        }
    }

    private fun showOfficialAppIconOrFallback(target: ImageView, fallback: Int) {
        // Fetches the real currently installed official app icon, so the graphic
        // is accurate and no third-party trademark asset is bundled in our APK.
        try {
            target.setImageDrawable(packageManager.getApplicationIcon(targetAttendancePackage))
        } catch (error: PackageManager.NameNotFoundException) {
            target.setImageResource(fallback)
        } catch (error: Exception) {
            Log.w("AttendanceLauncher", "Official app icon unavailable", error)
            target.setImageResource(fallback)
        }
    }

    private fun <T : View> animateEntrance(view: T, delayMs: Long = 0L): T = view.apply {
        if (!ValueAnimator.areAnimatorsEnabled() || periodEditorMode) return@apply
        alpha = 0f
        translationY = dp(9).toFloat()
        scaleX = 0.985f
        scaleY = 0.985f
        post {
            animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                .setStartDelay(delayMs).setDuration(320)
                .setInterpolator(android.view.animation.DecelerateInterpolator()).start()
        }
    }

    private fun currentRecords(): List<WorkRecord> = RecordStore.read(this).filter { it.date.startsWith(month.toString()) }

    private fun saveDraft() {
        val field = exportField ?: return
        draftMonth = month
        draftText = field.text.toString()
        draftPasteText = pasteField?.text?.toString() ?: draftPasteText
    }

    private fun clearDraft() { draftMonth = null; draftText = null; draftPasteText = null }

    private fun isAccessibilityEnabled(): Boolean {
        val component = ComponentName(this, CollectorAccessibilityService::class.java).flattenToString()
        return (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "")
            .split(":")
            .any { it.equals(component, ignoreCase = true) }
    }

    private fun createFile(request: Int, mime: String, filename: String) {
        try {
            pendingFileRequest = request
            pendingFileContent = if (request == saveCsv) {
                AttendanceParser.csv(RecordStore.read(this), month)
            } else {
                exportField?.text?.toString() ?: AttendanceParser.export(currentRecords(), month)
            }
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = mime
                putExtra(Intent.EXTRA_TITLE, filename)
            }, request)
        } catch (e: Exception) {
            pendingFileRequest = null
            pendingFileContent = null
            toast("파일 저장 화면을 열 수 없습니다")
            Log.e("AttendanceFile", "Could not open document picker", e)
        }
    }

    private fun heading(title: String, subtitle: String, color: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(label(title, 22f, ink, bold = true))
        addView(label(subtitle, 12.5f, muted).apply { topSpace(5) })
    }

    private fun recordPreview(item: WorkRecord): LinearLayout = horizontal().apply {
        gravity = Gravity.CENTER_VERTICAL
        val warning = item.differentFromReported
        val badgeColor = if (warning) amber else if (item.breakMinutes > 0) aqua else blueDeep
        val badgeBg = if (warning) amberSoft else if (item.breakMinutes > 0) greenSoft else blueSoft
        background = shape(if (warning) lemon else if (item.breakMinutes > 0) Color.parseColor("#F0FEFA") else skySoft, radius = 14, stroke = if (warning) Color.parseColor("#F5D69D") else if (item.breakMinutes > 0) Color.parseColor("#C2EBDA") else Color.parseColor("#D1E9FB"))
        setPadding(dp(11), dp(11), dp(11), dp(11))
        topSpace(7)
        addView(label(item.date.takeLast(5).replace('-', '.'), 14f, badgeColor, bold = true).apply {
            gravity = Gravity.CENTER
            background = shape(badgeBg, radius = 11)
            setPadding(dp(8), dp(10), dp(8), dp(10))
        })
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, dp(4), 0)
            addView(label("${item.start} ~ ${item.end}", 13f, ink, bold = true))
            addView(label(when {
                warning -> "⚠ 표시시간 차이 · 원본 확인"
                item.breakMinutes > 0 -> "식사 ${item.breakStart} ~ ${item.breakEnd} · ${item.breakMinutes}분 차감"
                else -> if (item.status.isBlank()) "근무 내역" else item.status
            }, 10.5f, if (warning) amber else muted).apply { topSpace(4) })
        }, LinearLayout.LayoutParams(0, -2, 1f))
        addView(label("${item.minutes / 60}h ${item.minutes % 60}m", 15f, badgeColor, bold = true).apply {
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
        })
    }

    private fun heroMetric(title: String, value: String, accent: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = gradient(intArrayOf(Color.parseColor("#273E92"), Color.parseColor("#4F3E9D")), radius = 15)
        setPadding(dp(10), dp(12), dp(8), dp(12))
        addView(label(title, 10f, Color.parseColor("#E5ECFF")))
        addView(label(value, 17f, accent, bold = true).apply { topSpace(5) })
    }

    private fun statCard(title: String, value: String, bg: Int, fg: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = shape(Color.WHITE, radius = 14, stroke = border)
        setPadding(dp(10), dp(12), dp(8), dp(12))
        addView(label(title, 11.5f, muted, bold = true))
        addView(label(value, 18f, fg, bold = true).apply { topSpace(6) })
    }

    private fun chip(textValue: String, bg: Int, fg: Int): TextView = label(textValue, 11.5f, fg, bold = true).apply {
        background = shape(bg, radius = 100)
        setPadding(dp(10), dp(6), dp(10), dp(6))
    }

    private fun lifestyleCard(title: String, subtitle: String, drawableRes: Int, bg: Int, accent: Int, officialIcon: Boolean = false, actionText: String = "열기", onClick: () -> Unit): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        background = RippleDrawable(ColorStateList.valueOf(Color.parseColor("#244269F5")), shape(bg, radius = 13, stroke = border), null)
        setPadding(dp(10), dp(11), dp(8), dp(11))
        minHeight = dp(70)
        isClickable = true; isFocusable = true
        contentDescription = "$title, $subtitle"
        setOnClickListener { onClick() }
        addView(ImageView(this@MainActivity).apply {
            if (officialIcon) showOfficialAppIconOrFallback(this, drawableRes) else setImageResource(drawableRes)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = null
        }, LinearLayout.LayoutParams(dp(30), dp(30)).apply { marginEnd = dp(8) })
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            addView(label(title, 12.5f, accent, true).apply { maxLines = 1 })
            addView(label(subtitle, 10f, muted).apply { topSpace(3); maxLines = 1 })
        }, LinearLayout.LayoutParams(0, -2, 1f))
    }

    private fun infoRow(title: String, value: String): LinearLayout = horizontal().apply {
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(6), 0, dp(6))
        addView(label(title, 13f, muted, bold = true), LinearLayout.LayoutParams(0, -2, 0.9f))
        addView(label(value, 13f, ink, bold = true), LinearLayout.LayoutParams(0, -2, 1.1f))
    }

    private fun changeLogItem(title: String, desc: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        setPadding(0, dp(7), 0, dp(7))
        addView(label(title, 12.5f, blueDeep, bold = true).apply {
            gravity = Gravity.CENTER
            background = shape(blueSoft, radius = 12)
            setPadding(dp(14), dp(5), dp(14), dp(5))
        })
        addView(label(desc, 12.5f, ink).apply { setPadding(dp(10), dp(4), 0, dp(4)) }, LinearLayout.LayoutParams(0, -2, 1f))
    }

    private fun fieldBox(title: String, value: String, digits: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(label(title, 12f, muted, bold = true))
        addView(EditText(this@MainActivity).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            filters = arrayOf(InputFilter.LengthFilter(digits))
            setSingleLine(true)
            setText(value)
            selectAll()
            textSize = 19f
            setTextColor(ink)
            background = shape(cardGray, radius = 12, stroke = border)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }.also { if (digits == 4) yearField = it else monthField = it })
    }

    private fun section(title: String, description: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = shape(Color.WHITE, radius = 18, stroke = border)
        setPadding(dp(14), dp(15), dp(14), dp(14))
        addView(label(title, 16f, ink, true))
        addView(label(description, 11.5f, muted).apply { topSpace(4) })
        addView(space(12))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(11) }
    }

    private fun step(index: String, title: String, sub: String): LinearLayout = horizontal().apply {
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(7), 0, dp(7))
        addView(label(index, 13f, blue, bold = true).apply {
            gravity = Gravity.CENTER
            background = shape(when (index) { "01" -> blueSoft; "02" -> greenSoft; else -> violetSoft }, radius = 12)
            setTextColor(when (index) { "01" -> blue; "02" -> aqua; else -> violet })
        }, LinearLayout.LayoutParams(dp(42), dp(42)))
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
            addView(label(title, 13.5f, ink, bold = true))
            addView(label(sub, 11.5f, muted).apply { topSpace(3) })
        }, LinearLayout.LayoutParams(0, -2, 1f))
    }

    private fun label(value: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        typeface = Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
        includeFontPadding = true
        setLineSpacing(dp(1).toFloat(), 1.05f)
    }

    private fun action(textValue: String, primary: Boolean = false, destructive: Boolean = false, onClick: () -> Unit): Button = Button(this).apply {
        text = textValue
        isAllCaps = false
        textSize = if (textValue.length >= 10) 11.5f else 13f
        setPadding(dp(5), dp(3), dp(5), dp(3))
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        val accent = when {
            textValue.contains("접근성") || textValue.contains("OCR") || textValue.contains("권한") -> aqua
            textValue.contains("파일") || textValue.contains("복사") || textValue.contains("공유") -> violet
            textValue.contains("삭제") -> red
            textValue.contains("이전") || textValue.contains("다음") || textValue.contains("이번") -> sky
            textValue.contains("공식 앱") -> coral
            else -> blueDeep
        }
        setTextColor(when { primary -> Color.WHITE; destructive -> red; else -> accent })
        val shapeBase = when {
            primary -> when (accent) {
                aqua -> gradient(intArrayOf(Color.parseColor("#0EA7B0"), Color.parseColor("#18C4A3")), radius = 14)
                violet -> gradient(intArrayOf(violet, coral), radius = 14)
                else -> gradient(intArrayOf(blue, violet), radius = 14)
            }
            destructive -> shape(redSoft, radius = 14, stroke = Color.parseColor("#FFD2DC"))
            accent == sky -> shape(skySoft, radius = 14)
            accent == violet -> shape(violetSoft, radius = 14)
            else -> shape(blueSoft, radius = 14)
        }
        background = RippleDrawable(ColorStateList.valueOf(Color.parseColor("#44FFFFFF")), shapeBase, null)
        if (primary) elevation = dp(1).toFloat()
        minHeight = dp(43)
        setOnTouchListener { _, event ->
            if (ValueAnimator.areAnimatorsEnabled() && !periodEditorMode) {
                when (event.actionMasked) {
                    android.view.MotionEvent.ACTION_DOWN -> animate().scaleX(0.985f).scaleY(0.985f).setDuration(90L).start()
                    android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL ->
                        animate().scaleX(1f).scaleY(1f).setDuration(130L).start()
                }
            }
            false // Android still handles the normal click and accessibility action
        }
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(43))
    }

    private fun horizontal(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    private fun space(height: Int): View = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }

    private fun <T : View> T.topSpace(dpSize: Int): T = apply {
        val params = (layoutParams as? LinearLayout.LayoutParams) ?: LinearLayout.LayoutParams(-1, -2)
        params.topMargin = dp(dpSize)
        layoutParams = params
    }

    private fun <T : View> T.withMargin(left: Int, top: Int, right: Int, bottom: Int): T = apply {
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(left), dp(top), dp(right), dp(bottom)) }
    }

    private fun shape(fill: Int, radius: Int = 16, stroke: Int = Color.TRANSPARENT): GradientDrawable = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }

    private fun gradient(colors: IntArray, radius: Int): GradientDrawable = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply {
        cornerRadius = dp(radius).toFloat()
    }

    private fun toast(message: String) { Toast.makeText(this, message, Toast.LENGTH_LONG).show() }
    private fun dp(value: Int): Int = (resources.displayMetrics.density * value).toInt()
}
