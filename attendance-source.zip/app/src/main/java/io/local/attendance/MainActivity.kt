package io.local.attendance

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.animation.ValueAnimator
import android.content.ActivityNotFoundException
import android.content.pm.PackageManager
import android.net.Uri
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Rect
import android.view.MotionEvent
import android.view.inputmethod.InputMethodManager
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.os.SystemClock
import java.io.IOException
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.os.Build
import android.util.Log
import android.provider.Settings
import android.provider.CalendarContract
import java.time.format.DateTimeFormatter
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.time.YearMonth
import java.time.LocalDate
import java.time.LocalTime
import java.time.DayOfWeek
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters
import java.util.Locale

/** Native, dependency-light personal dashboard. No credentials or network permissions. */
class MainActivity : Activity() {
    companion object {
        const val ACTION_EDIT_PERIOD = "io.local.attendance.action.EDIT_PERIOD"
    }
    private val saveTxt = 1102
    private val saveCsv = 1103
    private val targetAttendancePackage = "com.kosaf.gpsAttendance"

    // Persisted app-wide dark/light palette; every tab uses the same surface tokens.
    private var darkMode = false
    private var historyEarlyExpanded = false
    private var historyLaterExpanded = false
    private var lastVisibilityRefresh = 0L
    // Prism palette: compact contrasts across all four tabs.
    private val navy: Int get() = Color.parseColor(if (darkMode) "#DEE7FF" else "#14234B")
    private val blue: Int get() = Color.parseColor(if (darkMode) "#A6BCFF" else "#3151BB")
    private val blueDeep: Int get() = Color.parseColor(if (darkMode) "#B8C5FF" else "#3946BB")
    private val blueSoft: Int get() = Color.parseColor(if (darkMode) "#263458" else "#EEF2FF")
    private val violet: Int get() = Color.parseColor(if (darkMode) "#D7B6FF" else "#7139BC")
    private val violetSoft: Int get() = Color.parseColor(if (darkMode) "#352A52" else "#F1EEFF")
    private val aqua: Int get() = Color.parseColor(if (darkMode) "#7AE0CF" else "#006E67")
    private val greenSoft: Int get() = Color.parseColor(if (darkMode) "#193C39" else "#E4F8F3")
    private val amber: Int get() = Color.parseColor(if (darkMode) "#F9CB72" else "#9D6208")
    private val amberSoft: Int get() = Color.parseColor(if (darkMode) "#42351F" else "#FFF3D9")
    private val red: Int get() = Color.parseColor(if (darkMode) "#FF90A9" else "#BB285A")
    private val redSoft: Int get() = Color.parseColor(if (darkMode) "#452638" else "#FFF1F5")
    private val surface: Int get() = Color.parseColor(if (darkMode) "#111827" else "#F6F8FC")
    private val border: Int get() = Color.parseColor(if (darkMode) "#596C87" else "#C5CFDE")
    private val ink: Int get() = Color.parseColor(if (darkMode) "#EFF3FF" else "#18253E")
    private val muted: Int get() = Color.parseColor(if (darkMode) "#D3DEEF" else "#3F4D63")
    private val cardGray: Int get() = Color.parseColor(if (darkMode) "#202B3D" else "#F5F7FB")
    private val coral: Int get() = Color.parseColor(if (darkMode) "#FFB0CA" else "#B12A61")
    private val coralSoft: Int get() = Color.parseColor(if (darkMode) "#472B3B" else "#FFF1F5")
    private val sky: Int get() = Color.parseColor(if (darkMode) "#A5E0FF" else "#005F99")
    private val skySoft: Int get() = Color.parseColor(if (darkMode) "#193A53" else "#E9F7FF")
    private val peach: Int get() = Color.parseColor(if (darkMode) "#423124" else "#FFF2E5")
    private val lemon: Int get() = Color.parseColor(if (darkMode) "#423B25" else "#FFF8D9")

    private lateinit var shell: LinearLayout
    private lateinit var host: FrameLayout
    private lateinit var navigation: LinearLayout
    private lateinit var topBar: LinearLayout
    // Avoid repeatedly rebuilding the dashboard after startup errors.
    private var startupFailed = false
    private var firstResume = true
    // The floating date shortcut keeps the complete home dashboard visible
    // and aligns the existing date form to the scroll viewport after layout.
    private var periodEditorMode = false
    private var periodEditorSection: View? = null
    private var lastRenderedRecordsHash: Int? = null
    private var renderingTab = false
    private var lastRenderedCollectionInfoHash: Int? = null
    private var pendingFileRequest: Int? = null
    private var pendingFileContent: String? = null

    private var tab = 0
    // Zero = vertical bar chart, one = trend line graph; kept across rotations.
    private var flowDisplayMode = 0
    private var showAllRows = false
    private lateinit var month: YearMonth
    private var yearField: EditText? = null
    private var monthField: EditText? = null
    private var pasteField: EditText? = null
    private var draftMonth: YearMonth? = null
    private var draftText: String? = null
    private var draftPasteText: String? = null
    // Inline record editing: no separate Dialog/window is created when Edit is tapped.
    private var recordEditMode = false
    private var inlineRecordField: EditText? = null

    private val versionName = "v1.7"
    private val minAndroidText = "Android 8.0 이상 (API 26+)"
    private val targetAndroidText = "Android 8.0~16 지원 · Android 16 (API 36) 대응"

    override fun onCreate(savedInstanceState: Bundle?) {
        // Keep the icon-based OS launch splash, then switch to the normal app theme.
        darkMode = getSharedPreferences("attendance_display", MODE_PRIVATE).getBoolean("dark_mode", false)
        setTheme(if (darkMode) R.style.AttendanceThemeDark else R.style.AttendanceTheme)
        super.onCreate(savedInstanceState)
        // Startup failures should show a minimal diagnostic screen instead of an
        // unexplained immediate close. User attendance records are never deleted.
        try {
            // Saved UI state wins over a previously consumed intent on rotation.
            periodEditorMode = savedInstanceState?.getBoolean("period_editor_mode")
                ?: (intent?.action == ACTION_EDIT_PERIOD)
            tab = savedInstanceState?.getInt("selected_tab", 0)?.coerceIn(0, 3) ?: 0
            flowDisplayMode = (savedInstanceState?.getInt("flow_display_mode")
                ?: getSharedPreferences("attendance_display", MODE_PRIVATE).getInt("flow_mode", 0)).coerceIn(0, 1)
            showAllRows = savedInstanceState?.getBoolean("show_all_rows", false) ?: false
            draftMonth = savedInstanceState?.getString("draft_month")?.let { runCatching { YearMonth.parse(it) }.getOrNull() }
            draftText = savedInstanceState?.getString("draft_text")
            recordEditMode = savedInstanceState?.getBoolean("record_edit_mode", false) ?: false
            draftPasteText = savedInstanceState?.getString("draft_paste_text")
            pendingFileRequest = savedInstanceState?.getInt("pending_file_request", -1)?.takeIf { it > 0 }
            pendingFileContent = savedInstanceState?.getString("pending_file_content")
            initializeDashboard()
            // Only a genuinely fresh launcher start gets the extra three-second overlay.
            // Returning from background, opening via a shortcut, rotating, or restoring
            // Android's OS-managed launch splash is sufficient. Do NOT add a
            // three-second in-app overlay: launcher re-entry/background restores
            // can produce a second splash even when this task is already alive.
            if (!periodEditorMode && savedInstanceState != null) {
                restoreScroll(savedInstanceState.getInt("scroll_position", 0))
            }
        } catch (error: Exception) {
            startupFailed = true
            Log.e("AttendanceStartup", "Failed to initialize the dashboard", error)
            showStartupError(error)
        }
    }

    private fun initializeDashboard() {
        // Edge-to-edge is mandatory for targetSdk 36. Keep the gradient behind the
        // status bar and the bottom navigation behind gesture/three-button insets.
        // Using system-bar colors alone on Android 16 no longer protects content.
        configureSystemBars()
        month = RecordStore.selectedMonth(this)
        RecordStore.refreshDisclosureConsent(this)

        shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(surface)
            clipToPadding = false
        }
        setContentView(shell)
        shell.isFocusableInTouchMode = true
        shell.requestFocus()

        topBar = toolbar()
        shell.addView(topBar)
        host = FrameLayout(this)
        shell.addView(host, LinearLayout.LayoutParams(-1, 0, 1f))
        navigation = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = shape(if (darkMode) cardGray else Color.WHITE, radius = 0, stroke = border)
            elevation = dp(4).toFloat()
            setPadding(dp(14), dp(5), dp(14), dp(5))
            clipToPadding = false
        }
        shell.addView(navigation, LinearLayout.LayoutParams(-1, dp(65)))

        shell.setOnApplyWindowInsetsListener { _, insets ->
            // Insets may arrive while the Activity is still being initialized.
            // Never let a transient insets issue terminate the application.
            try {
                if (::topBar.isInitialized && ::navigation.isInitialized && ::host.isInitialized) {
                    applyInsets(insets)
                }
            } catch (error: Exception) {
                Log.e("AttendanceStartup", "Could not apply window insets", error)
            }
            insets
        }
        renderTab()
        // Layout/insets are requested only after the entire view hierarchy is built.
        shell.post {
            if (!startupFailed) {
                updateSystemBarIconsSafely()
                shell.requestApplyInsets()
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putBoolean("period_editor_mode", periodEditorMode)
        outState.putInt("selected_tab", tab)
        outState.putInt("flow_display_mode", flowDisplayMode)
        outState.putBoolean("show_all_rows", showAllRows)
        outState.putInt("scroll_position", currentScrollY())
        if (tab == 1) saveDraft()
        outState.putBoolean("record_edit_mode", recordEditMode)
        // Avoid oversized Binder state from a pasted multi-page record export.
        draftText?.takeIf { it.length <= 70000 }?.let { outState.putString("draft_text", it) }
        draftMonth?.let { outState.putString("draft_month", it.toString()) }
        draftPasteText?.takeIf { it.length <= 50000 }?.let { outState.putString("draft_paste_text", it) }
        pendingFileRequest?.let { outState.putInt("pending_file_request", it) }
        pendingFileContent?.takeIf { it.length <= 70000 }?.let { outState.putString("pending_file_content", it) }
        super.onSaveInstanceState(outState)
    }

    override fun onNewIntent(newIntent: Intent) {
        super.onNewIntent(newIntent)
        setIntent(newIntent)
        if (newIntent.action != ACTION_EDIT_PERIOD) {
            // Reopening from the launcher should not trap the user in shortcut mode.
            if (newIntent.action == Intent.ACTION_MAIN && periodEditorMode) {
                periodEditorMode = false
                if (!startupFailed && ::host.isInitialized) renderTab()
            }
            return
        }
        // This intent may arrive while the Activity is already on top: singleTop.
        // Never queue a scroll on an old ScrollView that onResume will replace.
        periodEditorMode = true
        if (!startupFailed && ::host.isInitialized) {
            try {
                if (tab == 1) saveDraft()
                tab = 0
                renderTab()
                showPeriodEditorImmediately()
            } catch (error: Exception) {
                startupFailed = true
                Log.e("AttendanceNavigation", "Could not open date editor", error)
                showStartupError(error)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (firstResume) {
            firstResume = false
            if (periodEditorMode) showPeriodEditorImmediately()
        }
        if (!startupFailed && ::host.isInitialized) {
            try {
                if (periodEditorMode) {
                    // Keep the date editor aligned after returning from Settings.
                    if (tab != 0 || periodEditorSection == null) {
                        tab = 0
                        renderTab()
                    }
                    showPeriodEditorImmediately()
                } else if (tab == 3 || month != RecordStore.selectedMonth(this) ||
                    lastRenderedRecordsHash != RecordStore.read(this).hashCode() ||
                    lastRenderedCollectionInfoHash != RecordStore.lastCollection(this).hashCode()) {
                    month = RecordStore.selectedMonth(this)
                    // Always refresh permission state on the Settings tab. Refresh data
                    // views only when attendance records actually changed.
                    // clipboard or document provider momentarily pauses this Activity.
                    val previousY = currentScrollY()
                    if (tab == 1) saveDraft()
                    renderTab()
                    restoreScroll(previousY)
                }
            } catch (error: Exception) {
                startupFailed = true
                Log.e("AttendanceStartup", "Failed to resume dashboard", error)
                showStartupError(error)
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || startupFailed || !::host.isInitialized || periodEditorMode) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastVisibilityRefresh < 500L) return
        lastVisibilityRefresh = now
        if (renderingTab) return
        try {
            val currentMonth = RecordStore.selectedMonth(this)
            val currentHash = RecordStore.read(this).hashCode()
            if (month != currentMonth || lastRenderedRecordsHash != currentHash ||
                lastRenderedCollectionInfoHash != RecordStore.lastCollection(this).hashCode()) {
                if (tab == 1) saveDraft()
                val y = currentScrollY()
                month = currentMonth
                renderTab()
                restoreScroll(y)
            }
        } catch (error: Exception) {
            Log.e("AttendanceRecords", "Focus refresh failed; keeping the current screen", error)
        }
    }

    override fun onPause() {
        if (::host.isInitialized && tab == 1) saveDraft()
        super.onPause()
    }

    override fun onDestroy() {
        // No delayed in-app splash callbacks can run after returning from background.
        // Activity finishing does not revoke a separately granted accessibility service.
        super.onDestroy()
    }

    @Deprecated("Android back behavior across API levels")
    override fun onBackPressed() {
        if (periodEditorMode) {
            periodEditorMode = false
            renderTab()
            return
        }
        // Back/returning from the recent-apps screen must not disable accessibility.
        super.onBackPressed()
    }

    @Deprecated("For this small self-contained Android project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == saveTxt || requestCode == saveCsv) {
            // Capture file content BEFORE opening the system picker so a resume or
            // selected-month change never exports a different snapshot by accident.
            val snapshot = if (pendingFileRequest == requestCode) pendingFileContent else null
            pendingFileRequest = null
            pendingFileContent = null
            if (resultCode != RESULT_OK || data?.data == null) return
            try {
                val content = snapshot ?: throw IOException("저장할 파일 내용이 없습니다")
                val output = contentResolver.openOutputStream(data.data!!)
                    ?: throw IOException("저장 위치에 파일을 열 수 없습니다")
                output.use { it.write(content.toByteArray(Charsets.UTF_8)) }
                toast("파일 저장 완료")
            } catch (e: Exception) {
                Log.e("AttendanceFile", "Document write failed", e)
                toast("파일 저장 실패: ${e.localizedMessage}")
            }
            return
        }
    }

    /**
     * Avoid querying Window.getInsetsController() before the window is attached.
     * Some Android 16/OEM framework builds throw inside that platform call,
     * even when the caller uses Kotlin's null-safe operator.
     */
    @Suppress("DEPRECATION")
    private fun configureSystemBars() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
            // Do not access window.insetsController during Activity.onCreate().
        } else {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                (if (darkMode) 0 else View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR or
                    View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Three-button Samsung navigation needs a system-owned, legible region.
            // Do not obscure its controls with a completely transparent bar.
            window.isNavigationBarContrastEnforced = true
            window.isStatusBarContrastEnforced = false
        }
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
    }

    /** Optional decoration only. UI still works if the OS cannot supply a controller. */
    private fun updateSystemBarIconsSafely() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        try {
            val controller = window.decorView.windowInsetsController ?: return
            val flags = WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS or
                WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
            controller.setSystemBarsAppearance(if (darkMode) 0 else flags, flags)
        } catch (error: Exception) {
            Log.w("AttendanceStartup", "System bar icon styling skipped", error)
        }
    }

    /** Protect interactive content from notches and 3-button/gesture navigation. */
    @Suppress("DEPRECATION")
    private fun applyInsets(insets: WindowInsets) {
        val bars = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
        } else null
        val tappableBottom = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            insets.getInsets(WindowInsets.Type.tappableElement()).bottom
        } else 0
        val top = bars?.top ?: insets.systemWindowInsetTop
        val bottom = maxOf(bars?.bottom ?: insets.systemWindowInsetBottom, tappableBottom)
        val left = bars?.left ?: insets.systemWindowInsetLeft
        val right = bars?.right ?: insets.systemWindowInsetRight
        val barLeft = dp(16) + left
        val barTop = dp(9) + top
        val barRight = dp(16) + right
        if (topBar.paddingLeft != barLeft || topBar.paddingTop != barTop ||
            topBar.paddingRight != barRight || topBar.paddingBottom != dp(10)) {
            topBar.setPadding(barLeft, barTop, barRight, dp(10))
        }
        val navLeft = dp(10) + left
        val navRight = dp(10) + right
        val navBottom = dp(5) + bottom
        if (navigation.paddingLeft != navLeft || navigation.paddingBottom != navBottom ||
            navigation.paddingRight != navRight) {
            navigation.setPadding(navLeft, dp(5), navRight, navBottom)
        }
        // Landscape and foldables can have camera cutouts on the side.
        if (host.paddingLeft != left || host.paddingRight != right) host.setPadding(left, 0, right, 0)
        val targetHeight = dp(65) + bottom
        val params = navigation.layoutParams as? LinearLayout.LayoutParams
        if (params != null && params.height != targetHeight) {
            params.height = targetHeight
            navigation.layoutParams = params
        }
        // Insets are applied to the visible controls, not to the scroll host:
        // no double padding when the system switches gesture/3-button navigation.
    }

    /** A crash-safe, native-only fallback; contains no OCR or accessibility initialization. */
    private fun showStartupError(error: Exception) {
        val diagnostic = buildString {
            append("근무로그 v1.7 / Android SDK ")
            append(Build.VERSION.SDK_INT)
            append("\n")
            append(error.javaClass.name)
            append("\n")
            error.stackTrace.firstOrNull { it.className.startsWith("io.local.attendance") }
                ?.let { append(it.className).append(":").append(it.lineNumber) }
        }
        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(surface)
            setPadding(dp(24), dp(48), dp(24), dp(24))
        }
        wrapper.addView(TextView(this).apply {
            text = "근무로그를 시작하지 못했어요"
            textSize = 22f
            setTextColor(ink)
            typeface = Typeface.DEFAULT_BOLD
        })
        wrapper.addView(TextView(this).apply {
            text = "저장된 근무기록은 삭제되지 않았습니다. 아래의 진단 정보를 복사해 개발자에게 전달해 주세요."
            textSize = 15f
            setTextColor(muted)
            setPadding(0, dp(14), 0, dp(12))
        })
        wrapper.addView(TextView(this).apply {
            text = diagnostic
            textSize = 12f
            setTextColor(muted)
        })
        wrapper.addView(Button(this).apply {
            text = "진단 정보 복사"
            isAllCaps = false
            setOnClickListener {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("근무로그 시작 오류", diagnostic))
                Toast.makeText(this@MainActivity, "진단 정보를 복사했습니다", Toast.LENGTH_SHORT).show()
            }
        })
        wrapper.addView(Button(this).apply {
            text = "다시 시작"
            isAllCaps = false
            setOnClickListener { recreate() }
        })
        setContentView(wrapper)
    }

    private fun toolbar(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        background = shape(if (darkMode) cardGray else Color.WHITE, radius = 0, stroke = border)
        setPadding(dp(16), dp(9), dp(16), dp(10))
        addView(ImageView(this@MainActivity).apply {
            setImageResource(R.mipmap.ic_launcher)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "근무로그 앱 아이콘"
        }, LinearLayout.LayoutParams(dp(36), dp(36)))
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, 0, 0)
            addView(label("근무로그", 17f, ink, bold = true))
            addView(label("나의 근무시간을 한눈에", 10.5f, muted))
        }, LinearLayout.LayoutParams(0, -2, 1f))
        addView(chip(versionName, blueSoft, blueDeep))
    }

    private fun renderTab() {
        if (!::host.isInitialized || renderingTab) return
        renderingTab = true
        try {
        if (tab == 1 && recordEditMode) saveDraft()
        host.removeAllViews()
        inlineRecordField = null
        yearField = null
        monthField = null
        periodEditorSection = null
        pasteField = null

        val scroll = ScrollView(this).apply {
            clipToPadding = false
            setBackgroundColor(surface)
            setPadding(0, 0, 0, dp(20))
            isFillViewport = true
        }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(14), dp(15), dp(12))
            clipToPadding = false
        }
        scroll.addView(column, ViewGroup.LayoutParams(-1, -2))
        host.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        when (tab) {
            0 -> renderHome(column)
            1 -> try {
                renderRecords(column)
            } catch (error: Exception) {
                Log.e("AttendanceRecords", "Records screen could not be rendered", error)
                column.removeAllViews()
                column.addView(heading("기록을 표시하지 못했어요", "저장된 근무기록은 그대로 보관됩니다.", red))
                column.addView(section("화면 오류 안내", "기록을 지우거나 앱을 종료하지 않았어요.").apply {
                    addView(label("아래 진단 내용을 복사해 오류를 알려 주세요.", 12f, ink))
                    addView(action("오류 정보 복사") {
                        val report = "기록 탭 오류: ${error.javaClass.simpleName}: ${error.message.orEmpty()}"
                        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                            .setPrimaryClip(ClipData.newPlainText("근무로그 오류", report))
                        toast("오류 정보를 복사했어요")
                    }.apply { topSpace(9) })
                    addView(action("홈으로 이동") { tab = 0; renderTab() }.apply { topSpace(8) })
                })
            }
            2 -> renderStats(column)
            else -> renderSettings(column)
        }
        renderBottomNav()
        lastRenderedRecordsHash = RecordStore.read(this).hashCode()
        lastRenderedCollectionInfoHash = RecordStore.lastCollection(this).hashCode()
        // Subtle entrance motion for the dashboard sections. System-level reduced
        // animations are respected, and content never depends on animation.
        // No entrance animations on records: avoid redraws while the editor is created.
        if (tab != 1 && ValueAnimator.areAnimatorsEnabled() && !periodEditorMode) {
            for (index in 0 until minOf(2, column.childCount)) {
                animateEntrance(column.getChildAt(index), index * 60L)
            }
        }
        } finally {
            renderingTab = false
        }
    }

    /**
     * The normal home stays visible. Align the entire period editor card to the
     * visible ScrollView viewport instead of showing an isolated date-only page.
     * A post-layout Rect accounts for margins and dynamically sized cards.
     */
    private fun showPeriodEditorImmediately() {
        if (!periodEditorMode || !::host.isInitialized || startupFailed) return
        val scroll = host.getChildAt(0) as? ScrollView ?: return
        val editor = periodEditorSection ?: return
        shell.requestFocus() // Do not unexpectedly open the keyboard.
        scroll.post {
            if (!periodEditorMode || host.getChildAt(0) !== scroll ||
                editor.parent !== scroll.getChildAt(0)) return@post
            val rectangle = Rect()
            editor.getDrawingRect(rectangle)
            scroll.offsetDescendantRectToMyCoords(editor, rectangle)
            val topInset = dp(12)
            val scrollRange = ((scroll.getChildAt(0)?.height ?: 0) - scroll.height + scroll.paddingBottom)
                .coerceAtLeast(0)
            // Prefer top-aligning the card; at the end of a short page this clamps
            // to a safe reachable value without jumping to a blank bottom area.
            val destination = (scroll.scrollY + rectangle.top - topInset)
                .coerceIn(0, scrollRange)
            scroll.scrollTo(0, destination)
            editor.announceForAccessibility("조회 기간 날짜 수정 영역으로 이동했습니다")
        }
    }

    private fun renderBottomNav() {
        navigation.removeAllViews()
        val tabs = listOf("홈", "기록", "통계", "설정")
        val icons = listOf(R.drawable.nav_home, R.drawable.nav_records, R.drawable.nav_stats, R.drawable.nav_settings)
        // Four distinct, contrast-tested accents; every one has a light and dark palette.
        val accents = listOf(blueDeep, aqua, violet, sky)
        val pastels = listOf(blueSoft, greenSoft, violetSoft, skySoft)
        tabs.forEachIndexed { i, title ->
            val active = i == tab
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                background = RippleDrawable(ColorStateList.valueOf(if (darkMode) Color.parseColor("#445F76A3") else Color.parseColor("#16314F8A")),
                    shape(if (active) pastels[i] else Color.TRANSPARENT, radius = 13,
                        stroke = if (active) accents[i] else Color.TRANSPARENT), null)
                setPadding(dp(3), dp(5), dp(3), dp(5))
                isSelected = active
                contentDescription = if (active) "$title 탭, 선택됨" else "$title 탭"
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    if (i != tab || periodEditorMode) {
                        if (tab == 1) saveDraft()
                        periodEditorMode = false
                        tab = i
                        renderTab()
                    }
                }
            }
            val tint = if (active) accents[i] else muted
            item.addView(ImageView(this).apply {
                setImageResource(icons[i])
                imageTintList = ColorStateList.valueOf(tint)
                contentDescription = null
            }, LinearLayout.LayoutParams(dp(20), dp(20)))
            item.addView(label(title, 12f, if (active) accents[i] else muted, bold = active).apply {
                gravity = Gravity.CENTER
                topSpace(3)
            })
            navigation.addView(item, LinearLayout.LayoutParams(0, -1, 1f).apply {
                marginStart = dp(3)
                marginEnd = dp(3)
            })
        }
    }

    private fun renderHome(root: LinearLayout) {
        // Always render the complete dashboard. The accessibility shortcut
        // scrolls to the original date editor in this same home screen.
        val rows = currentRecords()
        val total = rows.sumOf { it.minutes }
        val mismatch = rows.count { it.differentFromReported }

        val gross = rows.sumOf { it.grossMinutes }
        val deducted = rows.sumOf { it.breakMinutes }
        val displayed = rows.sumOf { it.reportedMinutes ?: it.minutes }
        val withDisplayed = rows.count { it.reportedMinutes != null }

        val heroCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = gradient(if (darkMode) intArrayOf(Color.parseColor("#1D315F"), Color.parseColor("#392F72")) else intArrayOf(Color.parseColor("#26366F"), Color.parseColor("#4E5FBA")), radius = 20)
            setPadding(dp(17), dp(16), dp(17), dp(15))
            addView(horizontal().apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(label("${month.year}년 ${month.monthValue}월의 기록", 12f, Color.parseColor("#DCE5FF"), true))
                    addView(label("${total / 60}시간 ${total % 60}분", 29f, Color.WHITE, true).apply { topSpace(5) })
                    addView(label("휴게 차감 후 근무시간", 11f, Color.parseColor("#E5EAFE")).apply { topSpace(2) })
                }, LinearLayout.LayoutParams(0, -2, 1f))
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(R.drawable.dashboard_illustration)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    contentDescription = null
                }, LinearLayout.LayoutParams(dp(68), dp(70)))
            })
            addView(horizontal().apply {
                topSpace(13)
                addView(heroMetric("총 기록", "${rows.size}건", Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f))
                addView(heroMetric("휴게", "${deducted / 60}h ${deducted % 60}m", Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(7) })
                addView(heroMetric("확인 필요", "${mismatch}건", Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(7) })
            })
        }.withMargin(0, 0, 0, 11)
        root.addView(heroCard)

        if (rows.isNotEmpty() && withDisplayed > 0) {
            val warning = mismatch > 0
            root.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = shape(if (warning) amberSoft else greenSoft, radius = 18)
                setPadding(dp(15), dp(13), dp(15), dp(13))
                addView(label(if (warning) "⚠  표시시간과 차이가 있어요" else "✓  표시시간과 일치해요",
                    14f, if (warning) amber else aqua, bold = true))
                addView(label("목록 항목 표시시간 합계 ${displayed / 60}시간 ${displayed % 60}분  ·  계산 ${total / 60}시간 ${total % 60}분",
                    12.5f, ink).apply { topSpace(5) })
                addView(label(if (warning)
                    "식사시간이 저장되지 않은 기존 기록일 수 있어요. 원본 목록을 다시 수집해 확인하세요."
                    else "원본에 명시된 식사·휴게시간만 차감했어요. 공식 월간 인정시간과는 별도로 대조하세요.",
                    11.5f, muted).apply { topSpace(4) })
            }.withMargin(0, 0, 0, 14))
        }

        root.addView(section("오늘의 루틴", "자주 사용하는 기능만 간편하게").apply {
            val first = horizontal()
            first.addView(lifestyleCard("자동 수집", "목록 수집 시작", R.drawable.home_automation_illustration, blueSoft, blue) {
                if (isAccessibilityEnabled()) openOfficialAttendanceApp()
                else showAccessibilityDisclosure(openSettings = true)
            }, LinearLayout.LayoutParams(0, -2, 1f))
            first.addView(lifestyleCard("내 근무기록", "날짜별 상세 내역", R.drawable.nav_records, greenSoft, aqua) {
                tab = 1; renderTab()
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
            addView(first)
            val second = horizontal().apply { topSpace(8) }
            second.addView(lifestyleCard("월간 공유", "전체 날짜·시간", R.drawable.monthly_share_illustration, violetSoft, violet) {
                shareSummary()
            }, LinearLayout.LayoutParams(0, -2, 1f))
            second.addView(lifestyleCard("접근성 설정", "권한 바로 열기", R.drawable.nav_settings, skySoft, sky) {
                showAccessibilityDisclosure(openSettings = true)
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
            addView(second)
            addView(action("한국장학재단 공식 출근부 열기", primary = true) { openOfficialAttendanceApp() }
                .apply { topSpace(9); contentDescription = "한국장학재단 공식 출근부 앱 실행" })
        })
        renderWeeklyChart(root, rows)
        root.addView(action("근무 캘린더에서 날짜별 보기") { tab = 2; renderTab() }.withMargin(0, 0, 0, 10))
        root.addView(horizontal().apply {
            addView(action("전체 날짜·시각 복사") { copyMonthDetails() }, LinearLayout.LayoutParams(0, dp(43), 1f))
            addView(action("기록 확인") { tab = 1; renderTab() }, LinearLayout.LayoutParams(0, dp(43), 1f).apply { marginStart = dp(8) })
        }.withMargin(0, 0, 0, 12))

        root.addView(createPeriodEditorCard())

        root.addView(section("처음 사용하시나요?", "설치·제한된 설정·자동 수집 3단계 안내").apply {
            addView(action("사용 방법 자세히 보기", primary = true) { tab = 3; renderTab() })
        })
        root.addView(label("개인 기기 내 저장 · 공식 기관이 제공하거나 승인한 앱이 아닌 개인용 도우미", 11f, muted).apply {
            gravity = Gravity.CENTER
            topSpace(3)
        })
    }

    /** One shared form, used in-place on the home page or as the first card on direct entry. */
    private fun createPeriodEditorCard(): LinearLayout {
        val dateEditor = section("조회 기간", "원하는 연도와 월을 직접 입력해 조회할 수 있습니다.").apply {
            addView(chip("◉ 현재 선택  ${month.year}년 ${month.monthValue}월", amberSoft, amber).apply { topSpace(2) })
            val row = horizontal().apply { topSpace(9) }
            val yearBox = fieldBox("연도", month.year.toString().padStart(4, '0'), 4)
            val monthBox = fieldBox("월", month.monthValue.toString(), 2)
            row.addView(yearBox, LinearLayout.LayoutParams(0, -2, 2f))
            row.addView(monthBox, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10) })
            addView(row)
            addView(action("이 연도 · 월 적용", primary = true) { applyFields() }.apply { topSpace(10) })
            val quick = horizontal().apply { topSpace(9) }
            quick.addView(action("〈 이전 달") { changeMonth(-1) }, LinearLayout.LayoutParams(0, dp(48), 1f))
            quick.addView(action("이번 달") { changeMonth(0) }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(8) })
            quick.addView(action("다음 달 〉") { changeMonth(1) }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(8) })
            addView(quick)
            // Handy when opening this editor from the official app's floating menu.
            addView(action("날짜 설정 후 출근부로 돌아가기") { openOfficialAttendanceApp() }.apply { topSpace(9) })
            if (periodEditorMode) {
                addView(action("홈 맨 위로 이동") {
                    periodEditorMode = false
                    (host.getChildAt(0) as? ScrollView)?.smoothScrollTo(0, 0)
                }.apply { topSpace(9) })
            }
            addView(chip("조회 가능: 2000년~2100년", blueSoft, blueDeep).apply { topSpace(10) })
            addView(label("※ 여기서 선택한 조회 월은 근무로그에만 적용됩니다. 공식 출근부 앱의 조회 월은 그 앱에서 별도로 선택하세요.", 11.5f, muted).apply { topSpace(8) })
        }
        periodEditorSection = dateEditor
        return dateEditor
    }

    /** Calendar-aligned weeks; each percentage is relative to this month's stored minutes. */
    private fun renderWeeklyChart(root: LinearLayout, rows: List<WorkRecord>) {
        val weeks = MonthlyWeekStats.weeks(month, rows)
        val monthMinutes = weeks.sumOf { it.minutes }
        root.addView(section("이번 달 근무 흐름", "월~일 달력 주차 · 전체 근무시간 대비 비율").apply {
            val modeRow = horizontal().apply { gravity = Gravity.CENTER_VERTICAL }
            modeRow.addView(action("차트", primary = flowDisplayMode == 0) { switchFlowMode(0) },
                LinearLayout.LayoutParams(0, dp(40), 1f))
            modeRow.addView(action("그래프", primary = flowDisplayMode == 1) { switchFlowMode(1) },
                LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(8) })
            addView(modeRow)
            addView(WeeklyFlowView(weeks, flowDisplayMode).apply {
                contentDescription = weeks.joinToString(", ") { w ->
                    "${w.number}주차 ${w.firstDay.monthValue}월 ${w.firstDay.dayOfMonth}일부터 ${w.lastDay.dayOfMonth}일까지 " +
                    "${w.minutes / 60}시간 ${w.minutes % 60}분 " +
                    String.format(Locale.KOREA, "%.1f퍼센트", w.sharePercent)
                }
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
                tag = "weekly_flow_display"
            }, LinearLayout.LayoutParams(-1, dp(158)).apply { topMargin = dp(8) })
            weeks.chunked(2).forEach { pair ->
                addView(horizontal().apply {
                    topSpace(5)
                    pair.forEachIndexed { index, w ->
                        addView(LinearLayout(this@MainActivity).apply {
                            orientation = LinearLayout.VERTICAL
                            background = shape(cardGray, radius = 11, stroke = border)
                            setPadding(dp(9), dp(9), dp(9), dp(9))
                            addView(label("${w.number}주차 · ${w.firstDay.dayOfMonth}~${w.lastDay.dayOfMonth}일", 11f, muted, true))
                            addView(label("${w.minutes / 60}h ${w.minutes % 60}m  ·  " +
                                String.format(Locale.KOREA, "%.1f%%", w.sharePercent), 12.5f, ink, true).apply { topSpace(3) })
                        }, LinearLayout.LayoutParams(0, -2, 1f).apply {
                            if (index > 0) marginStart = dp(7)
                        })
                    }
                    if (pair.size == 1) addView(View(this@MainActivity),
                        LinearLayout.LayoutParams(0, dp(1), 1f).apply { marginStart = dp(7) })
                })
            }
            addView(label("월 합계 ${monthMinutes / 60}시간 ${monthMinutes % 60}분 · " +
                "${weeks.size}개 달력 주차${if (monthMinutes == 0) " · 기록 없음" else ""}", 11f, muted)
                .apply { topSpace(9) })
        })
    }

    private fun switchFlowMode(next: Int) {
        if (next == flowDisplayMode) return
        val y = currentScrollY()
        flowDisplayMode = next
        getSharedPreferences("attendance_display", MODE_PRIVATE).edit().putInt("flow_mode", next).apply()
        renderTab()
        restoreScroll(y)
    }

    private inner class WeeklyFlowView(private val weeks: List<CalendarWeek>, private val mode: Int): View(this@MainActivity) {
        private val pen = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            if (weeks.isEmpty()) return
            val left = dp(10).toFloat()
            val right = width - dp(10).toFloat()
            val top = dp(24).toFloat()
            val bottom = height - dp(30).toFloat()
            val max = weeks.maxOf { it.minutes }.coerceAtLeast(60).toFloat()
            pen.style = Paint.Style.STROKE
            pen.strokeWidth = dp(1).toFloat()
            pen.color = border
            for (line in 0..3) {
                val y = top + (bottom - top) * line / 3f
                canvas.drawLine(left, y, right, y, pen)
            }
            val step = (right - left) / weeks.size
            fun plotY(value: Int) = bottom - value.toFloat() / max * (bottom - top)
            if (mode == 0) {
                weeks.forEachIndexed { index, w ->
                    val x = left + (index + 0.5f) * step
                    val peak = plotY(w.minutes)
                    val barHeight = if (w.minutes == 0) 0f else (bottom - peak).coerceAtLeast(dp(3).toFloat())
                    pen.style = Paint.Style.FILL
                    pen.color = if (index == weeks.lastIndex) aqua else blue
                    if (barHeight > 0) canvas.drawRoundRect(x - step * .25f, bottom - barHeight,
                        x + step * .25f, bottom, dp(5).toFloat(), dp(5).toFloat(), pen)
                }
            } else {
                val path = Path()
                weeks.forEachIndexed { index, w ->
                    val x = left + (index + 0.5f) * step
                    val y = plotY(w.minutes)
                    if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                pen.style = Paint.Style.STROKE
                pen.strokeWidth = dp(3).toFloat()
                pen.color = blue
                canvas.drawPath(path, pen)
                weeks.forEachIndexed { index, w ->
                    val x = left + (index + 0.5f) * step
                    val y = plotY(w.minutes)
                    pen.style = Paint.Style.FILL
                    pen.color = if (darkMode) cardGray else Color.WHITE
                    canvas.drawCircle(x, y, dp(5).toFloat(), pen)
                    pen.color = if (index == weeks.lastIndex) aqua else blue
                    canvas.drawCircle(x, y, dp(3).toFloat(), pen)
                }
            }
            weeks.forEachIndexed { index, w ->
                val x = left + (index + 0.5f) * step
                pen.style = Paint.Style.FILL
                pen.textSize = dp(10).toFloat()
                pen.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                pen.textAlign = Paint.Align.CENTER
                pen.color = muted
                canvas.drawText("${w.number}주", x, bottom + dp(19), pen)
                pen.color = ink
                canvas.drawText(if (w.minutes == 0) "-" else String.format(Locale.KOREA, "%.0f%%", w.sharePercent),
                    x, (plotY(w.minutes) - dp(8)).coerceAtLeast(dp(11).toFloat()), pen)
            }
        }
    }

    /** A pastel diary calendar; the colors are legible in either display mode. */
    private fun renderMonthCalendar(root: LinearLayout, rows: List<WorkRecord>) {
        val daily = rows.groupBy { it.date }
        val weekNames = arrayOf("월", "화", "수", "목", "금", "토", "일")
        val pastel = (if (darkMode)
            arrayOf("#51354B", "#403557", "#2C455A", "#2B4A40", "#51462F", "#513A34", "#503449")
        else arrayOf("#FFEAF2", "#EEE9FF", "#E4F4FF", "#E5F8ED", "#FFF5D9", "#FFECE0", "#FBE7F1"))
            .map { Color.parseColor(it) }
        val accents = (if (darkMode)
            arrayOf("#FFC1D8", "#D8C7FF", "#B8E7FF", "#A5EBC8", "#FFE3A2", "#FFD0B0", "#FFB5D2")
        else arrayOf("#933D63", "#624A9D", "#266384", "#216C53", "#875B16", "#93583B", "#9C416E"))
            .map { Color.parseColor(it) }
        val strokes = (if (darkMode)
            arrayOf("#A56F8A", "#8D7AAA", "#709EB5", "#669982", "#B09B6D", "#B98970", "#AF7494")
        else arrayOf("#DFA8BE", "#BCAFE5", "#A9D6EC", "#9CDABE", "#E9D6A0", "#F2C4AA", "#E8B2CE"))
            .map { Color.parseColor(it) }
        val today = LocalDate.now()
        root.addView(section("근무 다이어리", "날짜마다 근무시간을 확인할 수 있어요").apply {
            val titleBar = horizontal().apply {
                gravity = Gravity.CENTER_VERTICAL
                background = shape(if (darkMode) Color.parseColor("#35283E") else Color.parseColor("#FFF0F6"),
                    radius = 15, stroke = if (darkMode) Color.parseColor("#77536D") else Color.parseColor("#F0C5D6"))
                setPadding(dp(7), dp(7), dp(7), dp(7))
            }
            titleBar.addView(action("‹") { changeMonth(-1) }, LinearLayout.LayoutParams(dp(42), dp(40)))
            titleBar.addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                addView(label("${month.year}년 ${month.monthValue}월", 16f, ink, true).apply { gravity = Gravity.CENTER })
            }, LinearLayout.LayoutParams(0, -2, 1f))
            titleBar.addView(action("›") { changeMonth(1) }, LinearLayout.LayoutParams(dp(42), dp(40)))
            addView(titleBar)
            addView(horizontal().apply {
                topSpace(12)
                weekNames.forEachIndexed { weekday, value ->
                    addView(label(value, 11.5f, accents[weekday], true).apply { gravity = Gravity.CENTER },
                        LinearLayout.LayoutParams(0, dp(26), 1f))
                }
            })
            val offset = month.atDay(1).dayOfWeek.value - 1
            val totalCells = ((offset + month.lengthOfMonth() + 6) / 7) * 7
            for (week in 0 until totalCells / 7) {
                addView(horizontal().apply {
                    topSpace(5)
                    for (weekday in 0..6) {
                        val dayNumber = week * 7 + weekday - offset + 1
                        if (dayNumber !in 1..month.lengthOfMonth()) {
                            addView(View(this@MainActivity), LinearLayout.LayoutParams(0, dp(74), 1f))
                            continue
                        }
                        val date = month.atDay(dayNumber)
                        val shifts = daily[date.toString()].orEmpty()
                        val workMinutes = shifts.sumOf { it.minutes }
                        val hasWork = shifts.isNotEmpty()
                        val isToday = date == today
                        val cell = LinearLayout(this@MainActivity).apply {
                            orientation = LinearLayout.VERTICAL
                            gravity = Gravity.CENTER
                            background = GradientDrawable().apply {
                                setColor(pastel[weekday])
                                cornerRadius = dp(12).toFloat()
                                val outline = if (isToday) accents[weekday] else if (hasWork) strokes[weekday] else border
                                if (hasWork || isToday) setStroke(dp(if (isToday) 2 else 1), outline)
                                else setStroke(dp(1), outline, dp(3).toFloat(), dp(3).toFloat())
                            }
                            setPadding(dp(1), dp(5), dp(1), dp(4))
                            addView(label("$dayNumber", 12f, accents[weekday], true).apply {
                                gravity = Gravity.CENTER
                            })
                            // Two large, separate rows. Time uses high-contrast ink in dark mode.
                            if (hasWork) {
                                addView(label("${workMinutes / 60}시간", 12.5f,
                                    if (darkMode) Color.WHITE else ink, true).apply {
                                        gravity = Gravity.CENTER; topSpace(2)
                                        setSingleLine(true)
                                    })
                                addView(label("${workMinutes % 60}분", 12f,
                                    if (darkMode) Color.parseColor("#E4ECFF") else Color.parseColor("#374151"), true).apply {
                                        gravity = Gravity.CENTER
                                        setSingleLine(true)
                                    })
                            } else {
                                addView(label("—", 11f, accents[weekday]).apply { gravity = Gravity.CENTER; topSpace(4) })
                            }
                            isClickable = true
                            isFocusable = true
                            contentDescription = "${date.year}년 ${date.monthValue}월 ${date.dayOfMonth}일, " +
                                if (hasWork) "근무 ${shifts.size}건, ${workMinutes / 60}시간 ${workMinutes % 60}분" else "근무 기록 없음"
                            setOnClickListener { showCalendarDay(date, shifts) }
                        }
                        addView(cell, LinearLayout.LayoutParams(0, dp(74), 1f).apply {
                            marginStart = if (weekday == 0) 0 else dp(4)
                        })
                    }
                })
            }
            addView(label("테두리 표시: 근무한 날  ·  진한 테두리: 오늘", 12f, muted).apply { topSpace(12) })
        })
    }

    private fun showCalendarDay(date: LocalDate, shifts: List<WorkRecord>) {
        val title = "${date.year}년 ${date.monthValue}월 ${date.dayOfMonth}일"
        if (shifts.isEmpty()) {
            appDialog().setTitle(title).setMessage("이 날짜에 저장된 근무기록이 없습니다.")
                .setPositiveButton("확인", null).show()
            return
        }
        val items = shifts.map { row ->
            "${row.start} ~ ${row.end} · ${row.minutes / 60}시간 ${row.minutes % 60}분" +
                if (row.breakMinutes > 0) " (휴게 ${row.breakMinutes}분)" else ""
        }.toTypedArray()
        // AlertDialog cannot reliably show setMessage and setItems together:
        // the message wins on many Android builds and hides the selectable shifts.
        if (shifts.size == 1) {
            addToDeviceCalendar(shifts.first())
        } else {
            appDialog().setTitle("$title · 근무를 선택하세요")
                .setItems(items) { _, index -> addToDeviceCalendar(shifts[index]) }
                .setNegativeButton("닫기", null).show()
        }
    }

    /** Calendar insert intent: works with compatible Samsung/Android calendar apps without calendar permissions. */
    private fun addToDeviceCalendar(row: WorkRecord) {
        try {
            val date = LocalDate.parse(row.date)
            if (date.year !in MonthlyWeekStats.FIRST_YEAR..MonthlyWeekStats.LAST_YEAR) {
                showDateRangeWarning("캘린더에 추가할 날짜가 허용 범위를 벗어났습니다.")
                return
            }
            // Overnight shifts end the following day; never create a reversed calendar event.
            val startTime = LocalTime.parse(row.start)
            val finishTime = LocalTime.parse(row.end)
            val finishDate = if (!finishTime.isAfter(startTime)) date.plusDays(1) else date
            if (finishDate.year > MonthlyWeekStats.LAST_YEAR) {
                showDateRangeWarning("퇴근 시간이 허용된 마지막 날짜(2100-12-31)를 넘습니다.")
                return
            }
            val start = date.atTime(startTime).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
            val end = finishDate.atTime(finishTime).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
            val intent = Intent(Intent.ACTION_INSERT).apply {
                data = CalendarContract.Events.CONTENT_URI
                putExtra(CalendarContract.Events.TITLE, "근무로그 · 근무")
                putExtra(CalendarContract.Events.DESCRIPTION, "근무로그에서 내보낸 기록. " +
                    "근무 ${row.minutes / 60}시간 ${row.minutes % 60}분, 휴게 ${row.breakMinutes}분")
                putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start)
                putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end)
            }
            // Use an INSERT-capable calendar activity, not a generic calendar
            // launcher (which may open only the calendar home screen).
            try {
                // Start the actual INSERT activity, not the app launcher.
                // Some Android 11+ devices falsely return null from resolveActivity
                // due to package visibility even when a calendar editor is present.
                startActivity(intent)
            } catch (error: ActivityNotFoundException) {
                Log.w("AttendanceCalendar", "No calendar event editor installed", error)
                offerCalendarWebFallback(row, start, end)
            }
        } catch (error: Exception) {
            Log.w("AttendanceCalendar", "Calendar event editor unavailable", error)
            toast("캘린더 입력 화면을 열지 못했습니다")
        }
    }

    private fun offerCalendarWebFallback(row: WorkRecord, start: Long, end: Long) {
        appDialog().setTitle("일정 입력 앱을 찾지 못했어요")
            .setMessage("기기에 일정 추가 기능이 있는 캘린더가 없습니다. Google 캘린더 웹에서 새 일정을 작성할까요? 외부 웹사이트가 열립니다.")
            .setNegativeButton("취소", null)
            .setPositiveButton("웹에서 입력") { _, _ ->
                try {
                    val utc = DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss'Z'")
                        .withZone(java.time.ZoneOffset.UTC)
                    val uri = Uri.parse("https://calendar.google.com/calendar/render").buildUpon()
                        .appendQueryParameter("action", "TEMPLATE")
                        .appendQueryParameter("text", "근무")
                        .appendQueryParameter("dates", "${utc.format(java.time.Instant.ofEpochMilli(start))}/${utc.format(java.time.Instant.ofEpochMilli(end))}")
                        .appendQueryParameter("details", "근무 ${row.minutes / 60}시간 ${row.minutes % 60}분 · 휴게 ${row.breakMinutes}분")
                        .build()
                    startActivity(Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE))
                } catch (error: Exception) {
                    Log.e("AttendanceCalendar", "Could not open calendar web editor", error)
                    toast("웹 캘린더를 열 수 없습니다")
                }
            }.show()
    }

    /** Keep the records page small and predictable. Optional actions are tucked away. */
    private fun renderRecords(root: LinearLayout) {
        val items = currentRecords()
        val totalMinutes = items.sumOf { it.minutes }
        val restMinutes = items.sumOf { it.breakMinutes }
        root.addView(heading("근무기록", "${month.year}년 ${month.monthValue}월 · ${items.size}건", violet))
        root.addView(horizontal().apply {
            topSpace(12)
            addView(statCard("계산 근무", "${totalMinutes / 60}h ${totalMinutes % 60}m", skySoft, sky),
                LinearLayout.LayoutParams(0, -2, 1f))
            addView(statCard("휴게 차감", "${restMinutes / 60}h ${restMinutes % 60}m", greenSoft, aqua),
                LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
        }.withMargin(0, 0, 0, 12))

        root.addView(section("텍스트 붙여넣기", "공식 출근부의 목록을 복사해 붙여넣을 수 있어요.").apply {
            val field = EditText(this@MainActivity).apply {
                minLines = 2; maxLines = 6; gravity = Gravity.TOP
                textSize = 13f; setTextColor(ink); setHintTextColor(muted)
                hint = "예: 11.05 근무 09:00 ~ 18:00"
                background = shape(if (darkMode) surface else cardGray, radius = 12, stroke = border)
                setPadding(dp(11), dp(11), dp(11), dp(11))
                setText(draftPasteText.orEmpty())
            }
            pasteField = field
            addView(field)
            addView(action("기록 추가", primary = true) {
                val parsed = AttendanceParser.fromListPage(field.text.toString(), month)
                if (parsed.isEmpty()) toast("날짜와 근무시간을 확인해 주세요")
                else if (RecordStore.add(this@MainActivity, parsed)) {
                    draftPasteText = null
                    renderTab()
                    toast("${parsed.size}건을 확인했어요")
                } else toast("저장에 실패했어요 · 기존 기록은 유지됩니다")
            }.apply { topSpace(9) })
        })

        // V1.7: the exported text is edited IN PLACE. No dialog or second window.
        // A dedicated, draggable scroll rail keeps the export navigable in both modes.
        root.addView(section("추출 결과 · 복사", "저장된 내역을 복사하거나 이 자리에서 수정하세요.").apply {
            val snapshot = AttendanceParser.export(items, month)
            val textHost = FrameLayout(this@MainActivity)
            val preview = TextView(this@MainActivity).apply {
                text = snapshot
                textSize = 14.5f
                typeface = Typeface.create("sans-serif", Typeface.NORMAL)
                setTextColor(ink)
                setLineSpacing(dp(4).toFloat(), 1.12f)
                setPadding(dp(12), dp(13), dp(8), dp(13))
            }
            textHost.addView(preview, FrameLayout.LayoutParams(-1, -2))
            val textScroll = ScrollView(this@MainActivity).apply {
                isFillViewport = false
                isVerticalScrollBarEnabled = false // Replaced by a visible themed rail.
                isSmoothScrollingEnabled = true
                background = shape(if (darkMode) surface else cardGray, radius = 14, stroke = border)
                addView(textHost, FrameLayout.LayoutParams(-1, -2))
                setOnTouchListener { view, event ->
                    if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                        view.parent?.requestDisallowInterceptTouchEvent(true)
                    } else if (event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_CANCEL) {
                        view.parent?.requestDisallowInterceptTouchEvent(false)
                    }
                    false
                }
            }
            addView(horizontal().apply {
                addView(textScroll, LinearLayout.LayoutParams(0, dp(258), 1f))
                addView(recordScrollRail(textScroll), LinearLayout.LayoutParams(dp(44), dp(258)).apply {
                    marginStart = dp(7)
                })
            })

            val toolbar = horizontal().apply { topSpace(10) }
            val left = action("전체 복사") { }
            val right = action("수정하기", primary = true) { }
            toolbar.addView(left, LinearLayout.LayoutParams(0, dp(49), 1f))
            toolbar.addView(right, LinearLayout.LayoutParams(0, dp(49), 1f).apply { marginStart = dp(8) })
            addView(toolbar)
            addView(label("수정하기를 누른 뒤 텍스트를 터치하면 커서로 바로 편집할 수 있어요.", 12f, muted)
                .apply { topSpace(7) })

            fun closeInlineEdit(discard: Boolean) {
                if (discard) {
                    draftMonth = null
                    draftText = null
                } else {
                    inlineRecordField?.let {
                        draftMonth = month
                        draftText = it.text?.toString().orEmpty()
                    }
                }
                recordEditMode = false
                inlineRecordField?.let { field ->
                    (getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager)
                        ?.hideSoftInputFromWindow(field.windowToken, 0)
                }
                inlineRecordField = null
                textHost.removeAllViews()
                preview.text = snapshot
                textHost.addView(preview, FrameLayout.LayoutParams(-1, -2))
                left.text = "전체 복사"
                right.text = "수정하기"
            }

            fun startInlineEdit(openKeyboard: Boolean = true) {
                val content = if (draftMonth == month) draftText ?: snapshot else snapshot
                val field = EditText(this@MainActivity).apply {
                    gravity = Gravity.TOP or Gravity.START
                    textSize = 14.5f
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                        InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                    typeface = Typeface.create("sans-serif", Typeface.NORMAL)
                    setTextColor(ink)
                    setHintTextColor(muted)
                    setSelectAllOnFocus(false)
                    setHorizontallyScrolling(false)
                    isVerticalScrollBarEnabled = false
                    background = null
                    setLineSpacing(dp(4).toFloat(), 1.12f)
                    setPadding(dp(12), dp(13), dp(8), dp(13))
                    setText(content)
                    setSelection(0)
                    contentDescription = "근무기록 편집 텍스트"
                }
                // Create only one editor, on user request, in the current text region.
                textHost.removeAllViews()
                textHost.addView(field, FrameLayout.LayoutParams(-1, -2))
                inlineRecordField = field
                recordEditMode = true
                draftMonth = month
                draftText = content
                left.text = "취소"
                right.text = "수정 저장"
                if (openKeyboard) field.post {
                    if (recordEditMode && inlineRecordField === field && field.isAttachedToWindow) {
                        field.requestFocus()
                        (getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager)
                            ?.showSoftInput(field, InputMethodManager.SHOW_IMPLICIT)
                    }
                }
            }

            left.setOnClickListener {
                try {
                    if (recordEditMode) closeInlineEdit(discard = true)
                    else {
                        copyText("근무기록", snapshot)
                        toast("근무기록을 복사했어요")
                    }
                } catch (error: Exception) {
                    Log.e("AttendanceRecords", "Copy/cancel failed", error)
                    toast("작업을 완료하지 못했어요")
                }
            }
            right.setOnClickListener {
                try {
                    if (!recordEditMode) startInlineEdit()
                    else {
                        val field = inlineRecordField
                        if (field == null) toast("편집 영역을 찾지 못했어요")
                        else {
                            draftMonth = month
                            draftText = field.text?.toString().orEmpty()
                            saveEditedRecords(draftText.orEmpty())
                        }
                    }
                } catch (error: Exception) {
                    Log.e("AttendanceRecords", "Inline record edit failed", error)
                    toast("편집 작업을 처리하지 못했어요. 기록은 그대로 보관됩니다.")
                }
            }
            if (recordEditMode && draftMonth == month) {
                // Restore the inline editor after a rotation or records refresh.
                startInlineEdit(openKeyboard = false)
            } else {
                recordEditMode = false
            }
            val extraActions = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                visibility = View.GONE
                addView(horizontal().apply {
                    topSpace(9)
                    addView(action("TXT 저장") { createFile(saveTxt, "text/plain", "근무기록_${month}.txt") },
                        LinearLayout.LayoutParams(0, dp(43), 1f))
                    addView(action("CSV 저장") { createFile(saveCsv, "text/csv", "근무기록_${month}.csv") },
                        LinearLayout.LayoutParams(0, dp(43), 1f).apply { marginStart = dp(8) })
                })
                addView(action("이 달 기록 삭제", destructive = true) {
                    appDialog().setTitle("${month} 기록 삭제")
                        .setMessage("이 달의 기록만 삭제합니다. 삭제 후에는 되돌릴 수 없어요.")
                        .setNegativeButton("취소", null)
                        .setPositiveButton("삭제") { _, _ ->
                            if (RecordStore.replaceMonth(this@MainActivity, month, emptyList())) {
                                clearDraft(); renderTab(); toast("선택한 달의 기록을 삭제했어요")
                            } else toast("삭제에 실패했어요. 기존 기록을 유지했습니다")
                        }.show()
                }.apply { topSpace(8) })
            }
            addView(action("내보내기 · 기록 관리  ⌄") {
                extraActions.visibility = if (extraActions.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            }.apply { topSpace(9) })
            addView(extraActions)
            addView(label("※ 계산 시간은 공식 인정시간과 다를 수 있어요.", 12f, muted).apply { topSpace(9) })
        })
        if (items.isNotEmpty()) {
            root.addView(section("최근 기록", "일자별 근무 내용을 확인해요").apply {
                val sorted = items.sortedWith(compareByDescending<WorkRecord> { it.date }.thenBy { it.start })
                // A month can contain many imported rows. Never inflate an
                // unbounded number of nested cards in a single main-thread frame.
                (if (showAllRows) sorted.take(50) else sorted.take(5)).forEach { addView(recordPreview(it)) }
                if (showAllRows && sorted.size > 50) {
                    addView(label("나머지 ${sorted.size - 50}건은 추출 결과 · 편집에서 볼 수 있어요.", 11.5f, muted)
                        .apply { topSpace(8) })
                }
                if (sorted.size > 5) addView(action(if (showAllRows) "목록 접기" else "기록 더 보기") {
                    saveDraft()
                    showAllRows = !showAllRows
                    renderTab()
                }.apply { topSpace(9) })
            })
        }

    }

    /** Compact arrow-and-thumb scrollbar inspired by classic scroll rails.
     *  It controls the same inline preview/edit ScrollView without opening windows.
     */
    private fun recordScrollRail(scroll: ScrollView): LinearLayout {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            contentDescription = "근무기록 스크롤 컨트롤"
        }
        val railBlue = if (darkMode) Color.parseColor("#24395C") else Color.parseColor("#EAF0FF")
        val railPurple = if (darkMode) Color.parseColor("#35406E") else Color.parseColor("#DDD9F9")
        val accentGradient = intArrayOf(Color.parseColor("#304AA8"), Color.parseColor("#7545A9"))
        fun moveBy(direction: Int) {
            scroll.smoothScrollBy(0, direction * (scroll.height * 0.7f).toInt().coerceAtLeast(dp(90)))
        }
        fun arrow(symbol: String, direction: Int) = Button(this).apply {
            text = symbol
            textSize = 18f
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            minimumWidth = 0
            minimumHeight = 0
            setPadding(0, 0, 0, 0)
            background = RippleDrawable(ColorStateList.valueOf(Color.parseColor("#55FFFFFF")),
                gradient(accentGradient, 11), null)
            contentDescription = if (direction < 0) "근무기록 위로 스크롤" else "근무기록 아래로 스크롤"
            setOnClickListener { moveBy(direction) }
        }
        bar.addView(arrow("▲", -1), LinearLayout.LayoutParams(dp(40), dp(44)))
        val track = FrameLayout(this).apply {
            background = gradient(intArrayOf(railBlue, railPurple), 14).apply { setStroke(dp(1), border) }
            contentDescription = "스크롤 막대 드래그"
        }
        val knob = View(this).apply {
            background = gradient(accentGradient, 12)
            elevation = dp(2).toFloat()
        }
        track.addView(knob, FrameLayout.LayoutParams(dp(30), dp(52), Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        bar.addView(track, LinearLayout.LayoutParams(dp(40), 0, 1f).apply {
            topMargin = dp(5)
            bottomMargin = dp(5)
        })
        bar.addView(arrow("▼", 1), LinearLayout.LayoutParams(dp(40), dp(44)))
        fun updateKnob() {
            val child = scroll.getChildAt(0) ?: return
            val range = (child.height - scroll.height).coerceAtLeast(0)
            val travel = (track.height - knob.height).coerceAtLeast(0)
            val progress = if (range == 0) 0f else scroll.scrollY.toFloat() / range
            knob.translationY = (travel * progress.coerceIn(0f, 1f))
            knob.alpha = if (range == 0) 0.65f else 1f
        }
        scroll.setOnScrollChangeListener { _, _, _, _, _ -> updateKnob() }
        scroll.getChildAt(0)?.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> updateKnob() }
        track.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    val range = ((scroll.getChildAt(0)?.height ?: 0) - scroll.height).coerceAtLeast(0)
                    val travel = (track.height - knob.height).coerceAtLeast(1)
                    val ratio = ((event.y - knob.height / 2f) / travel).coerceIn(0f, 1f)
                    scroll.scrollTo(0, (ratio * range).toInt())
                    updateKnob()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> true
                else -> false
            }
        }
        track.post { updateKnob() }
        return bar
    }

    /** Replacing a month always requires a user confirmation and preserves data on failure. */
    private fun saveEditedRecords(text: String, onSaved: (() -> Unit)? = null) {
        val dateLines = Regex("(?m)^\\s*(\\d{4})[-./](\\d{1,2})[-./](\\d{1,2})(?=\\s|$)")
        val invalid = dateLines.findAll(text).firstOrNull { match ->
            val y = match.groupValues[1].toIntOrNull()
            val m = match.groupValues[2].toIntOrNull()
            val d = match.groupValues[3].toIntOrNull()
            y == null || m == null || d == null ||
                y !in MonthlyWeekStats.FIRST_YEAR..MonthlyWeekStats.LAST_YEAR ||
                runCatching { LocalDate.of(y, m, d) }.isFailure
        }
        if (invalid != null) {
            showDateRangeWarning("잘못된 날짜: ${invalid.value.trim()}")
            return
        }
        val corrected = AttendanceParser.fromEditableText(text, month)
        if (corrected.isEmpty()) {
            toast("YYYY-MM-DD 09:00 ~ 11:00 형식을 확인해 주세요")
            return
        }
        appDialog().setTitle("${month} 기록 저장")
            .setMessage("이 달 기록을 수정한 ${corrected.size}건으로 교체할까요?")
            .setNegativeButton("취소", null)
            .setPositiveButton("저장") { _, _ ->
                if (RecordStore.replaceMonth(this, month, corrected)) {
                    clearDraft(); renderTab(); onSaved?.invoke(); toast("수정한 기록을 저장했어요")
                } else toast("저장 실패 · 기존 기록을 유지했어요")
            }.show()
    }

    private fun renderStats(root: LinearLayout) {
        val rows = currentRecords()
        val minutes = rows.sumOf { it.minutes }
        root.addView(heading("근무 통계", "${month.year}년 ${month.monthValue}월 · 기록을 한눈에", blue))
        root.addView(horizontal().apply {
            addView(statCard("계산 근무", "${minutes / 60}h ${minutes % 60}m", blueSoft, blue), LinearLayout.LayoutParams(0, -2, 1f))
            addView(statCard("근무 일수", "${rows.map { it.date }.distinct().size}일", greenSoft, aqua), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
        }.withMargin(0, 12, 0, 11))
        val lastCollection = RecordStore.lastCollection(this)
        if (lastCollection != null && lastCollection.month == month.toString()) {
            root.addView(section("자동 수집 결과", if (rows.isEmpty()) "기록이 없어 근무 흐름이 비어 있어요" else "저장된 기록으로 근무 흐름을 갱신했어요").apply {
                addView(label("${lastCollection.recordCount}건 저장 · 새로 추가 ${lastCollection.newCount}건", 14f, ink, true))
                addView(label(lastCollection.message, 11.5f, muted).apply { topSpace(5) })
                if (rows.isEmpty()) addView(label("현재 월의 기록이 없습니다. 공식 출근부 목록에서 읽을 수 있는 글자가 있는지 확인하세요.", 11.5f, amber).apply { topSpace(6) })
            })
        }
        renderWeeklyChart(root, rows)
        renderMonthCalendar(root, rows)
        root.addView(action("근무 통계 새로고침") {
            month = RecordStore.selectedMonth(this)
            renderTab()
            toast("${month.monthValue}월 기록과 차트를 갱신했어요")
        }.withMargin(0, 0, 0, 10))
        val all = RecordStore.read(this)
        val last = (5 downTo 0).mapNotNull { steps ->
            runCatching { month.minusMonths(steps.toLong()) }.getOrNull()
        }.map { ym ->
            ym to all.filter { it.date.startsWith(ym.toString()) }.sumOf { it.minutes }
        }
        val max = (last.maxOfOrNull { it.second } ?: 0).coerceAtLeast(1)
        root.addView(section("최근 6개월 비교", "저장된 날짜별 기록을 기준으로 계산해요").apply {
            last.forEach { (ym, value) ->
                addView(horizontal().apply {
                    gravity = Gravity.CENTER_VERTICAL
                    addView(label("${ym.monthValue}월", 12f, ink, true), LinearLayout.LayoutParams(dp(36), -2))
                    addView(FrameLayout(this@MainActivity).apply {
                        background = shape(blueSoft, radius = 5)
                        addView(View(this@MainActivity).apply {
                            background = shape(if (ym == month) blue else if (darkMode) Color.parseColor("#617BAE") else Color.parseColor("#8494D4"), radius = 5)
                        }, FrameLayout.LayoutParams(0, -1).apply { width = 0 })
                        post {
                            val bar = getChildAt(0)
                            bar.layoutParams = FrameLayout.LayoutParams(
                                (width * (value.toFloat() / max)).toInt().coerceAtLeast(if (value > 0) dp(3) else 0), -1)
                        }
                    }, LinearLayout.LayoutParams(0, dp(9), 1f).apply { marginStart = dp(8) })
                    addView(label("${value / 60}h ${value % 60}m", 11f, muted).apply { gravity = Gravity.END }, LinearLayout.LayoutParams(dp(76), -2))
                }.apply { topSpace(11) })
            }
        })
        root.addView(section("기록 확인", "합계가 공식 인정시간과 다르면 원본을 대조하세요").apply {
            addView(action("기록에서 상세 확인", primary = true) { tab = 1; renderTab() })
        })
    }

    /** Device-owned permission screens. We never change security settings ourselves. */
    private fun renderSettings(root: LinearLayout) {
        root.addView(heading("설정", "화면 모드 · 수집 권한 · 사용 안내 · 업데이트 기록", blue))
        root.addView(section("화면 모드", "모든 탭·팝업·입력창·플로팅 메뉴에 함께 적용됩니다").apply {
            val buttons = horizontal()
            buttons.addView(action("라이트", primary = !darkMode) { setDarkMode(false) },
                LinearLayout.LayoutParams(0, dp(43), 1f))
            buttons.addView(action("다크", primary = darkMode) { setDarkMode(true) },
                LinearLayout.LayoutParams(0, dp(43), 1f).apply { marginStart = dp(8) })
            addView(buttons)
        })
        root.addView(section("접근성 자동 수집", "${if (isAccessibilityEnabled()) "현재 사용 중" else "현재 사용 안 함"} · 공식 출근부 목록만 읽어요").apply {
            addView(chip(if (isAccessibilityEnabled()) "● 접근성 켜짐" else "○ 접근성 꺼짐",
                if (isAccessibilityEnabled()) greenSoft else amberSoft,
                if (isAccessibilityEnabled()) aqua else amber))
            addView(label("목록 수집 버튼을 누른 경우에만 날짜와 근무시각을 읽어요. 스크린샷 인식은 사용하지 않습니다.", 12f, muted).apply { topSpace(9) })
            addView(action("접근성 설정 바로 열기", primary = true) { showAccessibilityDisclosure(true) }.apply { topSpace(9) })
            addView(action("근무로그 앱 설정 열기") { openOwnAppDetails() }.apply { topSpace(8) })
            addView(action("접근성 상태 다시 확인") { renderTab() }.apply { topSpace(8) })
            if (isAccessibilityEnabled() && !CollectorAccessibilityService.isReady()) {
                addView(label("서비스가 아직 연결되지 않았습니다. 잠시 뒤 다시 확인하거나, 시스템 접근성 화면에서 사용 상태를 확인하세요.", 12f, amber).apply { topSpace(8) })
            }
            addView(action("접근성 권한 직접 끄기", destructive = true) {
                appDialog()
                    .setTitle("접근성 서비스 끄기")
                    .setMessage("수집만 중지하는 것이 아니라 접근성 서비스 사용을 해제합니다. 계속할까요?")
                    .setNegativeButton("취소", null)
                    .setPositiveButton("서비스 끄기") { _, _ ->
                        if (!CollectorAccessibilityService.disableFromApp()) {
                            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        }
                        host.postDelayed({ if (!startupFailed) renderTab() }, 350L)
                    }.show()
            }.apply { topSpace(8) })
            addView(action("기록 탭의 텍스트 붙여넣기 열기") { openRecordsTab() }.apply { topSpace(8) })
        })
        root.addView(section("처음 시작하기 · 3단계", "설치부터 권한 허용까지 차례대로 확인하세요").apply {
            addView(guideRow("01", "APK 설치 확인", "신뢰하는 출처의 설치 파일인지 확인하세요. Play Protect 경고가 뜨면 검사 결과부터 확인하세요.", "Google Play", "com.android.vending") { openPlayStore() })
            addView(guideRow("02", "제한된 설정 허용", "Android 13 이상: 설정 › 앱 › 근무로그 › 우측 상단 ⋮ › 제한된 설정 허용. 본인이 신뢰하는 앱에만 허용하세요.", "Android 설정", "com.android.settings") { openOwnAppDetails() })
            addView(guideRow("03", "접근성 서비스 켜기", "설정 › 접근성 › 설치된 앱 › 근무로그 › 사용. 승인 후 공식 출근부의 목록 수집 버튼을 누르세요.", "접근성", "com.android.settings") { showAccessibilityDisclosure(true) })
            addView(action("제한된 설정 안내 · Google 공식 문서") {
                openHelpUrl("https://support.google.com/android/answer/12623953?hl=ko")
            }.apply { topSpace(10) })
        })
        root.addView(section("Google Play 프로텍트", "Google Play 아이콘과 공식 도움말에서 보호 상태를 확인하세요").apply {
            addView(guideRow("✓", "Google Play에서 확인", "Play 스토어 › 프로필 › Play 프로텍트 › 설정(톱니바퀴) › 'Play 프로텍트로 앱 검사'. 해제도 가능하지만 보안을 위해 항상 켜 두는 것을 권장합니다.", "Google Play", "com.android.vending") { openPlayStore() })
            addView(label("설치 경고가 나올 때 무조건 보호 기능을 끄지 마세요. 인증된 서명본과 설치 출처를 확인하고, 오탐이면 Google에 재검토를 요청하세요.", 12f, muted).apply { topSpace(8) })
            addView(action("Google 공식 Play 프로텍트 안내") {
                openHelpUrl("https://support.google.com/googleplay/answer/2812853?hl=ko")
            }.apply { topSpace(9) })
        })
        root.addView(section("기록 관리", "앱 버전 유지 · 데이터는 기기 내부에 저장").apply {
            addView(infoRow("현재 버전", versionName))
            addView(infoRow("Android 지원", minAndroidText))
            addView(action("기록 백업·편집으로 이동") { tab = 1; renderTab() }.apply { topSpace(9) })
            addView(action("접근성 수집 범위 설명") { showAccessibilityDisclosure(false) }.apply { topSpace(8) })
        })
        root.addView(section("업데이트 기록", "이전 버전의 변화를 시기별로 확인할 수 있습니다").apply {
            addView(changeLogItem("v1.6", "모든 화면 라이트·다크 대비, 손가락 두 개로 플로팅 메뉴 크기 조절, 편집 스크롤, 날짜 안내 개선"))
            addView(changeLogItem("v1.5", "수집 후 통계 갱신, 접근성 안정화, 텍스트 입력 접근 개선, 공식 앱 바로가기, 테마 전환"))
            val earlyContent = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                visibility = if (historyEarlyExpanded) View.VISIBLE else View.GONE
                addView(changeLogItem("v0.1~0.4", "출퇴근 시간 파싱·목록 수집 기반, 월별 조회 및 자동 수집 종료 기능"))
                addView(changeLogItem("v0.5~0.6", "초기 안정화·기록 관리 개선 구간"))
                addView(changeLogItem("v0.7", "접근성 목록 재시도·연도 자유 입력·하단 탭 UI 및 앱 아이콘"))
            }
            addView(action("v0.1 ~ v0.7  ${if (historyEarlyExpanded) "접기 ▲" else "펼치기 ▼"}") {
                historyEarlyExpanded = !historyEarlyExpanded
                val y = currentScrollY(); renderTab(); restoreScroll(y)
            }.apply { topSpace(9) })
            addView(earlyContent)
            val laterContent = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                visibility = if (historyLaterExpanded) View.VISIBLE else View.GONE
                addView(changeLogItem("v0.7", "월 조회·대시보드 기반 안정화"))
                addView(changeLogItem("v0.9~1.0", "식사·휴게시간 계산 개선, 접근성 사용 범위 안내·사용자 동의"))
                addView(changeLogItem("v1.1~1.2", "Android 16 시작 안전성, 주간 차트·공식 출근부 앱 바로가기"))
                addView(changeLogItem("v1.3~1.4", "날짜 바로가기, 전체 날짜·시각 공유, 텍스트 수집·컴팩트 UI·차트/그래프 전환"))
            }
            addView(action("v0.7 ~ v1.4  ${if (historyLaterExpanded) "접기 ▲" else "펼치기 ▼"}") {
                historyLaterExpanded = !historyLaterExpanded
                val y = currentScrollY(); renderTab(); restoreScroll(y)
            }.apply { topSpace(8) })
            addView(laterContent)
        })
    }

    private fun setDarkMode(enabled: Boolean) {
        if (darkMode == enabled) return
        if (tab == 1) saveDraft()
        val y = currentScrollY()
        darkMode = enabled
        getSharedPreferences("attendance_display", MODE_PRIVATE).edit()
            .putBoolean("dark_mode", enabled).apply()
        setTheme(if (darkMode) R.style.AttendanceThemeDark else R.style.AttendanceTheme)
        shell.setBackgroundColor(surface)
        val oldTop = topBar
        val topParams = oldTop.layoutParams
        shell.removeView(oldTop)
        topBar = toolbar()
        shell.addView(topBar, 0, topParams)
        navigation.background = shape(if (darkMode) cardGray else Color.WHITE, radius = 0, stroke = border)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) configureSystemBars()
        updateSystemBarIconsSafely()
        renderTab()
        shell.requestApplyInsets()
        restoreScroll(y)
    }

    private fun openRecordsTab() {
        periodEditorMode = false
        if (tab == 1) saveDraft()
        tab = 1
        renderTab()
        // The paste box is immediately below the summary on the records page.
        (host.getChildAt(0) as? ScrollView)?.post {
            (host.getChildAt(0) as? ScrollView)?.scrollTo(0, 0)
        }
    }

    private fun guideRow(number: String, title: String, content: String, iconLabel: String, pkg: String, onClick: () -> Unit): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(cardGray, radius = 13, stroke = border)
            setPadding(dp(12), dp(11), dp(12), dp(11))
            addView(horizontal().apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(label(number, 11f, blue, true).apply {
                    gravity = Gravity.CENTER; background = shape(blueSoft, radius = 9)
                }, LinearLayout.LayoutParams(dp(30), dp(30)))
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(9), 0, 0, 0)
                    addView(label(title, 13.5f, ink, true))
                    addView(label(iconLabel, 10f, muted))
                }, LinearLayout.LayoutParams(0, -2, 1f))
                addView(ImageView(this@MainActivity).apply {
                    try { setImageDrawable(packageManager.getApplicationIcon(pkg)) }
                    catch (_: Exception) { setImageResource(R.mipmap.ic_launcher) }
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    contentDescription = "$iconLabel 아이콘"
                }, LinearLayout.LayoutParams(dp(29), dp(29)))
            })
            addView(label(content, 12f, ink).apply { topSpace(8) })
            addView(action("설정/안내 열기", onClick = onClick).apply { topSpace(8) })
        }.withMargin(0, 0, 0, 8)

    private fun openOwnAppDetails() {
        try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.parse("package:$packageName"))) }
        catch (_: Exception) { toast("앱 설정 화면을 열 수 없습니다") }
    }
    private fun openPlayStore() {
        try {
            val launch = packageManager.getLaunchIntentForPackage("com.android.vending")
            if (launch != null) startActivity(launch) else openHelpUrl("https://play.google.com/store")
        } catch (_: Exception) { toast("Google Play를 열 수 없습니다") }
    }
    private fun openHelpUrl(address: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(address))) }
        catch (_: Exception) { toast("안내 링크를 열 수 없습니다") }
    }

    /** One clear, separate disclosure immediately before directing the user to Android's settings. */
    private fun showAccessibilityDisclosure(openSettings: Boolean) {
        // Never revoke an already granted consent simply by OPENING the disclosure.
        // Doing so disconnects a running accessibility service when the user returns.
        val alreadyConsented = RecordStore.consent(this)
        val disclosure = "이 앱은 한국장학재단의 공식 앱이 아닌 개인용 근무기록 도우미입니다.\n\n" +
            "• 접근 대상: 한국장학재단 출근부 앱(com.kosaf.gpsAttendance)\n" +
            "• 읽는 내용: 조회 목록에 표시된 근무 날짜, 출퇴근 시각, 식사·휴게시간, 기관 확인 상태\n" +
            "• 동작: 사용자가 ‘목록 수집’을 누르면 접근성에 표시된 텍스트를 읽고 목록만 스크롤합니다. 스크린샷/OCR은 하지 않습니다.\n" +
            "• 보관: 추출한 근무기록은 이 휴대전화의 앱 내부에만 저장합니다. 로그인 정보는 수집·저장하지 않으며 서버로 전송하지 않습니다.\n" +
            "• 사용 중지: 떠 있는 ‘수집 중지’는 수집 작업만 멈춥니다. 서비스 권한은 설정 탭에서 직접 끌 수 있습니다.\n\n" +
            "이 권한은 강력한 화면 접근 권한입니다. 반드시 내용을 확인한 뒤 동의해 주세요. 거절해도 기록 탭에서 직접 편집하거나 텍스트를 붙여넣을 수 있습니다."
        appDialog()
            .setTitle("접근성 권한 · 수집 범위 안내")
            .setMessage(disclosure)
            .setNegativeButton(if (openSettings) "동의하지 않음" else "닫기") { _, _ ->
                if (openSettings && !alreadyConsented) RecordStore.setConsent(this, false)
            }
            .setPositiveButton(if (openSettings) "동의하고 설정 열기" else "확인") { _, _ ->
                if (openSettings) {
                    try {
                        RecordStore.setConsent(this, true)
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    } catch (_: Exception) {
                        toast("접근성 설정을 열 수 없습니다")
                        if (!alreadyConsented) RecordStore.setConsent(this, false)
                    }
                }
            }
            .show()
    }

    private fun applyFields() {
        val year = yearField?.text?.toString()?.trim()?.toIntOrNull()
        val monthNumber = monthField?.text?.toString()?.trim()?.toIntOrNull()
        if (year == null || year !in MonthlyWeekStats.FIRST_YEAR..MonthlyWeekStats.LAST_YEAR || monthNumber == null || monthNumber !in 1..12) {
            showDateRangeWarning("입력한 연도 또는 월이 올바르지 않습니다. 연도는 2000~2100, 월은 1~12 사이로 입력해 주세요.")
            return
        }
        changeTo(YearMonth.of(year, monthNumber), preserveScroll = true)
    }

    private fun changeMonth(direction: Int) {
        val next = if (direction == 0) YearMonth.now() else runCatching { month.plusMonths(direction.toLong()) }.getOrNull()
        if (next == null || next.year !in MonthlyWeekStats.FIRST_YEAR..MonthlyWeekStats.LAST_YEAR) {
            showDateRangeWarning("이동하려는 월이 허용 범위 밖입니다. 이전·다음 달 선택은 범위 안에서만 가능합니다.")
            return
        }
        changeTo(next, preserveScroll = true)
    }

    /** Fully themed, friendly date guidance instead of a platform warning box. */
    private fun showDateRangeWarning(details: String) {
        val warningDialog = Dialog(this, if (darkMode) R.style.AttendanceDialogDark else R.style.AttendanceDialogLight)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(if (darkMode) Color.parseColor("#202B3D") else Color.WHITE, radius = 24, stroke = border)
            setPadding(dp(21), dp(22), dp(21), dp(19))
            addView(horizontal().apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(label("!", 21f, amber, true).apply {
                    gravity = Gravity.CENTER
                    background = shape(amberSoft, radius = 15)
                }, LinearLayout.LayoutParams(dp(48), dp(48)))
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(12), 0, 0, 0)
                    addView(label("날짜를 다시 확인해 주세요", 17f, ink, true))
                    addView(label("선택한 날짜를 적용하지 않았어요", 11.5f, muted).apply { topSpace(3) })
                }, LinearLayout.LayoutParams(0, -2, 1f))
            })
            addView(label(details, 13.5f, ink).apply {
                topSpace(19)
                setLineSpacing(dp(3).toFloat(), 1.08f)
            })
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                background = shape(if (darkMode) Color.parseColor("#303A48") else Color.parseColor("#F5F7FC"), radius = 13, stroke = border)
                setPadding(dp(12), dp(12), dp(12), dp(12))
                addView(label("선택 가능한 날짜", 11.5f, muted, true))
                addView(label("2000년 1월 1일 ~ 2100년 12월 31일", 13f, blueDeep, true).apply { topSpace(5) })
                addView(label("월은 1~12 사이에서 입력해 주세요.", 11.5f, muted).apply { topSpace(4) })
            }.apply { topSpace(15) })
            addView(action("확인했어요", primary = true) { warningDialog.dismiss() }.apply { topSpace(18) })
        }
        warningDialog.setContentView(content)
        warningDialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        warningDialog.show()
        warningDialog.window?.decorView?.let { card -> animateEntrance(card, 0L) }
        warningDialog.window?.setLayout(
            (resources.displayMetrics.widthPixels - dp(36)).coerceAtMost(dp(430)),
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    /** Uniform dark/light styling for every other confirmation, list and permission dialog. */
    private fun appDialog(): AlertDialog.Builder = AlertDialog.Builder(this,
        if (darkMode) R.style.AttendanceDialogDark else R.style.AttendanceDialogLight)

    private fun changeTo(value: YearMonth, preserveScroll: Boolean = false) {
        val scrollY = if (preserveScroll) currentScrollY() else 0
        month = value
        RecordStore.setSelectedMonth(this, value)
        clearDraft()
        showAllRows = false
        renderTab()
        if (periodEditorMode) showPeriodEditorImmediately()
        else if (preserveScroll) restoreScroll(scrollY)
    }

    private fun currentScrollY(): Int = (host.getChildAt(0) as? ScrollView)?.scrollY ?: 0

    private fun restoreScroll(scrollY: Int) {
        val scrollView = host.getChildAt(0) as? ScrollView ?: return
        scrollView.post { scrollView.scrollTo(0, scrollY) }
    }

    private fun monthlySummaryText(rows: List<WorkRecord> = currentRecords()): String {
        val total = rows.sumOf { it.minutes }
        val breakTotal = rows.sumOf { it.breakMinutes }
        val mismatch = rows.count { it.differentFromReported }
        return "${month.year}년 ${month.monthValue}월 근무 ${total / 60}시간 ${total % 60}분 · 휴게 차감 ${breakTotal / 60}시간 ${breakTotal % 60}분 · 확인 필요 ${mismatch}건"
    }

    private fun fullMonthText(): String = AttendanceParser.monthlyShareText(currentRecords(), month)

    private fun copyText(label: String, value: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText(label, value))
    }

    private fun copyMonthDetails() {
        runCatching { copyText("${month} 날짜·출퇴근 시각", fullMonthText()) }
            .onSuccess { toast("전체 날짜·출퇴근 시각을 복사했어요") }
            .onFailure { Log.e("AttendanceShare", "Copy failed", it); toast("복사할 수 없습니다") }
    }

    /** A single tap opens the Android share sheet with ALL dated shift details. */
    private fun shareSummary() {
        try {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, fullMonthText())
            }, "월간 날짜·시각 공유"))
        } catch (e: Exception) {
            Log.e("AttendanceShare", "Could not open share sheet", e)
            toast("공유 화면을 열 수 없습니다")
        }
    }

    /**
     * Uses the verified official Play package (com.kosaf.gpsAttendance).
     * Package visibility is declared narrowly in AndroidManifest.xml.
     * Never request QUERY_ALL_PACKAGES or an elevated permission.
     */
    private fun openOfficialAttendanceApp() {
        val launcher = try {
            packageManager.getLaunchIntentForPackage(targetAttendancePackage)
                ?: Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_LAUNCHER)
                    setPackage(targetAttendancePackage)
                }.let { intent ->
                    val info = packageManager.resolveActivity(intent, 0)
                    if (info != null) intent else null
                }
        } catch (error: Exception) {
            Log.w("AttendanceLauncher", "Could not resolve official app", error)
            null
        }
        if (launcher != null) {
            try {
                startActivity(launcher.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            } catch (error: ActivityNotFoundException) {
                Log.w("AttendanceLauncher", "Official app is not launchable", error)
            } catch (error: SecurityException) {
                Log.w("AttendanceLauncher", "Launch restricted by device", error)
            }
        }
        appDialog()
            .setTitle("공식 출근부 앱을 열 수 없어요")
            .setMessage("한국장학재단 출근부 앱이 설치되지 않았거나, 사용 중지·보안 정책으로 실행할 수 없습니다. Play 스토어의 공식 앱 페이지를 확인할까요?")
            .setNegativeButton("닫기", null)
            .setPositiveButton("공식 앱 확인") { _, _ -> openOfficialAppStorePage() }
            .show()
    }

    private fun openOfficialAppStorePage() {
        val storeUrl = "https://play.google.com/store/apps/details?id=$targetAttendancePackage"
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$targetAttendancePackage")))
        } catch (error: ActivityNotFoundException) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(storeUrl)))
            } catch (fallbackError: Exception) {
                toast("공식 앱 페이지를 열 수 없습니다")
            }
        } catch (error: SecurityException) {
            toast("기기 정책에 따라 앱 스토어를 열 수 없습니다")
        }
    }

    private fun showOfficialAppIconOrFallback(target: ImageView, fallback: Int) {
        // Fetches the real currently installed official app icon, so the graphic
        // is accurate and no third-party trademark asset is bundled in our APK.
        try {
            target.setImageDrawable(packageManager.getApplicationIcon(targetAttendancePackage))
        } catch (error: PackageManager.NameNotFoundException) {
            target.setImageResource(fallback)
        } catch (error: Exception) {
            Log.w("AttendanceLauncher", "Official app icon unavailable", error)
            target.setImageResource(fallback)
        }
    }

    private fun <T : View> animateEntrance(view: T, delayMs: Long = 0L): T = view.apply {
        if (!ValueAnimator.areAnimatorsEnabled() || periodEditorMode) return@apply
        alpha = 0f
        translationY = dp(9).toFloat()
        scaleX = 0.985f
        scaleY = 0.985f
        post {
            animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                .setStartDelay(delayMs).setDuration(320)
                .setInterpolator(android.view.animation.DecelerateInterpolator()).start()
        }
    }

    private fun currentRecords(): List<WorkRecord> = RecordStore.read(this).filter { it.date.startsWith(month.toString()) }

    private fun saveDraft() {
        draftPasteText = pasteField?.text?.toString() ?: draftPasteText
        if (recordEditMode && tab == 1) {
            inlineRecordField?.let { field ->
                draftMonth = month
                draftText = field.text?.toString().orEmpty()
            }
        }
    }

    private fun clearDraft() {
        draftMonth = null
        draftText = null
        draftPasteText = null
        recordEditMode = false
        inlineRecordField = null
    }

    private fun isAccessibilityEnabled(): Boolean {
        val component = ComponentName(this, CollectorAccessibilityService::class.java).flattenToString()
        return runCatching {
            (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "")
                .split(":")
                .any { it.equals(component, ignoreCase = true) ||
                    ComponentName.unflattenFromString(it) == ComponentName(this, CollectorAccessibilityService::class.java) }
        }.getOrDefault(false)
    }

    private fun createFile(request: Int, mime: String, filename: String) {
        try {
            pendingFileRequest = request
            pendingFileContent = if (request == saveCsv) {
                AttendanceParser.csv(RecordStore.read(this), month)
            } else {
                AttendanceParser.export(currentRecords(), month)
            }
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = mime
                putExtra(Intent.EXTRA_TITLE, filename)
            }, request)
        } catch (e: Exception) {
            pendingFileRequest = null
            pendingFileContent = null
            toast("파일 저장 화면을 열 수 없습니다")
            Log.e("AttendanceFile", "Could not open document picker", e)
        }
    }

    private fun heading(title: String, subtitle: String, color: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(label(title, 22f, ink, bold = true))
        addView(label(subtitle, 12.5f, muted).apply { topSpace(5) })
    }

    private fun recordPreview(item: WorkRecord): LinearLayout = horizontal().apply {
        gravity = Gravity.CENTER_VERTICAL
        val warning = item.differentFromReported
        val badgeColor = if (warning) amber else if (item.breakMinutes > 0) aqua else blueDeep
        val badgeBg = if (warning) amberSoft else if (item.breakMinutes > 0) greenSoft else blueSoft
        background = shape(
            if (warning) lemon else if (item.breakMinutes > 0) greenSoft else skySoft,
            radius = 14, stroke = border
        )
        setPadding(dp(11), dp(11), dp(11), dp(11))
        topSpace(7)
        addView(label(item.date.takeLast(5).replace('-', '.'), 13f, badgeColor, bold = true).apply {
            gravity = Gravity.CENTER
            background = shape(badgeBg, radius = 11)
            setPadding(dp(4), dp(10), dp(4), dp(10))
        }, LinearLayout.LayoutParams(dp(65), -2))
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, dp(4), 0)
            addView(label("${item.start} ~ ${item.end}", 13f, ink, bold = true))
            addView(label(when {
                warning -> "⚠ 표시시간 차이 · 원본 확인"
                item.breakMinutes > 0 -> "식사 ${item.breakStart} ~ ${item.breakEnd} · ${item.breakMinutes}분 차감"
                else -> if (item.status.isBlank()) "근무 내역" else item.status
            }, 12f, if (warning) amber else muted).apply { topSpace(4) })
        }, LinearLayout.LayoutParams(0, -2, 1f))
        addView(label("${item.minutes / 60}h ${item.minutes % 60}m", 12.5f, badgeColor, bold = true).apply {
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            setSingleLine(true)
        }, LinearLayout.LayoutParams(dp(74), -2))
    }

    private fun heroMetric(title: String, value: String, accent: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = gradient(if (darkMode) intArrayOf(Color.parseColor("#233C75"), Color.parseColor("#40306B")) else intArrayOf(Color.parseColor("#273E92"), Color.parseColor("#4F3E9D")), radius = 15)
        setPadding(dp(10), dp(12), dp(8), dp(12))
        addView(label(title, 10f, Color.parseColor("#E5ECFF")))
        addView(label(value, 17f, accent, bold = true).apply { topSpace(5) })
    }

    private fun statCard(title: String, value: String, bg: Int, fg: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = shape(if (darkMode) cardGray else Color.WHITE, radius = 14, stroke = border)
        setPadding(dp(10), dp(12), dp(8), dp(12))
        addView(label(title, 11.5f, muted, bold = true))
        addView(label(value, 18f, fg, bold = true).apply { topSpace(6) })
    }

    private fun chip(textValue: String, bg: Int, fg: Int): TextView = label(textValue, 11.5f, fg, bold = true).apply {
        background = shape(bg, radius = 100)
        setPadding(dp(10), dp(6), dp(10), dp(6))
    }

    private fun lifestyleCard(title: String, subtitle: String, drawableRes: Int, bg: Int, accent: Int, officialIcon: Boolean = false, actionText: String = "열기", onClick: () -> Unit): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        background = RippleDrawable(ColorStateList.valueOf(Color.parseColor("#244269F5")), shape(bg, radius = 13, stroke = border), null)
        setPadding(dp(10), dp(11), dp(8), dp(11))
        // LinearLayout extends View, which exposes setMinimumHeight (not TextView.minHeight).
        setMinimumHeight(dp(70))
        isClickable = true; isFocusable = true
        contentDescription = "$title, $subtitle"
        setOnClickListener { onClick() }
        addView(ImageView(this@MainActivity).apply {
            if (officialIcon) showOfficialAppIconOrFallback(this, drawableRes) else setImageResource(drawableRes)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = null
        }, LinearLayout.LayoutParams(dp(30), dp(30)).apply { marginEnd = dp(8) })
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            addView(label(title, 12.5f, accent, true).apply { maxLines = 1 })
            addView(label(subtitle, 10f, muted).apply { topSpace(3); maxLines = 1 })
        }, LinearLayout.LayoutParams(0, -2, 1f))
    }

    private fun infoRow(title: String, value: String): LinearLayout = horizontal().apply {
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(6), 0, dp(6))
        addView(label(title, 13f, muted, bold = true), LinearLayout.LayoutParams(0, -2, 0.9f))
        addView(label(value, 13f, ink, bold = true), LinearLayout.LayoutParams(0, -2, 1.1f))
    }

    private fun changeLogItem(title: String, desc: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        setPadding(0, dp(7), 0, dp(7))
        addView(label(title, 12.5f, blueDeep, bold = true).apply {
            gravity = Gravity.CENTER
            background = shape(blueSoft, radius = 12)
            setPadding(dp(14), dp(5), dp(14), dp(5))
        })
        addView(label(desc, 12.5f, ink).apply { setPadding(dp(10), dp(4), 0, dp(4)) }, LinearLayout.LayoutParams(0, -2, 1f))
    }

    private fun fieldBox(title: String, value: String, digits: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(label(title, 12f, muted, bold = true))
        addView(EditText(this@MainActivity).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            filters = arrayOf(InputFilter.LengthFilter(digits))
            setSingleLine(true)
            setText(value)
            selectAll()
            textSize = 19f
            setTextColor(ink)
            setHintTextColor(muted)
            background = shape(if (darkMode) surface else cardGray, radius = 12, stroke = border)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }.also { if (digits == 4) yearField = it else monthField = it })
    }

    private fun section(title: String, description: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = shape(if (darkMode) cardGray else Color.WHITE, radius = 18, stroke = border)
        setPadding(dp(14), dp(15), dp(14), dp(14))
        addView(label(title, 16f, ink, true))
        addView(label(description, 11.5f, muted).apply { topSpace(4) })
        addView(space(12))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(11) }
    }

    private fun step(index: String, title: String, sub: String): LinearLayout = horizontal().apply {
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(7), 0, dp(7))
        addView(label(index, 13f, blue, bold = true).apply {
            gravity = Gravity.CENTER
            background = shape(when (index) { "01" -> blueSoft; "02" -> greenSoft; else -> violetSoft }, radius = 12)
            setTextColor(when (index) { "01" -> blue; "02" -> aqua; else -> violet })
        }, LinearLayout.LayoutParams(dp(42), dp(42)))
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
            addView(label(title, 13.5f, ink, bold = true))
            addView(label(sub, 11.5f, muted).apply { topSpace(3) })
        }, LinearLayout.LayoutParams(0, -2, 1f))
    }

    private fun label(value: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        typeface = Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
        if (size <= 12f && color == muted) setTypeface(typeface, Typeface.BOLD)
        includeFontPadding = true
        setLineSpacing(dp(1).toFloat(), 1.05f)
    }

    private fun action(textValue: String, primary: Boolean = false, destructive: Boolean = false, onClick: () -> Unit): Button = Button(this).apply {
        text = textValue
        isAllCaps = false
        textSize = if (textValue.length >= 10) 11.5f else 13f
        setPadding(dp(5), dp(3), dp(5), dp(3))
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        val accent = when {
            textValue.contains("접근성") || textValue.contains("OCR") || textValue.contains("권한") -> aqua
            textValue.contains("파일") || textValue.contains("복사") || textValue.contains("공유") -> violet
            textValue.contains("삭제") -> red
            textValue.contains("이전") || textValue.contains("다음") || textValue.contains("이번") -> sky
            textValue.contains("공식 앱") -> coral
            else -> blueDeep
        }
        // Primary fills stay dark in BOTH themes: pale foregrounds never sit on pale fills.
        setTextColor(when { primary -> Color.WHITE; destructive -> red; else -> accent })
        val shapeBase = when {
            primary -> when (accent) {
                aqua -> gradient(intArrayOf(Color.parseColor("#076B68"), Color.parseColor("#076A78")), radius = 14)
                violet -> gradient(intArrayOf(Color.parseColor("#58409C"), Color.parseColor("#74386B")), radius = 14)
                else -> gradient(if (darkMode) intArrayOf(Color.parseColor("#334DAD"), Color.parseColor("#5A358E"))
                    else intArrayOf(Color.parseColor("#3045AC"), Color.parseColor("#6440A4")), radius = 14)
            }
            destructive -> shape(redSoft, radius = 14, stroke = if (darkMode) red else Color.parseColor("#E8A1BB"))
            accent == sky -> shape(skySoft, radius = 14, stroke = border)
            accent == violet -> shape(violetSoft, radius = 14, stroke = border)
            else -> shape(blueSoft, radius = 14, stroke = border)
        }
        background = RippleDrawable(ColorStateList.valueOf(if (darkMode) Color.parseColor("#44FFFFFF") else Color.parseColor("#220C1B36")), shapeBase, null)
        if (primary) elevation = dp(1).toFloat()
        minHeight = dp(43)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(43))
    }

    private fun horizontal(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    private fun space(height: Int): View = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }

    private fun <T : View> T.topSpace(dpSize: Int): T = apply {
        val params = (layoutParams as? LinearLayout.LayoutParams) ?: LinearLayout.LayoutParams(-1, -2)
        params.topMargin = dp(dpSize)
        layoutParams = params
    }

    private fun <T : View> T.withMargin(left: Int, top: Int, right: Int, bottom: Int): T = apply {
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(left), dp(top), dp(right), dp(bottom)) }
    }

    private fun shape(fill: Int, radius: Int = 16, stroke: Int = Color.TRANSPARENT): GradientDrawable = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }

    private fun gradient(colors: IntArray, radius: Int): GradientDrawable = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply {
        cornerRadius = dp(radius).toFloat()
    }

    private fun toast(message: String) { Toast.makeText(this, message, Toast.LENGTH_LONG).show() }
    private fun dp(value: Int): Int = (resources.displayMetrics.density * value).toInt()
}
