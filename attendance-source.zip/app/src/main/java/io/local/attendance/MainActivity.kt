package io.local.attendance

import android.app.Activity
import android.app.AlertDialog
import android.animation.ValueAnimator
import android.content.ActivityNotFoundException
import android.content.pm.PackageManager
import android.net.Uri
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.os.Build
import android.util.Log
import android.provider.Settings
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import java.time.YearMonth
import java.time.LocalDate

/** Native, dependency-light personal dashboard. No credentials or network permissions. */
class MainActivity : Activity() {
    private val openImage = 1101
    private val saveTxt = 1102
    private val saveCsv = 1103
    private val targetAttendancePackage = "com.kosaf.gpsAttendance"

    // Prism palette: bright accents with readable contrast and the same four-tab layout.
    private val navy = Color.parseColor("#14234B")
    private val blue = Color.parseColor("#4165FF")
    private val blueDeep = Color.parseColor("#3946BB")
    private val blueSoft = Color.parseColor("#EDF2FF")
    private val violet = Color.parseColor("#854EDC")
    private val violetSoft = Color.parseColor("#F2EAFF")
    private val aqua = Color.parseColor("#007E76")
    private val greenSoft = Color.parseColor("#E4F8F3")
    private val amber = Color.parseColor("#9D6208")
    private val amberSoft = Color.parseColor("#FFF3D9")
    private val red = Color.parseColor("#BB285A")
    private val redSoft = Color.parseColor("#FFF0F4")
    private val surface = Color.parseColor("#F8F7FF")
    private val border = Color.parseColor("#E6E9F5")
    private val ink = Color.parseColor("#1C2948")
    private val muted = Color.parseColor("#73809A")
    private val cardGray = Color.parseColor("#F9FAFF")
    private val coral = Color.parseColor("#E8477A")
    private val coralSoft = Color.parseColor("#FFF0F4")
    private val sky = Color.parseColor("#0786CC")
    private val skySoft = Color.parseColor("#E9F7FF")
    private val peach = Color.parseColor("#FFF2E5")
    private val lemon = Color.parseColor("#FFF8D9")

    private lateinit var shell: LinearLayout
    private lateinit var host: FrameLayout
    private lateinit var navigation: LinearLayout
    private lateinit var topBar: LinearLayout
    // Avoid repeatedly rebuilding the dashboard after startup errors.
    private var startupFailed = false
    private var firstResume = true

    private var tab = 0
    private var showAllRows = false
    private lateinit var month: YearMonth
    private var yearField: EditText? = null
    private var monthField: EditText? = null
    private var exportField: EditText? = null
    private var pasteField: EditText? = null
    private var draftMonth: YearMonth? = null
    private var draftText: String? = null

    private val versionName = "v1.2"
    private val minAndroidText = "Android 8.0 이상 (API 26+)"
    private val targetAndroidText = "Android 8.0~16 지원 · Android 16 (API 36) 대응"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Startup failures should show a minimal diagnostic screen instead of an
        // unexplained immediate close. User attendance records are never deleted.
        try {
            initializeDashboard()
        } catch (error: Exception) {
            startupFailed = true
            Log.e("AttendanceStartup", "Failed to initialize the dashboard", error)
            showStartupError(error)
        }
    }

    private fun initializeDashboard() {
        // Edge-to-edge is mandatory for targetSdk 36. Keep the gradient behind the
        // status bar and the bottom navigation behind gesture/three-button insets.
        // Using system-bar colors alone on Android 16 no longer protects content.
        configureSystemBars()
        month = RecordStore.selectedMonth(this)
        RecordStore.refreshDisclosureConsent(this)

        shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(surface)
            clipToPadding = false
        }
        setContentView(shell)

        topBar = toolbar()
        shell.addView(topBar)
        // Small color ribbon makes the dashboard lively without changing its navigation structure.
        shell.addView(horizontal().apply {
            listOf(blue, sky, aqua, Color.parseColor("#FFC45F"), coral, violet).forEach { color ->
                addView(View(this@MainActivity).apply { setBackgroundColor(color) },
                    LinearLayout.LayoutParams(0, dp(4), 1f))
            }
        })
        host = FrameLayout(this)
        shell.addView(host, LinearLayout.LayoutParams(-1, 0, 1f))
        navigation = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = gradient(intArrayOf(Color.WHITE, Color.parseColor("#FFF6FD")), radius = 0)
            elevation = dp(10).toFloat()
            setPadding(dp(10), dp(8), dp(10), dp(8))
            clipToPadding = false
        }
        shell.addView(navigation, LinearLayout.LayoutParams(-1, dp(76)))

        shell.setOnApplyWindowInsetsListener { _, insets ->
            // Insets may arrive while the Activity is still being initialized.
            // Never let a transient insets issue terminate the application.
            try {
                if (::topBar.isInitialized && ::navigation.isInitialized && ::host.isInitialized) {
                    applyInsets(insets)
                }
            } catch (error: Exception) {
                Log.e("AttendanceStartup", "Could not apply window insets", error)
            }
            insets
        }
        renderTab()
        // Layout/insets are requested only after the entire view hierarchy is built.
        shell.post {
            if (!startupFailed) {
                updateSystemBarIconsSafely()
                shell.requestApplyInsets()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // onCreate already built the first screen; do not build it twice at launch.
        if (firstResume) {
            firstResume = false
            return
        }
        if (!startupFailed && ::host.isInitialized) {
            try {
                renderTab()
            } catch (error: Exception) {
                startupFailed = true
                Log.e("AttendanceStartup", "Failed to resume dashboard", error)
                showStartupError(error)
            }
        }
    }

    override fun onPause() {
        if (::host.isInitialized && tab == 1) saveDraft()
        super.onPause()
    }

    override fun onDestroy() {
        if (isFinishing) CollectorAccessibilityService.shutdownFromApp()
        super.onDestroy()
    }

    @Deprecated("Android back behavior across API levels")
    override fun onBackPressed() {
        CollectorAccessibilityService.shutdownFromApp()
        super.onBackPressed()
    }

    @Deprecated("For this small self-contained Android project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        if (requestCode == saveTxt || requestCode == saveCsv) {
            val text = if (requestCode == saveCsv) {
                AttendanceParser.csv(RecordStore.read(this), month)
            } else {
                draftText ?: AttendanceParser.export(currentRecords(), month)
            }
            try {
                contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                toast("파일 저장 완료")
            } catch (e: Exception) {
                toast("파일 저장 실패: ${e.localizedMessage}")
            }
            return
        }
        if (requestCode != openImage) return
        val capturedMonth = month
        val recognizer = TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        try {
            recognizer.process(InputImage.fromFilePath(this, uri))
                .addOnSuccessListener { ocr ->
                    val parsed = AttendanceParser.fromListPage(ocr.text, capturedMonth)
                    if (parsed.isNotEmpty()) RecordStore.add(this, parsed)
                    toast("OCR ${parsed.size}건 추출 · 원본과 대조해 주세요")
                    if (month == capturedMonth) {
                        tab = 2
                        renderTab()
                        pasteField?.setText(ocr.text)
                    }
                }
                .addOnFailureListener { toast("OCR 인식 실패: ${it.localizedMessage}") }
                .addOnCompleteListener { recognizer.close() }
        } catch (e: Exception) {
            recognizer.close()
            toast("이미지 열기 실패: ${e.localizedMessage}")
        }
    }

    /**
     * Avoid querying Window.getInsetsController() before the window is attached.
     * Some Android 16/OEM framework builds throw inside that platform call,
     * even when the caller uses Kotlin's null-safe operator.
     */
    @Suppress("DEPRECATION")
    private fun configureSystemBars() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
            // Do not access window.insetsController during Activity.onCreate().
        } else {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.isNavigationBarContrastEnforced = false
            window.isStatusBarContrastEnforced = false
        }
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
    }

    /** Optional decoration only. UI still works if the OS cannot supply a controller. */
    private fun updateSystemBarIconsSafely() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        try {
            val controller = window.decorView.windowInsetsController ?: return
            controller.setSystemBarsAppearance(
                WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,
                WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS or
                    WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
            )
        } catch (error: Exception) {
            Log.w("AttendanceStartup", "System bar icon styling skipped", error)
        }
    }

    /** Protect interactive content from notches and 3-button/gesture navigation. */
    @Suppress("DEPRECATION")
    private fun applyInsets(insets: WindowInsets) {
        val bars = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
        } else null
        val top = bars?.top ?: insets.systemWindowInsetTop
        val bottom = bars?.bottom ?: insets.systemWindowInsetBottom
        val left = bars?.left ?: insets.systemWindowInsetLeft
        val right = bars?.right ?: insets.systemWindowInsetRight
        val barLeft = dp(18) + left
        val barTop = dp(16) + top
        val barRight = dp(18) + right
        if (topBar.paddingLeft != barLeft || topBar.paddingTop != barTop ||
            topBar.paddingRight != barRight || topBar.paddingBottom != dp(16)) {
            topBar.setPadding(barLeft, barTop, barRight, dp(16))
        }
        val navLeft = dp(10) + left
        val navRight = dp(10) + right
        val navBottom = dp(8) + bottom
        if (navigation.paddingLeft != navLeft || navigation.paddingBottom != navBottom ||
            navigation.paddingRight != navRight) {
            navigation.setPadding(navLeft, dp(8), navRight, navBottom)
        }
        // Landscape and foldables can have camera cutouts on the side.
        if (host.paddingLeft != left || host.paddingRight != right) host.setPadding(left, 0, right, 0)
        val targetHeight = dp(76) + bottom
        val params = navigation.layoutParams as? LinearLayout.LayoutParams
        if (params != null && params.height != targetHeight) {
            params.height = targetHeight
            navigation.layoutParams = params
        }
        // Insets are applied to the visible controls, not to the scroll host:
        // no double padding when the system switches gesture/3-button navigation.
    }

    /** A crash-safe, native-only fallback; contains no OCR or accessibility initialization. */
    private fun showStartupError(error: Exception) {
        val diagnostic = buildString {
            append("근무로그 v1.1 / Android SDK ")
            append(Build.VERSION.SDK_INT)
            append("\n")
            append(error.javaClass.name)
            append("\n")
            error.stackTrace.firstOrNull { it.className.startsWith("io.local.attendance") }
                ?.let { append(it.className).append(":").append(it.lineNumber) }
        }
        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(dp(24), dp(48), dp(24), dp(24))
        }
        wrapper.addView(TextView(this).apply {
            text = "근무로그를 시작하지 못했어요"
            textSize = 22f
            setTextColor(Color.rgb(24, 39, 74))
            typeface = Typeface.DEFAULT_BOLD
        })
        wrapper.addView(TextView(this).apply {
            text = "저장된 근무기록은 삭제되지 않았습니다. 아래의 진단 정보를 복사해 개발자에게 전달해 주세요."
            textSize = 15f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(14), 0, dp(12))
        })
        wrapper.addView(TextView(this).apply {
            text = diagnostic
            textSize = 12f
            setTextColor(Color.DKGRAY)
        })
        wrapper.addView(Button(this).apply {
            text = "진단 정보 복사"
            isAllCaps = false
            setOnClickListener {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("근무로그 시작 오류", diagnostic))
                Toast.makeText(this@MainActivity, "진단 정보를 복사했습니다", Toast.LENGTH_SHORT).show()
            }
        })
        wrapper.addView(Button(this).apply {
            text = "다시 시작"
            isAllCaps = false
            setOnClickListener { recreate() }
        })
        setContentView(wrapper)
    }

    private fun toolbar(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        background = gradient(intArrayOf(navy, Color.parseColor("#3C389D"), Color.parseColor("#8A47C9")), radius = 0)
        setPadding(dp(18), dp(15), dp(18), dp(15))
        // Show the ORIGINAL icon from the installed official KOSAF attendance app.
        // This is an independent personal helper; it is not an official KOSAF app.
        addView(ImageView(this@MainActivity).apply {
            showOfficialAppIconOrFallback(this, R.drawable.dashboard_illustration)
            scaleType = ImageView.ScaleType.FIT_CENTER
            background = shape(Color.WHITE, radius = 15)
            setPadding(dp(4), dp(4), dp(4), dp(4))
            contentDescription = "한국장학재단 출근부 앱 참고 아이콘"
        }.also { animateEntrance(it, 80) }, LinearLayout.LayoutParams(dp(48), dp(48)))
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
            addView(label("근무로그", 20f, Color.WHITE, bold = true))
            addView(label("오늘도 수고했어요 ✦ 비공식 개인용 도우미", 11.2f, Color.parseColor("#E9E9FF")))
        }, LinearLayout.LayoutParams(0, -2, 1f))
        addView(label(versionName, 11f, Color.WHITE, bold = true).apply {
            background = shape(Color.parseColor("#6D4CBE"), radius = 100)
            setPadding(dp(11), dp(7), dp(11), dp(7))
        })
    }

    private fun renderTab() {
        if (!::host.isInitialized) return
        host.removeAllViews()
        yearField = null
        monthField = null
        exportField = null
        pasteField = null

        val scroll = ScrollView(this).apply {
            clipToPadding = false
            setBackgroundColor(surface)
            setPadding(0, 0, 0, dp(20))
            isFillViewport = true
        }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(18))
            clipToPadding = false
        }
        scroll.addView(column, ViewGroup.LayoutParams(-1, -2))
        host.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        when (tab) {
            0 -> renderHome(column)
            1 -> renderRecords(column)
            2 -> renderTools(column)
            else -> renderInfo(column)
        }
        renderBottomNav()
        // Subtle entrance motion for the dashboard sections. System-level reduced
        // animations are respected, and content never depends on animation.
        if (ValueAnimator.areAnimatorsEnabled()) {
            for (index in 0 until column.childCount) {
                if (index < 8) animateEntrance(column.getChildAt(index), (index * 32L).coerceAtMost(190L))
            }
        }
    }

    private fun renderBottomNav() {
        navigation.removeAllViews()
        val tabs = listOf("홈", "기록", "가져오기", "정보")
        val icons = listOf(R.drawable.nav_home, R.drawable.nav_records, R.drawable.nav_import, R.drawable.nav_info)
        val accents = listOf(blue, violet, aqua, coral)
        val pastels = listOf(blueSoft, violetSoft, greenSoft, coralSoft)
        tabs.forEachIndexed { i, title ->
            val active = i == tab
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                background = if (active) gradient(intArrayOf(pastels[i], Color.WHITE), radius = 19) else shape(Color.TRANSPARENT, radius = 19)
                setPadding(dp(4), dp(7), dp(4), dp(7))
                contentDescription = if (active) "$title 탭, 선택됨" else "$title 탭"
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    if (i != tab) {
                        if (tab == 1) saveDraft()
                        tab = i
                        renderTab()
                    }
                }
            }
            val tint = if (active) accents[i] else Color.parseColor("#A8B1C7")
            item.addView(ImageView(this).apply {
                setImageResource(icons[i])
                imageTintList = ColorStateList.valueOf(tint)
                contentDescription = null
            }, LinearLayout.LayoutParams(dp(22), dp(22)))
            item.addView(label(title, 12f, if (active) accents[i] else muted, bold = active).apply {
                gravity = Gravity.CENTER
                topSpace(5)
            })
            navigation.addView(item, LinearLayout.LayoutParams(0, -1, 1f).apply {
                marginStart = dp(3)
                marginEnd = dp(3)
            })
        }
    }

    private fun renderHome(root: LinearLayout) {
        val rows = currentRecords()
        val total = rows.sumOf { it.minutes }
        val mismatch = rows.count { it.differentFromReported }

        val gross = rows.sumOf { it.grossMinutes }
        val deducted = rows.sumOf { it.breakMinutes }
        val displayed = rows.sumOf { it.reportedMinutes ?: it.minutes }
        val withDisplayed = rows.count { it.reportedMinutes != null }

        val heroCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = gradient(intArrayOf(Color.parseColor("#192955"), Color.parseColor("#4A49C4"), Color.parseColor("#F25F9B")), radius = 26)
            elevation = dp(4).toFloat()
            setPadding(dp(20), dp(21), dp(20), dp(20))
            addView(horizontal().apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(chip("✦  ${month.year}년 ${month.monthValue}월", Color.parseColor("#4853AD"), Color.WHITE))
                    addView(label("${total / 60}시간 ${total % 60}분", 31f, Color.WHITE, bold = true).apply { topSpace(12) })
                    addView(label("휴게를 제외한 나의 근무", 12f, Color.parseColor("#F4E8FF")).apply { topSpace(3) })
                    addView(label(if (rows.isEmpty()) "기록을 모으면 월간 리듬을 바로 볼 수 있어요" else "오늘도 차곡차곡 기록 중이에요", 11.5f, Color.parseColor("#E1F4FF")).apply { topSpace(7) })
                }, LinearLayout.LayoutParams(0, -2, 1f))
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(R.drawable.dashboard_illustration)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    contentDescription = null // Decorative illustration; data appears in text.
                }.also { animateEntrance(it, 80) }, LinearLayout.LayoutParams(dp(96), dp(108)))
            })
            addView(horizontal().apply {
                topSpace(18)
                addView(heroMetric("출퇴근 시각", "${gross / 60}h ${gross % 60}m", Color.parseColor("#D9E8FF")), LinearLayout.LayoutParams(0, -2, 1f))
                addView(heroMetric("휴게 차감", "${deducted / 60}h ${deducted % 60}m", Color.parseColor("#B5FFE7")), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(7) })
                addView(heroMetric("확인 필요", "${mismatch}건", Color.parseColor("#FFEAA4")), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(7) })
            })
            addView(label("${rows.size}건 저장  •  화면 표시시간 확인 ${withDisplayed}건", 11.5f, Color.parseColor("#F4EAFF")).apply { topSpace(14) })
            addView(horizontal().apply {
                topSpace(11)
                addView(chip("✓ 기기 안에 저장", Color.parseColor("#284C99"), Color.WHITE))
                addView(chip("✦ 필요한 기록만", Color.parseColor("#8B397E"), Color.WHITE).apply {
                    layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) }
                })
            })
        }.withMargin(0, 0, 0, 14)
        root.addView(heroCard)
        animateEntrance(heroCard)

        if (rows.isNotEmpty() && withDisplayed > 0) {
            val warning = mismatch > 0
            root.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = shape(if (warning) amberSoft else greenSoft, radius = 18)
                setPadding(dp(15), dp(13), dp(15), dp(13))
                addView(label(if (warning) "⚠  표시시간과 차이가 있어요" else "✓  표시시간과 일치해요",
                    14f, if (warning) amber else aqua, bold = true))
                addView(label("목록 항목 표시시간 합계 ${displayed / 60}시간 ${displayed % 60}분  ·  계산 ${total / 60}시간 ${total % 60}분",
                    12.5f, ink).apply { topSpace(5) })
                addView(label(if (warning)
                    "식사시간이 저장되지 않은 기존 기록일 수 있어요. 원본 목록을 다시 수집해 확인하세요."
                    else "원본에 명시된 식사·휴게시간만 차감했어요. 공식 월간 인정시간과는 별도로 대조하세요.",
                    11.5f, muted).apply { topSpace(4) })
            }.withMargin(0, 0, 0, 14))
        }

        root.addView(section("오늘의 루틴 카드", "일상에서 자주 쓰는 기능을 이미지 카드로 모았어요.").apply {
            val rowOne = horizontal()
            rowOne.addView(lifestyleCard("자동 수집", "목록을 열고 바로 시작", R.drawable.home_automation_illustration, blueSoft, blue) {
                showAccessibilityDisclosure(openSettings = true)
            }, LinearLayout.LayoutParams(0, -2, 1f))
            rowOne.addView(lifestyleCard("빠른 백업", "TXT 또는 CSV 저장", R.drawable.calendar_party_illustration, coralSoft, coral) {
                tab = 1
                renderTab()
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
            addView(rowOne)
            val rowTwo = horizontal().apply { topSpace(8) }
            rowTwo.addView(lifestyleCard("공식 앱 열기", "장학재단 출근부 바로가기", R.drawable.home_automation_illustration, greenSoft, aqua, officialIcon = true) {
                openOfficialAttendanceApp()
            }, LinearLayout.LayoutParams(0, -2, 1f))
            rowTwo.addView(lifestyleCard("월간 공유", "합계를 메시지로 전달", R.drawable.calendar_party_illustration, violetSoft, violet) {
                shareSummary()
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
            addView(rowTwo)
        })

        renderWeeklyChart(root, rows)

        root.addView(section("🔎 자동 수집 모드", "접근성 승인을 받아 공식 출근부 목록에서만 수집해요.").apply {
            addView(chip("대상 앱 한정 · 사용자가 시작", greenSoft, aqua))
            addView(label("① 접근성 사용 내용을 읽고 동의\n② 한국장학재단 앱에서 조회 → 목록 열기\n③ 떠 있는 ‘목록 수집’ 버튼 누르기", 12.5f, ink).apply {
                topSpace(11)
            })
            addView(action("자동 수집 시작 안내 · 권한 설정", primary = true) {
                showAccessibilityDisclosure(openSettings = true)
            }.apply { topSpace(12) })
            addView(action("설치 차단 · 접근성 제한 설명") {
                showSecurityLimitations()
            }.apply { topSpace(8) })
            addView(label("수집을 누르기 전에는 화면 기록을 시작하지 않아요. 앱 이동 또는 중지 시 종료합니다.", 11.5f, muted).apply { topSpace(9) })
        }.withMargin(0, 0, 0, 14))

        root.addView(section("빠른 액션 허브", "실제로 자주 쓰는 기능을 한 번에 모았어요.").apply {
            addView(horizontal().apply {
                addView(action("근무 합계 복사", primary = true) {
                    val summary = monthlySummaryText(rows)
                    (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                        .setPrimaryClip(ClipData.newPlainText("월 근무 합계", summary))
                    toast("월 근무 합계를 복사했어요")
                }, LinearLayout.LayoutParams(0, dp(48), 1f))
                addView(action("월간 공유") { shareSummary() },
                    LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(8) })
            })
            addView(horizontal().apply {
                topSpace(9)
                addView(action("기록 확인") { tab = 1; renderTab() }, LinearLayout.LayoutParams(0, dp(48), 1f))
                addView(action("텍스트 · 사진 가져오기") { tab = 2; renderTab() }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(8) })
            })
            addView(horizontal().apply {
                topSpace(9)
                addView(action("공식 앱 열기") { openOfficialAttendanceApp() }, LinearLayout.LayoutParams(0, dp(48), 1f))
                addView(action("권한 상태 확인") { showSecurityLimitations() }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(8) })
            })
        })

        root.addView(section("조회 기간", "원하는 연도와 월을 직접 입력해 조회할 수 있습니다.").apply {
            val row = horizontal()
            val yearBox = fieldBox("연도", month.year.toString().padStart(4, '0'), 4)
            val monthBox = fieldBox("월", month.monthValue.toString(), 2)
            row.addView(yearBox, LinearLayout.LayoutParams(0, -2, 2f))
            row.addView(monthBox, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10) })
            addView(row)
            addView(action("이 연도 · 월 적용", primary = true) { applyFields() }.apply { topSpace(10) })
            val quick = horizontal().apply { topSpace(9) }
            quick.addView(action("〈 이전 달") { changeMonth(-1) }, LinearLayout.LayoutParams(0, dp(48), 1f))
            quick.addView(action("이번 달") { changeMonth(0) }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(8) })
            quick.addView(action("다음 달 〉") { changeMonth(1) }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(8) })
            addView(quick)
            addView(chip("앱 내부 제한 없음", blueSoft, blueDeep).apply { topSpace(10) })
            addView(label("※ 앱 자체에 특정 연도 제한은 없습니다. 다만 공식 앱에 표시된 기간만 자동 수집할 수 있습니다.", 11.5f, muted).apply { topSpace(8) })
        })

        val serviceEnabled = isAccessibilityEnabled()
        val connected = CollectorAccessibilityService.isReady()
        root.addView(section("목록 수집", "접근성을 켠 후 장학재단 앱의 조회 → 목록에서 시작합니다.").apply {
            val statusBg = if (connected) greenSoft else if (serviceEnabled) amberSoft else Color.parseColor("#EEF1FA")
            val statusColor = if (connected) aqua else if (serviceEnabled) amber else muted
            val statusMsg = when {
                connected -> "● 접근성 연결됨 · 목록에서 시작 가능"
                serviceEnabled -> "● 접근성 활성화됨 · 연결 준비 중"
                else -> "● 접근성 꺼짐 · 사용 시 활성화하세요"
            }
            addView(label(statusMsg, 13f, statusColor, bold = true).apply {
                background = shape(statusBg, radius = 12)
                setPadding(dp(12), dp(12), dp(12), dp(12))
            }, LinearLayout.LayoutParams(-1, -2))
            addView(label("🔎 대상: 한국장학재단 출근부 앱 한 곳", 12.5f, ink, bold = true).apply {
                topSpace(12)
            })
            addView(label("화면의 날짜·근무시각·식사/휴게·확인 상태를 읽고 내 기기에만 저장해요. 글자가 보이지 않으면 현재 화면을 임시 OCR로 확인할 수 있습니다.", 12f, muted).apply { topSpace(5) })
            addView(action("권한 사용 안내 확인 · 설정 열기", primary = true) {
                showAccessibilityDisclosure(openSettings = true)
            }.apply { topSpace(13) })
            addView(action("중지하고 접근성 끄기") {
                CollectorAccessibilityService.shutdownFromApp()
                toast("접근성 해제를 요청했습니다")
                renderTab()
            }.apply { topSpace(9) })
            addView(label("✓ 직접 동의 후에만 설정으로 이동해요. 자동 승인·권한 우회는 하지 않습니다.", 11.5f, aqua).apply { topSpace(10) })
            addView(action("설치 차단 · 접근성 제한 안내") { showSecurityLimitations() }.apply { topSpace(9) })
        })

        root.addView(section("3단계 사용 방법", "시작 버튼은 장학재단 앱 화면에 나타납니다.").apply {
            addView(step("01", "장학재단 앱에서 근무 목록 열기", "로그인 → 조회 → 오른쪽 위 목록 보기"))
            addView(step("02", "파란색 ‘목록 수집’ 버튼 누르기", "화면 로딩 중이면 자동으로 다시 확인합니다"))
            addView(step("03", "완료되면 기록 탭 확인", "수집 종료 시 접근성 서비스는 자동으로 꺼집니다"))
        })
        root.addView(label("개인 기기 내 저장 · 공식 기관이 제공하거나 승인한 앱이 아닌 개인용 도우미", 11f, muted).apply {
            gravity = Gravity.CENTER
            topSpace(3)
        })
    }

    /** Small local-only visualization. Week 1 is days 1-7, week 2 is 8-14, etc. */
    private fun renderWeeklyChart(root: LinearLayout, rows: List<WorkRecord>) {
        val weeks = IntArray(5)
        for (record in rows) {
            val day = runCatching { LocalDate.parse(record.date).dayOfMonth }.getOrNull() ?: continue
            if (day in 1..31) weeks[(day - 1) / 7] += record.minutes
        }
        val maximum = (weeks.maxOrNull() ?: 0).coerceAtLeast(1)
        val accents = listOf(blue, violet, aqua, coral, sky)
        val lights = listOf(Color.parseColor("#9AC6FF"), Color.parseColor("#D4B3FF"),
            Color.parseColor("#7DE7CF"), Color.parseColor("#FFB4CF"), Color.parseColor("#9EDFFF"))
        root.addView(section("✦ 이번 달 근무 흐름", "1~7일 · 8~14일 · 15~21일 · 22~28일 · 29일 이후").apply {
            addView(horizontal().apply {
                gravity = Gravity.BOTTOM
                for (index in 0 until 5) {
                    val minutes = weeks[index]
                    val barHeight = if (minutes == 0) 5 else 12 + (minutes.toFloat() / maximum * 70).toInt()
                    addView(LinearLayout(this@MainActivity).apply {
                        orientation = LinearLayout.VERTICAL
                        gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                        setPadding(dp(3), 0, dp(3), 0)
                        addView(label(if (minutes > 0) "${minutes / 60}h" else "-", 11f,
                            if (minutes > 0) accents[index] else muted, bold = true).apply {
                            gravity = Gravity.CENTER
                        })
                        addView(FrameLayout(this@MainActivity).apply {
                            contentDescription = "${index + 1}주차 ${minutes / 60}시간 ${minutes % 60}분"
                            background = shape(Color.parseColor("#F0F2FC"), radius = 12)
                            addView(View(this@MainActivity).apply {
                                background = gradient(intArrayOf(lights[index], accents[index]), radius = 10)
                                if (minutes > 0 && ValueAnimator.areAnimatorsEnabled()) {
                                    // Animate each weekly bar upward from the baseline.
                                    scaleY = 0.12f
                                    post {
                                        pivotY = height.toFloat()
                                        animate().scaleY(1f).setStartDelay(index * 75L)
                                            .setDuration(430)
                                            .setInterpolator(android.view.animation.DecelerateInterpolator())
                                            .start()
                                    }
                                }
                            }, FrameLayout.LayoutParams(-1, dp(barHeight), Gravity.BOTTOM))
                        }, LinearLayout.LayoutParams(-1, dp(92)).apply { topMargin = dp(9) })
                        addView(label("${index + 1}주", 11.5f, ink, bold = true).apply {
                            gravity = Gravity.CENTER
                            topSpace(8)
                        })
                    }, LinearLayout.LayoutParams(0, -2, 1f))
                }
            })
            val days = rows.map { it.date }.distinct().size
            val longest = rows.groupBy { it.date }.values.maxOfOrNull { shifts -> shifts.sumOf { it.minutes } } ?: 0
            addView(horizontal().apply {
                topSpace(16)
                addView(chip("근무 ${days}일", greenSoft, aqua))
                addView(chip("하루 최대 ${longest / 60}h ${longest % 60}m", violetSoft, violet).apply {
                    layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) }
                })
            })
            if (rows.isEmpty()) {
                addView(label("아직 기록이 없어요. 아래 가져오기 메뉴에서 시작해 보세요!", 12f, muted).apply {
                    topSpace(12)
                })
            }
        })
    }

    private fun renderRecords(root: LinearLayout) {
        val items = currentRecords()
        val total = items.sumOf { it.minutes }
        val gross = items.sumOf { it.grossMinutes }
        val rest = items.sumOf { it.breakMinutes }
        val mismatch = items.count { it.differentFromReported }
        root.addView(heading("근무기록", "${month.year}년 ${month.monthValue}월 · ${items.size}건의 출근부 기록", violet))
        root.addView(horizontal().apply {
            topSpace(12)
            addView(statCard("✦ 계산 근무", "${total / 60}h ${total % 60}m", skySoft, sky), LinearLayout.LayoutParams(0, -2, 1f))
            addView(statCard("☘ 휴게 차감", "${rest / 60}h ${rest % 60}m", greenSoft, aqua), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
            addView(statCard("◈ 표시 차이", "${mismatch}건", if (mismatch == 0) violetSoft else amberSoft, if (mismatch == 0) violet else amber), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
        }.withMargin(0, 0, 0, 14))
        if (items.isNotEmpty()) {
            root.addView(section("일자별 한눈에 보기", "출퇴근 ${gross / 60}시간 · 명시된 식사/휴게 ${rest / 60}시간 차감").apply {
                val descending = items.sortedWith(compareByDescending<WorkRecord> { it.date }.thenBy { it.start })
                val visible = if (showAllRows) descending else descending.take(5)
                visible.forEach { addView(recordPreview(it)) }
                if (descending.size > 5) addView(action(if (showAllRows) "간략히 접기" else "전체 ${descending.size}건 펼쳐보기") {
                    val oldPosition = (host.getChildAt(0) as? ScrollView)?.scrollY ?: 0
                    saveDraft()
                    showAllRows = !showAllRows
                    renderTab()
                    (host.getChildAt(0) as? ScrollView)?.let { view ->
                        view.post { view.scrollTo(0, oldPosition) }
                    }
                }.apply { topSpace(9) })
            })
        }
        root.addView(section("추출 결과 · 편집", "식사/휴게 내역을 유지한 채 수정하거나 TXT/CSV로 저장하세요.").apply {
            val textBox = EditText(this@MainActivity).apply {
                gravity = Gravity.TOP
                minLines = 12
                maxLines = 26
                textSize = 13f
                typeface = Typeface.create("sans-serif", Typeface.NORMAL)
                setTextColor(ink)
                background = shape(cardGray, radius = 14, stroke = Color.parseColor("#D9DFF3"))
                setPadding(dp(12), dp(14), dp(12), dp(14))
                setText(if (draftMonth == month) draftText ?: AttendanceParser.export(items, month) else AttendanceParser.export(items, month))
            }
            exportField = textBox
            addView(textBox)
            addView(action("현재 내용 복사", primary = true) {
                val value = exportField?.text?.toString().orEmpty()
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("근로시간", value))
                toast("복사했어요")
            }.apply { topSpace(10) })
            addView(action("TXT 파일로 저장") {
                saveDraft(); createFile(saveTxt, "text/plain", "근무기록_${month}.txt")
            }.apply { topSpace(9) })
            addView(action("CSV 파일로 저장") { createFile(saveCsv, "text/csv", "근무기록_${month}.csv") }.apply { topSpace(9) })
        })
        root.addView(section("기록 편집", "직접 수정한 시간표를 저장하거나 해당 월 기록을 삭제할 수 있습니다.").apply {
            addView(action("수정한 날짜·시각으로 월 기록 교체") {
                val corrected = AttendanceParser.fromEditableText(exportField?.text?.toString().orEmpty(), month)
                if (corrected.isEmpty()) {
                    toast("YYYY-MM-DD 09:00 ~ 11:00 형식을 확인하세요")
                    return@action
                }
                AlertDialog.Builder(this@MainActivity).setTitle("${month} 기록 교체")
                    .setMessage("현재 월의 저장 기록을 ${corrected.size}건으로 교체할까요? 편집본에 적힌 표시시간·기관확인·식사시간도 함께 복구합니다.")
                    .setNegativeButton("취소", null)
                    .setPositiveButton("교체") { _, _ ->
                        RecordStore.replaceMonth(this@MainActivity, month, corrected)
                        clearDraft(); renderTab()
                    }.show()
            })
            addView(action("이 달 저장 기록 삭제", destructive = true) {
                AlertDialog.Builder(this@MainActivity).setTitle("${month} 기록 삭제")
                    .setMessage("선택한 월에 저장된 기록만 삭제합니다. 계속할까요?")
                    .setNegativeButton("취소", null)
                    .setPositiveButton("삭제") { _, _ ->
                        RecordStore.replaceMonth(this@MainActivity, month, emptyList())
                        clearDraft(); renderTab()
                    }.show()
            }.apply { topSpace(9) })
            addView(label("※ 식사 12:00 ~ 13:00처럼 명시된 시간만 차감합니다. 누락되면 원본에서 확인해 주세요.", 11.5f, muted).apply { topSpace(10) })
        })
    }

    private fun renderTools(root: LinearLayout) {
        root.addView(heading("가져오기", "자동 수집이 어려우면 텍스트 붙여넣기나 이미지 OCR로 읽어요.", aqua))
        root.addView(section("목록 텍스트 분석", "조회 월: ${month} · 목록의 날짜와 시간을 그대로 붙여넣으세요.").apply {
            val field = EditText(this@MainActivity).apply {
                gravity = Gravity.TOP
                minLines = 9
                maxLines = 18
                textSize = 13f
                hint = "예시\n04.29 8시간 0분\n기관확인 완료\n근무 09:00 ~ 18:00\n식사 12:00 ~ 13:00"
                background = shape(cardGray, radius = 14, stroke = border)
                setPadding(dp(12), dp(14), dp(12), dp(14))
            }
            pasteField = field
            addView(field)
            addView(action("텍스트에서 근무기록 추출", primary = true) {
                val records = AttendanceParser.fromListPage(field.text.toString(), month)
                if (records.isEmpty()) toast("근무 시각을 찾지 못했습니다. 조회 연도·월을 확인하세요")
                else {
                    RecordStore.add(this@MainActivity, records)
                    toast("${records.size}건 저장 · 기록 탭에서 확인")
                }
            }.apply { topSpace(10) })
        })
        root.addView(section("사진에서 읽기", "목록 스크린샷을 선택하면 기기 내 OCR로 분석합니다.").apply {
            addView(action("스크린샷 선택 · 한국어 OCR", primary = true) {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "image/*"
                }, openImage)
            })
            addView(chip("서버 업로드 없음", blueSoft, blueDeep).apply { topSpace(10) })
            addView(label("사진을 서버에 업로드하지 않습니다. 캡처가 차단된 화면은 우회하지 않아요.", 11.5f, muted).apply { topSpace(8) })
        })
    }

    private fun renderInfo(root: LinearLayout) {
        root.addView(heading("정보", "앱 버전과 사용 방법을 한곳에서 확인할 수 있어요.", red))
        root.addView(section("앱 정보", "현재 버전과 지원 환경입니다.").apply {
            addView(infoRow("앱 이름", "근무로그"))
            addView(infoRow("현재 버전", versionName))
            addView(infoRow("빌드 구분", "일상형 대시보드 · 자동 수집 홈 개편"))
            addView(infoRow("최소 지원", minAndroidText))
            addView(infoRow("권장 환경", targetAndroidText))
            addView(infoRow("저장 방식", "기기 내부 저장 / 서버 전송 없음"))
            addView(infoRow("핵심 기능", "자동 수집 · OCR · TXT/CSV 백업"))
        })
        root.addView(section("최신 버전 · v1.2", "현재 사용 중인 업데이트입니다.").apply {
            addView(changeLogItem("v1.2", "공식 출근부 앱 바로 열기 수정, 공식 앱 아이콘 연동, 화면 진입 애니메이션, 월 변경 시 화면 위치 유지, 생활형 카드·액션 허브"))
        })
        root.addView(section("버전 기록 · v0.6~v1.1", "최근 이전 버전 변경 내역입니다.").apply {
            addView(changeLogItem("v1.1", "Android 16 앱 시작 안정화, 주간 근무 그래프·빠른 메뉴"))
            addView(changeLogItem("v1.0", "접근성 사용 내용 공개·동의 안내 강화, 공식 출근부 앱으로 수집 범위 제한"))
            addView(changeLogItem("v0.9", "식사·휴게시간 계산 보완, 파스텔 카드와 컬러 아이콘"))
            addView(changeLogItem("v0.8", "갤럭시 하단 버튼 영역 대응, 정보 탭 추가, 화면 여백 정리"))
            addView(changeLogItem("v0.7", "연도 제한 제거, 접근성 초기 재시도 안정화"))
            addView(changeLogItem("v0.6", "자동 수집 중지 처리, OCR 인식 보완"))
        })
        root.addView(section("버전 기록 · v0.1~v0.6", "초기 버전의 변경 내역입니다.").apply {
            addView(changeLogItem("v0.6", "자동 수집 중지 처리, OCR 인식 보완"))
            addView(changeLogItem("v0.5", "목록 인식 영역 확대, 0건 인식 문제 보완"))
            addView(changeLogItem("v0.4", "TXT·CSV 저장 및 월간 편집 기능 개선"))
            addView(changeLogItem("v0.3", "이미지 OCR 보조 추가"))
            addView(changeLogItem("v0.2", "목록 파싱 안정화"))
            addView(changeLogItem("v0.1", "근무로그 첫 버전과 근무 기록 기본 기능"))
        })
        root.addView(section("개인정보 · 접근성 안내", "무엇을 읽는지 확인하고 언제든 중지할 수 있어요.").apply {
            addView(infoRow("자동 수집 대상", "한국장학재단 출근부 앱"))
            addView(infoRow("읽는 정보", "목록의 날짜·시간·식사·상태"))
            addView(infoRow("저장 및 공유", "기기 내부 저장 · 서버 전송 없음"))
            addView(infoRow("캡처 사용", "필요할 때 일시적으로 OCR"))
            addView(label("접근성 서비스를 사용하지 않아도 텍스트 붙여넣기와 스크린샷 가져오기 기능을 이용할 수 있습니다.", 12f, muted).apply { topSpace(8) })
            addView(action("접근성 권한 안내 자세히 보기") { showAccessibilityDisclosure(openSettings = false) }.apply { topSpace(11) })
        })
        root.addView(section("사용 팁", "실제 사용 시 도움이 되는 점을 정리했습니다.").apply {
            addView(changeLogItem("접근성 설정 직후", "한국장학재단 앱의 조회 → 목록 화면을 먼저 띄운 뒤 수집 버튼을 누르세요."))
            addView(changeLogItem("수집 결과 확인", "식사·휴게시간이 있는 날은 기록에 차감 내역이 표시되는지 확인하세요."))
            addView(changeLogItem("업데이트 설치 전", "기존 기록을 TXT 또는 CSV로 백업하면 안전합니다."))
        })
    }

    /** Explain that package signing and accessibility approval are separate security decisions. */
    private fun showSecurityLimitations() {
        AlertDialog.Builder(this)
            .setTitle("자동 수집 · Android 보안 안내")
            .setMessage(
                "자동 수집은 한국장학재단 출근부 앱에서 사용자가 ‘목록 수집’을 누를 때만 실행됩니다. " +
                    "목록의 근무시간을 읽고 필요 시 일시적으로 기기 내 OCR을 사용하며, 다른 앱으로 이동하면 중단합니다.\n\n" +
                    "• GitHub 서명 APK라도 Google Play 프로텍트가 설치를 차단할 수 있습니다.\n" +
                    "• 갤럭시의 ‘제한된 설정’은 Android에서 직접 승인해야 하며, 이 앱이 자동 해제할 수 없습니다.\n" +
                    "• 위험하다는 안내가 나오면 보호 기능을 끄기 전에 설치 출처와 권한을 확인하세요.\n" +
                    "• 앱 사용 중에는 떠 있는 ‘중지’를 눌러 언제든 수집을 끝낼 수 있습니다."
            )
            .setPositiveButton("확인", null)
            .show()
    }

    /** One clear, separate disclosure immediately before directing the user to Android's settings. */
    private fun showAccessibilityDisclosure(openSettings: Boolean) {
        // A previous acceptance never silently authorizes a new permissions flow.
        // Dismissing the dialog is not treated as consent.
        if (openSettings) RecordStore.setConsent(this, false)
        val disclosure = "이 앱은 한국장학재단의 공식 앱이 아닌 개인용 근무기록 도우미입니다.\n\n" +
            "• 접근 대상: 한국장학재단 출근부 앱(com.kosaf.gpsAttendance)\n" +
            "• 읽는 내용: 조회 목록에 표시된 근무 날짜, 출퇴근 시각, 식사·휴게시간, 기관 확인 상태\n" +
            "• 동작: 사용자가 ‘목록 수집’을 누른 뒤 목록을 아래로 스크롤합니다. 필요한 경우 화면을 일시적으로 캡처해 기기 내 OCR로 읽습니다.\n" +
            "• 보관: 추출한 근무기록은 이 휴대전화의 앱 내부에만 저장합니다. 화면 캡처와 로그인 정보는 파일로 저장하지 않으며 서버로 전송하지 않습니다.\n" +
            "• 사용 중지: 떠 있는 ‘중지’ 버튼이나 앱의 ‘접근성 끄기’ 버튼을 사용하세요. 완료 시 자동 해제를 요청합니다.\n\n" +
            "이 권한은 강력한 화면 접근 권한입니다. 반드시 내용을 확인한 뒤 동의해 주세요. 거절해도 텍스트·사진 가져오기 기능은 사용할 수 있습니다."
        AlertDialog.Builder(this)
            .setTitle("접근성 권한 · 수집 범위 안내")
            .setMessage(disclosure)
            .setNegativeButton(if (openSettings) "동의하지 않음" else "닫기") { _, _ ->
                if (openSettings) RecordStore.setConsent(this, false)
            }
            .setPositiveButton(if (openSettings) "동의하고 설정 열기" else "확인") { _, _ ->
                if (openSettings) {
                    RecordStore.setConsent(this, true)
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
            }
            .show()
    }

    private fun applyFields() {
        val year = yearField?.text?.toString()?.trim()?.toIntOrNull()
        val monthNumber = monthField?.text?.toString()?.trim()?.toIntOrNull()
        if (year == null || year !in 1..9999 || monthNumber == null || monthNumber !in 1..12) {
            toast("연도는 1~9999, 월은 1~12 사이의 숫자로 입력해 주세요")
            return
        }
        changeTo(YearMonth.of(year, monthNumber), preserveScroll = true)
    }

    private fun changeMonth(direction: Int) {
        val next = if (direction == 0) YearMonth.now() else runCatching { month.plusMonths(direction.toLong()) }.getOrNull()
        if (next == null || next.year !in 1..9999) {
            toast("연도는 0001~9999까지 선택할 수 있습니다")
            return
        }
        changeTo(next, preserveScroll = true)
    }

    private fun changeTo(value: YearMonth, preserveScroll: Boolean = false) {
        val scrollY = if (preserveScroll) currentScrollY() else 0
        month = value
        RecordStore.setSelectedMonth(this, value)
        clearDraft()
        showAllRows = false
        renderTab()
        if (preserveScroll) restoreScroll(scrollY)
    }

    private fun currentScrollY(): Int = (host.getChildAt(0) as? ScrollView)?.scrollY ?: 0

    private fun restoreScroll(scrollY: Int) {
        val scrollView = host.getChildAt(0) as? ScrollView ?: return
        scrollView.post { scrollView.scrollTo(0, scrollY) }
    }

    private fun monthlySummaryText(rows: List<WorkRecord> = currentRecords()): String {
        val total = rows.sumOf { it.minutes }
        val breakTotal = rows.sumOf { it.breakMinutes }
        val mismatch = rows.count { it.differentFromReported }
        return "${month.year}년 ${month.monthValue}월 근무 ${total / 60}시간 ${total % 60}분 · 휴게 차감 ${breakTotal / 60}시간 ${breakTotal % 60}분 · 확인 필요 ${mismatch}건"
    }

    private fun shareSummary() {
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, monthlySummaryText())
        }, "월간 근무 요약 공유"))
    }

    /**
     * Uses the verified official Play package (com.kosaf.gpsAttendance).
     * Package visibility is declared narrowly in AndroidManifest.xml.
     * Never request QUERY_ALL_PACKAGES or an elevated permission.
     */
    private fun openOfficialAttendanceApp() {
        val launcher = try {
            packageManager.getLaunchIntentForPackage(targetAttendancePackage)
                ?: Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_LAUNCHER)
                    setPackage(targetAttendancePackage)
                }.let { intent ->
                    val info = packageManager.resolveActivity(intent, 0)
                    if (info != null) intent else null
                }
        } catch (error: Exception) {
            Log.w("AttendanceLauncher", "Could not resolve official app", error)
            null
        }
        if (launcher != null) {
            try {
                startActivity(launcher.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            } catch (error: ActivityNotFoundException) {
                Log.w("AttendanceLauncher", "Official app is not launchable", error)
            } catch (error: SecurityException) {
                Log.w("AttendanceLauncher", "Launch restricted by device", error)
            }
        }
        AlertDialog.Builder(this)
            .setTitle("공식 출근부 앱을 열 수 없어요")
            .setMessage("한국장학재단 출근부 앱이 설치되지 않았거나, 사용 중지·보안 정책으로 실행할 수 없습니다. Play 스토어의 공식 앱 페이지를 확인할까요?")
            .setNegativeButton("닫기", null)
            .setPositiveButton("공식 앱 확인") { _, _ -> openOfficialAppStorePage() }
            .show()
    }

    private fun openOfficialAppStorePage() {
        val storeUrl = "https://play.google.com/store/apps/details?id=$targetAttendancePackage"
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$targetAttendancePackage")))
        } catch (error: ActivityNotFoundException) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(storeUrl)))
            } catch (fallbackError: Exception) {
                toast("공식 앱 페이지를 열 수 없습니다")
            }
        } catch (error: SecurityException) {
            toast("기기 정책에 따라 앱 스토어를 열 수 없습니다")
        }
    }

    private fun showOfficialAppIconOrFallback(target: ImageView, fallback: Int) {
        // Fetches the real currently installed official app icon, so the graphic
        // is accurate and no third-party trademark asset is bundled in our APK.
        try {
            target.setImageDrawable(packageManager.getApplicationIcon(targetAttendancePackage))
        } catch (error: PackageManager.NameNotFoundException) {
            target.setImageResource(fallback)
        } catch (error: Exception) {
            Log.w("AttendanceLauncher", "Official app icon unavailable", error)
            target.setImageResource(fallback)
        }
    }

    private fun <T : View> animateEntrance(view: T, delayMs: Long = 0L): T = view.apply {
        if (!ValueAnimator.areAnimatorsEnabled()) return@apply
        alpha = 0f
        translationY = dp(9).toFloat()
        scaleX = 0.985f
        scaleY = 0.985f
        post {
            animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                .setStartDelay(delayMs).setDuration(320)
                .setInterpolator(android.view.animation.DecelerateInterpolator()).start()
        }
    }

    private fun currentRecords(): List<WorkRecord> = RecordStore.read(this).filter { it.date.startsWith(month.toString()) }

    private fun saveDraft() {
        val field = exportField ?: return
        draftMonth = month
        draftText = field.text.toString()
    }

    private fun clearDraft() { draftMonth = null; draftText = null }

    private fun isAccessibilityEnabled(): Boolean {
        val component = ComponentName(this, CollectorAccessibilityService::class.java).flattenToString()
        return (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "")
            .split(":")
            .any { it.equals(component, ignoreCase = true) }
    }

    private fun createFile(request: Int, mime: String, filename: String) {
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
            putExtra(Intent.EXTRA_TITLE, filename)
        }, request)
    }

    private fun heading(title: String, subtitle: String, color: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(label(title, 26f, ink, bold = true))
        addView(label(subtitle, 12.5f, muted).apply { topSpace(5) })
        addView(View(this@MainActivity).apply { background = shape(color, radius = 100) },
            LinearLayout.LayoutParams(dp(32), dp(4)).apply { topMargin = dp(10) })
    }

    private fun recordPreview(item: WorkRecord): LinearLayout = horizontal().apply {
        gravity = Gravity.CENTER_VERTICAL
        val warning = item.differentFromReported
        val badgeColor = if (warning) amber else if (item.breakMinutes > 0) aqua else blueDeep
        val badgeBg = if (warning) amberSoft else if (item.breakMinutes > 0) greenSoft else blueSoft
        background = shape(if (warning) lemon else if (item.breakMinutes > 0) Color.parseColor("#F0FEFA") else skySoft, radius = 14, stroke = if (warning) Color.parseColor("#F5D69D") else if (item.breakMinutes > 0) Color.parseColor("#C2EBDA") else Color.parseColor("#D1E9FB"))
        setPadding(dp(11), dp(11), dp(11), dp(11))
        topSpace(7)
        addView(label(item.date.takeLast(5).replace('-', '.'), 14f, badgeColor, bold = true).apply {
            gravity = Gravity.CENTER
            background = shape(badgeBg, radius = 11)
            setPadding(dp(8), dp(10), dp(8), dp(10))
        })
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, dp(4), 0)
            addView(label("${item.start} ~ ${item.end}", 13f, ink, bold = true))
            addView(label(when {
                warning -> "⚠ 표시시간 차이 · 원본 확인"
                item.breakMinutes > 0 -> "식사 ${item.breakStart} ~ ${item.breakEnd} · ${item.breakMinutes}분 차감"
                else -> if (item.status.isBlank()) "근무 내역" else item.status
            }, 10.5f, if (warning) amber else muted).apply { topSpace(4) })
        }, LinearLayout.LayoutParams(0, -2, 1f))
        addView(label("${item.minutes / 60}h ${item.minutes % 60}m", 15f, badgeColor, bold = true).apply {
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
        })
    }

    private fun heroMetric(title: String, value: String, accent: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = gradient(intArrayOf(Color.parseColor("#273E92"), Color.parseColor("#4F3E9D")), radius = 15)
        setPadding(dp(10), dp(12), dp(8), dp(12))
        addView(label(title, 10f, Color.parseColor("#E5ECFF")))
        addView(label(value, 17f, accent, bold = true).apply { topSpace(5) })
    }

    private fun statCard(title: String, value: String, bg: Int, fg: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = gradient(intArrayOf(bg, Color.WHITE), radius = 18)
        setPadding(dp(11), dp(16), dp(9), dp(16))
        addView(label(title, 11.5f, muted, bold = true))
        addView(label(value, 18f, fg, bold = true).apply { topSpace(6) })
    }

    private fun chip(textValue: String, bg: Int, fg: Int): TextView = label(textValue, 11.5f, fg, bold = true).apply {
        background = shape(bg, radius = 100)
        setPadding(dp(10), dp(6), dp(10), dp(6))
    }

    private fun lifestyleCard(title: String, subtitle: String, drawableRes: Int, bg: Int, accent: Int, officialIcon: Boolean = false, onClick: () -> Unit): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = gradient(intArrayOf(bg, Color.WHITE), radius = 18)
        setPadding(dp(12), dp(12), dp(12), dp(12))
        addView(ImageView(this@MainActivity).apply {
            if (officialIcon) showOfficialAppIconOrFallback(this, drawableRes) else setImageResource(drawableRes)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = if (officialIcon) "한국장학재단 출근부 공식 앱 아이콘" else null
        }.also { animateEntrance(it, 60) }, LinearLayout.LayoutParams(dp(64), dp(64)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        addView(label(title, 14f, accent, bold = true).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            topSpace(8)
        })
        addView(label(subtitle, 11.5f, ink).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            topSpace(4)
        })
        addView(action("바로 열기", primary = false, onClick = onClick).apply { topSpace(10) })
    }

    private fun infoRow(title: String, value: String): LinearLayout = horizontal().apply {
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(6), 0, dp(6))
        addView(label(title, 13f, muted, bold = true), LinearLayout.LayoutParams(0, -2, 0.9f))
        addView(label(value, 13f, ink, bold = true), LinearLayout.LayoutParams(0, -2, 1.1f))
    }

    private fun changeLogItem(title: String, desc: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        setPadding(0, dp(7), 0, dp(7))
        addView(label(title, 12.5f, blueDeep, bold = true).apply {
            gravity = Gravity.CENTER
            background = shape(blueSoft, radius = 12)
            setPadding(dp(10), dp(8), dp(10), dp(8))
        })
        addView(label(desc, 12.5f, ink).apply { setPadding(dp(10), dp(4), 0, dp(4)) }, LinearLayout.LayoutParams(0, -2, 1f))
    }

    private fun fieldBox(title: String, value: String, digits: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(label(title, 12f, muted, bold = true))
        addView(EditText(this@MainActivity).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            filters = arrayOf(InputFilter.LengthFilter(digits))
            setSingleLine(true)
            setText(value)
            selectAll()
            textSize = 19f
            setTextColor(ink)
            background = shape(cardGray, radius = 12, stroke = border)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }.also { if (digits == 4) yearField = it else monthField = it })
    }

    private fun section(title: String, description: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        val accent = when {
            title.contains("기록") || title.contains("추출") -> violet
            title.contains("사진") || title.contains("수집") || title.contains("텍스트") -> aqua
            title.contains("편집") || title.contains("삭제") -> coral
            title.contains("기간") -> sky
            title.contains("사용") -> amber
            title.contains("개인정보") -> sky
            else -> violet
        }
        val paleStroke = when (accent) {
            violet -> Color.parseColor("#E5D9FE")
            aqua -> Color.parseColor("#CCEFE6")
            coral -> Color.parseColor("#FFD4E0")
            sky -> Color.parseColor("#C9E8FF")
            else -> Color.parseColor("#F9E5B9")
        }
        background = shape(Color.WHITE, radius = 23, stroke = paleStroke)
        elevation = dp(2).toFloat()
        setPadding(dp(17), dp(18), dp(17), dp(17))
        addView(horizontal().apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(View(this@MainActivity).apply { background = gradient(intArrayOf(accent, coral), radius = 20) },
                LinearLayout.LayoutParams(dp(5), dp(22)).apply { marginEnd = dp(9) })
            addView(label(title, 18f, ink, bold = true))
        })
        addView(label(description, 12f, muted).apply { topSpace(6) })
        addView(space(13))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) }
    }

    private fun step(index: String, title: String, sub: String): LinearLayout = horizontal().apply {
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(7), 0, dp(7))
        addView(label(index, 13f, blue, bold = true).apply {
            gravity = Gravity.CENTER
            background = shape(when (index) { "01" -> blueSoft; "02" -> greenSoft; else -> violetSoft }, radius = 12)
            setTextColor(when (index) { "01" -> blue; "02" -> aqua; else -> violet })
        }, LinearLayout.LayoutParams(dp(42), dp(42)))
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
            addView(label(title, 13.5f, ink, bold = true))
            addView(label(sub, 11.5f, muted).apply { topSpace(3) })
        }, LinearLayout.LayoutParams(0, -2, 1f))
    }

    private fun label(value: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        typeface = Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
        includeFontPadding = true
        setLineSpacing(dp(1).toFloat(), 1.05f)
    }

    private fun action(textValue: String, primary: Boolean = false, destructive: Boolean = false, onClick: () -> Unit): Button = Button(this).apply {
        text = textValue
        isAllCaps = false
        textSize = 13f
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        val accent = when {
            textValue.contains("접근성") || textValue.contains("OCR") || textValue.contains("권한") -> aqua
            textValue.contains("파일") || textValue.contains("복사") || textValue.contains("공유") -> violet
            textValue.contains("삭제") -> red
            textValue.contains("이전") || textValue.contains("다음") || textValue.contains("이번") -> sky
            textValue.contains("공식 앱") -> coral
            else -> blueDeep
        }
        setTextColor(when { primary -> Color.WHITE; destructive -> red; else -> accent })
        val shapeBase = when {
            primary -> when (accent) {
                aqua -> gradient(intArrayOf(Color.parseColor("#0EA7B0"), Color.parseColor("#18C4A3")), radius = 14)
                violet -> gradient(intArrayOf(violet, coral), radius = 14)
                else -> gradient(intArrayOf(blue, violet), radius = 14)
            }
            destructive -> shape(redSoft, radius = 14, stroke = Color.parseColor("#FFD2DC"))
            accent == sky -> shape(skySoft, radius = 14)
            accent == violet -> shape(violetSoft, radius = 14)
            else -> shape(blueSoft, radius = 14)
        }
        background = RippleDrawable(ColorStateList.valueOf(Color.parseColor("#44FFFFFF")), shapeBase, null)
        if (primary) elevation = dp(2).toFloat()
        minHeight = dp(48)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(48))
    }

    private fun horizontal(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    private fun space(height: Int): View = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }

    private fun <T : View> T.topSpace(dpSize: Int): T = apply {
        val params = (layoutParams as? LinearLayout.LayoutParams) ?: LinearLayout.LayoutParams(-1, -2)
        params.topMargin = dp(dpSize)
        layoutParams = params
    }

    private fun <T : View> T.withMargin(left: Int, top: Int, right: Int, bottom: Int): T = apply {
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(left), dp(top), dp(right), dp(bottom)) }
    }

    private fun shape(fill: Int, radius: Int = 16, stroke: Int = Color.TRANSPARENT): GradientDrawable = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }

    private fun gradient(colors: IntArray, radius: Int): GradientDrawable = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply {
        cornerRadius = dp(radius).toFloat()
    }

    private fun toast(message: String) { Toast.makeText(this, message, Toast.LENGTH_LONG).show() }
    private fun dp(value: Int): Int = (resources.displayMetrics.density * value).toInt()
}
