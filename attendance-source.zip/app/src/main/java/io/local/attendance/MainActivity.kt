package io.local.attendance

import android.app.Activity
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.Dialog
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.view.animation.LinearInterpolator
import android.content.ActivityNotFoundException
import android.content.pm.PackageManager
import android.net.Uri
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Rect
import android.view.MotionEvent
import android.view.inputmethod.InputMethodManager
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.drawable.Drawable
import android.os.SystemClock
import java.io.IOException
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.os.Build
import android.util.Log
import android.provider.Settings
import android.provider.CalendarContract
import java.time.format.DateTimeFormatter
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.time.YearMonth
import java.time.LocalDate
import java.time.LocalTime
import java.time.DayOfWeek
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters
import java.util.Locale

internal enum class MonthlyGoalTone { ON_TRACK, NEAR_LIMIT, EXCEEDED }

internal data class MonthlyGoalProgress(
    val goalHours: Int,
    val workedMinutes: Int,
    val goalMinutes: Int,
    val percentTenths: Int,
    val remainingMinutes: Int,
    val excessMinutes: Int,
    val tone: MonthlyGoalTone,
    val fillFraction: Float
)

/** Computes progress, remaining time, and threshold tone for an optional monthly hour cap. */
internal fun calculateMonthlyGoalProgress(workedMinutes: Int, goalHours: Int): MonthlyGoalProgress? {
    if (goalHours <= 0) return null
    val safeWorked = workedMinutes.coerceAtLeast(0)
    val goalMinutes = goalHours * 60
    val percentTenths = ((safeWorked.toLong() * 1000L + goalMinutes / 2L) / goalMinutes.toLong())
        .toInt()
        .coerceAtLeast(0)
    val tone = when {
        safeWorked > goalMinutes -> MonthlyGoalTone.EXCEEDED
        safeWorked.toLong() * 100L >= goalMinutes.toLong() * 85L -> MonthlyGoalTone.NEAR_LIMIT
        else -> MonthlyGoalTone.ON_TRACK
    }
    return MonthlyGoalProgress(
        goalHours = goalHours,
        workedMinutes = safeWorked,
        goalMinutes = goalMinutes,
        percentTenths = percentTenths,
        remainingMinutes = (goalMinutes - safeWorked).coerceAtLeast(0),
        excessMinutes = (safeWorked - goalMinutes).coerceAtLeast(0),
        tone = tone,
        fillFraction = (safeWorked.toFloat() / goalMinutes.toFloat()).coerceIn(0f, 1f)
    )
}

/** Native, dependency-light personal dashboard. No credentials or network permissions. */
class MainActivity : Activity() {
    companion object {
        const val ACTION_EDIT_PERIOD = "io.local.attendance.action.EDIT_PERIOD"
    }
    private val saveTxt = 1102
    private val saveCsv = 1103
    private val targetAttendancePackage = "com.kosaf.gpsAttendance"

    // Persisted app-wide dark/light palette; every tab uses vibrant pop-bento tokens.
    private var darkMode = false
    private var lastVisibilityRefresh = 0L
    // Multi-hue pop-pastel palette with crisp legibility in both light and dark modes.
    private val navy: Int get() = Color.parseColor(if (darkMode) "#E0E7FF" else "#161B2E")
    private val blue: Int get() = Color.parseColor(if (darkMode) "#A5B4FC" else "#5B4BFF")
    private val blueDeep: Int get() = Color.parseColor(if (darkMode) "#C4B5FD" else "#4338CA")
    private val blueSoft: Int get() = Color.parseColor(if (darkMode) "#25294A" else "#EDE9FE")
    private val violet: Int get() = Color.parseColor(if (darkMode) "#F472B6" else "#DB2777")
    private val violetSoft: Int get() = Color.parseColor(if (darkMode) "#3B1D36" else "#FCE7F3")
    private val aqua: Int get() = Color.parseColor(if (darkMode) "#34D399" else "#059669")
    private val greenSoft: Int get() = Color.parseColor(if (darkMode) "#133228" else "#DCFCE7")
    private val amber: Int get() = Color.parseColor(if (darkMode) "#FBBF24" else "#D97706")
    private val amberSoft: Int get() = Color.parseColor(if (darkMode) "#382814" else "#FEF3C7")
    private val red: Int get() = Color.parseColor(if (darkMode) "#FB7185" else "#E11D48")
    private val redSoft: Int get() = Color.parseColor(if (darkMode) "#3D1929" else "#FFE4EE")
    private val surface: Int get() = Color.parseColor(if (darkMode) "#0E1120" else "#F7F5FF")
    private val border: Int get() = Color.parseColor(if (darkMode) "#2F3654" else "#E2DCF8")
    private val ink: Int get() = Color.parseColor(if (darkMode) "#F2F4FF" else "#161B2E")
    private val muted: Int get() = Color.parseColor(if (darkMode) "#D3DEEF" else "#3F4D63")
    private val cardGray: Int get() = Color.parseColor(if (darkMode) "#181C30" else "#F3F0FF")
    private val coral: Int get() = Color.parseColor(if (darkMode) "#FB7185" else "#E11D48")
    private val coralSoft: Int get() = Color.parseColor(if (darkMode) "#3A1B2C" else "#FFE7F1")
    private val sky: Int get() = Color.parseColor(if (darkMode) "#38BDF8" else "#0284C7")
    private val skySoft: Int get() = Color.parseColor(if (darkMode) "#142B3E" else "#E0F2FE")
    private val peach: Int get() = Color.parseColor(if (darkMode) "#3B281B" else "#FFEDD5")
    private val lemon: Int get() = Color.parseColor(if (darkMode) "#3B3219" else "#FEF3C7")
    private val cardFill: Int get() = Color.parseColor(if (darkMode) "#161A2C" else "#FFFFFF")

    private lateinit var rootContainer: FrameLayout
    private lateinit var shell: LinearLayout
    private lateinit var host: FrameLayout
    private lateinit var navigation: LinearLayout
    private lateinit var topBar: LinearLayout
    private var topMonthBadge: TextView? = null
    // Avoid repeatedly rebuilding the dashboard after startup errors.
    private var startupFailed = false
    private var firstResume = true
    private var launchDrawListener: ViewTreeObserver.OnPreDrawListener? = null
    private var launchSplashOverlay: View? = null
    private var launchSplashRunnable: Runnable? = null
    private var splashSpinnerAnimator: ObjectAnimator? = null
    private var periodBackCallback: Any? = null
    // The floating date shortcut keeps the complete home dashboard visible
    // and aligns the existing date form to the scroll viewport after layout.
    private var periodEditorMode = false
    private var periodEditorSection: View? = null
    private var lastRenderedRecordsHash: Int? = null
    private var renderingTab = false
    private var lastRenderedCollectionInfoHash: Int? = null
    private var lastAccessibilityEnabled: Boolean? = null
    private var lastAccessibilityReady: Boolean? = null
    private var pendingRestoreScrollY: Int? = null
    private var activeDialog: Dialog? = null
    private var pendingFileRequest: Int? = null
    private var pendingFileContent: String? = null

    private var tab = 0
    // Zero = vertical bar chart, one = trend line graph; kept across rotations.
    private var flowDisplayMode = 0
    private var showAllRows = false
    private var settingsGuideExpanded = false
    private var settingsHelpExpanded = false
    private lateinit var month: YearMonth
    private var yearField: EditText? = null
    private var monthField: EditText? = null
    private var pasteField: EditText? = null
    private var draftMonth: YearMonth? = null
    private var draftText: String? = null
    private var draftPasteText: String? = null
    // Inline record editing: no separate Dialog/window is created when Edit is tapped.
    private var recordEditMode = false
    private var inlineRecordField: EditText? = null

    private val versionName = "v1.8"
    private val minAndroidText = "Android 8.0 이상 (API 26+)"
    private val targetAndroidText = "Android 8.0~16 지원 · Android 16 (API 36) 대응"

    override fun onCreate(savedInstanceState: Bundle?) {
        val launchStartedAt = SystemClock.uptimeMillis()
        val freshLaunch = savedInstanceState == null && !CollectionSession.isOpen(this) &&
            intent?.action == Intent.ACTION_MAIN
        // Keep the icon-based OS launch splash, then switch to the normal app theme.
        darkMode = getSharedPreferences("attendance_display", MODE_PRIVATE).getBoolean("dark_mode", false)
        setTheme(if (darkMode) R.style.AttendanceThemeDark else R.style.AttendanceTheme)
        super.onCreate(savedInstanceState)
        // Startup failures should show a minimal diagnostic screen instead of an
        // unexplained immediate close. User attendance records are never deleted.
        try {
            // Saved UI state wins over a previously consumed intent on rotation.
            periodEditorMode = savedInstanceState?.getBoolean("period_editor_mode")
                ?: (intent?.action == ACTION_EDIT_PERIOD)
            tab = savedInstanceState?.getInt("selected_tab", 0)?.coerceIn(0, 3) ?: 0
            flowDisplayMode = (savedInstanceState?.getInt("flow_display_mode")
                ?: getSharedPreferences("attendance_display", MODE_PRIVATE).getInt("flow_mode", 0)).coerceIn(0, 1)
            showAllRows = savedInstanceState?.getBoolean("show_all_rows", false) ?: false
            draftMonth = savedInstanceState?.getString("draft_month")?.let { runCatching { YearMonth.parse(it) }.getOrNull() }
            draftText = savedInstanceState?.getString("draft_text")
            recordEditMode = savedInstanceState?.getBoolean("record_edit_mode", false) ?: false
            draftPasteText = savedInstanceState?.getString("draft_paste_text")
            pendingFileRequest = savedInstanceState?.getInt("pending_file_request", -1)?.takeIf { it > 0 }
            pendingFileContent = savedInstanceState?.getString("pending_file_content")
            initializeDashboard()
            CollectionSession.open(this)
            if (freshLaunch) retainLaunchScreenUntil(launchStartedAt + 2000L)
            if (!periodEditorMode && savedInstanceState != null) {
                restoreScroll(savedInstanceState.getInt("scroll_position", 0))
            }
        } catch (error: Exception) {
            startupFailed = true
            Log.e("AttendanceStartup", "Failed to initialize the dashboard", error)
            showStartupError(error)
        }
    }

    /** Show the 2-second launch splash with a clear loading indicator underneath; never block threads or start a second Activity. */
    private fun retainLaunchScreenUntil(deadline: Long) {
        attachLaunchOverlay()
        val hideTask = Runnable { dismissLaunchSplashOverlay(immediate = false) }
        launchSplashRunnable = hideTask
        shell.postDelayed(hideTask, 2000L)
        val listener = object : ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                if (SystemClock.uptimeMillis() < deadline) return true
                if (shell.viewTreeObserver.isAlive) shell.viewTreeObserver.removeOnPreDrawListener(this)
                launchDrawListener = null
                dismissLaunchSplashOverlay(immediate = !ValueAnimator.areAnimatorsEnabled())
                return true
            }
        }
        launchDrawListener = listener
        shell.viewTreeObserver.addOnPreDrawListener(listener)
    }

    private fun attachLaunchOverlay() {
        if (!::rootContainer.isInitialized || isFinishing || isDestroyed) return
        launchSplashOverlay?.let { existing ->
            (existing.parent as? ViewGroup)?.removeView(existing)
        }
        val overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = heroMeshDrawable(0)
            setPadding(dp(28), dp(48), dp(28), dp(48))
            isClickable = true
            isFocusable = true
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS

            addView(FrameLayout(this@MainActivity).apply {
                background = shape(Color.parseColor("#24FFFFFF"), radius = 34, stroke = Color.parseColor("#44FFFFFF"))
                setPadding(dp(8), dp(8), dp(8), dp(8))
                addView(FrameLayout(this@MainActivity).apply {
                    background = shape(Color.parseColor("#3DFFFFFF"), radius = 26, stroke = Color.parseColor("#88FFFFFF"))
                    setPadding(dp(14), dp(14), dp(14), dp(14))
                    addView(ImageView(this@MainActivity).apply {
                        setImageResource(R.drawable.ic_launcher_foreground)
                        scaleType = ImageView.ScaleType.FIT_CENTER
                        contentDescription = null
                    }, FrameLayout.LayoutParams(dp(72), dp(72), Gravity.CENTER))
                }, FrameLayout.LayoutParams(-1, -1))
            }, LinearLayout.LayoutParams(dp(116), dp(116)))

            addView(label("근무로그", 30f, Color.WHITE, bold = true).apply {
                gravity = Gravity.CENTER
                topSpace(18)
            })
            addView(label("나의 근무시간과 출근 기록을 한눈에", 13.5f, Color.parseColor("#F1EEFF")).apply {
                gravity = Gravity.CENTER
                topSpace(5)
            })
            addView(chip("✦  스마트 출퇴근 · 근무시간 정리", Color.parseColor("#2EFFFFFF"), Color.WHITE).apply {
                background = shape(Color.parseColor("#2BFFFFFF"), radius = 100, stroke = Color.parseColor("#55FFFFFF"))
                topSpace(12)
            }, LinearLayout.LayoutParams(-2, -2).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                topMargin = dp(12)
            })

            // Loading window directly below the splash hero mark for immediate visual feedback.
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                background = patternedCardDrawable(
                    fill = if (darkMode) Color.parseColor("#EB161A2E") else Color.parseColor("#FAFFFFFF"),
                    stroke = Color.parseColor("#99FFFFFF"),
                    accent = violet,
                    secondary = aqua,
                    kind = PatternKind.SPARKLES,
                    radiusDp = 24
                )
                elevation = dp(8).toFloat()
                setPadding(dp(18), dp(15), dp(18), dp(13))
                addView(horizontal().apply {
                    gravity = Gravity.CENTER_VERTICAL
                    addView(ProgressBar(this@MainActivity).apply {
                        isIndeterminate = true
                        indeterminateDrawable = splashSpinnerDrawable()
                        indeterminateTintList = null
                        splashSpinnerAnimator?.cancel()
                        splashSpinnerAnimator = ObjectAnimator.ofFloat(this, View.ROTATION, 0f, 360f).apply {
                            duration = 950L
                            repeatCount = ObjectAnimator.INFINITE
                            interpolator = LinearInterpolator()
                            if (ValueAnimator.areAnimatorsEnabled()) start()
                        }
                    }, LinearLayout.LayoutParams(dp(30), dp(30)))
                    addView(LinearLayout(this@MainActivity).apply {
                        orientation = LinearLayout.VERTICAL
                        setPadding(dp(14), 0, 0, 0)
                        addView(label("앱을 불러오는 중...", 14.5f, ink, bold = true))
                        addView(label("근무기록과 달력을 준비하고 있어요", 11.5f, muted).apply { topSpace(3) })
                    }, LinearLayout.LayoutParams(0, -2, 1f))
                })
                addView(View(this@MainActivity).apply {
                    background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                        intArrayOf(blue, violet, coral, amber, aqua)).apply { cornerRadius = dp(4).toFloat() }
                }, LinearLayout.LayoutParams(-1, dp(3)).apply {
                    topMargin = dp(12)
                })
            }, LinearLayout.LayoutParams(-1, -2).apply {
                topMargin = dp(28)
                marginStart = dp(10)
                marginEnd = dp(10)
            })
        }
        launchSplashOverlay = overlay
        rootContainer.addView(overlay, FrameLayout.LayoutParams(-1, -1))
    }

    private fun dismissLaunchSplashOverlay(immediate: Boolean = false) {
        launchSplashRunnable?.let { task ->
            if (::shell.isInitialized) shell.removeCallbacks(task)
        }
        launchSplashRunnable = null
        splashSpinnerAnimator?.cancel()
        splashSpinnerAnimator = null
        val overlay = launchSplashOverlay ?: return
        launchSplashOverlay = null
        if (isFinishing || isDestroyed) {
            overlay.animate().cancel()
            runCatching { (overlay.parent as? ViewGroup)?.removeView(overlay) }
            return
        }
        if (immediate || !ValueAnimator.areAnimatorsEnabled()) {
            overlay.animate().cancel()
            runCatching { (overlay.parent as? ViewGroup)?.removeView(overlay) }
            return
        }
        overlay.animate().alpha(0f).setDuration(220L).withEndAction {
            runCatching { (overlay.parent as? ViewGroup)?.removeView(overlay) }
        }.start()
    }

    private fun initializeDashboard() {
        // Edge-to-edge is mandatory for targetSdk 36. Keep the gradient behind the
        // status bar and the bottom navigation behind gesture/three-button insets.
        // Using system-bar colors alone on Android 16 no longer protects content.
        configureSystemBars()
        month = RecordStore.selectedMonth(this)
        RecordStore.refreshDisclosureConsent(this)

        shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(surface)
            clipToPadding = false
        }
        rootContainer = FrameLayout(this).apply {
            setBackgroundColor(surface)
            addView(shell, FrameLayout.LayoutParams(-1, -1))
        }
        setContentView(rootContainer)
        shell.isFocusableInTouchMode = true
        shell.requestFocus()

        topBar = toolbar()
        shell.addView(topBar)
        host = FrameLayout(this)
        shell.addView(host, LinearLayout.LayoutParams(-1, 0, 1f))
        navigation = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = bottomNavDrawable()
            elevation = if (darkMode) dp(2).toFloat() else dp(6).toFloat()
            setPadding(dp(14), dp(6), dp(14), dp(6))
            clipToPadding = false
        }
        shell.addView(navigation, LinearLayout.LayoutParams(-1, dp(65)))

        shell.setOnApplyWindowInsetsListener { _, insets ->
            // Insets may arrive while the Activity is still being initialized.
            // Never let a transient insets issue terminate the application.
            try {
                if (::topBar.isInitialized && ::navigation.isInitialized && ::host.isInitialized) {
                    applyInsets(insets)
                }
            } catch (error: Exception) {
                Log.e("AttendanceStartup", "Could not apply window insets", error)
            }
            insets
        }
        renderTab()
        // Layout/insets are requested only after the entire view hierarchy is built.
        shell.post {
            if (!startupFailed) {
                updateSystemBarIconsSafely()
                shell.requestApplyInsets()
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putBoolean("period_editor_mode", periodEditorMode)
        outState.putInt("selected_tab", tab)
        outState.putInt("flow_display_mode", flowDisplayMode)
        outState.putBoolean("show_all_rows", showAllRows)
        outState.putInt("scroll_position", currentScrollY())
        if (tab == 1) saveDraft()
        outState.putBoolean("record_edit_mode", recordEditMode)
        // Avoid oversized Binder state from a pasted multi-page record export.
        draftText?.takeIf { it.length <= 70000 }?.let { outState.putString("draft_text", it) }
        draftMonth?.let { outState.putString("draft_month", it.toString()) }
        draftPasteText?.takeIf { it.length <= 50000 }?.let { outState.putString("draft_paste_text", it) }
        pendingFileRequest?.let { outState.putInt("pending_file_request", it) }
        pendingFileContent?.takeIf { it.length <= 70000 }?.let { outState.putString("pending_file_content", it) }
        super.onSaveInstanceState(outState)
    }

    override fun onNewIntent(newIntent: Intent) {
        super.onNewIntent(newIntent)
        setIntent(newIntent)
        if (newIntent.action != ACTION_EDIT_PERIOD) {
            // Reopening from the launcher should not trap the user in shortcut mode.
            if (newIntent.action == Intent.ACTION_MAIN && periodEditorMode) {
                periodEditorMode = false
                if (!startupFailed && ::host.isInitialized) renderTab()
            }
            return
        }
        // This intent may arrive while the Activity is already on top: singleTop.
        // Never queue a scroll on an old ScrollView that onResume will replace.
        periodEditorMode = true
        if (!startupFailed && ::host.isInitialized) {
            try {
                if (tab == 1) saveDraft()
                tab = 0
                renderTab()
                showPeriodEditorImmediately()
            } catch (error: Exception) {
                startupFailed = true
                Log.e("AttendanceNavigation", "Could not open date editor", error)
                showStartupError(error)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (!startupFailed) CollectionSession.open(this)
        if (firstResume) {
            firstResume = false
            if (periodEditorMode) showPeriodEditorImmediately()
        }
        if (!startupFailed && ::host.isInitialized) {
            try {
                if (periodEditorMode) {
                    // Keep the date editor aligned after returning from Settings.
                    if (tab != 0 || periodEditorSection == null) {
                        tab = 0
                        renderTab()
                    }
                    showPeriodEditorImmediately()
                } else if ((tab == 3 && (lastAccessibilityEnabled != isAccessibilityEnabled() ||
                        lastAccessibilityReady != CollectorAccessibilityService.isReady())) ||
                    month != RecordStore.selectedMonth(this) ||
                    lastRenderedRecordsHash != RecordStore.read(this).hashCode() ||
                    lastRenderedCollectionInfoHash != RecordStore.lastCollection(this).hashCode()) {
                    month = RecordStore.selectedMonth(this)
                    // Refresh Settings when permission state changed, or data tabs when records changed.
                    val previousY = pendingRestoreScrollY ?: currentScrollY()
                    if (tab == 1) saveDraft()
                    renderTab()
                    restoreScroll(previousY)
                }
            } catch (error: Exception) {
                startupFailed = true
                Log.e("AttendanceStartup", "Failed to resume dashboard", error)
                showStartupError(error)
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || startupFailed || !::host.isInitialized || periodEditorMode) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastVisibilityRefresh < 500L) return
        lastVisibilityRefresh = now
        if (renderingTab) return
        try {
            val currentMonth = RecordStore.selectedMonth(this)
            val currentHash = RecordStore.read(this).hashCode()
            if (month != currentMonth || lastRenderedRecordsHash != currentHash ||
                lastRenderedCollectionInfoHash != RecordStore.lastCollection(this).hashCode()) {
                if (tab == 1) saveDraft()
                val y = currentScrollY()
                month = currentMonth
                renderTab()
                restoreScroll(y)
            }
        } catch (error: Exception) {
            Log.e("AttendanceRecords", "Focus refresh failed; keeping the current screen", error)
        }
    }

    override fun onPause() {
        if (::host.isInitialized && tab == 1) saveDraft()
        super.onPause()
    }

    override fun onDestroy() {
        if (Build.VERSION.SDK_INT >= 33) {
            runCatching {
                (periodBackCallback as? android.window.OnBackInvokedCallback)?.let {
                    onBackInvokedDispatcher.unregisterOnBackInvokedCallback(it)
                }
            }
        }
        periodBackCallback = null
        launchDrawListener?.let {
            if (::shell.isInitialized && shell.viewTreeObserver.isAlive) shell.viewTreeObserver.removeOnPreDrawListener(it)
        }
        launchDrawListener = null
        launchSplashRunnable?.let { task ->
            if (::shell.isInitialized) shell.removeCallbacks(task)
        }
        launchSplashRunnable = null
        splashSpinnerAnimator?.cancel()
        splashSpinnerAnimator = null
        launchSplashOverlay?.let { overlay ->
            overlay.animate().cancel()
            runCatching { (overlay.parent as? ViewGroup)?.removeView(overlay) }
        }
        launchSplashOverlay = null
        runCatching { activeDialog?.dismiss() }
        activeDialog = null
        if (isFinishing && !isChangingConfigurations) {
            CollectionSession.close()
            CollectorAccessibilityService.onAppClosed()
        }
        super.onDestroy()
    }

    @Deprecated("Android back behavior across API levels")
    @SuppressLint("GestureBackNavigation") // API 26–32 fallback; 33+ uses the platform dispatcher below.
    override fun onBackPressed() {
        if (periodEditorMode) {
            periodEditorMode = false
            renderTab()
            return
        }
        // Back/returning from the recent-apps screen must not disable accessibility.
        super.onBackPressed()
    }

    private fun updatePeriodBackCallback() {
        if (Build.VERSION.SDK_INT < 33) return
        val current = periodBackCallback as? android.window.OnBackInvokedCallback
        if (periodEditorMode && current == null) {
            val callback = android.window.OnBackInvokedCallback {
                periodEditorMode = false
                renderTab()
            }
            onBackInvokedDispatcher.registerOnBackInvokedCallback(
                android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, callback)
            periodBackCallback = callback
        } else if (!periodEditorMode && current != null) {
            onBackInvokedDispatcher.unregisterOnBackInvokedCallback(current)
            periodBackCallback = null
        }
    }

    @Deprecated("For this small self-contained Android project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == saveTxt || requestCode == saveCsv) {
            // Capture file content BEFORE opening the system picker so a resume or
            // selected-month change never exports a different snapshot by accident.
            val snapshot = if (pendingFileRequest == requestCode) pendingFileContent else null
            pendingFileRequest = null
            pendingFileContent = null
            if (resultCode != RESULT_OK || data?.data == null) return
            try {
                val content = snapshot ?: throw IOException("저장할 파일 내용이 없습니다")
                val output = contentResolver.openOutputStream(data.data!!)
                    ?: throw IOException("저장 위치에 파일을 열 수 없습니다")
                output.use { it.write(content.toByteArray(Charsets.UTF_8)) }
                toast("파일 저장 완료")
            } catch (e: Exception) {
                Log.e("AttendanceFile", "Document write failed", e)
                toast("파일 저장 실패: ${e.localizedMessage}")
            }
            return
        }
    }

    /**
     * Avoid querying Window.getInsetsController() before the window is attached.
     * Some Android 16/OEM framework builds throw inside that platform call,
     * even when the caller uses Kotlin's null-safe operator.
     */
    @Suppress("DEPRECATION")
    private fun configureSystemBars() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
            // Do not access window.insetsController during Activity.onCreate().
        } else {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                (if (darkMode) 0 else View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR or
                    View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Three-button Samsung navigation needs a system-owned, legible region.
            // Do not obscure its controls with a completely transparent bar.
            window.isNavigationBarContrastEnforced = true
            window.isStatusBarContrastEnforced = false
        }
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
    }

    /** Optional decoration only. UI still works if the OS cannot supply a controller. */
    private fun updateSystemBarIconsSafely() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        try {
            val controller = window.decorView.windowInsetsController ?: return
            val flags = WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS or
                WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
            controller.setSystemBarsAppearance(if (darkMode) 0 else flags, flags)
        } catch (error: Exception) {
            Log.w("AttendanceStartup", "System bar icon styling skipped", error)
        }
    }

    /** Protect interactive content from notches and 3-button/gesture navigation. */
    @Suppress("DEPRECATION")
    private fun applyInsets(insets: WindowInsets) {
        val bars = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val current = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            Rect(current.left, current.top, current.right, current.bottom)
        } else Rect(insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
            insets.systemWindowInsetRight, insets.systemWindowInsetBottom)
        val tappableBottom = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            insets.getInsets(WindowInsets.Type.tappableElement()).bottom
        } else 0
        val imeBottom = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            insets.getInsets(WindowInsets.Type.ime()).bottom
        } else 0
        val top = bars.top
        val bottom = maxOf(bars.bottom, tappableBottom)
        val imeVisible = imeBottom > bottom + dp(40)
        val left = bars.left
        val right = bars.right
        val barLeft = dp(16) + left
        val barTop = dp(9) + top
        val barRight = dp(16) + right
        if (topBar.paddingLeft != barLeft || topBar.paddingTop != barTop ||
            topBar.paddingRight != barRight || topBar.paddingBottom != dp(12)) {
            topBar.setPadding(barLeft, barTop, barRight, dp(12))
        }
        val navLeft = dp(10) + left
        val navRight = dp(10) + right
        val navBottom = dp(5) + bottom
        if (navigation.paddingLeft != navLeft || navigation.paddingBottom != navBottom ||
            navigation.paddingRight != navRight) {
            navigation.setPadding(navLeft, dp(5), navRight, navBottom)
        }
        val targetNavVisibility = if (imeVisible) View.GONE else View.VISIBLE
        if (navigation.visibility != targetNavVisibility) navigation.visibility = targetNavVisibility
        val shellBottom = if (imeVisible) imeBottom else 0
        if (shell.paddingBottom != shellBottom) shell.setPadding(0, 0, 0, shellBottom)
        // Landscape and foldables can have camera cutouts on the side.
        if (host.paddingLeft != left || host.paddingRight != right) host.setPadding(left, 0, right, 0)
        val targetHeight = dp(65) + bottom
        val params = navigation.layoutParams as? LinearLayout.LayoutParams
        if (params != null && params.height != targetHeight) {
            params.height = targetHeight
            navigation.layoutParams = params
        }
        // Insets are applied to the visible controls, not to the scroll host:
        // no double padding when the system switches gesture/3-button navigation.
    }

    /** A crash-safe, native-only fallback; contains no OCR or accessibility initialization. */
    private fun showStartupError(error: Exception) {
        val diagnostic = buildString {
            append("근무로그 v1.8 / Android SDK ")
            append(Build.VERSION.SDK_INT)
            append("\n")
            append(error.javaClass.name)
            append("\n")
            error.stackTrace.firstOrNull { it.className.startsWith("io.local.attendance") }
                ?.let { append(it.className).append(":").append(it.lineNumber) }
        }
        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(surface)
            setPadding(dp(24), dp(48), dp(24), dp(24))
        }
        wrapper.addView(TextView(this).apply {
            text = "근무로그를 시작하지 못했어요"
            textSize = 22f
            setTextColor(ink)
            typeface = Typeface.DEFAULT_BOLD
        })
        wrapper.addView(TextView(this).apply {
            text = "저장된 근무기록은 삭제되지 않았습니다. 아래의 진단 정보를 복사해 개발자에게 전달해 주세요."
            textSize = 15f
            setTextColor(muted)
            setPadding(0, dp(14), 0, dp(12))
        })
        wrapper.addView(TextView(this).apply {
            text = diagnostic
            textSize = 12f
            setTextColor(muted)
        })
        wrapper.addView(Button(this).apply {
            text = "진단 정보 복사"
            isAllCaps = false
            setOnClickListener {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("근무로그 시작 오류", diagnostic))
                Toast.makeText(this@MainActivity, "진단 정보를 복사했습니다", Toast.LENGTH_SHORT).show()
            }
        })
        wrapper.addView(Button(this).apply {
            text = "다시 시작"
            isAllCaps = false
            setOnClickListener { recreate() }
        })
        setContentView(wrapper)
    }

    private fun toolbar(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        background = topBarDrawable()
        elevation = if (darkMode) 0f else dp(2).toFloat()
        setPadding(dp(16), dp(10), dp(16), dp(11))
        addView(ImageView(this@MainActivity).apply {
            setImageResource(R.mipmap.ic_launcher)
            background = gradient(intArrayOf(blueSoft, violetSoft), radius = 13).apply {
                setStroke(dp(1), adjustAlpha(violet, if (darkMode) 0.45f else 0.28f))
            }
            setPadding(dp(2), dp(2), dp(2), dp(2))
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "근무로그 앱 아이콘"
        }, LinearLayout.LayoutParams(dp(40), dp(40)))
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(11), 0, dp(8), 0)
            addView(label("근무로그", 18f, ink, bold = true))
            addView(label("나의 근무시간을 한눈에", 10.5f, muted))
        }, LinearLayout.LayoutParams(0, -2, 1f))
        val monthBadge = chip("✦ ${month.year}.${month.monthValue.toString().padStart(2, '0')}", violetSoft, violet).apply {
            background = RippleDrawable(
                ColorStateList.valueOf(adjustAlpha(violet, 0.20f)),
                gradient(intArrayOf(blueSoft, violetSoft), radius = 100).apply {
                    setStroke(dp(1), adjustAlpha(violet, if (darkMode) 0.48f else 0.30f))
                },
                null
            )
            textSize = 11.5f
            setPadding(dp(12), dp(6), dp(12), dp(6))
            isClickable = true
            isFocusable = true
            contentDescription = "조회 기간 빠른 변경"
            attachPressBounce(0.95f)
            setOnClickListener {
                if (tab == 1) saveDraft()
                periodEditorMode = true
                tab = 0
                renderTab()
                showPeriodEditorImmediately()
            }
        }
        topMonthBadge = monthBadge
        addView(monthBadge)
    }

    private fun renderTab() {
        if (!::host.isInitialized || renderingTab) return
        renderingTab = true
        try {
        if (tab == 1 && recordEditMode) saveDraft()
        host.removeAllViews()
        inlineRecordField = null
        yearField = null
        monthField = null
        periodEditorSection = null
        pasteField = null

        topMonthBadge?.text = "✦ ${month.year}.${month.monthValue.toString().padStart(2, '0')}"

        val scroll = ScrollView(this).apply {
            clipToPadding = false
            background = canvasBackgroundDrawable()
            setPadding(0, 0, 0, dp(20))
            isFillViewport = true
        }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            clipToPadding = false
        }
        scroll.addView(column, ViewGroup.LayoutParams(-1, -2))
        host.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        when (tab) {
            0 -> renderHome(column)
            1 -> try {
                renderRecords(column)
            } catch (error: Exception) {
                Log.e("AttendanceRecords", "Records screen could not be rendered", error)
                column.removeAllViews()
                column.addView(heading("기록을 표시하지 못했어요", "저장된 근무기록은 그대로 보관됩니다.", red))
                column.addView(section("화면 오류 안내", "기록을 지우거나 앱을 종료하지 않았어요.", red, PatternKind.DOTS).apply {
                    addView(label("아래 진단 내용을 복사해 오류를 알려 주세요.", 12f, ink))
                    addView(action("오류 정보 복사") {
                        val report = "기록 탭 오류: ${error.javaClass.simpleName}: ${error.message.orEmpty()}"
                        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                            .setPrimaryClip(ClipData.newPlainText("근무로그 오류", report))
                        toast("오류 정보를 복사했어요")
                    }.apply { topSpace(9) })
                    addView(action("홈으로 이동") { tab = 0; renderTab() }.apply { topSpace(8) })
                })
            }
            2 -> renderStats(column)
            else -> renderSettings(column)
        }
        renderBottomNav()
        updatePeriodBackCallback()
        lastRenderedRecordsHash = RecordStore.read(this).hashCode()
        lastRenderedCollectionInfoHash = RecordStore.lastCollection(this).hashCode()
        lastAccessibilityEnabled = isAccessibilityEnabled()
        lastAccessibilityReady = CollectorAccessibilityService.isReady()
        // Subtle entrance motion for the dashboard sections. System-level reduced
        // animations are respected, and content never depends on animation.
        // No entrance animations on records: avoid redraws while the editor is created.
        if (tab != 1 && ValueAnimator.areAnimatorsEnabled() && !periodEditorMode && pendingRestoreScrollY == null) {
            for (index in 0 until minOf(3, column.childCount)) {
                animateEntrance(column.getChildAt(index), index * 55L)
            }
        }
        } finally {
            renderingTab = false
        }
    }

    /**
     * The normal home stays visible. Align the entire period editor card to the
     * visible ScrollView viewport instead of showing an isolated date-only page.
     * A post-layout Rect accounts for margins and dynamically sized cards.
     */
    private fun showPeriodEditorImmediately() {
        if (!periodEditorMode || !::host.isInitialized || startupFailed) return
        val scroll = host.getChildAt(0) as? ScrollView ?: return
        val editor = periodEditorSection ?: return
        shell.requestFocus() // Do not unexpectedly open the keyboard.
        fun alignEditor(): Boolean {
            if (!periodEditorMode || host.getChildAt(0) !== scroll ||
                editor.parent !== scroll.getChildAt(0)) return true
            val contentH = scroll.getChildAt(0)?.height ?: 0
            if (scroll.height <= 0 || contentH <= 0) return false
            val rectangle = Rect()
            editor.getDrawingRect(rectangle)
            scroll.offsetDescendantRectToMyCoords(editor, rectangle)
            val topInset = dp(12)
            val scrollRange = (contentH - scroll.height + scroll.paddingBottom).coerceAtLeast(0)
            // Prefer top-aligning the card; at the end of a short page this clamps
            // to a safe reachable value without jumping to a blank bottom area.
            val destination = (scroll.scrollY + rectangle.top - topInset).coerceIn(0, scrollRange)
            scroll.scrollTo(0, destination)
            editor.announceForAccessibility("조회 기간 날짜 수정 영역으로 이동했습니다")
            return true
        }
        if (!alignEditor()) {
            val vto = scroll.viewTreeObserver
            val listener = object : ViewTreeObserver.OnGlobalLayoutListener {
                override fun onGlobalLayout() {
                    if (alignEditor() && scroll.viewTreeObserver.isAlive) {
                        scroll.viewTreeObserver.removeOnGlobalLayoutListener(this)
                    }
                }
            }
            if (vto.isAlive) vto.addOnGlobalLayoutListener(listener)
            scroll.post {
                if (alignEditor() && scroll.viewTreeObserver.isAlive) {
                    scroll.viewTreeObserver.removeOnGlobalLayoutListener(listener)
                }
            }
        }
    }

    private fun renderBottomNav() {
        navigation.removeAllViews()
        val tabs = listOf("홈", "기록", "통계", "설정")
        val icons = listOf(R.drawable.nav_home, R.drawable.nav_records, R.drawable.nav_stats, R.drawable.nav_settings)
        // Four distinct, high-contrast candy-pop accents with matching pastel pills.
        val accents = listOf(blue, violet, aqua, amber)
        val pastels = listOf(blueSoft, violetSoft, greenSoft, amberSoft)
        val companions = listOf(skySoft, redSoft, skySoft, coralSoft)
        tabs.forEachIndexed { i, title ->
            val active = i == tab
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                val pill = if (active) gradient(intArrayOf(pastels[i], companions[i]), radius = 20).apply {
                    setStroke(dp(1), adjustAlpha(accents[i], if (darkMode) 0.50f else 0.34f))
                } else shape(Color.TRANSPARENT, radius = 20)
                background = RippleDrawable(ColorStateList.valueOf(adjustAlpha(accents[i], 0.18f)), pill, null)
                setPadding(dp(3), dp(5), dp(3), dp(4))
                isSelected = active
                contentDescription = if (active) "$title 탭, 선택됨" else "$title 탭"
                isClickable = true
                isFocusable = true
                attachPressBounce(0.94f)
                setOnClickListener {
                    if (i != tab || periodEditorMode) {
                        if (tab == 1) saveDraft()
                        periodEditorMode = false
                        pendingRestoreScrollY = null
                        tab = i
                        renderTab()
                    }
                }
            }
            val tint = if (active) accents[i] else muted
            item.addView(ImageView(this).apply {
                setImageResource(icons[i])
                imageTintList = ColorStateList.valueOf(tint)
                contentDescription = null
            }, LinearLayout.LayoutParams(dp(20), dp(20)))
            item.addView(label(title, 11.5f, if (active) accents[i] else muted, bold = active).apply {
                gravity = Gravity.CENTER
                topSpace(2)
            })
            if (active) {
                item.addView(View(this).apply {
                    background = shape(accents[i], radius = 4)
                }, LinearLayout.LayoutParams(dp(14), dp(3)).apply { topMargin = dp(2) })
            }
            navigation.addView(item, LinearLayout.LayoutParams(0, -1, 1f).apply {
                marginStart = dp(3)
                marginEnd = dp(3)
            })
        }
    }

    private fun renderHome(root: LinearLayout) {
        // Always render the complete dashboard. The accessibility shortcut
        // scrolls to the original date editor in this same home screen.
        val rows = currentRecords()
        val total = rows.sumOf { it.minutes }
        val mismatch = rows.count { it.differentFromReported }

        val gross = rows.sumOf { it.grossMinutes }
        val deducted = rows.sumOf { it.breakMinutes }
        val displayed = rows.sumOf { it.reportedMinutes ?: it.minutes }
        val withDisplayed = rows.count { it.reportedMinutes != null }
        val goal = calculateMonthlyGoalProgress(total, monthlyGoalHours())

        val heroCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = heroMeshDrawable(28)
            elevation = if (darkMode) dp(4).toFloat() else dp(8).toFloat()
            if (Build.VERSION.SDK_INT >= 28 && !darkMode) {
                outlineAmbientShadowColor = adjustAlpha(violet, 0.35f)
                outlineSpotShadowColor = adjustAlpha(blue, 0.40f)
            }
            setPadding(dp(22), dp(20), dp(22), dp(20))
            addView(horizontal().apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(horizontal().apply {
                        gravity = Gravity.CENTER_VERTICAL
                        addView(chip("✦  MONTHLY REPORT", Color.parseColor("#2BFFFFFF"), Color.WHITE).apply {
                            background = shape(Color.parseColor("#29FFFFFF"), radius = 100, stroke = Color.parseColor("#55FFFFFF"))
                            textSize = 10f
                            setPadding(dp(9), dp(3), dp(9), dp(3))
                        }, LinearLayout.LayoutParams(-2, -2))
                        if (goal != null) {
                            val pillLabel = if (goal.tone == MonthlyGoalTone.EXCEEDED) {
                                "⚠ 초과 +${goal.excessMinutes / 60}h"
                            } else {
                                "목표 ${goal.goalHours}h · ${goal.percentTenths / 10}%"
                            }
                            addView(chip(pillLabel, Color.parseColor("#33FFFFFF"), Color.WHITE).apply {
                                background = shape(Color.parseColor("#33FFFFFF"), radius = 100, stroke = Color.parseColor("#66FFFFFF"))
                                textSize = 10f
                                setPadding(dp(8), dp(3), dp(8), dp(3))
                            }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(6) })
                        }
                    }, LinearLayout.LayoutParams(-2, -2))
                    addView(label("${month.year}년 ${month.monthValue}월의 기록", 13.5f, Color.parseColor("#F1EEFF"), true).apply { topSpace(8) })
                    addView(label("${total / 60}시간 ${total % 60}분", 32f, Color.WHITE, true).apply { topSpace(5) })
                    addView(label("휴게 차감 후 근무시간", 12f, Color.parseColor("#DFDAFF")).apply { topSpace(4) })
                }, LinearLayout.LayoutParams(0, -2, 1f))
                addView(FrameLayout(this@MainActivity).apply {
                    background = RippleDrawable(
                        ColorStateList.valueOf(Color.parseColor("#44FFFFFF")),
                        shape(Color.parseColor("#38FFFFFF"), radius = 16, stroke = Color.parseColor("#77FFFFFF")),
                        null
                    )
                    setPadding(dp(11), dp(11), dp(11), dp(11))
                    isClickable = true
                    isFocusable = true
                    contentDescription = "근무 통계 바로가기"
                    attachPressBounce(0.93f)
                    setOnClickListener { tab = 2; renderTab() }
                    addView(ImageView(this@MainActivity).apply {
                        setImageResource(R.drawable.nav_stats)
                        imageTintList = ColorStateList.valueOf(Color.WHITE)
                        scaleType = ImageView.ScaleType.FIT_CENTER
                        contentDescription = null
                    }, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
                }, LinearLayout.LayoutParams(dp(46), dp(46)))
            })
            addView(horizontal().apply {
                topSpace(16)
                addView(heroMetric("총 기록", "${rows.size}건", sky, frosted = true).apply {
                    isClickable = true; isFocusable = true
                    attachPressBounce(0.96f)
                    setOnClickListener { tab = 1; renderTab() }
                }, LinearLayout.LayoutParams(0, dp(68), 1f))
                addView(heroMetric("휴게", "${deducted / 60}h ${deducted % 60}m", aqua, frosted = true).apply {
                    isClickable = true; isFocusable = true
                    attachPressBounce(0.96f)
                    setOnClickListener { tab = 2; renderTab() }
                }, LinearLayout.LayoutParams(0, dp(68), 1f).apply { marginStart = dp(7) })
                addView(heroMetric("확인 필요", "${mismatch}건", if (mismatch > 0) amber else violet, frosted = true).apply {
                    isClickable = true; isFocusable = true
                    attachPressBounce(0.96f)
                    setOnClickListener { tab = 1; renderTab() }
                }, LinearLayout.LayoutParams(0, dp(68), 1f).apply { marginStart = dp(7) })
            })
        }.withMargin(0, 0, 0, 14)
        root.addView(heroCard)

        if (rows.isNotEmpty() && withDisplayed > 0) {
            val warning = mismatch > 0
            val bannerAccent = if (warning) amber else aqua
            val bannerCompanion = if (warning) coral else sky
            root.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = patternedCardDrawable(
                    fill = if (warning) amberSoft else greenSoft,
                    stroke = adjustAlpha(bannerAccent, if (darkMode) 0.42f else 0.28f),
                    accent = bannerAccent,
                    secondary = bannerCompanion,
                    kind = PatternKind.SPARKLES,
                    radiusDp = 20
                )
                setPadding(dp(16), dp(15), dp(16), dp(15))
                addView(label(if (warning) "!" else "✓", 16f, Color.WHITE, bold = true).apply {
                    gravity = Gravity.CENTER
                    background = gradient(intArrayOf(bannerAccent, bannerCompanion), radius = 18)
                }, LinearLayout.LayoutParams(dp(34), dp(34)).apply { marginEnd = dp(12) })
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(label(if (warning) "표시시간과 차이가 있어요" else "표시시간과 일치해요",
                        14f, bannerAccent, bold = true))
                    addView(label("목록 항목 표시시간 합계 ${displayed / 60}시간 ${displayed % 60}분  ·  계산 ${total / 60}시간 ${total % 60}분",
                        12.5f, ink).apply { topSpace(4) })
                    addView(label(if (warning)
                        "식사시간이 저장되지 않은 기존 기록일 수 있어요. 원본 목록을 다시 수집해 확인하세요."
                        else "원본에 명시된 식사·휴게시간만 차감했어요. 공식 월간 인정시간과는 별도로 대조하세요.",
                        11.5f, muted).apply { topSpace(3) })
                }, LinearLayout.LayoutParams(0, -2, 1f))
            }.withMargin(0, 0, 0, 14))
        }

        root.addView(section("빠른 실행", "자주 쓰는 기능을 한곳에서", blue, PatternKind.CONFETTI, intArrayOf(blue, violet, aqua, amber)).apply {
            val first = horizontal()
            first.addView(lifestyleCard("자동 수집", "출근부 목록 읽기", R.drawable.nav_import, blueSoft, blue, kind = PatternKind.RINGS) {
                if (isAccessibilityEnabled()) openOfficialAttendanceApp()
                else showAccessibilityDisclosure(openSettings = true)
            }, LinearLayout.LayoutParams(0, dp(72), 1f))
            first.addView(lifestyleCard("내 근무기록", "날짜별 상세 내역", R.drawable.nav_records, violetSoft, violet, kind = PatternKind.STRIPES) {
                tab = 1; renderTab()
            }, LinearLayout.LayoutParams(0, dp(72), 1f).apply { marginStart = dp(8) })
            addView(first)
            val second = horizontal().apply { topSpace(8) }
            second.addView(lifestyleCard("월간 공유", "전체 날짜·시간", R.drawable.nav_stats, greenSoft, aqua, kind = PatternKind.DOTS) {
                shareSummary()
            }, LinearLayout.LayoutParams(0, dp(72), 1f))
            second.addView(lifestyleCard("접근성 설정", "권한 바로 열기", R.drawable.nav_settings, amberSoft, amber, kind = PatternKind.SPARKLES) {
                showAccessibilityDisclosure(openSettings = true)
            }, LinearLayout.LayoutParams(0, dp(72), 1f).apply { marginStart = dp(8) })
            addView(second)
            addView(action("한국장학재단 공식 출근부 열기", primary = true, gradientColors = intArrayOf(blue, violet)) { openOfficialAttendanceApp() }
                .apply { topSpace(12); contentDescription = "한국장학재단 공식 출근부 앱 실행" })
        })
        renderMonthlyGoalCard(root, total)
        renderWeeklyChart(root, rows)

        root.addView(createPeriodEditorCard())

        root.addView(label("개인 기기 내 저장 · 공식 기관이 제공하거나 승인한 앱이 아닌 개인용 도우미", 11f, muted).apply {
            gravity = Gravity.CENTER
            topSpace(3)
        })
    }

    private fun monthlyGoalHours(): Int =
        getSharedPreferences("attendance_display", MODE_PRIVATE).getInt("monthly_goal_hours", 0).coerceIn(0, 400)

    private fun updateMonthlyGoalHours(hours: Int) {
        val safeHours = hours.coerceIn(0, 400)
        getSharedPreferences("attendance_display", MODE_PRIVATE)
            .edit()
            .putInt("monthly_goal_hours", safeHours)
            .apply()
        val scrollY = currentScrollY()
        pendingRestoreScrollY = scrollY
        renderTab()
        restoreScroll(scrollY)
    }

    private fun formatKorDuration(totalMinutes: Int): String =
        "${totalMinutes / 60}시간 ${totalMinutes % 60}분"

    private fun renderMonthlyGoalCard(root: LinearLayout, workedMinutes: Int) {
        val goal = calculateMonthlyGoalProgress(workedMinutes, monthlyGoalHours())
        val presetHours = listOf(40, 60, 80)
        if (goal == null) {
            root.addView(section(
                "월 목표 · 한도 시간",
                "이번 달 목표나 최대 인정시간을 정해 진행률을 확인해요.",
                sky,
                PatternKind.SPARKLES,
                intArrayOf(sky, aqua, violet)
            ).apply {
                addView(label("자주 쓰는 월간 기준 시간을 누르거나 직접 입력하세요.", 12.5f, muted))
                addView(horizontal().apply {
                    topSpace(10)
                    presetHours.forEachIndexed { index, hours ->
                        addView(action("${hours}시간") {
                            updateMonthlyGoalHours(hours)
                            toast("월 목표 시간을 ${hours}시간으로 설정했어요")
                        }, LinearLayout.LayoutParams(0, -2, 1f).apply {
                            if (index > 0) marginStart = dp(8)
                        })
                    }
                })
                addView(action("목표 시간 직접 입력", primary = true, gradientColors = intArrayOf(sky, blue)) {
                    showGoalHoursDialog()
                }.apply { topSpace(9) })
            })
            return
        }

        val accent: Int
        val companion: Int
        val badgeBg: Int
        val badgeText: String
        val statusLine: String
        val barColors: IntArray
        val cardPattern: PatternKind
        when (goal.tone) {
            MonthlyGoalTone.EXCEEDED -> {
                accent = red
                companion = coral
                badgeBg = redSoft
                badgeText = "⚠ 한도 초과"
                statusLine = "목표보다 +${formatKorDuration(goal.excessMinutes)} 초과했어요"
                barColors = intArrayOf(coral, red)
                cardPattern = PatternKind.STRIPES
            }
            MonthlyGoalTone.NEAR_LIMIT -> {
                accent = amber
                companion = coral
                badgeBg = amberSoft
                val reached = goal.remainingMinutes == 0
                badgeText = if (reached) "● 목표 100% 달성" else "▲ 한도 임박"
                statusLine = if (reached) {
                    "설정한 ${goal.goalHours}시간을 정확히 채웠어요"
                } else {
                    "한도까지 ${formatKorDuration(goal.remainingMinutes)} 남았어요"
                }
                barColors = intArrayOf(amber, coral)
                cardPattern = PatternKind.SPARKLES
            }
            MonthlyGoalTone.ON_TRACK -> {
                accent = aqua
                companion = sky
                badgeBg = greenSoft
                badgeText = "● 여유롭게 진행 중"
                statusLine = "목표까지 ${formatKorDuration(goal.remainingMinutes)} 남았어요"
                barColors = intArrayOf(aqua, sky)
                cardPattern = PatternKind.SPARKLES
            }
        }
        val percentText = "${goal.percentTenths / 10}.${goal.percentTenths % 10}%"

        root.addView(section(
            "월 목표 · 한도 시간",
            "설정 한도 ${goal.goalHours}시간 대비 현재 진행 현황",
            accent,
            cardPattern,
            intArrayOf(accent, companion, violet)
        ).apply {
            addView(horizontal().apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(chip(badgeText, badgeBg, accent), LinearLayout.LayoutParams(-2, -2))
                    addView(label(statusLine, 14.5f, ink, true).apply { topSpace(7) })
                }, LinearLayout.LayoutParams(0, -2, 1f))
                addView(label(percentText, 22f, accent, true).apply {
                    gravity = Gravity.END
                    setPadding(dp(8), 0, 0, 0)
                }, LinearLayout.LayoutParams(-2, -2))
            })

            addView(FrameLayout(this@MainActivity).apply {
                background = shape(
                    if (darkMode) surface else cardGray,
                    radius = 100,
                    stroke = adjustAlpha(accent, if (darkMode) 0.34f else 0.18f)
                )
                val bar = View(this@MainActivity).apply {
                    background = gradient(barColors, radius = 100)
                }
                addView(bar, FrameLayout.LayoutParams(0, -1))
                fun applyBarWidth(trackW: Int, trackH: Int) {
                    if (trackW <= 0) return
                    val targetW = (trackW * goal.fillFraction).toInt()
                        .coerceAtLeast(if (goal.workedMinutes > 0) dp(8) else 0)
                        .coerceAtMost(trackW)
                    if (bar.layoutParams.width != targetW) {
                        bar.layoutParams = FrameLayout.LayoutParams(targetW, -1)
                    }
                    if (trackH > 0) {
                        bar.measure(
                            View.MeasureSpec.makeMeasureSpec(targetW, View.MeasureSpec.EXACTLY),
                            View.MeasureSpec.makeMeasureSpec(trackH, View.MeasureSpec.EXACTLY)
                        )
                        bar.layout(0, 0, targetW, trackH)
                    }
                }
                addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ ->
                    applyBarWidth(r - l, b - t)
                }
                post { applyBarWidth(width, height) }
            }, LinearLayout.LayoutParams(-1, dp(14)).apply { topSpace(12) })

            addView(label(
                "${formatKorDuration(goal.workedMinutes)} / ${goal.goalHours}시간 0분 ($percentText)",
                12f,
                muted
            ).apply { topSpace(8) })

            addView(horizontal().apply {
                topSpace(11)
                addView(action("목표 변경") { showGoalHoursDialog() }, LinearLayout.LayoutParams(0, -2, 1f))
                addView(action("목표 해제") {
                    updateMonthlyGoalHours(0)
                    toast("월 목표 시간을 해제했어요")
                }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
            })
        })
    }

    private fun showGoalHoursDialog() {
        if (isFinishing || isDestroyed) return
        val goalDialog = Dialog(this, if (darkMode) R.style.AttendanceDialogDark else R.style.AttendanceDialogLight)
        val currentGoal = monthlyGoalHours()
        lateinit var inputBox: EditText
        lateinit var errorLabel: TextView
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = patternedCardDrawable(
                fill = cardFill,
                stroke = adjustAlpha(sky, if (darkMode) 0.42f else 0.28f),
                accent = sky,
                secondary = aqua,
                kind = PatternKind.SPARKLES,
                radiusDp = 24,
                topStripColors = intArrayOf(sky, aqua, violet)
            )
            setPadding(dp(21), dp(24), dp(21), dp(19))
            addView(horizontal().apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(label("◎", 20f, Color.WHITE, true).apply {
                    gravity = Gravity.CENTER
                    background = gradient(intArrayOf(sky, violet), radius = 16)
                }, LinearLayout.LayoutParams(dp(46), dp(46)))
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(12), 0, 0, 0)
                    addView(label("월 목표 · 한도 시간 설정", 17f, ink, true))
                    addView(label("1~400시간 사이에서 한 달 기준을 입력하세요", 11.5f, muted).apply { topSpace(3) })
                }, LinearLayout.LayoutParams(0, -2, 1f))
            })

            addView(horizontal().apply {
                topSpace(16)
                listOf(40, 60, 80).forEachIndexed { index, hours ->
                    addView(action("${hours}h") {
                        inputBox.setText(hours.toString())
                        inputBox.setSelection(inputBox.text.length)
                        errorLabel.visibility = View.GONE
                    }, LinearLayout.LayoutParams(0, -2, 1f).apply {
                        if (index > 0) marginStart = dp(8)
                    })
                }
            })

            inputBox = EditText(this@MainActivity).apply {
                hint = "예: 60"
                inputType = InputType.TYPE_CLASS_NUMBER
                filters = arrayOf(InputFilter.LengthFilter(3))
                textSize = 18f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(ink)
                setHintTextColor(muted)
                background = shape(if (darkMode) surface else cardGray, radius = 14, stroke = adjustAlpha(sky, 0.35f))
                setPadding(dp(14), dp(12), dp(14), dp(12))
                if (currentGoal > 0) {
                    setText(currentGoal.toString())
                    setSelection(text.length)
                }
            }
            addView(inputBox, LinearLayout.LayoutParams(-1, -2).apply { topSpace(12) })

            errorLabel = label("1~400 사이의 시간(정수)을 입력해 주세요.", 12f, red, true).apply {
                topSpace(8)
                visibility = View.GONE
            }
            addView(errorLabel)

            addView(horizontal().apply {
                topSpace(16)
                addView(action("닫기") { goalDialog.dismiss() }, LinearLayout.LayoutParams(0, -2, 1f))
                addView(action("적용하기", primary = true, gradientColors = intArrayOf(sky, blue)) {
                    val parsed = inputBox.text.toString().trim().toIntOrNull()
                    if (parsed == null || parsed !in 1..400) {
                        errorLabel.visibility = View.VISIBLE
                        return@action
                    }
                    goalDialog.dismiss()
                    if (activeDialog === goalDialog) activeDialog = null
                    updateMonthlyGoalHours(parsed)
                    toast("월 목표 시간을 ${parsed}시간으로 설정했어요")
                }, LinearLayout.LayoutParams(0, -2, 1.4f).apply { marginStart = dp(8) })
            })
        }
        goalDialog.setContentView(content)
        goalDialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        showSafeDialog(goalDialog)
        goalDialog.window?.decorView?.let { animateEntrance(it, 0L) }
        goalDialog.window?.setLayout(
            (resources.displayMetrics.widthPixels - dp(36)).coerceAtMost(dp(430)),
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    /** One shared form, used in-place on the home page or as the first card on direct entry. */
    private fun createPeriodEditorCard(): LinearLayout {
        val dateEditor = section("조회 기간", "원하는 연도와 월을 직접 입력해 조회할 수 있습니다.", amber, PatternKind.STRIPES, intArrayOf(amber, coral, violet)).apply {
            addView(chip("◉ 현재 선택  ${month.year}년 ${month.monthValue}월", amberSoft, amber).apply { topSpace(2) })
            val row = horizontal().apply { topSpace(9) }
            val yearBox = fieldBox("연도", month.year.toString().padStart(4, '0'), 4)
            val monthBox = fieldBox("월", month.monthValue.toString(), 2)
            row.addView(yearBox, LinearLayout.LayoutParams(0, -2, 2f))
            row.addView(monthBox, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10) })
            addView(row)
            addView(action("이 연도 · 월 적용", primary = true, gradientColors = intArrayOf(coral, amber)) { applyFields() }.apply { topSpace(10) })
            val quick = horizontal().apply { topSpace(9) }
            quick.addView(action("〈 이전 달") { changeMonth(-1) }, LinearLayout.LayoutParams(0, -2, 1f))
            quick.addView(action("이번 달") { changeMonth(0) }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
            quick.addView(action("다음 달 〉") { changeMonth(1) }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
            addView(quick)
            // Handy when opening this editor from the official app's floating menu.
            addView(action("날짜 설정 후 출근부로 돌아가기") { openOfficialAttendanceApp() }.apply { topSpace(9) })
            if (periodEditorMode) {
                addView(action("홈 맨 위로 이동") {
                    periodEditorMode = false
                    updatePeriodBackCallback()
                    (host.getChildAt(0) as? ScrollView)?.smoothScrollTo(0, 0)
                }.apply { topSpace(9) })
            }
            addView(chip("조회 가능: 2000년~2100년", blueSoft, blueDeep).apply { topSpace(10) })
            addView(label("※ 여기서 선택한 조회 월은 근무로그에만 적용됩니다. 공식 출근부 앱의 조회 월은 그 앱에서 별도로 선택하세요.", 11.5f, muted).apply { topSpace(8) })
        }
        periodEditorSection = dateEditor
        return dateEditor
    }

    /** Calendar-aligned weeks; each percentage is relative to this month's stored minutes. */
    private fun renderWeeklyChart(root: LinearLayout, rows: List<WorkRecord>) {
        val weeks = MonthlyWeekStats.weeks(month, rows)
        val monthMinutes = weeks.sumOf { it.minutes }
        val weekAccents = intArrayOf(blue, sky, aqua, violet, coral, amber)
        val weekPastels = intArrayOf(blueSoft, skySoft, greenSoft, violetSoft, coralSoft, amberSoft)
        root.addView(section("이번 달 근무 흐름", "월~일 달력 주차 · 전체 근무시간 대비 비율", violet, PatternKind.WAVES, intArrayOf(blue, sky, aqua, violet)).apply {
            val modeRow = horizontal().apply {
                gravity = Gravity.CENTER_VERTICAL
                background = shape(if (darkMode) surface else cardGray, radius = 17, stroke = border)
                setPadding(dp(4), dp(4), dp(4), dp(4))
            }
            modeRow.addView(action("차트", primary = flowDisplayMode == 0, gradientColors = intArrayOf(blue, violet)) { switchFlowMode(0) }
                .apply {
                    minHeight = dp(40)
                    if (flowDisplayMode != 0) background = shape(Color.TRANSPARENT, radius = 14)
                },
                LinearLayout.LayoutParams(0, -2, 1f))
            modeRow.addView(action("그래프", primary = flowDisplayMode == 1, gradientColors = intArrayOf(violet, coral)) { switchFlowMode(1) }
                .apply {
                    minHeight = dp(40)
                    if (flowDisplayMode != 1) background = shape(Color.TRANSPARENT, radius = 14)
                },
                LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(4) })
            addView(modeRow)
            addView(WeeklyFlowView(weeks, flowDisplayMode).apply {
                contentDescription = weeks.joinToString(", ") { w ->
                    "${w.number}주차 ${w.firstDay.monthValue}월 ${w.firstDay.dayOfMonth}일부터 ${w.lastDay.dayOfMonth}일까지 " +
                    "${w.minutes / 60}시간 ${w.minutes % 60}분 " +
                    String.format(Locale.KOREA, "%.1f퍼센트", w.sharePercent)
                }
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
                tag = "weekly_flow_display"
            }, LinearLayout.LayoutParams(-1, dp(164)).apply { topMargin = dp(8) })
            var weekIdx = 0
            weeks.chunked(2).forEach { pair ->
                addView(horizontal().apply {
                    topSpace(6)
                    pair.forEachIndexed { index, w ->
                        val ci = weekIdx % weekAccents.size
                        weekIdx++
                        val accent = weekAccents[ci]
                        val pastel = weekPastels[ci]
                        addView(LinearLayout(this@MainActivity).apply {
                            orientation = LinearLayout.VERTICAL
                            gravity = Gravity.CENTER_VERTICAL
                            background = patternedCardDrawable(
                                fill = pastel,
                                stroke = adjustAlpha(accent, if (darkMode) 0.42f else 0.25f),
                                accent = accent,
                                secondary = sky,
                                kind = PatternKind.DOTS,
                                radiusDp = 14,
                                topStripColors = intArrayOf(accent, sky)
                            )
                            setPadding(dp(11), dp(9), dp(11), dp(9))
                            addView(label("● ${w.number}주차 · ${w.firstDay.dayOfMonth}~${w.lastDay.dayOfMonth}일", 11f, accent, true))
                            addView(label("${w.minutes / 60}h ${w.minutes % 60}m  ·  " +
                                String.format(Locale.KOREA, "%.1f%%", w.sharePercent), 12.5f, ink, true).apply { topSpace(3) })
                            addView(FrameLayout(this@MainActivity).apply {
                                background = shape(adjustAlpha(accent, if (darkMode) 0.22f else 0.14f), radius = 100)
                                val fillBar = View(this@MainActivity).apply {
                                    background = gradient(intArrayOf(accent, sky), radius = 100)
                                }
                                addView(fillBar, FrameLayout.LayoutParams(0, -1))
                                fun syncBar(trackW: Int, trackH: Int) {
                                    if (trackW <= 0) return
                                    val ratio = (w.sharePercent.toFloat() / 100f).coerceIn(0f, 1f)
                                    val fw = if (w.minutes > 0) (trackW * ratio).toInt().coerceAtLeast(dp(6)).coerceAtMost(trackW) else 0
                                    if (fillBar.layoutParams.width != fw) {
                                        fillBar.layoutParams = FrameLayout.LayoutParams(fw, -1)
                                    }
                                    if (trackH > 0) {
                                        fillBar.measure(
                                            View.MeasureSpec.makeMeasureSpec(fw, View.MeasureSpec.EXACTLY),
                                            View.MeasureSpec.makeMeasureSpec(trackH, View.MeasureSpec.EXACTLY)
                                        )
                                        fillBar.layout(0, 0, fw, trackH)
                                    }
                                }
                                addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ -> syncBar(r - l, b - t) }
                                post { syncBar(width, height) }
                            }, LinearLayout.LayoutParams(-1, dp(5)).apply { topSpace(6) })
                        }, LinearLayout.LayoutParams(0, dp(74), 1f).apply {
                            if (index > 0) marginStart = dp(7)
                        })
                    }
                    if (pair.size == 1) addView(View(this@MainActivity),
                        LinearLayout.LayoutParams(0, dp(74), 1f).apply { marginStart = dp(7) })
                })
            }
            addView(label("월 합계 ${monthMinutes / 60}시간 ${monthMinutes % 60}분 · " +
                "${weeks.size}개 달력 주차${if (monthMinutes == 0) " · 기록 없음" else ""}", 11f, muted)
                .apply { topSpace(9) })
        })
    }

    private fun switchFlowMode(next: Int) {
        if (next == flowDisplayMode) return
        val y = currentScrollY()
        flowDisplayMode = next
        getSharedPreferences("attendance_display", MODE_PRIVATE).edit().putInt("flow_mode", next).apply()
        renderTab()
        restoreScroll(y)
    }

    private inner class WeeklyFlowView(private val weeks: List<CalendarWeek>, private val mode: Int): View(this@MainActivity) {
        private val labelTypeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        private val pen = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            typeface = labelTypeface
        }
        private val gridPen = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(1).toFloat()
            pathEffect = DashPathEffect(floatArrayOf(dp(4).toFloat(), dp(4).toFloat()), 0f)
        }
        private val stripePen = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            strokeCap = Paint.Cap.ROUND
            color = Color.argb(if (darkMode) 44 else 64, 255, 255, 255)
        }
        private val barGradPen = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val areaPen = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val linePath = Path()
        private val areaPath = Path()
        private val barPath = Path()
        private val barRect = RectF()
        private var cachedW = -1
        private var cachedDark = false
        private var cachedLineShader: LinearGradient? = null
        private var cachedAreaShader: LinearGradient? = null

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            if (weeks.isEmpty()) return
            val left = dp(10).toFloat()
            val right = width - dp(10).toFloat()
            val top = dp(24).toFloat()
            val bottom = height - dp(30).toFloat()
            val max = weeks.maxOf { it.minutes }.coerceAtLeast(60).toFloat()
            val popColors = intArrayOf(blue, sky, aqua, violet, coral, amber)
            gridPen.color = adjustAlpha(border, 0.85f)
            for (line in 0..2) {
                val y = top + (bottom - top) * line / 3f
                canvas.drawLine(left, y, right, y, gridPen)
            }
            pen.shader = null
            pen.style = Paint.Style.STROKE
            pen.strokeWidth = dp(1).toFloat()
            pen.color = border
            canvas.drawLine(left, bottom, right, bottom, pen)
            val step = (right - left) / weeks.size
            fun plotY(value: Int) = bottom - value.toFloat() / max * (bottom - top)
            if (mode == 0) {
                val barRadius = dp(8).toFloat()
                val stripeGap = dp(8).toFloat()
                stripePen.strokeWidth = dp(2).toFloat()
                weeks.forEachIndexed { index, w ->
                    val x = left + (index + 0.5f) * step
                    val color = popColors[index % popColors.size]
                    val nextColor = popColors[(index + 1) % popColors.size]
                    val halfW = (step * .26f).coerceAtMost(dp(18).toFloat())
                    pen.style = Paint.Style.FILL
                    pen.color = adjustAlpha(color, if (darkMode) 0.16f else 0.10f)
                    canvas.drawRoundRect(x - halfW, top, x + halfW, bottom, barRadius, barRadius, pen)
                    val peak = plotY(w.minutes)
                    val barHeight = if (w.minutes == 0) 0f else (bottom - peak).coerceAtLeast(dp(5).toFloat())
                    if (barHeight > 0) {
                        barRect.set(x - halfW, bottom - barHeight, x + halfW, bottom)
                        barPath.reset()
                        barPath.addRoundRect(barRect, barRadius, barRadius, Path.Direction.CW)
                        barGradPen.shader = LinearGradient(barRect.left, barRect.top, barRect.left, barRect.bottom,
                            intArrayOf(color, adjustAlpha(nextColor, 0.92f)), null, Shader.TileMode.CLAMP)
                        canvas.drawPath(barPath, barGradPen)
                        canvas.save()
                        canvas.clipPath(barPath)
                        var sy = barRect.top - barRect.width()
                        while (sy < barRect.bottom + barRect.width()) {
                            canvas.drawLine(barRect.left - dp(2), sy + barRect.width(), barRect.right + dp(2), sy, stripePen)
                            sy += stripeGap
                        }
                        pen.color = Color.argb(65, 255, 255, 255)
                        canvas.drawRoundRect(barRect.left + dp(3), barRect.top + dp(2), barRect.right - dp(3), barRect.top + dp(5), dp(2).toFloat(), dp(2).toFloat(), pen)
                        canvas.restore()
                    }
                }
            } else {
                if (cachedW != width || cachedDark != darkMode || cachedLineShader == null) {
                    cachedW = width
                    cachedDark = darkMode
                    cachedLineShader = LinearGradient(left, top, right, top, intArrayOf(blue, sky, aqua, violet, coral), null, Shader.TileMode.CLAMP)
                    cachedAreaShader = LinearGradient(0f, top, 0f, bottom, intArrayOf(adjustAlpha(violet, 0.30f), adjustAlpha(sky, 0.03f)), null, Shader.TileMode.CLAMP)
                }
                linePath.reset()
                areaPath.reset()
                var prevX = 0f
                var prevY = 0f
                weeks.forEachIndexed { index, w ->
                    val x = left + (index + 0.5f) * step
                    val y = plotY(w.minutes)
                    if (index == 0) {
                        linePath.moveTo(x, y)
                        areaPath.moveTo(x, bottom)
                        areaPath.lineTo(x, y)
                    } else {
                        val midX = (prevX + x) * 0.5f
                        linePath.cubicTo(midX, prevY, midX, y, x, y)
                        areaPath.cubicTo(midX, prevY, midX, y, x, y)
                    }
                    prevX = x
                    prevY = y
                    if (index == weeks.lastIndex) {
                        areaPath.lineTo(x, bottom)
                        areaPath.close()
                    }
                }
                areaPen.shader = cachedAreaShader
                canvas.drawPath(areaPath, areaPen)
                pen.style = Paint.Style.STROKE
                pen.strokeWidth = dp(3).toFloat()
                pen.shader = cachedLineShader
                canvas.drawPath(linePath, pen)
                pen.shader = null
                weeks.forEachIndexed { index, w ->
                    val x = left + (index + 0.5f) * step
                    val y = plotY(w.minutes)
                    val dotColor = popColors[index % popColors.size]
                    pen.style = Paint.Style.FILL
                    pen.color = adjustAlpha(dotColor, if (darkMode) 0.36f else 0.24f)
                    canvas.drawCircle(x, y, dp(9).toFloat(), pen)
                    pen.color = dotColor
                    canvas.drawCircle(x, y, dp(6).toFloat(), pen)
                    pen.color = if (darkMode) cardFill else Color.WHITE
                    canvas.drawCircle(x, y, dp(3).toFloat(), pen)
                }
            }
            weeks.forEachIndexed { index, w ->
                val x = left + (index + 0.5f) * step
                val accent = popColors[index % popColors.size]
                pen.style = Paint.Style.FILL
                pen.textSize = dp(10).toFloat()
                pen.textAlign = Paint.Align.CENTER
                pen.color = if (w.minutes > 0) accent else muted
                canvas.drawText("${w.number}주", x, bottom + dp(19), pen)
                val pctLabel = if (w.minutes == 0) "-" else String.format(Locale.KOREA, "%.0f%%", w.sharePercent)
                val labelY = (plotY(w.minutes) - dp(9)).coerceAtLeast(dp(12).toFloat())
                if (w.minutes > 0) {
                    val pillW = (pen.measureText(pctLabel) + dp(10)).coerceAtLeast(dp(24).toFloat())
                    val pillTop = (labelY - dp(10)).coerceAtLeast(dp(1).toFloat())
                    val pillBottom = labelY + dp(3)
                    pen.color = adjustAlpha(accent, if (darkMode) 0.26f else 0.14f)
                    canvas.drawRoundRect(x - pillW * 0.5f, pillTop, x + pillW * 0.5f, pillBottom, dp(6).toFloat(), dp(6).toFloat(), pen)
                }
                pen.color = if (w.minutes > 0) accent else muted
                canvas.drawText(pctLabel, x, labelY, pen)
            }
        }
    }

    /** A pastel diary calendar; the colors are legible in either display mode. */
    private fun renderMonthCalendar(root: LinearLayout, rows: List<WorkRecord>) {
        val daily = rows.groupBy { it.date }
        val weekNames = arrayOf("월", "화", "수", "목", "금", "토", "일")
        val today = LocalDate.now()
        val tilePastels = intArrayOf(blueSoft, skySoft, greenSoft, violetSoft, amberSoft)
        val tileAccents = intArrayOf(blue, sky, aqua, violet, amber)
        root.addView(section("근무 다이어리", "날짜마다 근무시간을 확인할 수 있어요", coral, PatternKind.CONFETTI, intArrayOf(coral, amber, aqua, sky, violet)).apply {
            val titleBar = horizontal().apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(4), 0, dp(4))
            }
            titleBar.addView(action("‹") { changeMonth(-1) }.apply {
                contentDescription = "이전 달"
                background = RippleDrawable(ColorStateList.valueOf(adjustAlpha(violet, 0.18f)),
                    shape(if (darkMode) surface else cardGray, radius = 24, stroke = border), null)
            }, LinearLayout.LayoutParams(dp(44), dp(44)))
            titleBar.addView(FrameLayout(this@MainActivity).apply {
                addView(chip("${month.year}년 ${month.monthValue}월", violetSoft, violet).apply {
                    background = gradient(intArrayOf(blueSoft, violetSoft), radius = 100).apply {
                        setStroke(dp(1), adjustAlpha(violet, if (darkMode) 0.42f else 0.25f))
                    }
                    textSize = 15f
                    setTextColor(ink)
                    setPadding(dp(18), dp(7), dp(18), dp(7))
                }, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
            }, LinearLayout.LayoutParams(0, -2, 1f))
            titleBar.addView(action("›") { changeMonth(1) }.apply {
                contentDescription = "다음 달"
                background = RippleDrawable(ColorStateList.valueOf(adjustAlpha(violet, 0.18f)),
                    shape(if (darkMode) surface else cardGray, radius = 24, stroke = border), null)
            }, LinearLayout.LayoutParams(dp(44), dp(44)))
            addView(titleBar)
            addView(horizontal().apply {
                topSpace(12)
                background = shape(if (darkMode) surface else cardGray, radius = 12)
                setPadding(dp(2), dp(2), dp(2), dp(2))
                weekNames.forEachIndexed { weekday, value ->
                    val wColor = when (weekday) { 6 -> red; 5 -> sky; else -> muted }
                    addView(label(value, 12f, wColor, bold = weekday >= 5).apply { gravity = Gravity.CENTER },
                        LinearLayout.LayoutParams(0, dp(26), 1f).apply { marginStart = if (weekday == 0) 0 else dp(4) })
                }
            })
            val offset = month.atDay(1).dayOfWeek.value - 1
            val totalCells = ((offset + month.lengthOfMonth() + 6) / 7) * 7
            for (week in 0 until totalCells / 7) {
                addView(horizontal().apply {
                    topSpace(5)
                    for (weekday in 0..6) {
                        val dayNumber = week * 7 + weekday - offset + 1
                        if (dayNumber !in 1..month.lengthOfMonth()) {
                            addView(LinearLayout(this@MainActivity).apply {
                                orientation = LinearLayout.VERTICAL
                                gravity = Gravity.CENTER
                                background = shape(
                                    adjustAlpha(cardGray, if (darkMode) 0.28f else 0.48f),
                                    radius = 14,
                                    stroke = adjustAlpha(border, if (darkMode) 0.35f else 0.55f)
                                )
                                addView(label("·", 12f, adjustAlpha(muted, 0.38f)).apply {
                                    gravity = Gravity.CENTER
                                })
                                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
                            }, LinearLayout.LayoutParams(0, dp(76), 1f).apply {
                                marginStart = if (weekday == 0) 0 else dp(4)
                            })
                            continue
                        }
                        val date = month.atDay(dayNumber)
                        val shifts = daily[date.toString()].orEmpty()
                        val workMinutes = shifts.sumOf { it.minutes }
                        val hasWork = shifts.isNotEmpty()
                        val isToday = date == today
                        val ci = (dayNumber + week) % tilePastels.size
                        val cellAccent = tileAccents[ci]
                        val cellPastel = tilePastels[ci]
                        val cell = LinearLayout(this@MainActivity).apply {
                            orientation = LinearLayout.VERTICAL
                            gravity = Gravity.CENTER
                            setMinimumHeight(dp(76))
                            val fill = if (hasWork) cellPastel else adjustAlpha(cardGray, if (darkMode) 0.55f else 0.72f)
                            val strokeColor = if (isToday) coral else if (hasWork) adjustAlpha(cellAccent, if (darkMode) 0.45f else 0.32f) else adjustAlpha(border, if (darkMode) 0.45f else 0.70f)
                            val cellShape = if (hasWork && !isToday) {
                                patternedCardDrawable(
                                    fill = fill,
                                    stroke = strokeColor,
                                    accent = cellAccent,
                                    secondary = violet,
                                    kind = PatternKind.SPARKLES,
                                    radiusDp = 14,
                                    topStripColors = intArrayOf(cellAccent, violet)
                                )
                            } else {
                                shape(fill, radius = 14, stroke = strokeColor).apply {
                                    if (isToday) setStroke(dp(2), coral)
                                }
                            }
                            background = RippleDrawable(ColorStateList.valueOf(cellPastel), cellShape, null)
                            setPadding(dp(2), dp(5), dp(2), dp(5))
                            val dayInk = if (darkMode) Color.WHITE else ink
                            val dayColor = when {
                                isToday -> coral
                                hasWork -> cellAccent
                                weekday == 6 -> red
                                weekday == 5 -> sky
                                else -> dayInk
                            }
                            addView(label("$dayNumber", 13f, dayColor, hasWork || isToday).apply {
                                gravity = Gravity.CENTER
                                includeFontPadding = false
                            })
                            if (hasWork) {
                                addView(label("${workMinutes / 60}h", 11.5f, cellAccent, true).apply {
                                    gravity = Gravity.CENTER; topSpace(3); setSingleLine(true); includeFontPadding = false
                                })
                                addView(label("${workMinutes % 60}m", 10f, muted).apply {
                                    gravity = Gravity.CENTER; setSingleLine(true); includeFontPadding = false
                                })
                            }
                            isClickable = true
                            isFocusable = true
                            contentDescription = "${date.year}년 ${date.monthValue}월 ${date.dayOfMonth}일, " +
                                if (hasWork) "근무 ${shifts.size}건, ${workMinutes / 60}시간 ${workMinutes % 60}분" else "근무 기록 없음"
                            setOnClickListener { showCalendarDay(date, shifts) }
                        }
                        addView(cell, LinearLayout.LayoutParams(0, dp(76), 1f).apply {
                            marginStart = if (weekday == 0) 0 else dp(4)
                        })
                    }
                })
            }
            addView(label("알록달록 칸은 근무한 날 · 굵은 테두리는 오늘 · 날짜를 눌러 캘린더에 추가", 12f, muted).apply { topSpace(12) })
        })
    }

    private fun showCalendarDay(date: LocalDate, shifts: List<WorkRecord>) {
        if (isFinishing || isDestroyed) return
        val title = "${date.year}년 ${date.monthValue}월 ${date.dayOfMonth}일"
        if (shifts.isEmpty()) {
            appDialog().setTitle(title).setMessage("이 날짜에 저장된 근무기록이 없습니다.")
                .setPositiveButton("확인", null).show()
            return
        }
        val items = shifts.map { row ->
            "${row.start} ~ ${row.end} · ${row.minutes / 60}시간 ${row.minutes % 60}분" +
                if (row.breakMinutes > 0) " (휴게 ${row.breakMinutes}분)" else ""
        }.toTypedArray()
        // AlertDialog cannot reliably show setMessage and setItems together:
        // the message wins on many Android builds and hides the selectable shifts.
        if (shifts.size == 1) {
            addToDeviceCalendar(shifts.first())
        } else {
            appDialog().setTitle("$title · 근무를 선택하세요")
                .setItems(items) { _, index -> addToDeviceCalendar(shifts[index]) }
                .setNegativeButton("닫기", null).show()
        }
    }

    /** Calendar insert intent: works with compatible Samsung/Android calendar apps without calendar permissions. */
    private fun addToDeviceCalendar(row: WorkRecord) {
        try {
            val date = LocalDate.parse(row.date)
            if (date.year !in MonthlyWeekStats.FIRST_YEAR..MonthlyWeekStats.LAST_YEAR) {
                showDateRangeWarning("캘린더에 추가할 날짜가 허용 범위를 벗어났습니다.")
                return
            }
            // Overnight shifts end the following day; never create a reversed calendar event.
            val startTime = LocalTime.parse(row.start)
            val finishTime = LocalTime.parse(row.end)
            val finishDate = if (!finishTime.isAfter(startTime)) date.plusDays(1) else date
            if (finishDate.year > MonthlyWeekStats.LAST_YEAR) {
                showDateRangeWarning("퇴근 시간이 허용된 마지막 날짜(2100-12-31)를 넘습니다.")
                return
            }
            val start = date.atTime(startTime).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
            val end = finishDate.atTime(finishTime).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
            val intent = Intent(Intent.ACTION_INSERT).apply {
                data = CalendarContract.Events.CONTENT_URI
                putExtra(CalendarContract.Events.TITLE, "근무로그 · 근무")
                putExtra(CalendarContract.Events.DESCRIPTION, "근무로그에서 내보낸 기록. " +
                    "근무 ${row.minutes / 60}시간 ${row.minutes % 60}분, 휴게 ${row.breakMinutes}분")
                putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start)
                putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end)
            }
            // Use an INSERT-capable calendar activity, not a generic calendar
            // launcher (which may open only the calendar home screen).
            try {
                // Start the actual INSERT activity, not the app launcher.
                // Some Android 11+ devices falsely return null from resolveActivity
                // due to package visibility even when a calendar editor is present.
                startActivity(intent)
            } catch (error: ActivityNotFoundException) {
                Log.w("AttendanceCalendar", "No calendar event editor installed", error)
                offerCalendarWebFallback(row, start, end)
            }
        } catch (error: Exception) {
            Log.w("AttendanceCalendar", "Calendar event editor unavailable", error)
            toast("캘린더 입력 화면을 열지 못했습니다")
        }
    }

    private fun offerCalendarWebFallback(row: WorkRecord, start: Long, end: Long) {
        if (isFinishing || isDestroyed) return
        appDialog().setTitle("일정 입력 앱을 찾지 못했어요")
            .setMessage("기기에 일정 추가 기능이 있는 캘린더가 없습니다. Google 캘린더 웹에서 새 일정을 작성할까요? 외부 웹사이트가 열립니다.")
            .setNegativeButton("취소", null)
            .setPositiveButton("웹에서 입력") { _, _ ->
                try {
                    val utc = DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss'Z'")
                        .withZone(java.time.ZoneOffset.UTC)
                    val uri = Uri.parse("https://calendar.google.com/calendar/render").buildUpon()
                        .appendQueryParameter("action", "TEMPLATE")
                        .appendQueryParameter("text", "근무")
                        .appendQueryParameter("dates", "${utc.format(java.time.Instant.ofEpochMilli(start))}/${utc.format(java.time.Instant.ofEpochMilli(end))}")
                        .appendQueryParameter("details", "근무 ${row.minutes / 60}시간 ${row.minutes % 60}분 · 휴게 ${row.breakMinutes}분")
                        .build()
                    startActivity(Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE))
                } catch (error: Exception) {
                    Log.e("AttendanceCalendar", "Could not open calendar web editor", error)
                    toast("웹 캘린더를 열 수 없습니다")
                }
            }.show()
    }

    /** Keep the records page small and predictable. Optional actions are tucked away. */
    private fun renderRecords(root: LinearLayout) {
        val items = currentRecords()
        val totalMinutes = items.sumOf { it.minutes }
        val restMinutes = items.sumOf { it.breakMinutes }
        root.addView(heading("근무기록", "${month.year}년 ${month.monthValue}월 · ${items.size}건", violet))
        root.addView(horizontal().apply {
            topSpace(12)
            addView(statCard("계산 근무", "${totalMinutes / 60}h ${totalMinutes % 60}m", skySoft, sky, PatternKind.RINGS),
                LinearLayout.LayoutParams(0, dp(88), 1f))
            addView(statCard("휴게 차감", "${restMinutes / 60}h ${restMinutes % 60}m", greenSoft, aqua, PatternKind.DOTS),
                LinearLayout.LayoutParams(0, dp(88), 1f).apply { marginStart = dp(8) })
        }.withMargin(0, 0, 0, 12))

        root.addView(section("텍스트 붙여넣기", "공식 출근부의 목록을 복사해 붙여넣을 수 있어요.", violet, PatternKind.DOTS, intArrayOf(violet, coral)).apply {
            val field = EditText(this@MainActivity).apply {
                minLines = 2; maxLines = 6; gravity = Gravity.TOP
                textSize = 13f; setTextColor(ink); setHintTextColor(muted)
                hint = "예: 11.05 근무 09:00 ~ 18:00"
                background = shape(if (darkMode) surface else cardGray, radius = 14, stroke = adjustAlpha(violet, 0.25f))
                setPadding(dp(12), dp(11), dp(12), dp(11))
                setText(draftPasteText.orEmpty())
                var lastTouchY = 0f
                setOnTouchListener { view, event ->
                    when (event.actionMasked) {
                        MotionEvent.ACTION_DOWN -> {
                            lastTouchY = event.y
                            view.parent?.requestDisallowInterceptTouchEvent(
                                view.canScrollVertically(-1) || view.canScrollVertically(1)
                            )
                        }
                        MotionEvent.ACTION_MOVE -> {
                            val dy = event.y - lastTouchY
                            lastTouchY = event.y
                            if (dy != 0f) {
                                view.parent?.requestDisallowInterceptTouchEvent(
                                    view.canScrollVertically(if (dy > 0f) -1 else 1)
                                )
                            }
                        }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                            view.parent?.requestDisallowInterceptTouchEvent(false)
                    }
                    false
                }
            }
            pasteField = field
            addView(field)
            addView(action("기록 추가", primary = true, gradientColors = intArrayOf(violet, blue)) {
                val rawPaste = field.text.toString()
                if (rawPaste.isBlank()) {
                    toast("붙여넣을 텍스트를 먼저 입력해 주세요")
                    return@action
                }
                val parsed = AttendanceParser.fromListPage(rawPaste, month)
                if (parsed.isEmpty()) toast("날짜와 근무시간을 확인해 주세요")
                else if (RecordStore.add(this@MainActivity, parsed)) {
                    draftPasteText = null
                    (getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager)
                        ?.hideSoftInputFromWindow(field.windowToken, 0)
                    renderTab()
                    val firstParsedMonth = parsed.firstOrNull()?.date?.take(7)
                    val note = if (firstParsedMonth != null && parsed.none { it.date.startsWith(month.toString()) })
                        " · ${firstParsedMonth} 기록으로 저장" else ""
                    toast("${parsed.size}건을 확인했어요$note")
                } else toast("저장에 실패했어요 · 기존 기록은 유지됩니다")
            }.apply { topSpace(9) })
        })

        // V1.7: the exported text is edited IN PLACE. No dialog or second window.
        // A dedicated, draggable scroll rail keeps the export navigable in both modes.
        root.addView(section("추출 결과 · 복사", "저장된 내역을 복사하거나 이 자리에서 수정하세요.", sky, PatternKind.RINGS, intArrayOf(sky, blue, aqua)).apply {
            val snapshot = AttendanceParser.export(items, month)
            val textHost = FrameLayout(this@MainActivity)
            val preview = TextView(this@MainActivity).apply {
                text = snapshot
                textSize = 14.5f
                minHeight = dp(248)
                typeface = Typeface.create("sans-serif", Typeface.NORMAL)
                setTextColor(ink)
                setLineSpacing(dp(4).toFloat(), 1.12f)
                setPadding(dp(12), dp(13), dp(8), dp(13))
            }
            textHost.addView(preview, FrameLayout.LayoutParams(-1, -2))
            val textScroll = ScrollView(this@MainActivity).apply {
                isFillViewport = false
                isVerticalScrollBarEnabled = false // Replaced by a visible themed rail.
                isSmoothScrollingEnabled = true
                background = shape(if (darkMode) surface else cardGray, radius = 14, stroke = adjustAlpha(sky, 0.28f))
                addView(textHost, FrameLayout.LayoutParams(-1, -2))
                var lastTouchY = 0f
                setOnTouchListener { view, event ->
                    when (event.actionMasked) {
                        MotionEvent.ACTION_DOWN -> {
                            lastTouchY = event.y
                            view.parent?.requestDisallowInterceptTouchEvent(
                                view.canScrollVertically(-1) || view.canScrollVertically(1)
                            )
                        }
                        MotionEvent.ACTION_MOVE -> {
                            val dy = event.y - lastTouchY
                            lastTouchY = event.y
                            if (dy != 0f) {
                                view.parent?.requestDisallowInterceptTouchEvent(
                                    view.canScrollVertically(if (dy > 0f) -1 else 1)
                                )
                            }
                        }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                            view.parent?.requestDisallowInterceptTouchEvent(false)
                    }
                    false
                }
            }
            addView(horizontal().apply {
                addView(textScroll, LinearLayout.LayoutParams(0, dp(258), 1f))
                addView(recordScrollRail(textScroll), LinearLayout.LayoutParams(dp(30), dp(258)).apply {
                    marginStart = dp(5)
                })
            })

            val toolbar = horizontal().apply { topSpace(10) }
            val left = action("전체 복사") { }
            val right = action("수정하기", primary = true) { }
            toolbar.addView(left, LinearLayout.LayoutParams(0, -2, 1f))
            toolbar.addView(right, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
            addView(toolbar)
            addView(label("수정하기를 누른 뒤 텍스트를 터치하면 커서로 바로 편집할 수 있어요.", 12f, muted)
                .apply { topSpace(7) })

            fun closeInlineEdit(discard: Boolean) {
                if (discard) {
                    draftMonth = null
                    draftText = null
                } else {
                    inlineRecordField?.let {
                        draftMonth = month
                        draftText = it.text?.toString().orEmpty()
                    }
                }
                recordEditMode = false
                inlineRecordField?.let { field ->
                    (getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager)
                        ?.hideSoftInputFromWindow(field.windowToken, 0)
                }
                inlineRecordField = null
                textHost.removeAllViews()
                preview.text = snapshot
                textHost.addView(preview, FrameLayout.LayoutParams(-1, -2))
                left.text = "전체 복사"
                right.text = "수정하기"
            }

            fun startInlineEdit(openKeyboard: Boolean = true) {
                val content = if (draftMonth == month) draftText ?: snapshot else snapshot
                val field = EditText(this@MainActivity).apply {
                    gravity = Gravity.TOP or Gravity.START
                    minHeight = dp(248)
                    textSize = 14.5f
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                        InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                    typeface = Typeface.create("sans-serif", Typeface.NORMAL)
                    setTextColor(ink)
                    setHintTextColor(muted)
                    setSelectAllOnFocus(false)
                    setHorizontallyScrolling(false)
                    isVerticalScrollBarEnabled = false
                    background = null
                    setLineSpacing(dp(4).toFloat(), 1.12f)
                    setPadding(dp(12), dp(13), dp(8), dp(13))
                    setText(content)
                    setSelection(0)
                    contentDescription = "근무기록 편집 텍스트"
                }
                // Create only one editor, on user request, in the current text region.
                textHost.removeAllViews()
                textHost.addView(field, FrameLayout.LayoutParams(-1, -2))
                inlineRecordField = field
                recordEditMode = true
                draftMonth = month
                draftText = content
                left.text = "취소"
                right.text = "수정 저장"
                if (openKeyboard) field.post {
                    if (recordEditMode && inlineRecordField === field && field.isAttachedToWindow) {
                        field.requestFocus()
                        (getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager)
                            ?.showSoftInput(field, InputMethodManager.SHOW_IMPLICIT)
                    }
                }
            }

            left.setOnClickListener {
                try {
                    if (recordEditMode) closeInlineEdit(discard = true)
                    else {
                        copyText("근무기록", snapshot)
                        toast("근무기록을 복사했어요")
                    }
                } catch (error: Exception) {
                    Log.e("AttendanceRecords", "Copy/cancel failed", error)
                    toast("작업을 완료하지 못했어요")
                }
            }
            right.setOnClickListener {
                try {
                    if (!recordEditMode) startInlineEdit()
                    else {
                        val field = inlineRecordField
                        if (field == null) toast("편집 영역을 찾지 못했어요")
                        else {
                            draftMonth = month
                            draftText = field.text?.toString().orEmpty()
                            saveEditedRecords(draftText.orEmpty())
                        }
                    }
                } catch (error: Exception) {
                    Log.e("AttendanceRecords", "Inline record edit failed", error)
                    toast("편집 작업을 처리하지 못했어요. 기록은 그대로 보관됩니다.")
                }
            }
            if (recordEditMode && draftMonth == month) {
                // Restore the inline editor after a rotation or records refresh.
                startInlineEdit(openKeyboard = false)
            } else {
                recordEditMode = false
            }
            val extraActions = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                visibility = View.GONE
                addView(horizontal().apply {
                    topSpace(9)
                    addView(action("TXT 저장") { createFile(saveTxt, "text/plain", "근무기록_${month}.txt") },
                        LinearLayout.LayoutParams(0, -2, 1f))
                    addView(action("CSV 저장") { createFile(saveCsv, "text/csv", "근무기록_${month}.csv") },
                        LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
                })
                addView(action("이 달 기록 삭제", destructive = true) {
                    val d = appDialog().setTitle("${month} 기록 삭제")
                        .setMessage("이 달의 기록만 삭제합니다. 앱을 종료하기 전까지 기록 관리에서 마지막 변경을 한 번 되돌릴 수 있어요.")
                        .setNegativeButton("취소", null)
                        .setPositiveButton("삭제") { _, _ ->
                            if (RecordStore.replaceMonth(this@MainActivity, month, emptyList())) {
                                clearDraft(); renderTab(); toast("선택한 달의 기록을 삭제했어요")
                            } else toast("삭제에 실패했어요. 기존 기록을 유지했습니다")
                        }.show()
                    activeDialog = d
                }.apply { topSpace(8) })
                if (RecordStore.undoMonth() == month) {
                    addView(action("마지막 변경 되돌리기") {
                        val d = appDialog().setTitle("${month} 변경 되돌리기")
                            .setMessage("마지막 수정 또는 삭제 직전으로 이 달의 기록을 복원할까요? 다른 달은 유지됩니다.")
                            .setNegativeButton("취소", null)
                            .setPositiveButton("되돌리기") { _, _ ->
                                when (RecordStore.undoLastChange(this@MainActivity)) {
                                    RecordStore.UndoResult.RESTORED -> { clearDraft(); renderTab(); toast("마지막 변경을 되돌렸어요") }
                                    RecordStore.UndoResult.RECORDS_CHANGED -> { renderTab(); toast("이후 수집·추가된 기록이 있어 되돌리지 않았어요") }
                                    RecordStore.UndoResult.SAVE_FAILED -> toast("복원에 실패했어요. 현재 기록을 유지했습니다")
                                    RecordStore.UndoResult.UNAVAILABLE -> { renderTab(); toast("되돌릴 변경이 없어요") }
                                }
                            }.show()
                        activeDialog = d
                    }.apply { topSpace(8) })
                    addView(label("직접 수정·삭제한 마지막 1회만 복원해요. 앱을 종료하면 복원 내용은 사라져요.", 12f, muted).apply { topSpace(8) })
                }
            }
            addView(action("내보내기 · 기록 관리  ⌄") {
                extraActions.visibility = if (extraActions.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            }.apply { topSpace(9) })
            addView(extraActions)
            addView(label("※ 계산 시간은 공식 인정시간과 다를 수 있어요.", 12f, muted).apply { topSpace(9) })
        })
        if (items.isNotEmpty()) {
            root.addView(section("최근 기록", "일자별 근무 내용을 확인해요", aqua, PatternKind.DOTS, intArrayOf(aqua, sky)).apply {
                val sorted = items.sortedWith(compareByDescending<WorkRecord> { it.date }.thenBy { it.start })
                // A month can contain many imported rows. Never inflate an
                // unbounded number of nested cards in a single main-thread frame.
                (if (showAllRows) sorted.take(50) else sorted.take(5)).forEach { addView(recordPreview(it)) }
                if (showAllRows && sorted.size > 50) {
                    addView(label("나머지 ${sorted.size - 50}건은 추출 결과 · 편집에서 볼 수 있어요.", 11.5f, muted)
                        .apply { topSpace(8) })
                }
                if (sorted.size > 5) addView(action(if (showAllRows) "목록 접기" else "기록 더 보기") {
                    saveDraft()
                    showAllRows = !showAllRows
                    renderTab()
                }.apply { topSpace(9) })
            })
        }

    }

    /** Classic 2009-style, theme-independent silver scrollbar.
     *  The visible rail is 20dp; its 30dp touch region improves thumb dragging.
     *  Thumb position maps to the FULL content range, even for long records.
     */
    private fun recordScrollRail(scroll: ScrollView): LinearLayout {
        // Fixed silver palette: no dark-mode or wallpaper-dependent colors.
        val edge = Color.parseColor("#A1A1A4")
        val darkEdge = Color.parseColor("#77777B")
        val arrowInk = Color.parseColor("#505052")
        fun silver(top: String, bottom: String, outline: Int, radiusDp: Int): GradientDrawable =
            GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.parseColor(top), Color.parseColor(bottom))).apply {
                cornerRadius = dp(radiusDp).toFloat()
                setStroke(dp(1), outline)
            }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            contentDescription = "근무기록 스크롤 컨트롤"
        }
        fun moveBy(direction: Int) {
            scroll.smoothScrollBy(0, direction * (scroll.height * 0.85f).toInt().coerceAtLeast(dp(75)))
        }
        fun arrow(symbol: String, direction: Int): FrameLayout {
            val button = FrameLayout(this).apply {
                isClickable = true
                isFocusable = true
                contentDescription = if (direction < 0) "근무기록 위로 이동" else "근무기록 아래로 이동"
                setOnClickListener { moveBy(direction) }
            }
            val face = TextView(this).apply {
                text = symbol
                textSize = 11f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(arrowInk)
                gravity = Gravity.CENTER
                background = silver("#F9F9FA", "#DDDDDF", edge, 2)
                // The parent is the full tap target; the face only draws the classic arrow.
                isClickable = false
            }
            button.addView(face, FrameLayout.LayoutParams(dp(20), -1, Gravity.CENTER))
            return button
        }
        bar.addView(arrow("▲", -1), LinearLayout.LayoutParams(dp(30), dp(25)))

        // The track is wider to grab than it looks; only the center 20dp is drawn.
        val track = FrameLayout(this).apply {
            isClickable = true
            contentDescription = "스크롤 손잡이를 위아래로 드래그"
        }
        val channel = View(this).apply {
            background = silver("#F4F4F5", "#E9E9EA", Color.parseColor("#C9C9CB"), 0)
        }
        track.addView(channel, FrameLayout.LayoutParams(dp(20), -1, Gravity.CENTER_HORIZONTAL))
        val knob = FrameLayout(this).apply {
            background = silver("#F8F8F8", "#C5C5C8", darkEdge, 3)
            elevation = dp(1).toFloat()
        }
        // The classic three-grip-line decoration remains noninteractive.
        knob.addView(TextView(this).apply {
            text = "≡"
            textSize = 17f
            setTextColor(arrowInk)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            includeFontPadding = false
            isClickable = false
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }, FrameLayout.LayoutParams(-1, -1))
        track.addView(knob, FrameLayout.LayoutParams(dp(18), dp(40), Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        bar.addView(track, LinearLayout.LayoutParams(dp(30), 0, 1f))
        bar.addView(arrow("▼", 1), LinearLayout.LayoutParams(dp(30), dp(25)))

        fun maxScrollY(): Int {
            val contentHeight = scroll.getChildAt(0)?.height ?: 0
            val viewport = (scroll.height - scroll.paddingTop - scroll.paddingBottom).coerceAtLeast(0)
            return (contentHeight - viewport).coerceAtLeast(0)
        }
        fun updateKnob() {
            val height = track.height
            if (height <= 0) return
            val range = maxScrollY()
            val viewport = (scroll.height - scroll.paddingTop - scroll.paddingBottom).coerceAtLeast(1)
            val contentHeight = viewport + range
            val minThumb = dp(26).coerceAtMost(height)
            val maxThumb = dp(47).coerceAtMost(height)
            val proportional = (height.toFloat() * viewport / contentHeight).toInt()
            val thumbHeight = proportional.coerceIn(minThumb, maxThumb)
            val params = knob.layoutParams as FrameLayout.LayoutParams
            if (params.height != thumbHeight) {
                params.height = thumbHeight
                knob.layoutParams = params
            }
            val travel = (height - thumbHeight).coerceAtLeast(0)
            val progress = if (range == 0) 0f else scroll.scrollY.toFloat() / range
            knob.translationY = travel * progress.coerceIn(0f, 1f)
            // No movement is possible when there is not enough content to scroll.
            knob.alpha = if (range == 0) 0.62f else 1f
        }
        scroll.setOnScrollChangeListener { _, _, _, _, _ -> updateKnob() }
        scroll.getChildAt(0)?.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> updateKnob() }
        scroll.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> updateKnob() }
        track.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> updateKnob() }

        var grabOffset = 0f
        var isDragging = false
        track.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.parent?.requestDisallowInterceptTouchEvent(true)
                    bar.parent?.requestDisallowInterceptTouchEvent(true)
                    scroll.fling(0) // Stop kinetic scrolling before precise thumb positioning.
                    val thumbTop = knob.translationY
                    grabOffset = if (event.y >= thumbTop && event.y <= thumbTop + knob.height) {
                        event.y - thumbTop
                    } else {
                        knob.height / 2f
                    }
                    isDragging = true
                    if (maxScrollY() > 0) {
                        val travel = (track.height - knob.height).coerceAtLeast(1)
                        val progress = ((event.y - grabOffset) / travel).coerceIn(0f, 1f)
                        scroll.scrollTo(0, (progress * maxScrollY()).toInt())
                    }
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (isDragging) {
                        val range = maxScrollY()
                        if (range > 0) {
                            val travel = (track.height - knob.height).coerceAtLeast(1)
                            val progress = ((event.y - grabOffset) / travel).coerceIn(0f, 1f)
                            scroll.scrollTo(0, (progress * range).toInt())
                        }
                        updateKnob()
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    isDragging = false
                    view.parent?.requestDisallowInterceptTouchEvent(false)
                    bar.parent?.requestDisallowInterceptTouchEvent(false)
                    true
                }
                else -> false
            }
        }
        track.post { updateKnob() }
        return bar
    }

    /** Replacing a month always requires a user confirmation and preserves data on failure. */
    private fun saveEditedRecords(text: String, onSaved: (() -> Unit)? = null) {
        val dateLines = Regex("(?m)^\\s*(\\d{4})[-./](\\d{1,2})[-./](\\d{1,2})(?=\\s|$)")
        val invalid = dateLines.findAll(text).firstOrNull { match ->
            val y = match.groupValues[1].toIntOrNull()
            val m = match.groupValues[2].toIntOrNull()
            val d = match.groupValues[3].toIntOrNull()
            y == null || m == null || d == null ||
                y !in MonthlyWeekStats.FIRST_YEAR..MonthlyWeekStats.LAST_YEAR ||
                runCatching { LocalDate.of(y, m, d) }.isFailure
        }
        if (invalid != null) {
            showDateRangeWarning("잘못된 날짜: ${invalid.value.trim()}")
            return
        }
        val corrected = AttendanceParser.fromEditableText(text, month)
        if (corrected.isEmpty()) {
            toast("YYYY-MM-DD 09:00 ~ 11:00 형식을 확인해 주세요")
            return
        }
        val otherMonthCount = corrected.count { !it.date.startsWith(month.toString()) }
        val message = if (otherMonthCount > 0) {
            "참고: 선택한 달(${month})과 다른 날짜가 ${otherMonthCount}건 포함되어 있어 해당 월로 저장됩니다.\n\n이 달 기록을 수정한 ${corrected.size}건으로 교체할까요?"
        } else {
            "이 달 기록을 수정한 ${corrected.size}건으로 교체할까요?"
        }
        activeDialog?.dismiss()
        activeDialog = appDialog().setTitle("${month} 기록 저장")
            .setMessage(message)
            .setNegativeButton("취소", null)
            .setPositiveButton("저장") { _, _ ->
                inlineRecordField?.let { field ->
                    (getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager)
                        ?.hideSoftInputFromWindow(field.windowToken, 0)
                }
                if (RecordStore.replaceMonth(this, month, corrected)) {
                    clearDraft(); renderTab(); onSaved?.invoke(); toast("수정한 기록을 저장했어요")
                } else toast("저장 실패 · 기존 기록을 유지했어요")
            }.show()
    }

    private fun renderStats(root: LinearLayout) {
        val rows = currentRecords()
        val minutes = rows.sumOf { it.minutes }
        root.addView(heading("근무 통계", "${month.year}년 ${month.monthValue}월 · 기록을 한눈에", blue))
        root.addView(horizontal().apply {
            addView(statCard("계산 근무", "${minutes / 60}h ${minutes % 60}m", blueSoft, blue, PatternKind.RINGS), LinearLayout.LayoutParams(0, dp(88), 1f))
            addView(statCard("근무 일수", "${rows.map { it.date }.distinct().size}일", greenSoft, aqua, PatternKind.DOTS), LinearLayout.LayoutParams(0, dp(88), 1f).apply { marginStart = dp(8) })
        }.withMargin(0, 12, 0, 11))
        val lastCollection = RecordStore.lastCollection(this)
        if (lastCollection != null && lastCollection.month == month.toString()) {
            root.addView(section("자동 수집 결과", if (rows.isEmpty()) "기록이 없어 근무 흐름이 비어 있어요" else "저장된 기록으로 근무 흐름을 갱신했어요", aqua, PatternKind.STRIPES, intArrayOf(aqua, sky)).apply {
                addView(label("${lastCollection.recordCount}건 저장 · 새로 추가 ${lastCollection.newCount}건", 14f, ink, true))
                addView(label(lastCollection.message, 11.5f, muted).apply { topSpace(5) })
                if (rows.isEmpty()) addView(label("현재 월의 기록이 없습니다. 공식 출근부 목록에서 읽을 수 있는 글자가 있는지 확인하세요.", 11.5f, amber).apply { topSpace(6) })
            })
        }
        renderWeeklyChart(root, rows)
        renderMonthCalendar(root, rows)
        root.addView(action("근무 통계 새로고침") {
            month = RecordStore.selectedMonth(this)
            renderTab()
            toast("${month.monthValue}월 기록과 차트를 갱신했어요")
        }.withMargin(0, 0, 0, 10))
        val all = RecordStore.read(this)
        val last = (5 downTo 0).mapNotNull { steps ->
            runCatching { month.minusMonths(steps.toLong()) }.getOrNull()
        }.map { ym ->
            ym to all.filter { it.date.startsWith(ym.toString()) }.sumOf { it.minutes }
        }
        val max = (last.maxOfOrNull { it.second } ?: 0).coerceAtLeast(1)
        val monthColors = intArrayOf(sky, aqua, amber, coral, violet, blue)
        val monthPastels = intArrayOf(skySoft, greenSoft, amberSoft, coralSoft, violetSoft, blueSoft)
        root.addView(section("최근 6개월 비교", "저장된 날짜별 기록을 기준으로 계산해요", coral, PatternKind.CONFETTI, intArrayOf(coral, amber, aqua, sky, blue, violet)).apply {
            last.forEachIndexed { idx, (ym, value) ->
                val accent = monthColors[idx % monthColors.size]
                val track = monthPastels[idx % monthPastels.size]
                val selected = ym == month
                addView(horizontal().apply {
                    gravity = Gravity.CENTER_VERTICAL
                    addView(label("${ym.monthValue}월", 12f, if (selected) accent else ink, true), LinearLayout.LayoutParams(dp(36), -2))
                    addView(FrameLayout(this@MainActivity).apply {
                        background = shape(track, radius = 6)
                        val bar = View(this@MainActivity).apply {
                            background = shape(accent, radius = 6)
                        }
                        addView(bar, FrameLayout.LayoutParams(0, -1))
                        fun applyBarWidth(trackWidth: Int) {
                            if (trackWidth <= 0) return
                            val targetW = (trackWidth * (value.toFloat() / max)).toInt().coerceAtLeast(if (value > 0) dp(4) else 0)
                            if (bar.layoutParams.width != targetW) {
                                bar.layoutParams = FrameLayout.LayoutParams(targetW, -1)
                            }
                        }
                        addOnLayoutChangeListener { _, l, _, r, _, _, _, _, _ -> applyBarWidth(r - l) }
                        post { applyBarWidth(width) }
                    }, LinearLayout.LayoutParams(0, dp(10), 1f).apply { marginStart = dp(8) })
                    addView(label("${value / 60}h ${value % 60}m", 11f, if (selected) accent else muted, bold = selected).apply { gravity = Gravity.END }, LinearLayout.LayoutParams(dp(76), -2))
                }.apply { topSpace(11) })
            }
        })
        root.addView(section("기록 확인", "합계가 공식 인정시간과 다르면 원본을 대조하세요", violet, PatternKind.RINGS, intArrayOf(violet, blue)).apply {
            addView(action("기록에서 상세 확인", primary = true, gradientColors = intArrayOf(violet, coral)) { tab = 1; renderTab() })
        })
    }

    /** Device-owned permission screens. We never change security settings ourselves. */
    private fun renderSettings(root: LinearLayout) {
        root.addView(heading("설정", "자주 쓰는 환경 설정과 접근성 관리를 한곳에", blue).apply { topSpace(0) })
        root.addView(space(16))
        root.addView(section("화면 모드", "모든 탭·팝업·입력창·플로팅 메뉴에 함께 적용됩니다", violet, PatternKind.SPARKLES, intArrayOf(blue, violet, coral, amber)).apply {
            val buttons = horizontal()
            buttons.addView(action("라이트", primary = !darkMode, gradientColors = intArrayOf(blue, violet)) { setDarkMode(false) },
                LinearLayout.LayoutParams(0, -2, 1f))
            buttons.addView(action("다크", primary = darkMode, gradientColors = intArrayOf(violet, coral)) { setDarkMode(true) },
                LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
            addView(buttons)
        })
        root.addView(section("접근성 자동 수집", "${if (isAccessibilityEnabled()) "현재 사용 중" else "현재 사용 안 함"} · 공식 출근부 목록만 읽어요", aqua, PatternKind.DOTS, intArrayOf(aqua, sky, blue)).apply {
            addView(chip(if (isAccessibilityEnabled()) "● 접근성 켜짐" else "○ 접근성 꺼짐",
                if (isAccessibilityEnabled()) greenSoft else amberSoft,
                if (isAccessibilityEnabled()) aqua else amber))
            addView(label("근무로그가 실행 중이고 공식 출근부를 보고 있을 때만 메뉴가 나타나요. ‘목록 수집’을 눌러야 읽기 시작하며, 앱을 종료하거나 최근 앱에서 지우면 멈춰요. 스크린샷·OCR은 사용하지 않아요.", 12f, muted).apply { topSpace(9) })
            addView(action("접근성 설정 바로 열기", primary = true, gradientColors = intArrayOf(aqua, blue)) { showAccessibilityDisclosure(true) }.apply { topSpace(9) })
            addView(action("근무로그 앱 설정 열기") { openOwnAppDetails() }.apply { topSpace(8) })
            addView(action("접근성 상태 다시 확인") { renderTab() }.apply { topSpace(8) })
            if (isAccessibilityEnabled() && !CollectorAccessibilityService.isReady()) {
                addView(label("서비스가 아직 연결되지 않았습니다. 잠시 뒤 다시 확인하거나, 시스템 접근성 화면에서 사용 상태를 확인하세요.", 12f, amber).apply { topSpace(8) })
            }
            addView(action("접근성 권한 직접 끄기", destructive = true) {
                activeDialog?.dismiss()
                activeDialog = appDialog()
                    .setTitle("접근성 서비스 끄기")
                    .setMessage("수집만 중지하는 것이 아니라 접근성 서비스 사용을 해제합니다. 계속할까요?")
                    .setNegativeButton("취소", null)
                    .setPositiveButton("서비스 끄기") { _, _ ->
                        if (!CollectorAccessibilityService.disableFromApp()) {
                            try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                            catch (_: Exception) { toast("접근성 설정을 열 수 없습니다") }
                        }
                        host.postDelayed({ if (!startupFailed && !isFinishing && !isDestroyed) renderTab() }, 350L)
                    }.show()
            }.apply { topSpace(8) })
            addView(action("기록 탭의 텍스트 붙여넣기 열기") { openRecordsTab() }.apply { topSpace(8) })
        })
        root.addView(section("기록 관리", "앱 버전 유지 · 데이터는 기기 내부에 저장", sky, PatternKind.RINGS, intArrayOf(sky, blue)).apply {
            addView(infoRow("현재 버전", versionName))
            addView(infoRow("Android 지원", minAndroidText))
            addView(action("기록 백업·편집으로 이동") { tab = 1; renderTab() }.apply { topSpace(9) })
            addView(action("접근성 수집 범위 설명") { showAccessibilityDisclosure(false) }.apply { topSpace(8) })
        })
        renderGettingStarted(root)
        root.addView(section("설치·권한 도움말", "접근성 스위치를 누를 수 없을 때만 펼쳐 확인하세요", amber, PatternKind.RINGS, intArrayOf(amber, coral)).apply {
            val helpBody = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                visibility = if (settingsHelpExpanded) View.VISIBLE else View.GONE
                topSpace(10)
                addView(label("Android 13 이상에서 ‘제한된 설정’ 또는 ‘앱의 액세스가 거부됨 · 이 제한된 권한 없이는…’ 창이 뜨면 아래 앱 설정을 열고, 오른쪽 위 ⋮ → 제한된 설정 허용을 누르세요. 그런 다음 돌아와 접근성을 켜세요. 기기에 따라 메뉴 이름이 다를 수 있어요.", 13f, ink))
                addView(action("근무로그 앱 설정 열기") { openOwnAppDetails() }.apply { topSpace(12) })
                addView(action("제한된 설정 · 공식 도움말") {
                    openHelpUrl("https://support.google.com/android/answer/12623953?hl=ko")
                }.apply { topSpace(8) })
                addView(label("설치 경고가 나오면 설치 출처와 서명을 확인하세요. Play 프로텍트는 켜 둔 상태로 검사하세요.", 12.5f, muted).apply { topSpace(12) })
                addView(action("Google Play 열기") { openPlayStore() }.apply { topSpace(8) })
                addView(action("Play 프로텍트 · 공식 도움말") {
                    openHelpUrl("https://support.google.com/googleplay/answer/2812853?hl=ko")
                }.apply { topSpace(8) })
            }
            lateinit var helpToggle: Button
            helpToggle = action(if (settingsHelpExpanded) "제한된 설정 · 설치 도움말 접기  ⌃" else "제한된 설정 · 설치 도움말 펼치기  ⌄") {
                settingsHelpExpanded = !settingsHelpExpanded
                helpBody.visibility = if (settingsHelpExpanded) View.VISIBLE else View.GONE
                helpToggle.text = if (settingsHelpExpanded) "제한된 설정 · 설치 도움말 접기  ⌃" else "제한된 설정 · 설치 도움말 펼치기  ⌄"
            }
            addView(helpToggle)
            addView(helpBody)
        })
    }

    private fun renderGettingStarted(root: LinearLayout) {
        root.addView(section("처음 시작하기", "4단계 사용 안내를 필요할 때 펼쳐 따라 할 수 있어요", blue, PatternKind.CONFETTI, intArrayOf(blue, violet, aqua, amber)).apply {
            val stepsBox = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                visibility = if (settingsGuideExpanded) View.VISIBLE else View.GONE
                topSpace(10)
                addView(guideRow("1", "가져올 월을 선택해요",
                    "홈의 ‘조회 기간’에서 연도와 월을 입력하고 ‘이 연도 · 월 적용’을 누르세요. 이미 원하는 월이면 다음 단계로 가세요.",
                    "조회 기간 선택하기") {
                    tab = 0; periodEditorMode = true; renderTab(); showPeriodEditorImmediately()
                })
                addView(guideRow("2", "접근성을 한 번 켜 주세요",
                    "아래 버튼 → 안내에 동의 → 설치된 앱(또는 다운로드한 앱) → 근무로그 → 사용 켜기. 켠 뒤 뒤로 가기로 근무로그에 돌아오세요. 스위치가 막혀 있으면 아래 ‘설치·권한 도움말’을 확인하세요.",
                    if (isAccessibilityEnabled()) "접근성 켜짐 · 설정 확인" else "접근성 설정 열기") {
                    showAccessibilityDisclosure(true)
                })
                addView(guideRow("3", "공식 출근부의 목록을 열어요",
                    "아래 버튼으로 한국장학재단 출근부 앱을 열고 로그인하세요. 가져올 월을 조회해서 날짜와 출퇴근 시각이 보이는 목록을 띄우세요. 근무로그는 최근 앱에서 지우지 말고 두세요.",
                    "한국장학재단 출근부 열기") { openOfficialAttendanceApp() })
                addView(guideRow("4", "‘목록 수집’을 누르면 끝이에요",
                    "공식 출근부 위에 뜬 근무로그 메뉴에서 ‘목록 수집’을 누르세요. 완료 표시를 확인한 뒤 근무로그로 돌아오면 ‘기록’과 ‘통계’에서 확인할 수 있어요. 도중에 멈추려면 ‘중지’를 누르세요.",
                    "가져온 기록 확인하기") { openRecordsTab() })
                addView(label("메뉴가 안 보이나요? 근무로그를 한 번 연 뒤 공식 출근부로 이동하세요. 근무로그를 종료하거나 최근 앱에서 지우면 메뉴와 수집이 멈춰요.", 12.5f, muted).apply { topSpace(4) })
            }
            lateinit var guideToggle: Button
            guideToggle = action(if (settingsGuideExpanded) "사용 방법 4단계 접기  ⌃" else "사용 방법 4단계 펼치기  ⌄") {
                settingsGuideExpanded = !settingsGuideExpanded
                stepsBox.visibility = if (settingsGuideExpanded) View.VISIBLE else View.GONE
                guideToggle.text = if (settingsGuideExpanded) "사용 방법 4단계 접기  ⌃" else "사용 방법 4단계 펼치기  ⌄"
            }
            addView(guideToggle)
            addView(stepsBox)
        })
    }

    private fun setDarkMode(enabled: Boolean) {
        if (darkMode == enabled) return
        if (tab == 1) saveDraft()
        val y = currentScrollY()
        darkMode = enabled
        getSharedPreferences("attendance_display", MODE_PRIVATE).edit()
            .putBoolean("dark_mode", enabled).apply()
        setTheme(if (darkMode) R.style.AttendanceThemeDark else R.style.AttendanceTheme)
        if (::rootContainer.isInitialized) rootContainer.setBackgroundColor(surface)
        shell.setBackgroundColor(surface)
        val oldTop = topBar
        val topParams = oldTop.layoutParams
        shell.removeView(oldTop)
        topBar = toolbar()
        shell.addView(topBar, 0, topParams)
        navigation.background = bottomNavDrawable()
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) configureSystemBars()
        updateSystemBarIconsSafely()
        renderTab()
        shell.requestApplyInsets()
        restoreScroll(y)
    }

    private fun openRecordsTab() {
        periodEditorMode = false
        if (tab == 1) saveDraft()
        tab = 1
        renderTab()
        // The paste box is immediately below the summary on the records page.
        (host.getChildAt(0) as? ScrollView)?.post {
            (host.getChildAt(0) as? ScrollView)?.scrollTo(0, 0)
        }
    }

    private fun guideRow(number: String, title: String, content: String, buttonText: String, onClick: () -> Unit): LinearLayout {
        val (accent, companion, pastel, kind) = when (number) {
            "1" -> listOf(blue, violet, blueSoft, PatternKind.DOTS)
            "2" -> listOf(aqua, sky, greenSoft, PatternKind.RINGS)
            "3" -> listOf(violet, coral, violetSoft, PatternKind.SPARKLES)
            else -> listOf(amber, coral, amberSoft, PatternKind.CONFETTI)
        }
        val aColor = accent as Int
        val cColor = companion as Int
        val pColor = pastel as Int
        val pKind = kind as PatternKind
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = patternedCardDrawable(
                fill = pColor,
                stroke = adjustAlpha(aColor, if (darkMode) 0.38f else 0.24f),
                accent = aColor,
                secondary = cColor,
                kind = pKind,
                radiusDp = 18
            )
            setPadding(dp(14), dp(14), dp(14), dp(14))
            addView(horizontal().apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(label(number, 13f, Color.WHITE, true).apply {
                    gravity = Gravity.CENTER
                    background = gradient(intArrayOf(aColor, cColor), radius = 16)
                }, LinearLayout.LayoutParams(dp(32), dp(32)))
                addView(label(title, 14.5f, ink, true).apply { setPadding(dp(10), 0, 0, 0) },
                    LinearLayout.LayoutParams(0, -2, 1f))
            })
            addView(label(content, 13f, muted).apply { topSpace(9); setLineSpacing(dp(3).toFloat(), 1.12f) })
            addView(action(buttonText, onClick = onClick).apply { topSpace(11) })
        }.withMargin(0, 0, 0, 12)
    }

    private fun openOwnAppDetails() {
        try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.parse("package:$packageName"))) }
        catch (_: Exception) { toast("앱 설정 화면을 열 수 없습니다") }
    }
    private fun openPlayStore() {
        try {
            val launch = packageManager.getLaunchIntentForPackage("com.android.vending")
            if (launch != null) startActivity(launch) else openHelpUrl("https://play.google.com/store")
        } catch (_: Exception) { toast("Google Play를 열 수 없습니다") }
    }
    private fun openHelpUrl(address: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(address))) }
        catch (_: Exception) { toast("안내 링크를 열 수 없습니다") }
    }

    /** One clear, separate disclosure immediately before directing the user to Android's settings. */
    private fun showAccessibilityDisclosure(openSettings: Boolean) {
        // Never revoke an already granted consent simply by OPENING the disclosure.
        // Doing so disconnects a running accessibility service when the user returns.
        val alreadyConsented = RecordStore.consent(this)
        val disclosure = "이 앱은 한국장학재단의 공식 앱이 아닌 개인용 근무기록 도우미입니다.\n\n" +
            "• 접근 대상: 한국장학재단 출근부 앱(com.kosaf.gpsAttendance)\n" +
            "• 읽는 내용: 조회 목록에 표시된 근무 날짜, 출퇴근 시각, 식사·휴게시간, 기관 확인 상태\n" +
            "• 동작: 사용자가 ‘목록 수집’을 누르면 접근성에 표시된 텍스트를 읽고 목록만 스크롤합니다. 스크린샷/OCR은 하지 않습니다.\n" +
            "• 보관: 추출한 근무기록은 이 휴대전화의 앱 내부에만 저장합니다. 로그인 정보는 수집·저장하지 않으며 서버로 전송하지 않습니다.\n" +
            "• 실행 범위: 근무로그를 연 뒤 최근 앱에 남아 있을 때만 메뉴를 표시합니다. 앱을 종료하거나 최근 앱에서 지우면 메뉴와 수집이 멈춥니다. 기기 재시작 후에는 근무로그를 다시 열어 주세요.\n" +
            "• 사용 중지: 떠 있는 ‘수집 중지’는 수집 작업만 멈춥니다. 서비스 권한은 설정 탭에서 직접 끌 수 있습니다.\n\n" +
            "이 권한은 강력한 화면 접근 권한입니다. 반드시 내용을 확인한 뒤 동의해 주세요. 거절해도 기록 탭에서 직접 편집하거나 텍스트를 붙여넣을 수 있습니다."
        showSafeAlert(
            appDialog()
                .setTitle("접근성 권한 · 수집 범위 안내")
                .setMessage(disclosure)
                .setNegativeButton(if (openSettings) "동의하지 않음" else "닫기") { _, _ ->
                    if (openSettings && !alreadyConsented) RecordStore.setConsent(this, false)
                }
                .setPositiveButton(if (openSettings) "동의하고 설정 열기" else "확인") { _, _ ->
                    if (openSettings) {
                        try {
                            RecordStore.setConsent(this, true)
                            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        } catch (_: Exception) {
                            toast("접근성 설정을 열 수 없습니다")
                            if (!alreadyConsented) RecordStore.setConsent(this, false)
                        }
                    }
                }
        )
    }

    private fun applyFields() {
        val year = yearField?.text?.toString()?.trim()?.toIntOrNull()
        val monthNumber = monthField?.text?.toString()?.trim()?.toIntOrNull()
        if (year == null || year !in MonthlyWeekStats.FIRST_YEAR..MonthlyWeekStats.LAST_YEAR || monthNumber == null || monthNumber !in 1..12) {
            showDateRangeWarning("입력한 연도 또는 월이 올바르지 않습니다. 연도는 2000~2100, 월은 1~12 사이로 입력해 주세요.")
            return
        }
        changeTo(YearMonth.of(year, monthNumber), preserveScroll = true)
    }

    private fun changeMonth(direction: Int) {
        val next = if (direction == 0) YearMonth.now() else runCatching { month.plusMonths(direction.toLong()) }.getOrNull()
        if (next == null || next.year !in MonthlyWeekStats.FIRST_YEAR..MonthlyWeekStats.LAST_YEAR) {
            showDateRangeWarning("이동하려는 월이 허용 범위 밖입니다. 이전·다음 달 선택은 범위 안에서만 가능합니다.")
            return
        }
        changeTo(next, preserveScroll = true)
    }

    /** Fully themed, friendly date guidance instead of a platform warning box. */
    private fun showDateRangeWarning(details: String) {
        if (isFinishing || isDestroyed) return
        val warningDialog = Dialog(this, if (darkMode) R.style.AttendanceDialogDark else R.style.AttendanceDialogLight)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = patternedCardDrawable(
                fill = cardFill,
                stroke = adjustAlpha(amber, if (darkMode) 0.42f else 0.28f),
                accent = amber,
                secondary = coral,
                kind = PatternKind.SPARKLES,
                radiusDp = 24,
                topStripColors = intArrayOf(amber, coral, violet)
            )
            setPadding(dp(21), dp(24), dp(21), dp(19))
            addView(horizontal().apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(label("!", 21f, Color.WHITE, true).apply {
                    gravity = Gravity.CENTER
                    background = gradient(intArrayOf(amber, coral), radius = 16)
                }, LinearLayout.LayoutParams(dp(48), dp(48)))
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(12), 0, 0, 0)
                    addView(label("날짜를 다시 확인해 주세요", 17f, ink, true))
                    addView(label("선택한 날짜를 적용하지 않았어요", 11.5f, muted).apply { topSpace(3) })
                }, LinearLayout.LayoutParams(0, -2, 1f))
            })
            addView(label(details, 13.5f, ink).apply {
                topSpace(19)
                setLineSpacing(dp(3).toFloat(), 1.08f)
            })
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                background = patternedCardDrawable(
                    fill = blueSoft,
                    stroke = adjustAlpha(blue, if (darkMode) 0.35f else 0.20f),
                    accent = blue,
                    secondary = sky,
                    kind = PatternKind.DOTS,
                    radiusDp = 14
                )
                setPadding(dp(13), dp(12), dp(13), dp(12))
                addView(label("선택 가능한 날짜", 11.5f, muted, true))
                addView(label("2000년 1월 1일 ~ 2100년 12월 31일", 13f, blueDeep, true).apply { topSpace(5) })
                addView(label("월은 1~12 사이에서 입력해 주세요.", 11.5f, muted).apply { topSpace(4) })
            }.apply { topSpace(15) })
            addView(action("확인했어요", primary = true, gradientColors = intArrayOf(amber, coral)) { warningDialog.dismiss() }.apply { topSpace(18) })
        }
        warningDialog.setContentView(content)
        warningDialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        showSafeDialog(warningDialog)
        warningDialog.window?.decorView?.let { card -> animateEntrance(card, 0L) }
        warningDialog.window?.setLayout(
            (resources.displayMetrics.widthPixels - dp(36)).coerceAtMost(dp(430)),
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    /** Uniform dark/light styling for every other confirmation, list and permission dialog. */
    private fun appDialog(): AlertDialog.Builder = AlertDialog.Builder(this,
        if (darkMode) R.style.AttendanceDialogDark else R.style.AttendanceDialogLight)

    private fun showSafeDialog(dialog: Dialog) {
        if (isFinishing || isDestroyed) return
        activeDialog?.let { prev -> if (prev !== dialog) runCatching { if (prev.isShowing) prev.dismiss() } }
        activeDialog = dialog
        runCatching { dialog.show() }.onFailure { Log.w("AttendanceDialog", "Skipped dialog on closing window", it) }
    }

    private fun showSafeAlert(builder: AlertDialog.Builder): AlertDialog? {
        if (isFinishing || isDestroyed) return null
        activeDialog?.let { prev -> runCatching { if (prev.isShowing) prev.dismiss() } }
        val shown = runCatching { builder.show() }.getOrNull()
        if (shown != null) activeDialog = shown
        return shown
    }

    private fun changeTo(value: YearMonth, preserveScroll: Boolean = false) {
        val scrollY = if (preserveScroll) currentScrollY() else 0
        month = value
        RecordStore.setSelectedMonth(this, value)
        clearDraft()
        showAllRows = false
        if (preserveScroll && !periodEditorMode) pendingRestoreScrollY = scrollY
        renderTab()
        if (periodEditorMode) showPeriodEditorImmediately()
        else if (preserveScroll) restoreScroll(scrollY)
    }

    private fun currentScrollY(): Int = if (::host.isInitialized) (host.getChildAt(0) as? ScrollView)?.scrollY ?: 0 else 0

    private fun restoreScroll(scrollY: Int) {
        if (!::host.isInitialized || startupFailed || isFinishing || isDestroyed) return
        val scrollView = host.getChildAt(0) as? ScrollView ?: return
        pendingRestoreScrollY = scrollY
        fun applyScroll(): Boolean {
            if (isFinishing || isDestroyed || !::host.isInitialized || host.getChildAt(0) !== scrollView) return true
            val contentH = scrollView.getChildAt(0)?.height ?: 0
            if (scrollView.height <= 0 || contentH <= 0) return false
            val maxScroll = (contentH - scrollView.height + scrollView.paddingBottom).coerceAtLeast(0)
            scrollView.scrollTo(0, scrollY.coerceIn(0, maxScroll))
            pendingRestoreScrollY = null
            return true
        }
        if (!applyScroll()) {
            val vto = scrollView.viewTreeObserver
            val listener = object : ViewTreeObserver.OnGlobalLayoutListener {
                override fun onGlobalLayout() {
                    if (applyScroll() && scrollView.viewTreeObserver.isAlive) {
                        scrollView.viewTreeObserver.removeOnGlobalLayoutListener(this)
                    }
                }
            }
            if (vto.isAlive) vto.addOnGlobalLayoutListener(listener)
            scrollView.post {
                if (applyScroll() && scrollView.viewTreeObserver.isAlive) {
                    scrollView.viewTreeObserver.removeOnGlobalLayoutListener(listener)
                }
            }
        }
    }

    private fun monthlySummaryText(rows: List<WorkRecord> = currentRecords()): String {
        val total = rows.sumOf { it.minutes }
        val breakTotal = rows.sumOf { it.breakMinutes }
        val mismatch = rows.count { it.differentFromReported }
        return "${month.year}년 ${month.monthValue}월 근무 ${total / 60}시간 ${total % 60}분 · 휴게 차감 ${breakTotal / 60}시간 ${breakTotal % 60}분 · 확인 필요 ${mismatch}건"
    }

    private fun fullMonthText(): String = AttendanceParser.monthlyShareText(currentRecords(), month)

    private fun copyText(label: String, value: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText(label, value))
    }

    private fun copyMonthDetails() {
        runCatching { copyText("${month} 날짜·출퇴근 시각", fullMonthText()) }
            .onSuccess { toast("전체 날짜·출퇴근 시각을 복사했어요") }
            .onFailure { Log.e("AttendanceShare", "Copy failed", it); toast("복사할 수 없습니다") }
    }

    /** A single tap opens the Android share sheet with ALL dated shift details. */
    private fun shareSummary() {
        try {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, fullMonthText())
            }, "월간 날짜·시각 공유"))
        } catch (e: Exception) {
            Log.e("AttendanceShare", "Could not open share sheet", e)
            toast("공유 화면을 열 수 없습니다")
        }
    }

    /**
     * Uses the verified official Play package (com.kosaf.gpsAttendance).
     * Package visibility is declared narrowly in AndroidManifest.xml.
     * Never request QUERY_ALL_PACKAGES or an elevated permission.
     */
    private fun openOfficialAttendanceApp() {
        val launcher = try {
            packageManager.getLaunchIntentForPackage(targetAttendancePackage)
                ?: Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_LAUNCHER)
                    setPackage(targetAttendancePackage)
                }.let { intent ->
                    val info = packageManager.resolveActivity(intent, 0)
                    if (info != null) intent else null
                }
        } catch (error: Exception) {
            Log.w("AttendanceLauncher", "Could not resolve official app", error)
            null
        }
        if (launcher != null) {
            try {
                startActivity(launcher.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            } catch (error: ActivityNotFoundException) {
                Log.w("AttendanceLauncher", "Official app is not launchable", error)
            } catch (error: SecurityException) {
                Log.w("AttendanceLauncher", "Launch restricted by device", error)
            }
        }
        showSafeAlert(
            appDialog()
                .setTitle("공식 출근부 앱을 열 수 없어요")
                .setMessage("한국장학재단 출근부 앱이 설치되지 않았거나, 사용 중지·보안 정책으로 실행할 수 없습니다. Play 스토어의 공식 앱 페이지를 확인할까요?")
                .setNegativeButton("닫기", null)
                .setPositiveButton("공식 앱 확인") { _, _ -> openOfficialAppStorePage() }
        )
    }

    private fun openOfficialAppStorePage() {
        val storeUrl = "https://play.google.com/store/apps/details?id=$targetAttendancePackage"
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$targetAttendancePackage")))
        } catch (error: ActivityNotFoundException) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(storeUrl)))
            } catch (fallbackError: Exception) {
                toast("공식 앱 페이지를 열 수 없습니다")
            }
        } catch (error: SecurityException) {
            toast("기기 정책에 따라 앱 스토어를 열 수 없습니다")
        }
    }

    private fun showOfficialAppIconOrFallback(target: ImageView, fallback: Int) {
        // Fetches the real currently installed official app icon, so the graphic
        // is accurate and no third-party trademark asset is bundled in our APK.
        try {
            target.setImageDrawable(packageManager.getApplicationIcon(targetAttendancePackage))
        } catch (error: PackageManager.NameNotFoundException) {
            target.setImageResource(fallback)
        } catch (error: Exception) {
            Log.w("AttendanceLauncher", "Official app icon unavailable", error)
            target.setImageResource(fallback)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun <T : View> T.attachPressBounce(scaleDown: Float = 0.96f): T = apply {
        setOnTouchListener { v, event ->
            if (ValueAnimator.areAnimatorsEnabled()) {
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        v.animate().cancel()
                        v.animate().scaleX(scaleDown).scaleY(scaleDown).setDuration(85L).start()
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        v.animate().cancel()
                        v.animate().scaleX(1f).scaleY(1f).setDuration(165L)
                            .setInterpolator(android.view.animation.OvershootInterpolator(1.5f)).start()
                    }
                }
            }
            false
        }
    }

    private fun <T : View> animateEntrance(view: T, delayMs: Long = 0L): T = view.apply {
        if (!ValueAnimator.areAnimatorsEnabled() || periodEditorMode) return@apply
        alpha = 0f
        translationY = dp(10).toFloat()
        scaleX = 0.982f
        scaleY = 0.982f
        post {
            if (!isAttachedToWindow || isFinishing || isDestroyed) return@post
            animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                .setStartDelay(delayMs).setDuration(300)
                .setInterpolator(android.view.animation.DecelerateInterpolator(1.4f)).start()
        }
    }

    private fun currentRecords(): List<WorkRecord> = RecordStore.read(this).filter { it.date.startsWith(month.toString()) }

    private fun saveDraft() {
        draftPasteText = pasteField?.text?.toString() ?: draftPasteText
        if (recordEditMode && tab == 1) {
            inlineRecordField?.let { field ->
                draftMonth = month
                draftText = field.text?.toString().orEmpty()
            }
        }
    }

    private fun clearDraft() {
        draftMonth = null
        draftText = null
        draftPasteText = null
        recordEditMode = false
        inlineRecordField = null
    }

    private fun isAccessibilityEnabled(): Boolean {
        val component = ComponentName(this, CollectorAccessibilityService::class.java).flattenToString()
        return runCatching {
            (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "")
                .split(":")
                .any { it.equals(component, ignoreCase = true) ||
                    ComponentName.unflattenFromString(it) == ComponentName(this, CollectorAccessibilityService::class.java) }
        }.getOrDefault(false)
    }

    private fun createFile(request: Int, mime: String, filename: String) {
        try {
            pendingFileRequest = request
            pendingFileContent = if (request == saveCsv) {
                AttendanceParser.csv(RecordStore.read(this), month)
            } else {
                AttendanceParser.export(currentRecords(), month)
            }
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = mime
                putExtra(Intent.EXTRA_TITLE, filename)
            }, request)
        } catch (e: Exception) {
            pendingFileRequest = null
            pendingFileContent = null
            toast("파일 저장 화면을 열 수 없습니다")
            Log.e("AttendanceFile", "Could not open document picker", e)
        }
    }

    private fun heading(title: String, subtitle: String, color: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(label(title, 22f, ink, bold = true))
        addView(label(subtitle, 12.5f, muted).apply { topSpace(5) })
    }

    private fun recordPreview(item: WorkRecord): LinearLayout = horizontal().apply {
        gravity = Gravity.CENTER_VERTICAL
        val warning = item.differentFromReported
        val badgeColor = if (warning) amber else if (item.breakMinutes > 0) aqua else blueDeep
        val badgeBg = if (warning) amberSoft else if (item.breakMinutes > 0) greenSoft else blueSoft
        val cardBg = if (warning) lemon else if (item.breakMinutes > 0) greenSoft else skySoft
        background = patternedCardDrawable(
            fill = cardBg,
            stroke = adjustAlpha(badgeColor, if (darkMode) 0.42f else 0.25f),
            accent = badgeColor,
            secondary = violet,
            kind = if (warning) PatternKind.STRIPES else PatternKind.DOTS,
            radiusDp = 15
        )
        setPadding(dp(11), dp(11), dp(11), dp(11))
        topSpace(7)
        addView(label(item.date.takeLast(5).replace('-', '.'), 13f, badgeColor, bold = true).apply {
            gravity = Gravity.CENTER
            background = shape(badgeBg, radius = 11, stroke = adjustAlpha(badgeColor, 0.25f))
            setPadding(dp(4), dp(10), dp(4), dp(10))
        }, LinearLayout.LayoutParams(dp(65), -2))
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, dp(4), 0)
            addView(label("${item.start} ~ ${item.end}", 13f, ink, bold = true))
            addView(label(when {
                warning -> "⚠ 표시시간 차이 · 원본 확인"
                item.breakMinutes > 0 -> "식사 ${item.breakStart} ~ ${item.breakEnd} · ${item.breakMinutes}분 차감"
                else -> if (item.status.isBlank()) "근무 내역" else item.status
            }, 12f, if (warning) amber else muted).apply { topSpace(4) })
        }, LinearLayout.LayoutParams(0, -2, 1f))
        addView(label("${item.minutes / 60}h ${item.minutes % 60}m", 12.5f, badgeColor, bold = true).apply {
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            setSingleLine(true)
        }, LinearLayout.LayoutParams(dp(74), -2))
    }

    private fun heroMetric(title: String, value: String, accent: Int, frosted: Boolean = false): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_VERTICAL
        if (frosted) {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#36FFFFFF"), Color.parseColor("#18FFFFFF"))
            ).apply {
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), Color.parseColor("#58FFFFFF"))
            }
            setPadding(dp(11), dp(8), dp(10), dp(8))
            addView(horizontal().apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(FrameLayout(this@MainActivity).apply {
                    background = shape(adjustAlpha(accent, 0.35f), radius = 10)
                    addView(View(this@MainActivity).apply {
                        background = shape(accent, radius = 6)
                    }, FrameLayout.LayoutParams(dp(6), dp(6), Gravity.CENTER))
                }, LinearLayout.LayoutParams(dp(12), dp(12)).apply { marginEnd = dp(5) })
                addView(label(title, 11f, Color.parseColor("#EAE6FF"), bold = true).apply {
                    includeFontPadding = false
                })
            })
            addView(label(value, 16f, Color.WHITE, bold = true).apply {
                topSpace(5)
                includeFontPadding = false
            })
        } else {
            setPadding(0, dp(12), 0, dp(4))
            addView(label(title, 12f, muted))
            addView(label(value, 17f, accent, bold = true).apply { topSpace(6) })
        }
    }

    private fun statCard(title: String, value: String, bg: Int, fg: Int, kind: PatternKind = PatternKind.DOTS): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_VERTICAL
        setMinimumHeight(dp(88))
        background = patternedCardDrawable(
            fill = bg,
            stroke = adjustAlpha(fg, if (darkMode) 0.42f else 0.25f),
            accent = fg,
            secondary = violet,
            kind = kind,
            radiusDp = 20,
            topStripColors = intArrayOf(fg, violet)
        )
        setPadding(dp(16), dp(14), dp(14), dp(14))
        addView(horizontal().apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(View(this@MainActivity).apply {
                background = gradient(intArrayOf(fg, violet), radius = 10)
            }, LinearLayout.LayoutParams(dp(6), dp(6)).apply { marginEnd = dp(6) })
            addView(label(title, 11.5f, muted, bold = true).apply { includeFontPadding = false })
        })
        addView(label(value, 18.5f, fg, bold = true).apply {
            topSpace(6)
            includeFontPadding = false
        })
    }

    private fun chip(textValue: String, bg: Int, fg: Int): TextView = label(textValue, 11.5f, fg, bold = true).apply {
        background = shape(bg, radius = 100, stroke = adjustAlpha(fg, if (darkMode) 0.40f else 0.22f))
        setPadding(dp(10), dp(6), dp(10), dp(6))
    }

    private fun lifestyleCard(
        title: String,
        subtitle: String,
        drawableRes: Int,
        bg: Int,
        accent: Int,
        officialIcon: Boolean = false,
        actionText: String = "열기",
        kind: PatternKind = PatternKind.RINGS,
        onClick: () -> Unit
    ): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        val base = patternedCardDrawable(
            fill = bg,
            stroke = adjustAlpha(accent, if (darkMode) 0.44f else 0.26f),
            accent = accent,
            secondary = violet,
            kind = kind,
            radiusDp = 18,
            topStripColors = intArrayOf(accent, violet)
        )
        background = RippleDrawable(ColorStateList.valueOf(adjustAlpha(accent, 0.22f)), base, null)
        setPadding(dp(11), dp(10), dp(10), dp(10))
        // LinearLayout extends View, which exposes setMinimumHeight (not TextView.minHeight).
        setMinimumHeight(dp(70))
        isClickable = true; isFocusable = true
        contentDescription = "$title, $subtitle"
        attachPressBounce(0.96f)
        setOnClickListener { onClick() }
        addView(FrameLayout(this@MainActivity).apply {
            val badgeCompanion = when (accent) {
                blue -> violet
                aqua -> sky
                amber -> coral
                else -> blue
            }
            background = if (officialIcon) shape(Color.WHITE, radius = 12, stroke = adjustAlpha(accent, 0.22f))
            else gradient(intArrayOf(accent, badgeCompanion), radius = 13)
            addView(ImageView(this@MainActivity).apply {
                if (officialIcon) showOfficialAppIconOrFallback(this, drawableRes) else setImageResource(drawableRes)
                if (!officialIcon) imageTintList = ColorStateList.valueOf(Color.WHITE)
                scaleType = ImageView.ScaleType.FIT_CENTER
                contentDescription = null
            }, FrameLayout.LayoutParams(dp(19), dp(19), Gravity.CENTER))
        }, LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginEnd = dp(10) })
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            addView(label(title, 13f, ink, true).apply {
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                includeFontPadding = false
            })
            addView(label(subtitle, 11.5f, muted).apply {
                topSpace(4)
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                includeFontPadding = false
            })
        }, LinearLayout.LayoutParams(0, -2, 1f))
    }

    private fun infoRow(title: String, value: String): LinearLayout = horizontal().apply {
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(6), 0, dp(6))
        addView(label(title, 13f, muted, bold = true), LinearLayout.LayoutParams(0, -2, 0.9f))
        addView(label(value, 13f, ink, bold = true), LinearLayout.LayoutParams(0, -2, 1.1f))
    }

    private fun fieldBox(title: String, value: String, digits: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(label(title, 12f, muted, bold = true))
        addView(EditText(this@MainActivity).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            filters = arrayOf(InputFilter.LengthFilter(digits))
            setSingleLine(true)
            setText(value)
            selectAll()
            textSize = 19f
            setTextColor(ink)
            setHintTextColor(muted)
            background = shape(if (darkMode) surface else cardGray, radius = 12, stroke = border)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }.also { if (digits == 4) yearField = it else monthField = it })
    }

    private fun section(
        title: String,
        description: String,
        accent: Int = blue,
        kind: PatternKind = PatternKind.DOTS,
        stripColors: IntArray? = null
    ): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = patternedCardDrawable(
            fill = cardFill,
            stroke = if (darkMode) adjustAlpha(accent, 0.24f) else adjustAlpha(border, 0.95f),
            accent = accent,
            secondary = sky,
            kind = kind,
            radiusDp = 24,
            headerPillColors = stripColors ?: intArrayOf(accent, violet)
        )
        elevation = if (darkMode) dp(2).toFloat() else dp(3).toFloat()
        if (Build.VERSION.SDK_INT >= 28 && !darkMode) {
            outlineAmbientShadowColor = adjustAlpha(accent, 0.18f)
            outlineSpotShadowColor = adjustAlpha(accent, 0.22f)
        }
        setPadding(dp(18), dp(26), dp(18), dp(18))
        addView(label(title, 16.5f, ink, true))
        addView(label(description, 12.5f, muted).apply { topSpace(5) })
        addView(space(16))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) }
    }

    private fun step(index: String, title: String, sub: String): LinearLayout = horizontal().apply {
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(7), 0, dp(7))
        addView(label(index, 13f, blue, bold = true).apply {
            gravity = Gravity.CENTER
            background = shape(when (index) { "01" -> blueSoft; "02" -> greenSoft; else -> violetSoft }, radius = 12)
            setTextColor(when (index) { "01" -> blue; "02" -> aqua; else -> violet })
        }, LinearLayout.LayoutParams(dp(42), dp(42)))
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
            addView(label(title, 13.5f, ink, bold = true))
            addView(label(sub, 11.5f, muted).apply { topSpace(3) })
        }, LinearLayout.LayoutParams(0, -2, 1f))
    }

    private fun label(value: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        typeface = Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
        includeFontPadding = true
        setLineSpacing(dp(1).toFloat(), 1.05f)
    }

    private fun action(
        textValue: String,
        primary: Boolean = false,
        destructive: Boolean = false,
        gradientColors: IntArray? = null,
        onClick: () -> Unit
    ): Button = Button(this).apply {
        text = textValue
        isAllCaps = false
        textSize = if (textValue.length >= 16) 12.5f else 14f
        setPadding(dp(8), dp(5), dp(8), dp(5))
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        // Primary gradients stay deep & saturated in BOTH themes for crisp white labels.
        setTextColor(when { primary -> Color.WHITE; destructive -> red; else -> blueDeep })
        val shapeBase = when {
            primary -> gradient(
                gradientColors ?: intArrayOf(
                    Color.parseColor(if (darkMode) "#4F46E5" else "#5B4BFF"),
                    Color.parseColor(if (darkMode) "#9333EA" else "#EC4899")
                ),
                radius = 15
            )
            destructive -> shape(redSoft, radius = 15, stroke = adjustAlpha(red, 0.35f))
            else -> shape(if (darkMode) cardGray else Color.WHITE, radius = 15, stroke = border)
        }
        background = RippleDrawable(
            ColorStateList.valueOf(if (primary || darkMode) Color.parseColor("#44FFFFFF") else adjustAlpha(blue, 0.16f)),
            shapeBase,
            null
        )
        elevation = 0f
        minHeight = dp(48)
        attachPressBounce(0.97f)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, -2)
    }

    private fun horizontal(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    private fun space(height: Int): View = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }

    private fun <T : View> T.topSpace(dpSize: Int): T = apply {
        val params = (layoutParams as? LinearLayout.LayoutParams) ?: LinearLayout.LayoutParams(-1, -2)
        params.topMargin = dp(dpSize)
        layoutParams = params
    }

    private fun <T : View> T.withMargin(left: Int, top: Int, right: Int, bottom: Int): T = apply {
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(left), dp(top), dp(right), dp(bottom)) }
    }

    private fun shape(fill: Int, radius: Int = 16, stroke: Int = Color.TRANSPARENT): GradientDrawable = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }

    private fun gradient(colors: IntArray, radius: Int): GradientDrawable = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply {
        cornerRadius = dp(radius).toFloat()
    }

    private enum class PatternKind { DOTS, STRIPES, RINGS, CHECKER, CONFETTI, WAVES, SPARKLES }

    private fun drawSparkle(canvas: Canvas, cx: Float, cy: Float, radius: Float, paint: Paint, path: Path) {
        if (radius <= 0f) return
        val inner = radius * 0.28f
        path.reset()
        path.moveTo(cx, cy - radius)
        path.quadTo(cx, cy, cx + inner, cy - inner)
        path.lineTo(cx + radius, cy)
        path.quadTo(cx, cy, cx + inner, cy + inner)
        path.lineTo(cx, cy + radius)
        path.quadTo(cx, cy, cx - inner, cy + inner)
        path.lineTo(cx - radius, cy)
        path.quadTo(cx, cy, cx - inner, cy - inner)
        path.close()
        canvas.drawPath(path, paint)
    }

    private fun adjustAlpha(color: Int, factor: Float): Int {
        val alpha = (Color.alpha(color) * factor.coerceIn(0f, 1f)).toInt().coerceIn(0, 255)
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))
    }

    /** Multi-hue soft pastel canvas backdrop with floating bokeh & confetti pattern accents. */
    private fun canvasBackgroundDrawable(): Drawable = object : Drawable() {
        private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val blobPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val decoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
        private var lastW = -1f
        private var lastH = -1f
        private var lastDark = darkMode
        private var blob1: Shader? = null
        private var blob2: Shader? = null
        private var blob3: Shader? = null

        override fun draw(canvas: Canvas) {
            val w = bounds.width().toFloat()
            val h = bounds.height().toFloat()
            if (w <= 0f || h <= 0f) return
            if (w != lastW || h != lastH || lastDark != darkMode || bgPaint.shader == null) {
                lastW = w; lastH = h; lastDark = darkMode
                val baseColors = if (darkMode) {
                    intArrayOf(Color.parseColor("#0D1020"), Color.parseColor("#16122B"), Color.parseColor("#0E1B2A"))
                } else {
                    intArrayOf(Color.parseColor("#F5F2FF"), Color.parseColor("#FFF2F8"), Color.parseColor("#ECFAFF"))
                }
                bgPaint.shader = LinearGradient(0f, 0f, w, h.coerceAtLeast(1f), baseColors, null, Shader.TileMode.CLAMP)
                blob1 = RadialGradient(w * 0.90f, h * 0.12f, (w * 0.55f).coerceAtLeast(1f),
                    adjustAlpha(violet, if (darkMode) 0.14f else 0.11f), Color.TRANSPARENT, Shader.TileMode.CLAMP)
                blob2 = RadialGradient(w * 0.12f, h * 0.45f, (w * 0.50f).coerceAtLeast(1f),
                    adjustAlpha(sky, if (darkMode) 0.12f else 0.10f), Color.TRANSPARENT, Shader.TileMode.CLAMP)
                blob3 = RadialGradient(w * 0.85f, h * 0.82f, (w * 0.52f).coerceAtLeast(1f),
                    adjustAlpha(amber, if (darkMode) 0.10f else 0.09f), Color.TRANSPARENT, Shader.TileMode.CLAMP)
            }
            canvas.drawRect(bounds, bgPaint)

            // Soft colorful aura blobs (non-distracting behind cards).
            blobPaint.shader = blob1
            canvas.drawCircle(w * 0.90f, h * 0.12f, w * 0.55f, blobPaint)
            blobPaint.shader = blob2
            canvas.drawCircle(w * 0.12f, h * 0.45f, w * 0.50f, blobPaint)
            blobPaint.shader = blob3
            canvas.drawCircle(w * 0.85f, h * 0.82f, w * 0.52f, blobPaint)
            blobPaint.shader = null

            // Delicate confetti dots & hollow mini rings in outer gutter.
            val colors = intArrayOf(blue, violet, coral, amber, aqua, sky)
            val spots = arrayOf(
                0.08f to 0.08f, 0.92f to 0.24f, 0.05f to 0.36f, 0.95f to 0.54f,
                0.07f to 0.68f, 0.91f to 0.78f, 0.14f to 0.92f, 0.86f to 0.94f
            )
            spots.forEachIndexed { idx, (px, py) ->
                val cx = w * px
                val cy = h * py
                val c = adjustAlpha(colors[idx % colors.size], if (darkMode) 0.18f else 0.16f)
                decoPaint.color = c
                if (idx % 2 == 0) {
                    decoPaint.style = Paint.Style.FILL
                    canvas.drawCircle(cx, cy, dp(5 + idx % 3).toFloat(), decoPaint)
                } else {
                    decoPaint.style = Paint.Style.STROKE
                    decoPaint.strokeWidth = dp(2).toFloat()
                    canvas.drawCircle(cx, cy, dp(7).toFloat(), decoPaint)
                }
            }
        }
        override fun setAlpha(alpha: Int) {}
        override fun setColorFilter(colorFilter: ColorFilter?) {}
        @Suppress("OVERRIDE_DEPRECATION")
        @Deprecated("Deprecated in Java")
        override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
    }

    /** Soft translucent frosted top app bar with delicate pastel sheen & subtle bottom border. */
    private fun topBarDrawable(): Drawable = object : Drawable() {
        private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val starPath = Path()
        private var lastW = -1f
        private var lastDark = darkMode

        override fun draw(canvas: Canvas) {
            val w = bounds.width().toFloat()
            val h = bounds.height().toFloat()
            if (w <= 0f || h <= 0f) return
            if (w != lastW || lastDark != darkMode || linePaint.shader == null) {
                lastW = w; lastDark = darkMode
                linePaint.shader = LinearGradient(0f, 0f, w.coerceAtLeast(1f), 0f,
                    intArrayOf(adjustAlpha(blue, 0.22f), adjustAlpha(violet, 0.25f), adjustAlpha(aqua, 0.22f)),
                    null, Shader.TileMode.CLAMP)
            }
            fillPaint.color = adjustAlpha(cardFill, if (darkMode) 0.96f else 0.95f)
            canvas.drawRect(bounds, fillPaint)
            dotPaint.color = adjustAlpha(violet, if (darkMode) 0.12f else 0.06f)
            canvas.drawCircle(w * 0.86f, h * 0.22f, dp(22).toFloat(), dotPaint)
            dotPaint.color = adjustAlpha(sky, if (darkMode) 0.12f else 0.06f)
            canvas.drawCircle(w * 0.72f, h * 0.65f, dp(10).toFloat(), dotPaint)
            dotPaint.color = adjustAlpha(amber, if (darkMode) 0.22f else 0.16f)
            drawSparkle(canvas, w * 0.76f, h * 0.28f, dp(5).toFloat(), dotPaint, starPath)
            val lineH = dp(1).toFloat()
            canvas.drawRect(0f, h - lineH, w, h, linePaint)
        }
        override fun setAlpha(alpha: Int) {}
        override fun setColorFilter(colorFilter: ColorFilter?) {}
        @Suppress("OVERRIDE_DEPRECATION")
        @Deprecated("Deprecated in Java")
        override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
    }

    /** Clean elevated navigation dock with a delicate pearl top edge. */
    private fun bottomNavDrawable(): Drawable = object : Drawable() {
        private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var lastW = -1f
        private var lastDark = darkMode

        override fun draw(canvas: Canvas) {
            val w = bounds.width().toFloat()
            val h = bounds.height().toFloat()
            if (w <= 0f || h <= 0f) return
            if (w != lastW || lastDark != darkMode || linePaint.shader == null) {
                lastW = w; lastDark = darkMode
                linePaint.shader = LinearGradient(0f, 0f, w.coerceAtLeast(1f), 0f,
                    intArrayOf(adjustAlpha(border, 0.7f), adjustAlpha(violet, 0.26f), adjustAlpha(border, 0.7f)),
                    null, Shader.TileMode.CLAMP)
            }
            fillPaint.color = cardFill
            canvas.drawRect(bounds, fillPaint)
            canvas.drawRect(0f, 0f, w, dp(1).toFloat(), linePaint)
        }
        override fun setAlpha(alpha: Int) {}
        override fun setColorFilter(colorFilter: ColorFilter?) {}
        @Suppress("OVERRIDE_DEPRECATION")
        @Deprecated("Deprecated in Java")
        override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
    }

    /** Multi-stop gradient hero surface with luminous aurora glass sheen & 4-point sparkles. */
    private fun heroMeshDrawable(radiusDp: Int = 26): Drawable = object : Drawable() {
        private val meshPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val decoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
        private val strokeRim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val starPath = Path()
        private val clipPath = Path()
        private val rectF = RectF()
        private var lastW = -1f
        private var lastH = -1f
        private var lastDark = darkMode

        override fun draw(canvas: Canvas) {
            val w = bounds.width().toFloat()
            val h = bounds.height().toFloat()
            if (w <= 0f || h <= 0f) return
            rectF.set(bounds)
            val rad = if (radiusDp > 0) dp(radiusDp).toFloat() else 0f
            if (w != lastW || h != lastH || lastDark != darkMode || meshPaint.shader == null) {
                lastW = w; lastH = h; lastDark = darkMode
                val stops = if (darkMode) {
                    intArrayOf(Color.parseColor("#2E268C"), Color.parseColor("#6D28D9"), Color.parseColor("#B8185C"))
                } else {
                    intArrayOf(Color.parseColor("#5443FF"), Color.parseColor("#8B5CF6"), Color.parseColor("#EC4899"))
                }
                meshPaint.shader = LinearGradient(0f, 0f, w.coerceAtLeast(1f), h.coerceAtLeast(1f), stops, null, Shader.TileMode.CLAMP)
            }
            canvas.save()
            if (rad > 0f) {
                clipPath.reset()
                clipPath.addRoundRect(rectF, rad, rad, Path.Direction.CW)
                canvas.clipPath(clipPath)
            }
            canvas.drawRect(rectF, meshPaint)

            // Soft aurora highlights, diagonal glass sheen, rings & 4-point vector sparkles.
            decoPaint.style = Paint.Style.FILL
            decoPaint.color = Color.argb(42, 56, 189, 248)
            canvas.drawCircle(w * 0.90f, h * 0.14f, (w * 0.34f).coerceAtLeast(1f), decoPaint)
            decoPaint.color = Color.argb(38, 251, 191, 36)
            canvas.drawCircle(w * 0.08f, h * 0.90f, (w * 0.28f).coerceAtLeast(1f), decoPaint)
            decoPaint.color = Color.argb(26, 255, 255, 255)
            canvas.drawCircle(w * 0.20f, h * 0.08f, (w * 0.38f).coerceAtLeast(1f), decoPaint)

            decoPaint.style = Paint.Style.STROKE
            decoPaint.strokeWidth = dp(2).toFloat()
            decoPaint.color = Color.argb(58, 255, 255, 255)
            canvas.drawCircle(w * 0.84f, h * 0.26f, dp(32).toFloat(), decoPaint)
            decoPaint.color = Color.argb(34, 255, 255, 255)
            canvas.drawCircle(w * 0.84f, h * 0.26f, dp(52).toFloat(), decoPaint)

            decoPaint.style = Paint.Style.FILL
            decoPaint.color = Color.argb(125, 255, 255, 255)
            drawSparkle(canvas, w * 0.64f, h * 0.16f, dp(7).toFloat(), decoPaint, starPath)
            decoPaint.color = Color.argb(115, 253, 224, 71)
            drawSparkle(canvas, w * 0.14f, h * 0.22f, dp(5).toFloat(), decoPaint, starPath)
            decoPaint.color = Color.argb(95, 110, 231, 183)
            drawSparkle(canvas, w * 0.78f, h * 0.56f, dp(6).toFloat(), decoPaint, starPath)
            decoPaint.color = Color.argb(72, 255, 255, 255)
            canvas.drawCircle(w * 0.72f, h * 0.40f, dp(3).toFloat(), decoPaint)
            decoPaint.color = Color.argb(92, 52, 211, 153)
            canvas.drawRoundRect(w * 0.48f, h * 0.21f, w * 0.48f + dp(14), h * 0.21f + dp(5), dp(3).toFloat(), dp(3).toFloat(), decoPaint)
            canvas.restore()

            if (rad > 0f) {
                strokeRim.color = Color.argb(65, 255, 255, 255)
                strokeRim.strokeWidth = dp(1).toFloat()
                val inset = strokeRim.strokeWidth * 0.5f
                canvas.drawRoundRect(inset, inset, w - inset, h - inset, rad, rad, strokeRim)
            }
        }
        override fun setAlpha(alpha: Int) {}
        override fun setColorFilter(colorFilter: ColorFilter?) {}
        @Suppress("OVERRIDE_DEPRECATION")
        @Deprecated("Deprecated in Java")
        override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
    }

    /** Crisp card background with frosted pearl border, editorial header accent pill, and curated geometric motif. */
    private fun patternedCardDrawable(
        fill: Int,
        stroke: Int,
        accent: Int,
        secondary: Int,
        kind: PatternKind,
        radiusDp: Int = 22,
        topStripColors: IntArray? = null,
        headerPillColors: IntArray? = null
    ): Drawable = object : Drawable() {
        private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val patternPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
        private val stripPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val pillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val clipPath = Path()
        private val wavePath = Path()
        private val starPath = Path()
        private val rectF = RectF()
        private var lastW = -1f
        private var lastH = -1f
        private var lastDark = darkMode

        override fun draw(canvas: Canvas) {
            val w = bounds.width().toFloat()
            val h = bounds.height().toFloat()
            if (w <= 0f || h <= 0f) return
            rectF.set(bounds)
            val rad = dp(radiusDp).toFloat()
            clipPath.reset()
            clipPath.addRoundRect(rectF, rad, rad, Path.Direction.CW)

            fillPaint.color = fill
            canvas.drawRoundRect(rectF, rad, rad, fillPaint)

            canvas.save()
            canvas.clipPath(clipPath)

            // Soft ambient corner aura for glassmorphic depth.
            patternPaint.style = Paint.Style.FILL
            patternPaint.color = adjustAlpha(accent, if (darkMode) 0.08f else 0.045f)
            canvas.drawCircle(w - dp(18), dp(18).toFloat(), dp(42).toFloat(), patternPaint)
            patternPaint.color = adjustAlpha(secondary, if (darkMode) 0.06f else 0.035f)
            canvas.drawCircle(dp(22).toFloat(), h - dp(14), dp(34).toFloat(), patternPaint)

            val patAlpha = if (darkMode) 0.13f else 0.09f
            val patPrimary = adjustAlpha(accent, patAlpha)
            val patSecondary = adjustAlpha(secondary, patAlpha)
            when (kind) {
                PatternKind.DOTS -> {
                    patternPaint.style = Paint.Style.FILL
                    val gap = dp(12).toFloat()
                    for (row in 0..2) {
                        for (col in 0..4) {
                            val cx = w - dp(12) - col * gap - if (row % 2 == 1) gap * 0.5f else 0f
                            val cy = dp(14) + row * gap
                            patternPaint.color = if ((row + col) % 2 == 0) patPrimary else patSecondary
                            canvas.drawCircle(cx, cy, dp(2).toFloat(), patternPaint)
                        }
                    }
                }
                PatternKind.STRIPES -> {
                    patternPaint.style = Paint.Style.STROKE
                    patternPaint.strokeWidth = dp(4).toFloat()
                    val step = dp(13).toFloat()
                    var sx = w - dp(72)
                    var i = 0
                    while (sx < w + dp(32)) {
                        patternPaint.color = if (i % 2 == 0) patPrimary else patSecondary
                        canvas.drawLine(sx, -dp(6).toFloat(), sx + dp(40), dp(34).toFloat(), patternPaint)
                        sx += step
                        i++
                    }
                }
                PatternKind.RINGS -> {
                    patternPaint.style = Paint.Style.STROKE
                    patternPaint.strokeWidth = dp(2).toFloat()
                    val cy = dp(14).toFloat()
                    patternPaint.color = patPrimary
                    canvas.drawCircle(w - dp(12), cy, dp(16).toFloat(), patternPaint)
                    patternPaint.color = patSecondary
                    canvas.drawCircle(w - dp(12), cy, dp(28).toFloat(), patternPaint)
                    patternPaint.color = adjustAlpha(accent, patAlpha * 0.65f)
                    canvas.drawCircle(w - dp(12), cy, dp(40).toFloat(), patternPaint)
                }
                PatternKind.CHECKER -> {
                    patternPaint.style = Paint.Style.FILL
                    val cell = dp(9).toFloat()
                    val gap = dp(12).toFloat()
                    for (r in 0..2) {
                        for (c in 0..3) {
                            if ((r + c) % 2 == 0) {
                                patternPaint.color = if (r % 2 == 0) adjustAlpha(accent, patAlpha * 0.85f) else adjustAlpha(secondary, patAlpha * 0.85f)
                                val x0 = w - dp(10) - (c + 1) * gap
                                val y0 = dp(10) + r * gap
                                canvas.drawRoundRect(x0, y0, x0 + cell, y0 + cell, dp(3).toFloat(), dp(3).toFloat(), patternPaint)
                            }
                        }
                    }
                }
                PatternKind.CONFETTI -> {
                    patternPaint.style = Paint.Style.FILL
                    val palette = intArrayOf(
                        adjustAlpha(accent, patAlpha * 1.45f),
                        adjustAlpha(secondary, patAlpha * 1.45f),
                        adjustAlpha(amber, patAlpha * 1.45f),
                        adjustAlpha(aqua, patAlpha * 1.45f)
                    )
                    val pts = arrayOf(0.76f to 0.14f, 0.88f to 0.09f, 0.94f to 0.22f, 0.82f to 0.28f, 0.68f to 0.11f)
                    pts.forEachIndexed { idx, (px, py) ->
                        patternPaint.color = palette[idx % palette.size]
                        val cx = w * px
                        val cy = h * py
                        if (idx % 2 == 0) {
                            canvas.drawCircle(cx, cy, dp(3).toFloat(), patternPaint)
                        } else {
                            canvas.drawRoundRect(cx - dp(6), cy - dp(2), cx + dp(6), cy + dp(2), dp(2).toFloat(), dp(2).toFloat(), patternPaint)
                        }
                    }
                }
                PatternKind.WAVES -> {
                    patternPaint.style = Paint.Style.STROKE
                    patternPaint.strokeWidth = dp(2).toFloat()
                    val yBase = h - dp(14)
                    for (layer in 0..1) {
                        patternPaint.color = if (layer == 0) patPrimary else patSecondary
                        wavePath.reset()
                        val dy = yBase + layer * dp(6)
                        wavePath.moveTo(0f, dy)
                        wavePath.cubicTo(w * 0.25f, dy - dp(8), w * 0.50f, dy + dp(8), w * 0.75f, dy - dp(5))
                        wavePath.quadTo(w * 0.90f, dy - dp(10), w, dy + dp(3))
                        canvas.drawPath(wavePath, patternPaint)
                    }
                }
                PatternKind.SPARKLES -> {
                    patternPaint.style = Paint.Style.FILL
                    patternPaint.color = adjustAlpha(accent, patAlpha * 1.6f)
                    drawSparkle(canvas, w - dp(24), dp(22).toFloat(), dp(7).toFloat(), patternPaint, starPath)
                    patternPaint.color = adjustAlpha(secondary, patAlpha * 1.5f)
                    drawSparkle(canvas, w - dp(44), dp(16).toFloat(), dp(4).toFloat(), patternPaint, starPath)
                    patternPaint.color = adjustAlpha(amber, patAlpha * 1.4f)
                    canvas.drawCircle(w - dp(18), dp(42).toFloat(), dp(2).toFloat(), patternPaint)
                    canvas.drawCircle(w - dp(36), dp(36).toFloat(), dp(3).toFloat(), patternPaint)
                }
            }

            if (headerPillColors != null && headerPillColors.isNotEmpty()) {
                val pColors = if (headerPillColors.size == 1) intArrayOf(headerPillColors[0], headerPillColors[0]) else headerPillColors
                pillPaint.shader = LinearGradient(dp(18).toFloat(), 0f, dp(54).toFloat(), 0f, pColors, null, Shader.TileMode.CLAMP)
                canvas.drawRoundRect(dp(18).toFloat(), dp(13).toFloat(), dp(52).toFloat(), dp(17).toFloat(), dp(2).toFloat(), dp(2).toFloat(), pillPaint)
                pillPaint.shader = null
            }

            if (topStripColors != null && topStripColors.isNotEmpty()) {
                if (w != lastW || h != lastH || lastDark != darkMode || stripPaint.shader == null) {
                    lastW = w; lastH = h; lastDark = darkMode
                    val colors = if (topStripColors.size == 1) intArrayOf(topStripColors[0], topStripColors[0]) else topStripColors
                    val softTop = colors.map { adjustAlpha(it, if (darkMode) 0.11f else 0.06f) }.toIntArray()
                    stripPaint.shader = LinearGradient(0f, 0f, w.coerceAtLeast(1f), 0f, softTop, null, Shader.TileMode.CLAMP)
                    val borderColors = colors.map { adjustAlpha(it, if (darkMode) 0.44f else 0.36f) }.toIntArray()
                    strokePaint.shader = LinearGradient(0f, 0f, w.coerceAtLeast(1f), h.coerceAtLeast(1f) * 0.4f, borderColors, null, Shader.TileMode.CLAMP)
                }
                canvas.drawRect(0f, 0f, w, dp(9).toFloat(), stripPaint)
            }
            // Subtle top specular highlight along the upper edge.
            patternPaint.style = Paint.Style.STROKE
            patternPaint.strokeWidth = dp(1).toFloat()
            patternPaint.color = Color.argb(if (darkMode) 28 else 140, 255, 255, 255)
            canvas.drawLine(rad * 0.65f, dp(1).toFloat(), (w - rad * 0.65f).coerceAtLeast(rad * 0.65f), dp(1).toFloat(), patternPaint)
            canvas.restore()

            if (topStripColors != null && topStripColors.isNotEmpty()) {
                strokePaint.strokeWidth = dp(1).toFloat() * 1.4f
                val inset = strokePaint.strokeWidth * 0.5f
                canvas.drawRoundRect(inset, inset, w - inset, h - inset, (rad - inset).coerceAtLeast(1f), (rad - inset).coerceAtLeast(1f), strokePaint)
            } else if (stroke != Color.TRANSPARENT) {
                strokePaint.shader = null
                strokePaint.color = stroke
                strokePaint.strokeWidth = dp(1).toFloat()
                val inset = dp(1).toFloat() * 0.5f
                canvas.drawRoundRect(inset, inset, w - inset, h - inset, rad, rad, strokePaint)
            }
        }
        override fun setAlpha(alpha: Int) {}
        override fun setColorFilter(colorFilter: ColorFilter?) {}
        @Suppress("OVERRIDE_DEPRECATION")
        @Deprecated("Deprecated in Java")
        override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
    }

    /** Multi-hue circular loading ring visible both at frame zero and while spinning on launch. */
    private fun splashSpinnerDrawable(): Drawable = object : Drawable() {
        private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
        }
        private val arcRect = RectF()
        private var lastSize = -1f
        private var lastDark = darkMode

        override fun draw(canvas: Canvas) {
            val w = bounds.width().toFloat()
            val h = bounds.height().toFloat()
            val size = minOf(w, h)
            if (size <= 0f) return
            val strokeW = (size * 0.14f).coerceAtLeast(dp(3).toFloat())
            val pad = strokeW * 0.6f
            val cx = bounds.exactCenterX()
            val cy = bounds.exactCenterY()
            val radius = (size * 0.5f - pad).coerceAtLeast(1f)
            arcRect.set(cx - radius, cy - radius, cx + radius, cy + radius)

            trackPaint.strokeWidth = strokeW
            trackPaint.color = if (darkMode) Color.parseColor("#2B3154") else Color.parseColor("#E5E1FF")
            canvas.drawCircle(cx, cy, radius, trackPaint)

            if (size != lastSize || lastDark != darkMode || arcPaint.shader == null) {
                lastSize = size; lastDark = darkMode
                arcPaint.shader = SweepGradient(cx, cy, intArrayOf(blue, violet, coral, aqua, blue), null)
            }
            arcPaint.strokeWidth = strokeW
            canvas.drawArc(arcRect, -90f, 255f, false, arcPaint)
        }
        override fun setAlpha(alpha: Int) {}
        override fun setColorFilter(colorFilter: ColorFilter?) {}
        @Suppress("OVERRIDE_DEPRECATION")
        @Deprecated("Deprecated in Java")
        override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
    }

    private fun toast(message: String) {
        runCatching { Toast.makeText(applicationContext, message, Toast.LENGTH_LONG).show() }
    }
    private fun dp(value: Int): Int = (resources.displayMetrics.density * value).toInt()
}
