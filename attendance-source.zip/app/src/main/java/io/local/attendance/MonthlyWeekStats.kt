package io.local.attendance

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.TemporalAdjusters

/** Calendar-aligned weeks (Monday–Sunday), not fixed 1–7 day buckets. */
data class CalendarWeek(
    val number: Int,
    val firstDay: LocalDate,
    val lastDay: LocalDate,
    val minutes: Int,
    val sharePercent: Double
)

object MonthlyWeekStats {
    const val FIRST_YEAR = 2000
    const val LAST_YEAR = 2100

    fun supported(month: YearMonth): Boolean = month.year in FIRST_YEAR..LAST_YEAR

    /** Each week is clipped to the selected month; 4–6 rows depending on the calendar. */
    fun weeks(month: YearMonth, records: List<WorkRecord>): List<CalendarWeek> {
        require(supported(month)) { "Supported calendar years: $FIRST_YEAR..$LAST_YEAR" }
        val start = month.atDay(1)
        val end = month.atEndOfMonth()
        val alignedStart = start.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val daily = records.asSequence()
            .filter { it.valid }
            .mapNotNull { row -> runCatching { LocalDate.parse(row.date) }.getOrNull()?.let { it to row.minutes } }
            .filter { (date, _) -> !date.isBefore(start) && !date.isAfter(end) }
            .groupBy({ it.first }, { it.second })
            .mapValues { (_, minutes) -> minutes.sum() }
        val total = daily.values.sum()
        val weeks = mutableListOf<CalendarWeek>()
        var cursor = alignedStart
        while (!cursor.isAfter(end)) {
            val first = if (cursor.isBefore(start)) start else cursor
            val sunday = cursor.plusDays(6)
            val last = if (sunday.isAfter(end)) end else sunday
            var minutes = 0
            var day = first
            while (!day.isAfter(last)) {
                minutes += daily[day] ?: 0
                day = day.plusDays(1)
            }
            weeks += CalendarWeek(weeks.size + 1, first, last, minutes,
                if (total > 0) minutes * 100.0 / total else 0.0)
            cursor = cursor.plusDays(7)
        }
        return weeks
    }
}
