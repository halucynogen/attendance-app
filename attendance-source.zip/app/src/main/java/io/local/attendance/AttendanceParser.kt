package io.local.attendance

import java.time.LocalDate
import java.time.YearMonth

/** Android-independent parser. Only explicitly reported start/end times are recorded. */
data class WorkRecord(
    val date: String,
    val start: String,
    val end: String,
    val reportedMinutes: Int? = null,
    val status: String = "",
    val breakStart: String? = null,
    val breakEnd: String? = null
) {
    /** Scheduled time before subtracting explicitly listed meal/rest periods. */
    val grossMinutes: Int get() {
        val a = parseTime(start) ?: return 0
        val b = parseTime(end) ?: return 0
        return b - a
    }
    /** Only deduct a rest period when BOTH ends are present and inside this shift. */
    val breakMinutes: Int get() {
        val startMin = parseTime(start) ?: return 0
        val endMin = parseTime(end) ?: return 0
        val bStart = parseTime(breakStart ?: return 0) ?: return 0
        val bEnd = parseTime(breakEnd ?: return 0) ?: return 0
        return if (startMin <= bStart && bStart < bEnd && bEnd <= endMin) bEnd - bStart else 0
    }
    /** Net time, not the 09:00–18:00 raw span when lunch 12:00–13:00 is listed. */
    val minutes: Int get() = grossMinutes - breakMinutes
    val valid: Boolean get() = runCatching { LocalDate.parse(date) }.isSuccess &&
        parseTime(start) != null && parseTime(end) != null && minutes > 0
    val key: String get() = "$date|$start|$end"
    val differentFromReported: Boolean get() = reportedMinutes != null && reportedMinutes != minutes
}

private fun parseTime(value: String): Int? {
    val m = Regex("^(\\d{1,2}):(\\d{2})$").matchEntire(value.trim()) ?: return null
    val h = m.groupValues[1].toInt()
    val min = m.groupValues[2].toInt()
    return if (h in 0..23 && min in 0..59) h * 60 + min else null
}

object AttendanceParser {
    private val monthPattern = Regex("(?<!\\d)(\\d{4})\\s*[./-]\\s*(0?[1-9]|1[0-2])(?!\\s*[./-]\\s*\\d)(?!\\d)")
    // No match inside 2026.09.10 (the screenshot's work-site period).
    private val shortDate = Regex("(?<![\\d.])(0?[1-9]|1[0-2])\\s*[./]\\s*([0-3]?\\d)(?!\\d)")
    private val fullDate = Regex("(?<!\\d)(\\d{4})\\s*[./-]\\s*(0?[1-9]|1[0-2])\\s*[./-]\\s*([0-3]?\\d)(?!\\d)")
    private val workTime = Regex("근무\\s*([01]?\\d|2[0-3]):([0-5]\\d)\\s*[~～〜∼–—-]\\s*([01]?\\d|2[0-3]):([0-5]\\d)")
    private val plainTime = Regex("(?<!\\d)([01]?\\d|2[0-3]):([0-5]\\d)\\s*[~～〜∼–—-]\\s*([01]?\\d|2[0-3]):([0-5]\\d)")
    private val reported = Regex("(\\d{1,2})\\s*시간\\s*(\\d{1,2})\\s*분")
    // The official attendance list can show "식사 12:00 ~ 13:00" underneath a 09:00–18:00 shift.
    // A break must be explicitly labeled, never inferred from the 8-hour displayed total.
    private val restTime = Regex("(?:식사(?:시간)?|휴게(?:시간)?|휴식(?:시간)?)\\s*[:：]?\\s*([01]?\\d|2[0-3]):([0-5]\\d)\\s*[~～〜∼–—-]\\s*([01]?\\d|2[0-3]):([0-5]\\d)")
    private val shownField = Regex("표시시간\\s*(\\d{1,2})\\s*시간\\s*(\\d{1,2})\\s*분")
    private val statusPattern = Regex("기관\\s*확인\\s*전|기관\\s*확인\\s*완료|미\\s*완료")
    private val manualLine = Regex("(?m)^\\s*(\\d{4})[-./](\\d{1,2})[-./](\\d{1,2})\\s+([0-2]?\\d:[0-5]\\d)\\s*[~～〜∼–—-]\\s*([0-2]?\\d:[0-5]\\d)")

    private fun normalize(text: String): String = text
        .replace('\u00a0', ' ')
        .replace("\r", "")
        .replace(Regex("(?<=\\d)\\s*[:：]\\s*(?=\\d)"), ":")
        .replace(Regex("기관\\s+확인"), "기관확인")
        .replace(Regex("미\\s+완료"), "미완료")
        .replace(Regex("(?<!\\d)[Oo](?=\\d[:：])"), "0")

    private fun canonicalStatus(value: String): String {
        return when (value.replace(Regex("\\s+"), "")) {
            "기관확인전" -> "기관확인 전"
            "기관확인완료" -> "기관확인 완료"
            "미완료" -> "미완료"
            else -> value.trim()
        }
    }


    fun monthHeader(text: String): YearMonth? {
        val m = monthPattern.find(normalize(text)) ?: return null
        return runCatching { YearMonth.of(m.groupValues[1].toInt(), m.groupValues[2].toInt()) }
            .getOrNull()?.takeIf { it.year in 1..9999 }
    }

    /** For pasted text, accessibility tree pages, or OCR output. */
    fun fromListPage(text: String, selectedMonth: YearMonth): List<WorkRecord> {
        val normalized = normalize(text)
        val candidates = mutableListOf<Pair<Int, LocalDate>>()
        // Explicit full dates used by the editable export view.
        fullDate.findAll(normalized).forEach { m ->
            // Placement start dates such as "2026.09.10 ~" are not attendance rows.
            val trailing = normalized.substring(m.range.last + 1).take(8).trimStart()
            if (trailing.startsWith("~") || trailing.startsWith("～")) return@forEach
            val d = runCatching {
                LocalDate.of(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3].toInt())
            }.getOrNull()
            if (d != null && YearMonth.from(d) == selectedMonth) candidates += m.range.first to d
        }
        shortDate.findAll(normalized).forEach { m ->
            // Full-date patterns are already covered. Reject their inner fragments.
            if (candidates.any { (index, _) -> index <= m.range.first && m.range.first - index <= 10 }) return@forEach
            val mth = m.groupValues[1].toInt()
            val day = m.groupValues[2].toInt()
            if (mth != selectedMonth.monthValue) return@forEach
            val d = runCatching { LocalDate.of(selectedMonth.year, mth, day) }.getOrNull()
            if (d != null) candidates += m.range.first to d
        }
        val dates = candidates.distinctBy { it.first }.sortedBy { it.first }
        val result = mutableListOf<WorkRecord>()
        for (i in dates.indices) {
            val (begin, date) = dates[i]
            val end = dates.getOrNull(i + 1)?.first ?: normalized.length
            val section = normalized.substring(begin, end)
            val compact = section.replace(Regex("\\s+"), " ")
            val matches = workTime.findAll(compact).toList()
            val rests = restTime.findAll(compact).toList()
            // On OCR fallbacks, don't accidentally treat "식사 12:00~13:00" as a second shift.
            val timeMatches = if (matches.isEmpty()) {
                plainTime.findAll(compact).filter { t -> rests.none { r -> t.range.first in r.range } }.toList()
            } else matches
            val shownMinutes = reported.find(compact)?.let { it.groupValues[1].toInt() * 60 + it.groupValues[2].toInt() }
            // The actual monthly list places the status badge ABOVE the date at the right.
            val beforeFirstTime = compact.take(timeMatches.firstOrNull()?.range?.first ?: 0)
            val inlineState = statusPattern.find(beforeFirstTime)?.value.orEmpty()
            val precedingText = normalized.take(begin)
            val lastTimeEnd = plainTime.findAll(precedingText).lastOrNull()?.range?.last?.plus(1) ?: 0
            val lookBehind = precedingText.substring(maxOf(lastTimeEnd, begin - 260))
            val leadingState = statusPattern.findAll(lookBehind).lastOrNull()?.value.orEmpty()
            val state = canonicalStatus(inlineState.ifBlank { leadingState })
            timeMatches.forEachIndexed { index, match ->
                val (h1, m1, h2, m2) = match.destructured
                val nextStart = timeMatches.getOrNull(index + 1)?.range?.first ?: compact.length
                val rest = rests.firstOrNull { it.range.first >= match.range.last + 1 && it.range.first < nextStart }
                    ?: if (timeMatches.size == 1) rests.firstOrNull() else null
                val record = WorkRecord(
                    date.toString(),
                    "${h1.padStart(2, '0')}:$m1",
                    "${h2.padStart(2, '0')}:$m2",
                    if (timeMatches.size == 1) shownMinutes else null,
                    state,
                    rest?.let { "${it.groupValues[1].padStart(2, '0')}:${it.groupValues[2]}" },
                    rest?.let { "${it.groupValues[3].padStart(2, '0')}:${it.groupValues[4]}" }
                )
                if (record.valid) result += record
            }
        }
        return unique(result)
    }

    /** Merge one previous screen to recover a date or time split across a scroll boundary. */
    fun fromOverlappingPages(previousPage: String, currentPage: String, month: YearMonth): List<WorkRecord> {
        val current = fromListPage(currentPage, month)
        if (previousPage.isBlank()) return current
        val bridged = fromListPage(previousPage.takeLast(2600) + "\n" + currentPage, month)
        return unique(current + bridged)
    }

    fun fromText(text: String, fallbackMonth: YearMonth): List<WorkRecord> =
        fromListPage(text, monthHeader(text) ?: fallbackMonth)

    fun fromDetail(text: String, date: LocalDate): List<WorkRecord> =
        fromListPage("${date.monthValue}.${date.dayOfMonth}\n$text", YearMonth.from(date))

    /** For replacing one month's saved records after editing plain export lines. */
    fun fromEditableText(text: String, month: YearMonth): List<WorkRecord> {
        val source = normalize(text)
        val matches = manualLine.findAll(source).toList()
        return unique(matches.mapIndexedNotNull { index, m ->
            val date = runCatching {
                LocalDate.of(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3].toInt())
            }.getOrNull()
            if (date == null || YearMonth.from(date) != month) return@mapIndexedNotNull null
            val endIndex = matches.getOrNull(index + 1)?.range?.first ?: source.length
            val detail = source.substring(m.range.last + 1, endIndex)
            val rest = restTime.find(detail)
            val display = shownField.find(detail)
            WorkRecord(
                date.toString(), m.groupValues[4], m.groupValues[5],
                display?.let { it.groupValues[1].toInt() * 60 + it.groupValues[2].toInt() },
                canonicalStatus(statusPattern.find(detail)?.value.orEmpty()),
                rest?.let { "${it.groupValues[1].padStart(2, '0')}:${it.groupValues[2]}" },
                rest?.let { "${it.groupValues[3].padStart(2, '0')}:${it.groupValues[4]}" }
            ).takeIf { it.valid }
        })
    }

    fun unique(records: List<WorkRecord>): List<WorkRecord> =
        records.filter { it.valid }.groupBy { it.key }.values.map { versions ->
            // Re-importing the same shift with an explicit lunch break upgrades older saved rows.
            versions.maxByOrNull { (if (it.breakMinutes > 0) 4 else 0) + (if (it.reportedMinutes != null) 2 else 0) + (if (it.status.isNotEmpty()) 1 else 0) }!!
        }.sortedWith(compareBy(WorkRecord::date, WorkRecord::start, WorkRecord::end))

    fun export(records: List<WorkRecord>, month: YearMonth): String {
        val entries = unique(records).filter { it.date.startsWith(month.toString()) }
        if (entries.isEmpty()) return "$month 근무 내역\n\n수집된 근무기록이 없습니다. 누락 여부를 확인하세요."
        val body = entries.joinToString("\n") { r ->
            val shown = r.reportedMinutes?.let { " / 표시시간 ${it / 60}시간 ${it % 60}분" }.orEmpty()
            val rest = if (r.breakMinutes > 0) " / 식사 ${r.breakStart} ~ ${r.breakEnd} (${r.breakMinutes}분 차감)" else ""
            val state = if (r.status.isNotBlank()) " / ${r.status}" else ""
            val warn = if (r.differentFromReported) " / ⚠ 시간 차이 확인 · 휴게 누락 여부 점검" else ""
            "${r.date}  ${r.start} ~ ${r.end} (${r.minutes / 60}시간 ${r.minutes % 60}분)$rest$shown$state$warn"
        }
        val total = entries.sumOf { it.minutes }
        val mismatch = entries.count { it.differentFromReported }
        val shownTotal = entries.sumOf { it.reportedMinutes ?: it.minutes }
        val deducted = entries.sumOf { it.breakMinutes }
        return "$month 근무 내역\n\n$body\n\n실제 근무 계산 합계 (명시된 식사/휴게 차감): ${total / 60}시간 ${total % 60}분\n" +
            "목록 표시시간 기준 합계 (표시 없는 건은 계산값): ${shownTotal / 60}시간 ${shownTotal % 60}분\n" +
            "식사/휴게 차감 합계: ${deducted / 60}시간 ${deducted % 60}분\n" +
            "표시시간 불일치: ${mismatch}건\n※ 공식 월간 예상 근로시간·제외/인정시간과 다를 수 있습니다. 원본 확인 필요"
    }

    /** Complete clipboard/share payload; never reduce a month to just its total. */
    fun monthlyShareText(records: List<WorkRecord>, month: YearMonth): String {
        val entries = unique(records).filter { it.date.startsWith(month.toString()) }
        val total = entries.sumOf { it.minutes }
        val breakTotal = entries.sumOf { it.breakMinutes }
        val mismatch = entries.count { it.differentFromReported }
        val body = if (entries.isEmpty()) "저장된 근무기록이 없습니다." else entries.joinToString("\n") { record ->
            buildString {
                append(record.date).append("  ").append(record.start).append(" ~ ").append(record.end)
                append("  (실근무 ").append(record.minutes / 60).append("시간 ").append(record.minutes % 60).append("분)")
                if (record.breakMinutes > 0) {
                    append(" / 식사·휴게 ").append(record.breakStart).append(" ~ ")
                        .append(record.breakEnd).append(" (차감 ").append(record.breakMinutes).append("분)")
                }
                record.reportedMinutes?.let { append(" / 화면 표시 ").append(it / 60).append("시간 ").append(it % 60).append("분") }
                if (record.status.isNotBlank()) append(" / ").append(record.status)
                if (record.differentFromReported) append(" / ⚠ 표시시간 확인 필요")
            }
        }
        return buildString {
            append(month.year).append("년 ").append(month.monthValue).append("월 근무기록 전체\n")
            append("근무 ").append(entries.size).append("건 · 계산 합계 ")
                .append(total / 60).append("시간 ").append(total % 60).append("분\n")
            append("식사·휴게 차감 ").append(breakTotal / 60).append("시간 ")
                .append(breakTotal % 60).append("분 · 표시시간 확인 ").append(mismatch).append("건\n\n")
            append(body)
            append("\n\n※ 공식 출근부의 인정·예상 시간과 다를 수 있으니 원본을 확인하세요.")
        }
    }

    fun csv(records: List<WorkRecord>, month: YearMonth): String {
        fun q(s: String): String {
            val safe = if (s.firstOrNull() in listOf('=', '+', '-', '@', '\t', '\r')) "'" + s else s
            return "\"" + safe.replace("\"", "\"\"") + "\""
        }
        return "날짜,시작,종료,시각차이분,화면표시분,상태,시간불일치,식사시작,식사종료,식사차감분,계산근무분\n" +
            unique(records).filter { it.date.startsWith(month.toString()) }.joinToString("\n") { r ->
                listOf(
                    r.date,
                    r.start,
                    r.end,
                    r.grossMinutes.toString(),
                    r.reportedMinutes?.toString().orEmpty(),
                    r.status,
                    if (r.differentFromReported) "확인 필요" else "",
                    r.breakStart.orEmpty(),
                    r.breakEnd.orEmpty(),
                    r.breakMinutes.toString(),
                    r.minutes.toString()
                ).joinToString(",") { q(it) }
            }
    }
}
