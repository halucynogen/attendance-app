# v0.4 독립 테스트 결과

- `kotlinc AttendanceParser.kt tests/ParserTest.kt` → 11건 통과
- `kotlinc AttendanceParser.kt tests/ExtendedParserTest.kt` → 33개 테스트 그룹 통과 + 330개 날짜/시각 조합 통과
- 새 회귀 테스트: `2026.09.10 ~` 근로기관 기간이 월로 오인식되지 않음, `10.19` 등 10월 목록 6건 파싱, 20시간 계산 확인
- 실제 한국장학재단 앱과 접근성 서비스의 컴파일·실행/스크롤 및 OCR 인식은 현 환경에서 검증 불가
- 주의: 앱의 접근성 자동 OFF 동작은 Android API `AccessibilityService.disableSelf()`를 사용하도록 구현했지만 실기기 확인 전
