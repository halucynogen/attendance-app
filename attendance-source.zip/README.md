# 근무로그 V1.8 수정본

기존 패키지·저장 형식·홈/기록/통계/설정 4개 탭과 기능을 유지했습니다.
기존 GitHub 워크플로와 호환되도록 버전은 **1.8.0 / 180**입니다.

## 바뀐 화면과 동작

- 설정 맨 위에 실제 버튼 이름을 따라가는 4단계 시작 안내를 배치했습니다.
- 근무로그를 열고 최근 앱에 남겨 둔 동안에만 공식 출근부에 수집 메뉴를 표시합니다. 실행 종료·최근 앱 제거 시 메뉴와 수집이 멈춥니다. 접근성 서비스가 단독 재연결되어도 앱을 열기 전에는 수집 메뉴가 나오지 않습니다.
- 앱 내 업데이트 기록을 제거했습니다. 현재 버전은 설정의 기록 관리에서 확인합니다.
- 중립적인 배경·파란 포인트·여백으로 화면을 정리했습니다. 근무 다이어리는 근무일과 오늘을 구분합니다. 다크 모드와 기존 편집 스크롤바는 유지했습니다.
- 새로 실행할 때 OS 시작 화면을 약 2초 유지합니다. 백그라운드 복귀·회전·날짜 바로가기에서는 추가 대기 화면을 띄우지 않습니다.
- 사용자 동의를 받아 직접 수정·삭제한 마지막 1회 되돌리기를 추가했습니다.
- Android 16 뒤로 가기와 구형 Android용 여백·테마 호환성을 보완했습니다.

## 처음 가져오기

1. **홈 → 조회 기간**에서 연도·월을 입력하고 **이 연도 · 월 적용**을 누르세요.
2. **설정 → 처음 시작하기 → 접근성 설정 열기**를 누르세요. 안내에 동의하고 Android의 **설치된 앱/다운로드한 앱 → 근무로그 → 사용**을 켜세요. 뒤로 가기로 근무로그에 돌아오세요.
3. **한국장학재단 출근부 열기**로 공식 앱에 로그인하세요. 같은 월을 조회하고 날짜·출퇴근 시각이 보이는 목록을 여세요. 근무로그는 최근 앱에서 지우지 마세요.
4. 떠 있는 메뉴의 **목록 수집**을 누르세요. 완료 표시 후 근무로그의 **기록·통계**에서 확인하세요. 중간에 멈출 때는 **수집 중지**입니다.

접근성 스위치를 켤 수 없고 ‘제한된 설정’이 나오면 **설정 → 설치·권한 도움말 → 근무로그 앱 설정 열기 → ⋮ → 제한된 설정 허용**을 확인하세요. Android 13 이상에서 필요할 수 있고 기기마다 메뉴가 다릅니다. 접근성이 없어도 기존 붙여넣기·직접 편집을 이용할 수 있습니다.

## 실행 상태와 권한

Android가 보관하는 접근성 권한 자체를 앱 종료 때 강제로 끄지는 않습니다. 앱에서 연 실행 세션과 Android 작업 목록을 함께 확인해 메뉴·읽기·수집·스크롤을 차단합니다. 최근 앱 제거는 다음 화면 이벤트 또는 약 1초 주기 확인에서 반영됩니다. 프로세스가 재시작되면 앱을 직접 다시 열어야 합니다.

실제 OCR·화면 캡처는 사용하지 않으며, 한국장학재단 출근부의 접근성 텍스트만 읽습니다. 서버로 전송하지 않습니다.

## 마지막 변경 되돌리기

**수정 저장** 또는 **이 달 기록 삭제**가 성공하면 해당 월의 변경 전·후 내역을 메모리에 1회분만 보관합니다. **기록 → 내보내기 · 기록 관리 → 마지막 변경 되돌리기**에서 확인 후 복원합니다. 복구할 내용이 있을 때만 해당 월에 버튼이 나옵니다.

- 다른 월은 유지합니다. 해당 월에 이후 수집·추가·변경이 있으면 복원을 차단해 최신 기록을 보호합니다.
- 다음 직접 수정·삭제가 이전 복원 내용을 대체합니다. 되돌리기 자체를 다시 되돌리지는 않습니다.
- 앱 실행·프로세스 종료 시 임시 내용이 사라집니다. TXT/CSV 백업을 대신하지 않습니다.
- 기존 저장 형식과 위치는 바뀌지 않습니다.

## 기존 GitHub에서 빌드

배포 묶음의 **attendance-source.zip**을 저장소 최상단의 같은 파일로 교체하세요. 기존 **.github/workflows/build-apk.yml**, **build-signed-release.yml**은 수정 없이 사용합니다. 배포 묶음에도 원본 그대로 들어 있습니다.

**Actions → Build Android APK → Run workflow**로 디버그 APK를 만드세요. 기존 설치본 업데이트에는 **Build Signed Attendance APK**와 기존 서명키를 사용하세요. 삭제 후 재설치하면 저장 기록이 사라질 수 있습니다.

## 개발 검증

일반 APK 빌드는 기존과 같은 Java 17·Gradle 8.13·Android SDK 36입니다.

```text
gradle :app:assembleDebug :app:assembleRelease :app:lintDebug
python3 tests/V16BuildPreflight.py
python3 tests/V17InlineEditorScrollBarRegressionTest.py
python3 tests/V18ClassicScrollbarRegressionTest.py
```

Android 8·15·16 테스트 런타임을 사용하는 검사는 **Java 21**에서 `gradle :app:testDebugUnitTest`로 실행하세요. API 36 테스트 런타임에 Java 21이 필요합니다. 앱의 최소 Android 버전이나 기존 APK 빌드 Java 버전을 바꾸는 것은 아닙니다. 테스트 라이브러리는 APK에 포함되지 않습니다.

기존 Kotlin 파서·공유·연도·주차·수집 상태 테스트 7개는 Gradle이 JUnit 래퍼를 생성해 함께 실행합니다. 실제 Android View 렌더는 `app/build/reports/ui-preview`에 생성됩니다. 완료 결과와 실기기 확인 범위는 [검사 보고서](VALIDATION_KO.md)를 확인하세요.

## 참고 문서

- [Android 콘텐츠 구성과 간격](https://developer.android.com/design/ui/mobile/guides/layout-and-content/content-structure)
- [Android 레이아웃과 탐색](https://developer.android.com/design/ui/mobile/guides/layout-and-content/layout-and-nav-patterns)
- [Android 시작 화면](https://developer.android.com/develop/ui/views/launch/splash-screen)
- [Android 앱 작업 목록 API](https://developer.android.com/reference/android/app/ActivityManager#getAppTasks())
