# 근무로그 V1.8 — Spatial Quantum Solar HUD 업그레이드판

기존 패키지(`io.local.attendance`)·저장 형식·홈/기록/통계/설정 4개 탭과 원래 기능을 모두 그대로 보존하면서 **Spatial Quantum HUD — Quantum Solar System** 디자인과 안정성을 전면 개선했습니다.
기존 GitHub 워크플로와 호환되도록 버전은 **1.8.0 / 180**입니다.

## 주요 디자인 및 UX 개선 (`Spatial Quantum HUD`)

- **태양계 행성 컨셉 매핑**:
  - **홈 (`태양계 중심 HUD`)**: 중앙 태양 코어·양자 원자 오르빗·회전 눈금 링(`QuantumSolarSystemView`)과 지구·화성·수성·토성 궤도, 월 목표·한도 시간 게이지, 기존 V1.8 빠른 실행·`근무 캘린더에서 날짜별 보기`·`전체 날짜·시각 복사`·`기록 확인`·`처음 사용하시나요?` 안내를 모두 유지했습니다.
  - **기록 (`화성·지구 궤도 기록`)**: 캘린더 다이어리, 텍스트 붙여넣기, 추출 결과 미리보기·인라인 수정 및 클래식 고정 실버 스크롤바(`recordScrollRail`), CSV/TXT 내보내기, 직전 변경 되돌리기.
  - **통계 (`토성 궤도 통계`)**: 주차별 근무 비중을 수성~토성 궤도로 매핑한 `PlanetaryOrbitStripView`와 이중 양자 웨이브 + 스펙트럼 막대(`WeeklyFlowView`), 최근 6개월 비교, 월간 근무 다이어리.
  - **설정 (`해왕성 시스템 제어`)**: **3가지 화면 모드(`시스템 자동` · `라이트` · `다크`)**, 기본으로 펼쳐진 4단계 `처음 시작하기`, `설치·권한 도움말`, 접근성 권한 관리.
  - **떠 있는 위성 수집기 (`Lunar Satellite HUD`)**: 전체 표면 드래그, 길게 눌러 이동, 테두리 크기 조절, 두 손가락 핀치 축소·확대, 더블 탭 접기·펼치기 및 시스템 테마 자동 동기화.
- **라이트 모드 태양 빛번짐 완화 & 가독성 확보**: 밝은 하늘빛 성운 배경과 짙은 감색·브론즈 테두리 대비로 태양 코로나가 눈부시지 않고 숫자와 텍스트가 선명하게 읽힙니다.
- **시스템 자동 테마 & 성능 최적화**: 기기 다크/라이트 모드 전환 시(`theme_mode = system`) 앱과 위성 오버레이가 함께 전환되며, 태양·궤도 애니메이션은 화면이 보일 때만 실행되고 `onDraw` 내부 객체 할당을 제거했습니다.

## 처음 가져오기

1. **홈 → 조회 기간**에서 연도·월을 입력하고 **이 연도 · 월 적용**을 누르세요.
2. **설정 → 처음 시작하기 → 접근성 설정 열기**를 누르세요. 안내에 동의하고 Android의 **설치된 앱/다운로드한 앱 → 근무로그 → 사용**을 켜세요. 뒤로 가기로 근무로그에 돌아오세요.
3. **한국장학재단 출근부 열기**로 공식 앱에 로그인하세요. 같은 월을 조회하고 날짜·출퇴근 시각이 보이는 목록을 여세요. 근무로그는 최근 앱에서 지우지 마세요.
4. 떠 있는 메뉴의 **목록 수집**을 누르세요. 완료 표시 후 근무로그의 **기록·통계**에서 확인하세요. 중간에 멈출 때는 **수집 중지**입니다.

접근성 스위치를 켤 수 없고 ‘제한된 설정’이 나오면 **설정 → 설치·권한 도움말 → 근무로그 앱 설정 열기 → ⋮ → 제한된 설정 허용**을 확인하세요. Android 13 이상에서 필요할 수 있고 기기마다 메뉴가 다릅니다. 접근성이 없어도 기존 붙여넣기·직접 편집을 이용할 수 있습니다.

## 안정성 개선 사항

- **파서 보강**: `AttendanceParser.kt`에 좁은 줄바꿈 없는 공백(`\u202f`)·제로폭 문자(`U+200B~U+200D`, `FEFF`) 정규화 및 시간 범위 선행/후행 구분자 가드를 추가했습니다.
- **저장소 안전성**: `RecordStore.kt`에서 `applicationContext` 기준 `SharedPreferences` 접근 통일 및 손상된 JSON/타입 불일치(`ClassCastException`) 방어, `@Volatile` 세션 플래그(`CollectionSession.kt`)를 적용했습니다.
- **생명주기·IME 대응**: `MainActivity`에 `windowSoftInputMode="adjustResize"`, 안전 다이얼로그 가드, `onPause`/`onWindowFocusChanged`/`onDestroy` 애니메이션 정지 및 `onConfigurationChanged` 시스템 테마 동기화를 구현했습니다.

## 기존 GitHub에서 빌드

배포 묶음의 **attendance-source.zip**을 저장소 최상단의 같은 파일로 교체하세요. 기존 **.github/workflows/build-apk.yml**, **build-signed-release.yml**은 원본 그대로 유지되어 수정 없이 동작합니다.

## 개발 검증

```text
gradle :app:assembleDebug :app:assembleRelease :app:lintDebug
python tests/*.py
```

Android 8·15·16 테스트 런타임을 사용하는 검사는 **Java 21**에서 `gradle :app:testDebugUnitTest`로 실행하세요. 실제 Android View 렌더는 `app/build/reports/ui-preview`에 생성됩니다. 상세 결과는 [검사 보고서](VALIDATION_KO.md)를 확인하세요.
