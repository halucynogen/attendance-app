# SDK 설치 없이 APK 만들기 - GitHub Actions

이 ZIP은 APK 자체가 아닙니다. Android SDK/Gradle을 본인 PC에 설치할 필요 없이, GitHub Actions의 서버가 APK를 빌드하도록 설정한 Android Studio 프로젝트입니다.

## GitHub에서 빌드하기

1. GitHub 계정으로 로그인합니다. 새로운 **Private** Repository를 만듭니다. 이미 있는 프로젝트가 있다면 그 저장소를 사용해도 됩니다.
2. 이 ZIP을 압축 해제합니다. `app/`, `gradle/`, `.github/`, `build.gradle.kts`, `settings.gradle.kts` 등이 저장소 **최상위 경로**에 보이게 파일을 올립니다. 중요한 점: `.github/workflows/build-apk.yml` 파일도 반드시 올려야 합니다. 일부 휴대폰 파일 관리자는 `.github` 같은 점으로 시작하는 폴더를 숨길 수 있습니다.
3. GitHub 저장소에서 **Actions** → **Android DEBUG APK (development only)** → **Run workflow** 를 누릅니다. `main` 또는 `master` 브랜치로 파일을 업로드하면 자동 실행될 수도 있습니다.
4. 작업이 성공하면 해당 실행 결과 하단 **Artifacts** 영역의 `attendance-v1-debug-test-only`를 다운로드합니다. 이 항목은 **ZIP 형태**로 받아질 수 있으므로 압축을 풀어 `app-debug.apk`를 꺼냅니다.
5. 갤럭시에서 `app-debug.apk`를 열어 설치합니다. Android가 해당 파일 관리자/브라우저에 '알 수 없는 앱 설치' 허용을 요구할 수 있습니다. 설치 전 해당 파일이 이 빌드에서 만들어진 APK인지 확인하세요.
6. 설치 후 앱의 접근성 이용 설명을 읽고 본인이 동의한 경우에만 서비스를 활성화합니다. 한국장학재단 공식 앱에서 직접 로그인하고 `조회 → 목록` 화면을 열어 테스트합니다.

## 주의

- GitHub Actions는 원격 서버에서 실행됩니다. **한국장학재단 계정, 비밀번호, 실제 출근부 캡처·데이터를 저장소에 업로드하지 마세요.** 이 소스 ZIP에는 대화에 첨부된 화면 캡처가 포함되지 않았습니다.
- Actions가 실패하면 빌드 로그에서 실제 오류를 확인해야 하며, APK가 생성됐다고 간주하면 안 됩니다.
- 이전 버전과 동일하게 **삼성 갤럭시 실기기 및 공식 출근부 화면 자동 스크롤은 미검증**입니다.
- 클라우드의 앱 설치 빌드는 앱 동작을 보장하지 않으며, 일부 계정에서는 Actions 사용이 제한되거나 요금/한도가 적용될 수 있습니다.
- 발행되는 파일은 개발·테스트 목적의 **디버그 서명 APK**입니다. Android 서명 때문에 다른 컴퓨터/Actions 실행에서 만든 APK로 재설치 시 기존 앱과 서명이 달라 업데이트가 거절될 수 있습니다. 이런 경우 기존 앱 데이터를 백업한 후 제거해야 할 수 있습니다.
