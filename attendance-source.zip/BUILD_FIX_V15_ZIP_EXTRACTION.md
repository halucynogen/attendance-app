# V1.5 GitHub Actions 압축 해제 실패 수정 (2026-11-05)

## 증상

`unzip -tq attendance-source.zip`는 `No errors detected in compressed data`로 끝났지만 다음 검사 구문에서
`set -euo pipefail`에 의해 종료되어 GitHub Actions에 `exit code 1`만 표시되었습니다.

## 해결

- ZIP 무결성 검사와 프로젝트 위치 탐색을 분리하고 경과 메시지 출력
- `settings.gradle.kts`와 `app/build.gradle.kts`가 실제 있는 폴더를 찾아 `project/`로 복사
- ZIP 루트, 한 단계 위 폴더 포함, 전체 GitHub 업로드 묶음 내부의 소스 ZIP 세 경우 지원
- V1.5 버전/Android 36 미일치, `AndroidManifest.xml` 누락 시 자세한 `::error::` 진단
- `build-apk.yml`과 `build-signed-release.yml`에 동일한 소스 처리 흐름 적용

## 주의

원래 소스 ZIP(루트에 `app/`, `settings.gradle.kts` 포함)을 올리는 것이 가장 단순하고 안전합니다.
재압축/하위 폴더가 있는 ZIP도 처리할 수 있게 했지만 다른 앱 버전으로 넘어가지는 않습니다.

로컬에서 4가지 정상 ZIP 구조와 2가지 오류 ZIP 구조의 압축 해제/검증 스크립트를 실제 실행했습니다.
Android SDK를 사용한 `gradle :app:assembleDebug` / `assembleRelease`는 이 환경에서 실행할 수 없어 별도 GitHub 빌드 확인이 필요합니다.
