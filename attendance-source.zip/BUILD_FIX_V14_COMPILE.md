# 근무로그 V1.4 빌드 오류 수정 (2026-11-05)

## 수정한 오류

GitHub Actions의 `:app:compileReleaseKotlin` 중 다음 오류가 발생했습니다.

```
MainActivity.kt:1360:9 Unresolved reference 'minHeight'
```

원인: `lifestyleCard()`는 `LinearLayout`을 생성하지만, `minHeight`는 `TextView`/`Button` 관련 접근자여서 `LinearLayout`에서 참조할 수 없습니다.

수정: `app/src/main/java/io/local/attendance/MainActivity.kt`의 해당 호출을 `setMinimumHeight(dp(70))`로 교체했습니다. `Button`의 `minHeight` 접근자는 합법적이므로 그대로 뒀습니다.

## 버전 및 기능 유지

- 버전 `1.4.0`, `versionCode = 140`, 패키지명 `io.local.attendance` 유지
- 홈·기록·통계·설정 4탭, 차트/그래프 전환, 3초 스플래시, 월간 공유, 접근성 바로가기 등 기능 유지
- 저장 형식, 서명 관련 설정 변경 없음

## 다시 업로드 및 확인

1. 이 파일이 들어있는 **ZIP 자체**를 GitHub 저장소 최상위에 `attendance-source.zip`이라는 파일명으로 업로드/덮어쓰기하세요. (압축을 풀지 않고 ZIP 그대로 등록)
2. `.github/workflows/build-apk.yml` 또는 기존 릴리스 워크플로가 저장소에 있어야 합니다.
3. GitHub → Actions → `Build Android APK` 실행 또는 기존 릴리스 워크플로 재실행.
4. 통과하면 `attendance-v1.4-apk` 아티팩트에서 APK를 받습니다.

Gradle이 출력하는 `jvmTarget: String is deprecated`는 오류가 아닌 경고여서 이번 실패의 원인이 아닙니다.

**검증 범위:** ZIP 구조/파일 무결성 및 오류 라인 교체 확인. 이 환경에는 Android SDK/Gradle이 없어 APK 실제 컴파일·실기기 실행 테스트는 수행하지 못했습니다.
