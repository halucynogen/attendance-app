# 근무로그 V1.5 (빌드 150) — 수정 및 테스트 안내

## 빌드 오류 재발 방지

- `app/build.gradle.kts`에서 `versionCode = 150`, `versionName = "1.5.0"`을 사용합니다. 패키지는 `io.local.attendance`로 유지합니다.
- 빌드 워크플로는 저장소 **루트**의 `.github/workflows/build-apk.yml`과 `.github/workflows/build-signed-release.yml`입니다. 프로젝트 ZIP 내부의 동명 파일만 바꾸면 GitHub Actions가 읽는 워크플로는 갱신되지 않으므로 **두 파일을 루트에도 업로드**해야 합니다.
- `attendance-source.zip`은 저장소 최상단에 두세요. 압축을 풀어 나온 프로젝트 파일을 바로 루트에 중복 업로드하지 않아도 됩니다.
- 빌드 오류가 발생하면 Actions 로그의 **첫 `e:` / `error:` 줄**을 확인합니다. `jvmTarget is deprecated`는 실패 원인이 아닌 경고입니다.

## V1.5 변경

- 근무기록 저장 후 홈/통계가 자동 갱신됩니다. 0건 수집·읽기 실패 시에도 수집 결과를 보여 줍니다.
- 접근성 서비스의 `중지`는 수집만 중단합니다. 권한 해제는 설정 탭에서 확인 후 명시적으로 수행합니다.
- 기록 탭 상단에 **텍스트 붙여넣기 · 직접 추가** 기능을 표시합니다. 설정에서 기록 탭 바로가기 제공.
- 홈에 한국장학재단 공식 출근부 앱 바로가기 복원, 하단 홈·기록·통계·설정 4탭 유지.
- 새로 앱 실행하는 경우에만 약 3초 커스텀 스플래시; 백그라운드 복귀·화면 회전 시 미표시.
- 설정의 다크/라이트 테마는 모든 탭에 적용되며 기기에 저장됩니다.
- 설정에 `v0.1 ~ v0.7`, `v0.7 ~ v1.4` 업데이트 기록 펼치기/접기 추가.
- 기존 월간 공유·날짜 수정 자동 스크롤·차트/그래프 전환 유지.

## 검증 제한

- 이 파일은 **APK가 아닌 Android 프로젝트 소스**입니다.
- Kotlin 순수 로직 회귀 테스트, XML 무결성, Python 정적 검사, GitHub Actions 구조 검사를 시행합니다.
- 이 작업 환경에 Android SDK 36/Gradle 실행 환경이 없어 실제 Android APK 컴파일·에뮬레이터/실기기 테스트는 진행하지 못했습니다. GitHub Actions에서 빌드 완료를 확인해야 합니다.
- 실제 앱 설치로 업데이트할 때 기존 기록 유지에는 동일한 `applicationId`와 **동일한 APK 서명키**가 필요합니다. 서명키가 다르면 기존 설치본 위에 업데이트할 수 없습니다.


## GitHub Actions 빌드 준비 시 오류 해결

`No errors detected in compressed data of attendance-source.zip` 이후 `exit code 1`은 ZIP 데이터 손상이 아닌 프로젝트 폴더 탐색/버전 체크에서 실패했을 가능성이 큽니다. `build-apk.yml`, `build-signed-release.yml`을 수정하여 소스 ZIP·하위 폴더 ZIP·전체 묶음 ZIP을 인식하고 오류 원인을 자세히 출력하도록 했습니다. [BUILD_FIX_V15_ZIP_EXTRACTION.md](BUILD_FIX_V15_ZIP_EXTRACTION.md) 참조.

저장소 최상단의 `attendance-source.zip` 및 `.github/workflows` 아래 두 YAML 파일을 **모두 교체한 후** GitHub Actions를 재실행하세요.
