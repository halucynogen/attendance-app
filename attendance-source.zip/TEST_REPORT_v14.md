# v1.4 테스트 결과

- Kotlin `ParserTest.kt`: 기본 파서 11개 검사 통과
- Kotlin `ExtendedParserTest.kt`: 확장 35그룹 + 생성 330케이스 통과
- Kotlin `AprilScreenshotRegressionTest.kt`: 13근무 기록, 73시간 총 시각, 휴게 5시간, 순 근무 68시간 회귀 검사 통과
- Kotlin `YearRangeTest.kt`: 429개 연도 케이스 통과
- Kotlin `V14ShareTest.kt`: 날짜·출퇴근 시각·휴게·상태·합계/월 경계/중복·CSV 수식 방어·유효하지 않은 날짜 검사 통과
- Python 정적 테스트: 접근성 수집 정책, 플로팅 메뉴, 날짜 바로가기, 공식 앱 연동, Android 16 초기화, V1.4 스플래시·공유·파일, 저장 손상/실패 방어 검사 통과
- 리소스 XML 전체 파싱 통과, ZIP 무결성 검사 예정

**검증 한계:** Android SDK 및 Gradle 전체 빌드 도구가 이 환경에는 없어 Kotlin의 Android 의존 소스에 대한 APK 빌드/런타임 검증은 완료하지 못했습니다. GitHub Actions 빌드 및 실제 갤럭시/안드로이드 기기에서 스플래시, 접근성 오버레이, 위치 스크롤, 공유 선택기, 파일 저장, 화면 회전을 확인해야 합니다.
