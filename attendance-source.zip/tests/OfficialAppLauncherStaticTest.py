from pathlib import Path
import xml.etree.ElementTree as ET
ROOT = Path(__file__).resolve().parents[1]
manifest = ROOT / 'app/src/main/AndroidManifest.xml'
activity = ROOT / 'app/src/main/java/io/local/attendance/MainActivity.kt'
xml = ET.parse(manifest).getroot()
android = '{http://schemas.android.com/apk/res/android}'
queries = xml.find('queries')
assert queries is not None
packages = [p.attrib.get(android+'name') for p in queries.findall('package')]
assert packages == ['com.kosaf.gpsAttendance'], packages
assert not xml.findall("uses-permission[@android:name='android.permission.QUERY_ALL_PACKAGES']", {'android':'http://schemas.android.com/apk/res/android'})
s = activity.read_text(encoding='utf-8')
assert 'packageManager.getLaunchIntentForPackage(targetAttendancePackage)' in s
assert 'getApplicationIcon(targetAttendancePackage)' in s
assert 'openOfficialAppStorePage()' in s
assert 'v1.2' in s
assert '6개 버전씩 묶어서 볼 수 있어요' not in s
assert '버전 기록 · v0.6~v1.1' in s and '버전 기록 · v0.1~v0.6' in s
print('Official app launcher + manifest static tests PASSED')
