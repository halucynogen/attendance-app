"""V1.6: small AND expanded floating accessibility tool must show collection completion."""
from pathlib import Path
root = Path(__file__).resolve().parents[1]
svc = (root/'app/src/main/java/io/local/attendance/CollectorAccessibilityService.kt').read_text()
formatter = (root/'app/src/main/java/io/local/attendance/FloatingCollectionStatus.kt').read_text()
assert 'overlayStateBadge = stateBadge' in svc
assert 'header.addView(stateBadge' in svc, 'badge should stay visible even in compact mode'
assert 'wrap.addView(compact)' in svc, 'compact summary should remain visible'
assert 'info?.visibility = if (expanded) View.VISIBLE else View.GONE' in svc
assert 'overlayDetails?.visibility = View.VISIBLE' in svc
assert 'updateCompactStatus()' in svc and 'FloatingCollectionStatus.from(' in svc
assert 'compactStatus?.announceForAccessibility(' in svc
assert 'RecordStore.setLastCollection(this, ym, total, collected, reason)' in svc
assert 'getSharedPreferences("collection_ui", MODE_PRIVATE)' in svc
assert 'overlayStateBadge?.apply {' in svc
assert 'overlayStateBadge = null' in svc
assert 'if (active || startPending || startCheckInProgress) {' in svc
assert 'previously completed result' in svc or 'Preserve a previously completed result' in svc
assert 'overlay?.visibility = View.GONE' in svc and 'if (foregroundChanged)' in svc
assert 'status.startsWith("수집 완료")' in formatter
assert '"✓ 수집 완료"' in formatter
assert 'CollectionDisplayPhase.WARNING' in formatter
assert 'CollectionDisplayPhase.COMPLETE' in formatter
print('PASS V1.6 compact/expanded status badge, toast stability, accessibility announcement, persistence')
