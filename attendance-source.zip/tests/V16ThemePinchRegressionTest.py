"""Source-level checks for V1.6 UI improvement bundle; no Android SDK needed."""
from pathlib import Path
from xml.etree import ElementTree as ET
root = Path(__file__).resolve().parents[1]
main = (root/'app/src/main/java/io/local/attendance/MainActivity.kt').read_text()
svc = (root/'app/src/main/java/io/local/attendance/CollectorAccessibilityService.kt').read_text()
styles = (root/'app/src/main/res/values/styles.xml').read_text()
manifest = (root/'app/src/main/AndroidManifest.xml').read_text()
assert 'AttendanceThemeDark' in styles and 'AttendanceDialogDark' in styles
assert 'AttendanceDialogLight' in styles and '@drawable/dialog_surface_dark' in styles
assert 'R.style.AttendanceThemeDark' in main and 'R.style.AttendanceDialogDark' in main
assert 'val accents = listOf(blueDeep, aqua, violet, sky)' in main
assert 'val pastels = listOf(blueSoft, greenSoft, violetSoft, skySoft)' in main
assert 'private fun showDateRangeWarning(details: String)' in main
assert '날짜를 다시 확인해 주세요' in main and '2000년 1월 1일 ~ 2100년 12월 31일' in main
assert 'ScaleGestureDetector' in svc and 'override fun onScale(detector: ScaleGestureDetector)' in svc
assert 'pinch_zoom' in svc and 'onScaleEnd' in svc
assert 'overlayDarkMode != themeDark()' in svc
assert 'compactStatus?.visibility = if (expanded) View.GONE else View.VISIBLE' in svc
assert 'info?.visibility = if (expanded) View.VISIBLE else View.GONE' in svc
assert 'overlayActionButtons = listOf(collect, changeDate, stopButton)' in svc
assert 'toggleFloatingMenu()' not in svc and 'overlayToggle' not in svc
assert 'recordScrollRail(textScroll)' in main and 'scroll.smoothScrollBy' in main
assert 'saveEditedRecords(draftText.orEmpty())' in main
assert '내보내기 · 기록 관리  ⌄' in main and '현재 내용 공유' not in main
assert 'showLaunchSplash()' not in main and 'splashHandler.postDelayed' not in main
assert 'AttendanceSplashTheme' in manifest
for resource in (root/'app/src/main/res').rglob('*.xml'):
    ET.parse(resource)
print('PASS V1.6 themed screens/dialogs, pinch resize, two layouts, simple editor scrolling, no duplicate splash')
