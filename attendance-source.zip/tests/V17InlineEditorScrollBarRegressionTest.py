"""V1.7 regression checks for reported edit-button force-close and inline cursor/scrollbar."""
from pathlib import Path
import re
from xml.etree import ElementTree as ET
root = Path(__file__).resolve().parents[1]
main = (root/'app/src/main/java/io/local/attendance/MainActivity.kt').read_text()
gradle = (root/'app/build.gradle.kts').read_text()
workflows = '\n'.join(p.read_text() for p in (root/'.github/workflows').glob('*.yml'))
assert 'versionCode = 180' in gradle and 'versionName = "1.8.0"' in gradle
assert 'private val versionName = "v1.8"' in main
assert "'180'" in workflows and "'1.8.0'" in workflows
record = main[main.index('private fun renderRecords('): main.index('private fun recordScrollRail(')]
assert 'showRecordEditor(' not in main and 'saveEditorDraft(' not in main
assert 'val textHost = FrameLayout(this@MainActivity)' in record
assert 'textHost.removeAllViews()' in record
assert 'val field = EditText(this@MainActivity).apply {' in record
assert 'isVerticalScrollBarEnabled = false' in record
assert 'setSelection(0)' in record and 'field.requestFocus()' in record
assert 'inlineRecordField = field' in record and 'recordEditMode = true' in record
assert 'left.text = "취소"' in record and 'right.text = "수정 저장"' in record
assert 'if (recordEditMode) closeInlineEdit(discard = true)' in record
assert 'saveEditedRecords(draftText.orEmpty())' in record
assert 'copyText("근무기록", snapshot)' in record
rail = main[main.index('private fun recordScrollRail('):main.index('private fun saveEditedRecords(')]
assert 'scroll.smoothScrollBy(' in rail
assert 'track.setOnTouchListener' in rail and 'MotionEvent.ACTION_MOVE' in rail
assert 'scroll.setOnScrollChangeListener' in rail
assert 'arrow("▲", -1)' in rail and 'arrow("▼", 1)' in rail
assert 'val proportional = (height.toFloat() * viewport / contentHeight).toInt()' in rail
assert 'isDragging = true' in rail and 'scroll.scrollTo(0, (progress * range).toInt())' in rail
assert 'if (darkMode)' not in rail and '#F4F4F5' in rail
assert 'if (tab == 1 && recordEditMode) saveDraft()' in main
assert 'outState.putBoolean("record_edit_mode", recordEditMode)' in main
assert 'if (RecordStore.replaceMonth(this, month, corrected))' in main
for path in (root/'app/src/main').rglob('*.xml'):
    ET.parse(path)
print('PASS V1.8 inline editing, no editor dialog, scrollbar gestures, copy, draft restore, version/SDK resources (static)')
