"""V1.8 scroll-only regression: static source checks + mapping boundary cases."""
from pathlib import Path
import re
root = Path(__file__).resolve().parents[1]
main = (root / 'app/src/main/java/io/local/attendance/MainActivity.kt').read_text()
rail = main[main.index('private fun recordScrollRail('):main.index('private fun saveEditedRecords(')]
record = main[main.index('private fun renderRecords('):main.index('private fun recordScrollRail(')]
assert 'LinearLayout.LayoutParams(dp(30), dp(258))' in record
assert 'marginStart = dp(5)' in record
assert 'FrameLayout.LayoutParams(dp(20), -1, Gravity.CENTER_HORIZONTAL)' in rail
assert 'FrameLayout.LayoutParams(dp(18), dp(40), Gravity.TOP or Gravity.CENTER_HORIZONTAL)' in rail
assert '"#F4F4F5"' in rail and '"#C5C5C8"' in rail and '"#505052"' in rail
assert 'darkMode' not in rail and 'accentGradient' not in rail
assert 'isDragging = true' in rail
assert 'scroll.fling(0)' in rail
assert 'event.y - thumbTop' in rail
assert 'scroll.scrollTo(0, (progress * range).toInt())' in rail
assert 'view.parent?.requestDisallowInterceptTouchEvent(true)' in rail
assert 'scroll.addOnLayoutChangeListener' in rail
assert 'track.addOnLayoutChangeListener' in rail
assert 'val range = maxScrollY()' in rail
assert 'arrow("▲", -1)' in rail and 'arrow("▼", 1)' in rail
assert 'if (range == 0) 0.62f else 1f' in rail
# For long texts, a single thumb drag maps the full track to the full content range.
def map_thumb(y, offset, track_height, thumb_height, content_height, viewport_height):
    max_scroll = max(0, content_height - viewport_height)
    travel = max(1, track_height - thumb_height)
    fraction = max(0.0, min(1.0, (y - offset) / travel))
    return int(fraction * max_scroll)
for content, viewport, track, thumb in [(4000, 250, 200, 28), (20000, 258, 208, 26), (500, 250, 208, 47)]:
    offset=thumb/2
    assert map_thumb(offset, offset, track, thumb, content, viewport) == 0
    assert map_thumb(track-thumb+offset, offset, track, thumb, content, viewport) == content - viewport
    assert map_thumb(track*2, offset, track, thumb, content, viewport) == content - viewport
assert map_thumb(300, 20, 208, 47, 100, 258) == 0
print('PASS V1.8 silver scrollbar dimensions, theme independence, no overlay interception, full-range drag')
