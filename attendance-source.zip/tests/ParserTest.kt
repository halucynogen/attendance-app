package io.local.attendance

import java.time.YearMonth
import java.time.LocalDate

fun main() {
    val month = YearMonth.of(2026, 11)
    val imageText = """
        2026. 11
        총 예상 근로시간 2시간 0분
        국가근로장학금
        2026.09.10 ~
        근로복지공단대전지역본부 / 재활보상1부
        11.02 2시간 0분 기관확인 전
        근로복지공단대전지역본부
        근무 09:00 ~ 11:00
    """.trimIndent()
    val r = AttendanceParser.fromListPage(imageText, month)
    check(r.size == 1) { "screen parsed $r" }
    check(r[0].date == "2026-11-02" && r[0].minutes == 120 && r[0].reportedMinutes == 120) { "record $r" }
    check(r[0].status == "기관확인 전")
    check(AttendanceParser.monthHeader(imageText) == month)
    val page1 = "2026. 11\n11.02 2시간 0분\n근무 09:00 ~ 11:00\n11.04 3시간 0분\n근무 13:00 ~ 16:00"
    val page2 = "2026.11\n11.04 3시간 0분\n근무 13:00 ~ 16:00\n11.06 2시간 30분\n근무 10:00 ~ 12:30"
    val merged = AttendanceParser.unique(AttendanceParser.fromListPage(page1, month) + AttendanceParser.fromListPage(page2, month))
    check(merged.size == 3) { "overlap dedup failed $merged" }
    val mismatch = AttendanceParser.fromText("2026.11\n11.08 2시간 0분\n근무 09:00 ~ 12:00", month)
    check(mismatch.single().differentFromReported)
    val nextMonth = AttendanceParser.fromListPage("12.01\n근무 09:00 ~ 12:00", month)
    check(nextMonth.isEmpty())
    val badDate = AttendanceParser.fromListPage("11.31 근무 09:00 ~ 11:00", month)
    check(badDate.isEmpty())
    check(AttendanceParser.fromListPage("11.02 근무 11:00 ~ 09:00", month).isEmpty())
    val edited = AttendanceParser.fromEditableText("2026-11-02 09:00 ~ 11:00\n2026-11-04 13:00 ~ 16:00", month)
    check(edited.size == 2)
    val detail = AttendanceParser.fromDetail("근무 09:00 ~ 11:00", LocalDate.of(2026, 11, 2))
    check(detail.size == 1)
    check(AttendanceParser.csv(merged, month).lines().size == 4)
    println("ALL 11 PARSER CHECKS PASSED")
}
