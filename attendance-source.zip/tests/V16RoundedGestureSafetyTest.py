"""Regression guard: compact pill overlay and guarded multi-touch input."""
from pathlib import Path
p = Path(__file__).resolve().parents[1]/'app/src/main/java/io/local/attendance/CollectorAccessibilityService.kt'
s = p.read_text()
assert 'radiusDp = 28' in s and 'clipToOutline = true' in s
assert 'cornerRadius = dp(25).toFloat()' in s
assert 'radiusDp = 25' in s
assert 'buttons = LinearLayout(this).apply' in s
assert 'setPadding(dp(3), dp(6), dp(3), dp(3))' in s
assert s.count('marginStart = dp(7)') >= 2
assert 'overlayPinchInProgress = true' in s
assert 'overlayPinchInProgress = false' in s
assert 'super.dispatchTouchEvent(cancel)' in s
assert 'overlayBlockTapsUntil = SystemClock.uptimeMillis() + 420L' in s
assert 'if (!overlayPinchInProgress && SystemClock.uptimeMillis() >= overlayBlockTapsUntil)' in s
assert 'arrayOf("수집", "날짜", "중지")' in s
print('PASS V1.6 rounded inset buttons, click lock during and after pinch, compact actions')
