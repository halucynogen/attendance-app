"""User-reported regressions: records edit crash, missing copy, date list, overlay re-entry, legibility.

Static checks only: on-device verification/Android compiler still required.
"""
from pathlib import Path
import xml.etree.ElementTree as ET

base = Path(__file__).resolve().parents[1]
src = base / 'app/src/main/java/io/local/attendance'
a = (src / 'MainActivity.kt').read_text()
s = (src / 'CollectorAccessibilityService.kt').read_text()
g = (base / 'app/build.gradle.kts').read_text()
x = (base / 'app/src/main/res/xml/accessibility_config.xml').read_text()
assert 'versionCode = 180' in g and 'versionName = "1.8.0"' in g
# Records always expose extracted text and copy; editor no longer rebuilt inside tab.
assert 'root.addView(section("추출 결과 · 복사"' in a
assert 'val snapshot = AttendanceParser.export(items, month)' in a
assert 'textHost.addView(preview' in a
assert 'val left = action("전체 복사")' in a
assert 'val right = action("수정하기", primary = true)' in a
records = a[a.index('private fun renderRecords('):a.index('private fun recordScrollRail(')]
assert 'EditText(this@MainActivity)' in records  # user paste box
assert 'recordEditorOpen' not in a
assert 'private fun showRecordEditor(' not in a
assert 'recordScrollRail(textScroll)' in a and 'track.setOnTouchListener' in a
assert 'recordEditMode = true' in a and 'saveEditedRecords(draftText.orEmpty())' in a
# Date selection: single shift launches editor; multiple shifts selectable without message overriding items.
date_dialog = a[a.index('private fun showCalendarDay('):a.index('private fun addToDeviceCalendar(')]
assert 'if (shifts.size == 1)' in date_dialog
assert 'addToDeviceCalendar(shifts.first())' in date_dialog
assert '.setItems(items)' in date_dialog
assert '.setMessage(' in date_dialog  # Only the empty-date notice
assert '.setMessage("근무를 선택하면' not in date_dialog
assert 'Intent(Intent.ACTION_INSERT)' in a and 'CalendarContract.Events.CONTENT_URI' in a
assert 'startActivity(intent)' in a and 'offerCalendarWebFallback' in a
# Accessibility menu recovers when window-change events are suppressed or service interrupted.
assert 'typeWindowsChanged' in x
assert 'private val overlayRecovery = object : Runnable' in s
assert 'handler.postDelayed(this, 1600L)' in s
assert 'scheduleOverlayRecovery()' in s[s.index('override fun onServiceConnected'):s.index('override fun onAccessibilityEvent')]
assert 'scheduleOverlayRecovery()' in s[s.index('private fun cancelCollection'):s.index('private fun disableByUser')]
assert 'return activeRoot' in s and 'windows.asSequence()' in s
assert 'OFFICIAL_ATTENDANCE_PACKAGE' in s and 'RecordStore.consent' in s
assert 'begin()' in s and 'overlayButton("목록 수집"' in s
assert 'takeScreenshot' not in s
# Dark and light modes must not share low-contrast text tokens.
assert '"#D3DEEF" else "#3F4D63"' in a
assert 'if (darkMode) Color.WHITE else ink' in a
for f in (base / 'app/src/main').rglob('*.xml'):
    ET.parse(f)
print('PASS reported regressions: records preview/editor, date action, accessibility reentry, contrast (static only)')
