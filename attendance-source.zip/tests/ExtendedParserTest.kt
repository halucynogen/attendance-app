package io.local.attendance

import java.time.LocalDate
import java.time.YearMonth

/** Screenshots manually transcribed from user-provided mock/actual list layout. */
fun main() {
    val month = YearMonth.of(2026, 11)
    var passed = 0
    fun test(name: String, block: () -> Boolean) {
        check(block()) { "TEST FAILED: $name" }
        passed++
        println("OK ${passed.toString().padStart(2)} - $name")
    }
    val actualScreen = """
        2026. 11
        총 예상 근로시간 2시간
        제외예정시간 0분
        예상 장학금 25,580원
        국가근로장학금
        2026.09.10 ~
        근로복지공단대전지역본부 / 재활보상1부
        기관확인 전
        11.02 2시간 0분
        근로복지공단대전지역본부
        근무 09:00 ~ 11:00
        조회
    """.trimIndent()
    val first = AttendanceParser.fromListPage(actualScreen, month)
    test("actual provided screenshot text extracts one record") { first.size == 1 }
    test("date is November 2, 2026") { first.single().date == "2026-11-02" }
    test("start/end 09:00 to 11:00") { first.single().start == "09:00" && first.single().end == "11:00" }
    test("reported time 120 minutes") { first.single().reportedMinutes == 120 }
    test("agency placement date excluded") { first.none { it.date == "2026-09-10" } }
    test("status recognized") { first.single().status == "기관확인 전" }
    test("screen month recognized") { AttendanceParser.monthHeader(actualScreen) == month }

    val multi = """
        2026. 11
        국가근로장학금
        2026.09.10 ~
        11.02 2시간 0분 기관확인 전
        근무 09:00 ~ 11:00
        11.03 2시간 30분 기관확인 완료
        근무 13:00 ~ 15:30
        11.05 4시간 0분 미완료
        근무 09:00 ~ 13:00
    """.trimIndent()
    val shifts = AttendanceParser.fromListPage(multi, month)
    test("three shifts on one page") { shifts.size == 3 }
    test("all statuses mapped") { shifts.map { it.status } == listOf("기관확인 전", "기관확인 완료", "미완료") }
    test("display minutes bound to correct day") { shifts.map { it.reportedMinutes } == listOf(120,150,240) }
    test("total time is 510 minutes") { shifts.sumOf { it.minutes } == 510 }
    test("summary totals not parsed as a new shift") { shifts.all { it.date.startsWith("2026-11") } }

    val a11yOrder = "2026.11\n기관확인 전\n11.02 2시간 0분\n근무 09:00 ~ 11:00\n기관확인 완료\n11.03 1시간 0분\n근무 13:00 ~ 14:00"
    val a11yRows = AttendanceParser.fromListPage(a11yOrder, month)
    test("status above each date maps to each row") { a11yRows.map { it.status } == listOf("기관확인 전", "기관확인 완료") }

    val pageA = "2026.11\n11.02 2시간 0분\n근무 09:00 ~ 11:00\n11.03 3시간 0분"
    val pageB = "2026.11\n근무 13:00 ~ 16:00\n11.04 1시간 0분\n근무 12:00 ~ 13:00"
    val stitched = AttendanceParser.fromOverlappingPages(pageA, pageB, month)
    test("date at end of scroll page matched to next page time") { stitched.size == 3 && stitched[1].date == "2026-11-03" && stitched[1].start == "13:00" }
    test("bridging recovers reported minutes") { stitched[1].reportedMinutes == 180 }
    test("duplicate pages deduplicated") { AttendanceParser.fromOverlappingPages(pageA, pageA, month).size == 1 }
    test("multiple shifts in one day kept") { AttendanceParser.fromListPage("11.02 근무 09:00~11:00 근무 14:00~16:00", month).size == 2 }
    test("different months ignored") { AttendanceParser.fromListPage("12.01 근무 09:00~11:00", month).isEmpty() }
    test("impossible November 31 ignored") { AttendanceParser.fromListPage("11.31 근무 09:00~11:00", month).isEmpty() }
    test("reversed time ignored") { AttendanceParser.fromListPage("11.02 근무 11:00~09:00", month).isEmpty() }
    test("invalid minutes ignored") { AttendanceParser.fromListPage("11.02 근무 09:80~11:00", month).isEmpty() }
    test("OCR whitespace around colon parsed") { AttendanceParser.fromListPage("11.02 근무 09 : 00 ~ 11 : 00", month).size == 1 }
    test("OCR fullwidth colon parsed") { AttendanceParser.fromListPage("11.02 근무 09：00 ~ 11：00", month).size == 1 }
    test("plain time without 근무 parsed") { AttendanceParser.fromListPage("11.02 09:00 ~ 11:00", month).size == 1 }
    test("reported minute discrepancy flagged") { AttendanceParser.fromListPage("11.02 3시간 0분 근무 09:00 ~ 11:00", month).single().differentFromReported }
    test("CSV contains 3 data rows") { AttendanceParser.csv(shifts, month).lines().size == 4 }
    test("export includes review warning") { AttendanceParser.export(AttendanceParser.fromListPage("11.02 3시간 0분 근무 09:00 ~ 11:00", month), month).contains("시간 차이 확인") }
    test("editable text round-trip records") { AttendanceParser.fromEditableText("2026-11-02 09:00 ~ 11:00\n2026-11-04 12:00 ~ 13:00", month).size == 2 }
    test("detail from exact date") { AttendanceParser.fromDetail("근무 09:00 ~ 11:00", LocalDate.of(2026, 11, 2)).single().date == "2026-11-02" }

    var fuzzCount = 0
    for (day in 1..30) {
        for (startHour in 0..20 step 2) {
            val endHour = startHour + 2
            val time = "%02d:00 ~ %02d:00".format(startHour, endHour)
            val row = "11.%02d 2시간 0분 기관확인 전 근무 %s".format(day, time)
            val r = AttendanceParser.fromListPage(row, month)
            check(r.size == 1 && r[0].date == "2026-11-%02d".format(day) && r[0].minutes == 120 && !r[0].differentFromReported) {
                "randomized day/time case failed: $row => $r"
            }
            fuzzCount++
        }
    }
    test("${fuzzCount} valid day/time combinations") { fuzzCount == 330 }
    println("ALL $passed EXTENDED TEST GROUPS PASSED ($fuzzCount GENERATED CASES)")
}
