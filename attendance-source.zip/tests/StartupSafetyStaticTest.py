"""Static checks for the Android 16 startup crash mitigation (no Android SDK required)."""
from pathlib import Path
from xml.etree import ElementTree

root = Path(__file__).resolve().parents[1]
main = (root / 'app/src/main/java/io/local/attendance/MainActivity.kt').read_text()
gradle = (root / 'app/build.gradle.kts').read_text()
startup = main.split('private fun configureSystemBars()', 1)[1].split('private fun updateSystemBarIconsSafely()', 1)[0]
assert 'window.insetsController' not in startup.split('//', 1)[0], 'early controller use reintroduced'
assert '.windowInsetsController' not in startup, 'controller must not be queried during onCreate'
assert 'updateSystemBarIconsSafely()' in main
assert 'shell.post {' in main and 'Log.w("AttendanceStartup", "System bar icon styling skipped"' in main
assert 'R.drawable.dashboard_illustration' in main
assert 'renderWeeklyChart(root, rows)' in main
assert 'private val versionName = "v1.6"' in main
assert 'versionCode = 162' in gradle and 'versionName = "1.6.0"' in gradle
assert 'compileSdk = 36' in gradle and 'targetSdk = 36' in gradle
for xml in (root / 'app/src/main/res').rglob('*.xml'):
    ElementTree.parse(xml)
print('ANDROID 16 STARTUP GUARD + v1.4 UI STATIC CHECKS PASSED')
