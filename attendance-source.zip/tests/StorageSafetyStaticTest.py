"""Guard against reporting failed writes as successful and corrupt-store overwrites."""
from pathlib import Path
base=Path(__file__).resolve().parents[1]
store=(base/'app/src/main/java/io/local/attendance/RecordStore.kt').read_text()
main=(base/'app/src/main/java/io/local/attendance/MainActivity.kt').read_text()
service=(base/'app/src/main/java/io/local/attendance/CollectorAccessibilityService.kt').read_text()
assert 'private fun storedRecordsJson(c: Context): String?' in store
assert 'JSONArray(raw); raw' in store
assert 'val before = storedRecordsJson(c) ?: return false' in store
assert 'private fun save(c: Context, entries: List<WorkRecord>): Boolean' in store
assert '.commit()' in store
assert 'getOrDefault(false)' in store
assert 'RecordStore.add(this@MainActivity, parsed)' in main
assert 'previous.size != JSONArray(before).length()' in store
assert 'if (RecordStore.replaceMonth(this, month, corrected))' in main
assert 'if (RecordStore.replaceMonth(this@MainActivity, month, emptyList()))' in main
assert 'if (!RecordStore.add(this, AttendanceParser.fromOverlappingPages' in service
assert '저장 공간 오류 · 기존 기록 보호를 위해 수집 중지' in service
assert 'RecordStore.clear(' not in main
print('STORAGE CORRUPTION/FAILED-WRITE SAFETY STATIC CHECKS PASSED')
