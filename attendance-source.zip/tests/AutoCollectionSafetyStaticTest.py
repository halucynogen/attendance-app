"""No-SDK static regression checks for v1.1 user-triggered auto collection."""
from pathlib import Path
from xml.etree import ElementTree
root=Path(__file__).resolve().parents[1]
service=(root/'app/src/main/java/io/local/attendance/CollectorAccessibilityService.kt').read_text()
activity=(root/'app/src/main/java/io/local/attendance/MainActivity.kt').read_text()
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
config=(root/'app/src/main/res/xml/accessibility_config.xml').read_text()
workflow=(root/'.github/workflows/build-signed-release.yml').read_text()
assert 'OFFICIAL_ATTENDANCE_PACKAGE = "com.kosaf.gpsAttendance"' in service
assert service.count('authorizedTargetVisible()') >= 6
assert 'if (!RecordStore.consent(this))' in service
assert 'if (active && sourceApp != null) shutdown' in service
assert 'fun begin()' in service and 'overlayButton("목록 수집"' in service
assert 'private fun shutdown(' in service and 'disableSelf()' in service
assert '자동 수집 모드' in activity and 'showAccessibilityDisclosure(openSettings = true)' in activity
assert 'isAccessibilityTool="true"' not in config
assert 'android.permission.INTERNET' not in manifest
assert 'attendance-source.zip' in workflow and 'gradle --no-daemon --stacktrace -p "$APP_ROOT"' in workflow
for r in (root/'app/src/main/res').rglob('*.xml'): ElementTree.parse(r)
ElementTree.parse(root/'app/src/main/AndroidManifest.xml')
print('AUTO COLLECTION CONSENT / TARGET / SCREENSHOT / WORKFLOW CHECKS PASSED')
