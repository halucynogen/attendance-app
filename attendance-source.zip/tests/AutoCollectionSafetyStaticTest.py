"""No-SDK static regression checks for v1.1 user-triggered auto collection."""
from pathlib import Path
from xml.etree import ElementTree
root=Path(__file__).resolve().parents[1]
service=(root/'app/src/main/java/io/local/attendance/CollectorAccessibilityService.kt').read_text()
activity=(root/'app/src/main/java/io/local/attendance/MainActivity.kt').read_text()
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
config=(root/'app/src/main/res/xml/accessibility_config.xml').read_text()
workflow=(root/'.github/workflows/build-signed-release.yml').read_text()
assert 'OFFICIAL_ATTENDANCE_PACKAGE = "com.kosaf.gpsAttendance"' in service
assert 'private fun verifiedRoot()' in service and 'root.packageName?.toString() != targetPackage' in service
assert 'takeScreenshot(' not in service and 'runMultiRegionOcr(' not in service
assert 'if (!RecordStore.consent(this))' in service
assert 'val foregroundChanged = event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED' in service
assert 'if (foregroundChanged)' in service and 'if (active && appRoot() == null)' in service
assert 'fun begin()' in service and 'overlayButton("목록 수집"' in service
assert 'private fun cancelCollection(' in service and 'private fun disableByUser()' in service and service.count('        disableSelf()') == 1
assert 'lifestyleCard("자동 수집"' in activity and 'showAccessibilityDisclosure(openSettings = true)' in activity
assert 'root.addView(section("🔎 자동 수집 모드"' not in activity
assert 'isAccessibilityTool="true"' not in config
assert 'android.permission.INTERNET' not in manifest
assert 'attendance-source.zip' in workflow and 'gradle --no-daemon --stacktrace -p "$APP_ROOT"' in workflow
for r in (root/'app/src/main/res').rglob('*.xml'): ElementTree.parse(r)
ElementTree.parse(root/'app/src/main/AndroidManifest.xml')
print('AUTO COLLECTION CONSENT / TARGET / TEXT-ONLY / WORKFLOW CHECKS PASSED')
