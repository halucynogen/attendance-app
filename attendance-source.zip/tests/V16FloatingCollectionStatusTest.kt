package io.local.attendance

fun main() {
    var checks = 0
    fun verify(name: String, expected: Boolean) { check(expected) { name }; checks++ }
    val completed = FloatingCollectionStatus.from("수집 완료 · 총 12건 / 신규 3건 · 통계 탭에서 확인하세요", false)
    verify("badge complete for compact AND expanded", completed.badge == "✓ 수집 완료")
    verify("phase complete", completed.phase == CollectionDisplayPhase.COMPLETE)
    verify("count survives compact truncation", completed.compactText.contains("총 12건 / 신규 3건"))
    verify("UI summary drops navigation hint", !completed.compactText.contains("통계 탭"))
    val persistent = FloatingCollectionStatus.from("수집 완료 · 총 12건 / 신규 3건 · 통계 탭에서 확인하세요", false)
    verify("reattached status remains complete", persistent == completed)
    val loading = FloatingCollectionStatus.from("4월 목록 수집 중", true)
    verify("progress badge", loading.badge == "● 수집 중" && loading.phase == CollectionDisplayPhase.RUNNING)
    val empty = FloatingCollectionStatus.from("확인 필요 · 읽은 기록 0건", false)
    verify("0 rows must not show success", empty.phase == CollectionDisplayPhase.WARNING && empty.badge != completed.badge)
    val interrupted = FloatingCollectionStatus.from("사용자가 수집 중지", false)
    verify("stop must not show success", interrupted.phase == CollectionDisplayPhase.WARNING)
    val idle = FloatingCollectionStatus.from("", false)
    verify("idle state", idle.phase == CollectionDisplayPhase.IDLE)
    val long = FloatingCollectionStatus.from("수집 완료 · 총 121건 / 신규 110건 · 통계 탭에서 확인하세요" + "X".repeat(400), false)
    verify("long completion remains visible", long.badge == "✓ 수집 완료" && long.compactText.startsWith("✓ 수집 완료"))
    println("PASS: $checks compact/expanded completion-state checks")
}
