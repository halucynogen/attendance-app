"""Fast, dependency-free checks run before Gradle on GitHub Actions.
This catches wrong ZIPs, missing resources, outdated version metadata, and
source/export regressions with actionable messages. It is not an APK compiler.
"""
from pathlib import Path
import re
import sys
from xml.etree import ElementTree as ET

root = Path(__file__).resolve().parents[1]
def require(ok, message):
    if not ok:
        raise SystemExit(f'::error::V1.6 preflight: {message}')

app_gradle = root / 'app' / 'build.gradle.kts'
require(app_gradle.is_file(), 'app/build.gradle.kts not found; check archive layout')
build = app_gradle.read_text(encoding='utf-8')
for key, value in [('compileSdk', '36'), ('targetSdk', '36'), ('versionCode', '161'), ('versionName', '"1.6.0"')]:
    require(re.search(rf'\b{key}\s*=\s*{re.escape(value)}', build), f'{key} must be {value}')

manifest_file = root / 'app/src/main/AndroidManifest.xml'
require(manifest_file.is_file(), 'AndroidManifest.xml is missing')
res = root / 'app/src/main/res'
source = root / 'app/src/main/java/io/local/attendance'
require(source.is_dir(), 'Kotlin source package is missing')
for name in ('MainActivity.kt', 'RecordStore.kt', 'CollectorAccessibilityService.kt',
             'AttendanceParser.kt', 'MonthlyWeekStats.kt', 'FloatingCollectionStatus.kt'):
    require((source / name).is_file(), f'missing Kotlin source: {name}')

for xml in sorted((root / 'app/src/main').rglob('*.xml')):
    try:
        ET.parse(xml)
    except ET.ParseError as error:
        raise SystemExit(f'::error::Malformed Android XML {xml.relative_to(root)}: {error}')

# Resource references resolve either to a file resource or to a value entry.
values = set()
for file in (res / 'values').glob('*.xml'):
    tree = ET.parse(file)
    for elem in tree.getroot():
        name = elem.get('name')
        if name:
            values.add((elem.tag, name))
for file in (res / 'values-v31').glob('*.xml'):
    tree = ET.parse(file)
    for elem in tree.getroot():
        name = elem.get('name')
        if name:
            values.add((elem.tag, name))
file_types = {'drawable', 'mipmap', 'xml', 'raw', 'font', 'anim', 'menu', 'layout'}
kt = '\n'.join(p.read_text(encoding='utf-8') for p in source.glob('*.kt'))
for typ, key in set(re.findall(r'\bR\.(drawable|mipmap|style|xml|string|color|id)\.([A-Za-z_]\w*)', kt)):
    if typ in file_types:
        ok = any((res / f'{typ}{suffix}' / f'{key}{ext}').exists()
                 for suffix in ('', '-anydpi-v26', '-v31', '-hdpi', '-mdpi', '-xhdpi', '-xxhdpi', '-xxxhdpi')
                 for ext in ('.xml', '.png', '.webp', '.jpg'))
    elif typ == 'id' and key in {'content'}:
        ok = True  # framework-owned android.R.id.content
    else:
        ok = (typ, key) in values
    require(ok, f'missing resource R.{typ}.{key}')

require('setMinimumHeight(dp(70))' in kt, 'previous LinearLayout minimum-height compilation fix missing')
require('private fun renderWeeklyChart' in kt and 'MonthlyWeekStats.weeks(' in kt,
        'calendar-aligned chart calculation missing')
require('showDateRangeWarning(' in kt and 'FIRST_YEAR' in kt and 'LAST_YEAR' in kt,
        'date range guard missing')
require('overlayStateBadge' in kt and 'FloatingCollectionStatus.from' in kt,
        'small accessibility toolbar success badge missing')
require('canTakeScreenshot="false"' in (res/'xml/accessibility_config.xml').read_text(encoding='utf-8'),
        'screen capture must remain disabled')
strings = (res/'values/strings.xml').read_text(encoding='utf-8')
require('화면 캡처나 OCR은 사용하지 않습니다' in strings,
        'accessibility disclosure does not match behavior')
print('PASS V1.6 preflight: version 161, Android XML, resource references, core features, accessibility disclosure')
