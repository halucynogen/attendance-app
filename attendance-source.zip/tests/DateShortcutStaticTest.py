"""Non-Android-SDK structural regression tests for v1.3 date shortcut."""
from pathlib import Path
import re
import xml.etree.ElementTree as ET
root = Path(__file__).resolve().parents[1]
app = (root / 'app/src/main/java/io/local/attendance/MainActivity.kt').read_text()
service = (root / 'app/src/main/java/io/local/attendance/CollectorAccessibilityService.kt').read_text()
gradle = (root / 'app/build.gradle.kts').read_text()
manifest = ET.parse(root / 'app/src/main/AndroidManifest.xml').getroot()
android='{http://schemas.android.com/apk/res/android}'
activity = manifest.find('application/activity')
assert activity.attrib[android+'launchMode'] == 'singleTop'
assert 'versionCode = 132' in gradle and 'versionName = "1.3.0"' in gradle
assert 'private val versionName = "v1.3"' in app
assert 'const val ACTION_EDIT_PERIOD' in app
assert 'action = MainActivity.ACTION_EDIT_PERIOD' in service
assert 'Intent.FLAG_ACTIVITY_NEW_TASK' in service and 'Intent.FLAG_ACTIVITY_SINGLE_TOP' in service
assert 'openDateEditor()' in service
x=service.index('overlayButton("목록 수집"')
y=service.index('overlayButton("날짜 수정"')
z=service.index('overlayButton("중지"')
assert x < y < z, 'date action must be between collect and stop'
assert '#FFE16B' in service and '#FFD44C' in service, 'yellow date button expected'
assert 'active || startPending || startCheckInProgress || screenshotInFlight' in service
assert 'periodEditorSection = dateEditor' in app
assert '날짜 설정 후 출근부로 돌아가기' in app
assert 'TYPE_WINDOW_STATE_CHANGED && appRoot() == null' in service
assert 'scroll.scrollTo(0, targetY)' in app
assert 'if (ValueAnimator.areAnimatorsEnabled() && !periodJumpRequested)' in app
assert 'if (periodJumpRequested) scrollToPeriodEditor()' in app
assert 'overlayDetails = details' in service
assert 'dragHandle.setOnTouchListener' in service
assert 'toggleFloatingMenu()' in service
assert 'wm?.updateViewLayout(wrap, params)' in service
assert 'getSharedPreferences("floating_menu_position", MODE_PRIVATE)' in service
assert 'WindowInsets.Type.tappableElement()' in app
assert 'window.isNavigationBarContrastEnforced = true' in app
assert 'v0.6~v1.1' in app and 'v0.1~v0.6' in app
assert app.count('changeLogItem("v0.6"') == 0, 'versions should be grouped into range summaries'
assert '6개 버전씩 묶어서' not in app
assert 'isAccessibilityTool="true"' not in (root / 'app/src/main/res/xml/accessibility_config.xml').read_text()
print('v1.3 DATE SHORTCUT + NAV + CHANGELOG STATIC TESTS PASSED')
