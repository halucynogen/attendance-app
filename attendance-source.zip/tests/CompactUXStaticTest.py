"""Regression contract for compact v1.4, text-only accessibility and app-state safety."""
from pathlib import Path
from xml.etree import ElementTree as ET
root=Path(__file__).resolve().parents[1]
main=(root/'app/src/main/java/io/local/attendance/MainActivity.kt').read_text()
service=(root/'app/src/main/java/io/local/attendance/CollectorAccessibilityService.kt').read_text()
store=(root/'app/src/main/java/io/local/attendance/RecordStore.kt').read_text()
config=(root/'app/src/main/res/xml/accessibility_config.xml').read_text()
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
build=(root/'app/build.gradle.kts').read_text()
assert 'versionCode = 150' in build and 'versionName = "1.5.0"' in build
assert 'val tabs = listOf("홈", "기록", "통계", "설정")' in main
assert '빠른 액션 허브' not in main and '조회 월 설정' not in main and '빠른 백업' not in main
assert 'renderTools' not in main and 'renderInfo' not in main
assert 'splashHandler.postDelayed(dismiss, 3000L)' in main
assert 'R.mipmap.ic_launcher' in main
assert 'flowDisplayMode' in main and 'WeeklyFlowView' in main
assert 'private fun switchFlowMode(next: Int)' in main
assert '"flow_display_mode"' in main
assert 'private fun renderSettings' in main and 'openOwnAppDetails()' in main
assert 'com.android.vending' in main and 'getApplicationIcon(pkg)' in main
assert '설치된 앱' in main and '제한된 설정 허용' in main
assert 'support.google.com/googleplay/answer/2812853' in main
assert 'support.google.com/android/answer/12623953' in main
assert 'takeScreenshot' not in service and 'TextRecognition' not in service
assert 'InputImage' not in main and 'TextRecognition' not in main
assert 'startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT)' not in main
assert 'android:canTakeScreenshot="false"' in config
assert 'com.google.mlkit' not in build
assert 'android.permission.INTERNET' not in manifest
assert 'if (previous.size != JSONArray(before).length())' in store
assert '?: throw IOException("저장 위치에 파일을 열 수 없습니다")' in main
assert 'lastRenderedRecordsHash != RecordStore.read(this).hashCode()' in main
assert 'periodEditorSection = dateEditor' in main and 'scroll.offsetDescendantRectToMyCoords' in main
assert 'AttendanceParser.monthlyShareText' in main and 'Intent.createChooser' in main
for f in (root/'app/src/main/res').rglob('*.xml'): ET.parse(f)
ET.parse(root/'app/src/main/AndroidManifest.xml')
print('COMPACT V1.4 UI / SPLASH / CHART-GRAPH / A11Y / STORAGE CHECKS PASSED')
