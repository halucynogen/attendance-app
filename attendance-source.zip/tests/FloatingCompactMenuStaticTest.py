"""Ensure compact overlay keeps all actions visible and draggable."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'app/src/main/java/io/local/attendance/CollectorAccessibilityService.kt').read_text()
a=(root/'app/src/main/java/io/local/attendance/MainActivity.kt').read_text()
g=(root/'app/build.gradle.kts').read_text()
assert 'overlayZoom = prefs.getFloat("pinch_zoom"' in s
assert 'overlayDetails?.visibility = View.VISIBLE' in s
assert 'info?.visibility = if (expanded) View.VISIBLE else View.GONE' in s
assert 'overlayActionButtons = listOf(collect, changeDate, stopButton)' in s
assert 'floatingMenuWidth()' in s and 'overlayZoom - 0.4f' in s
assert 'button.layoutParams' in s and 'if (expanded) 48 else 42' in s
assert 'dragHandle.setOnTouchListener' in s and 'ScaleGestureDetector' in s
assert 'putBoolean("collapsed", !overlayExpanded)' in s
assert 'openDateEditor()' in s and '#FFE16B' in s and '#FFD45D' in s
assert 'scroll.scrollTo(0, destination)' in a and 'root.addView(createPeriodEditorCard())' in a
assert 'versionCode = 170' in g and 'versionName = "1.7.0"' in g
print('COMPACT OVERLAY 3-BUTTON/DRAG/PERSISTENCE STATIC CHECKS PASSED')
