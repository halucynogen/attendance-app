"""Ensure compact overlay keeps all actions visible and draggable."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'app/src/main/java/io/local/attendance/CollectorAccessibilityService.kt').read_text()
a=(root/'app/src/main/java/io/local/attendance/MainActivity.kt').read_text()
g=(root/'app/build.gradle.kts').read_text()
assert 'overlayExpanded = !prefs.getBoolean("collapsed", true)' in s
assert 'overlayDetails?.visibility = View.VISIBLE' in s
assert 'info?.visibility = if (expanded) View.VISIBLE else View.GONE' in s
assert 'overlayActionButtons = listOf(collect, changeDate, stopButton)' in s
assert 'floatingMenuWidth()' in s and 'if (overlayExpanded) 358 else 296' in s
assert 'button.layoutParams' in s and 'if (expanded) 46 else 43' in s
assert 'dragHandle.setOnTouchListener' in s
assert 'putBoolean("collapsed", !overlayExpanded)' in s
assert 'openDateEditor()' in s and '#FFE16B' in s
assert 'scroll.scrollTo(0, destination)' in a and 'root.addView(createPeriodEditorCard())' in a
assert 'versionCode = 150' in g and 'versionName = "1.5.0"' in g
print('COMPACT OVERLAY 3-BUTTON/DRAG/PERSISTENCE STATIC CHECKS PASSED')
