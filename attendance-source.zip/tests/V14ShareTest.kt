package io.local.attendance
import java.time.YearMonth

fun main() {
    val month = YearMonth.of(2026, 11)
    val entries = listOf(
        WorkRecord("2026-11-02", "09:00", "18:00", 480, "기관확인 완료", "12:00", "13:00"),
        WorkRecord("2026-11-04", "10:30", "14:00", 210, "기관확인 전"),
        WorkRecord("2026-12-01", "09:00", "11:00", 120)
    )
    val share = AttendanceParser.monthlyShareText(entries, month)
    check("2026-11-02  09:00 ~ 18:00" in share)
    check("2026-11-04  10:30 ~ 14:00" in share)
    check("2026-12-01" !in share)
    check("12:00 ~ 13:00" in share)
    check("기관확인 전" in share && "기관확인 완료" in share)
    check("11시간 30분" in share) { share }
    check(share.lines().any { it.contains("2건") })
    check("저장된 근무기록이 없습니다." in AttendanceParser.monthlyShareText(emptyList(), month))
    check(!WorkRecord("2026-11-31", "09:00", "11:00").valid)
    check(!WorkRecord("2026-11-02", "18:00", "09:00").valid)
    check(AttendanceParser.monthlyShareText(entries + entries.first(), month) == share)
    val hostile = WorkRecord("2026-11-05", "09:00", "11:00", status="=HYPERLINK(\"a\")")
    val csv = AttendanceParser.csv(listOf(hostile), month)
    check("\"'=HYPERLINK" in csv) { csv }
    println("V1.4 SHARE/INVALID-DATE/CSV GUARD CHECKS PASSED")
}
