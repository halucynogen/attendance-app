"""Priority-ordered v1.6 checks: records crash pressure, contrast, accessibility, event editor."""
from pathlib import Path
import xml.etree.ElementTree as ET
root = Path(__file__).resolve().parents[1]
main = (root/'app/src/main/java/io/local/attendance/MainActivity.kt').read_text()
service = (root/'app/src/main/java/io/local/attendance/CollectorAccessibilityService.kt').read_text()
gradle = (root/'app/build.gradle.kts').read_text()
manifest = (root/'app/src/main/AndroidManifest.xml').read_text()
assert 'versionCode = 162' in gradle and 'versionName = "1.6.0"' in gradle
# The records navigation must be lightweight and must not eagerly instantiate its export editor.
assert 'private fun showRecordEditor(canonical: String)' in main
assert 'addView(action("수정하기", primary = true)' in main
assert 'private fun saveEditorDraft(' in main
assert 'recordEditorOpen' not in main
assert main.index('private fun showRecordEditor(canonical: String)') > main.index('private fun renderRecords(root: LinearLayout)')
assert 'if (renderingTab) return' in main and 'renderingTab = true' in main
assert 'finally {' in main and 'renderingTab = false' in main
assert 'if (tab != 1 && ValueAnimator.areAnimatorsEnabled()' in main
assert 'sorted.take(50)' in main and 'sorted.take(5)' in main
assert 'LinearLayout.LayoutParams(dp(65), -2)' in main
assert 'LinearLayout.LayoutParams(dp(74), -2)' in main
# Diary time must have both hours and minutes in large high-contrast separate lines.
assert 'section("근무 다이어리"' in main
assert 'my little work diary' not in main and '♡' not in main
assert '"${workMinutes / 60}시간"' in main and '"${workMinutes % 60}분"' in main
assert 'if (darkMode) Color.WHITE else ink' in main and 'dp(70)' in main
# The accessibility toolbar must rearm after collection and after each re-entry.
assert 'private fun restoreOverlayForOfficialApp()' in service
assert 'private fun resetOverlayRetry()' in service
assert 'wasOfficialInForeground = false' in service
assert 'resetOverlayRetry()' in service[service.index('private fun cancelCollection'):service.index('private fun disableByUser')]
assert 'restoreOverlayForOfficialApp()' in service[service.index('override fun onAccessibilityEvent'):service.index('override fun onInterrupt')]
assert 'OFFICIAL_ATTENDANCE_PACKAGE = "com.kosaf.gpsAttendance"' in service
assert 'RecordStore.consent(this)' in service
# A chosen day asks the OS for a new EVENT editor, not a generic calendar home page.
assert 'startActivity(intent)' in main
assert 'setItems(items)' in main
assert 'if (shifts.size == 1)' in main
assert 'setMessage("근무를 선택하면' not in main
assert 'offerCalendarWebFallback' in main
assert 'calendar.google.com/calendar/render' in main
ET.fromstring(manifest)
print('PASS v1.6 priority fixes: lazy record editor, bounded rows, diary contrast, repeat overlay, calendar event intent')
