"""Guard the simplified records screen, distinct mini zoom, and diary calendar palette."""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
main = (root/'app/src/main/java/io/local/attendance/MainActivity.kt').read_text()
service = (root/'app/src/main/java/io/local/attendance/CollectorAccessibilityService.kt').read_text()
gradle = (root/'app/build.gradle.kts').read_text()
assert 'versionName = "1.6.0"' in gradle and 'versionCode = 161' in gradle
assert '1 -> try {' in main and 'catch (error: Exception)' in main
assert 'AttendanceRecords' in main and '기록 탭 오류:' in main
assert '기록을 지우거나 앱을 종료하지 않았어요.' in main
assert 'record_editor_illustration' not in main, 'unused illustration should not load when opening records'
assert 'scrollRecordEditor(editor, -1)' in main and 'scrollRecordEditor(editor, 1)' in main
assert 'saveEditedRecords(editor.text.toString())' in main
assert 'extraActions.visibility = if (extraActions.visibility == View.VISIBLE) View.GONE else View.VISIBLE' in main
assert 'RecordStore.replaceMonth(this, month, corrected)' in main
assert 'RecordStore.replaceMonth(this@MainActivity, month, emptyList())' in main
assert 'setOnTouchListener { _, event ->' not in main, 'no nonessential button animation'
assert 'val factor = detector.scaleFactor * detector.scaleFactor' in service
assert 'coerceIn(0.4f, 1.45f)' in service
assert '164 + (progress * 176f)' in service
assert 'arrayOf("수집", "날짜", "중지")' in service
assert 'height = dp(if (expanded) 48 else 42)' in service
assert 'if (wasExpanded != overlayExpanded) applyFloatingMenuSize(wrap)' in service
assert 'overlayStateBadge?.textSize' in service
assert 'updateCompactStatus()' in service
assert 'section("근무 다이어리"' in main
assert 'my little work diary' not in main and '♡' not in main
assert 'if (recordEditorOpen)' in main and 'recordEditorOpen = false' in main
assert 'if (darkMode)' in main and 'if (hasWork || isToday)' in main
assert 'setStroke(dp(1), outline, dp(3).toFloat(), dp(3).toFloat())' in main
assert 'setOnClickListener { showCalendarDay(date, shifts) }' in main
print('PASS V1.6 stable records / simple actions / true mini pinch / pastel light and dark diary')
