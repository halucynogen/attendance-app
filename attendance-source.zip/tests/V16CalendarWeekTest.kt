package io.local.attendance

import java.time.LocalDate
import java.time.YearMonth
import java.time.DayOfWeek
import kotlin.math.abs

/** Pure Kotlin data/regression tests; no emulator or UI automation required. */
fun main() {
    var checks = 0
    fun verify(message: String, condition: Boolean) {
        check(condition) { "FAIL: $message" }
        checks++
    }
    fun record(date: String, begin: String = "09:00", finish: String = "10:00") =
        WorkRecord(date, begin, finish)

    val four = MonthlyWeekStats.weeks(YearMonth.of(2021, 2), emptyList())
    verify("February 2021: four calendar weeks", four.size == 4)
    verify("February starts Monday", four.first().firstDay == LocalDate.of(2021, 2, 1))
    verify("February ends Sunday", four.last().lastDay == LocalDate.of(2021, 2, 28))

    val march = YearMonth.of(2026, 3)
    val shifts = listOf(
        record("2026-03-01", "09:00", "11:00"),
        record("2026-03-02"),
        record("2026-03-31"),
        record("2026-02-27", "09:00", "18:00"),
        record("2026-04-01", "09:00", "18:00")
    )
    val six = MonthlyWeekStats.weeks(march, shifts)
    verify("March 2026: six calendar weeks", six.size == 6)
    verify("first week contains Mar 1 only", six.first().firstDay == LocalDate.of(2026, 3, 1) && six.first().lastDay == LocalDate.of(2026, 3, 1))
    verify("second week Mon to Sun", six[1].firstDay == LocalDate.of(2026, 3, 2) && six[1].lastDay == LocalDate.of(2026, 3, 8))
    verify("last week reaches Mar 31", six.last().firstDay == LocalDate.of(2026, 3, 30) && six.last().lastDay == LocalDate.of(2026, 3, 31))
    verify("month total excludes adjacent months", six.sumOf { it.minutes } == 240)
    verify("first week 50 percent", abs(six.first().sharePercent - 50.0) < 0.0001)
    verify("second week 25 percent", abs(six[1].sharePercent - 25.0) < 0.0001)
    verify("last week 25 percent", abs(six.last().sharePercent - 25.0) < 0.0001)
    verify("percentages sum to 100", abs(six.sumOf { it.sharePercent } - 100.0) < 0.0001)
    verify("all weeks ordered without gaps", six.zipWithNext().all { (a, b) -> a.lastDay.plusDays(1) == b.firstDay })

    val jan2000 = MonthlyWeekStats.weeks(YearMonth.of(2000, 1), emptyList())
    verify("Jan 2000 valid", jan2000.first().firstDay == LocalDate.of(2000, 1, 1))
    val dec2100 = MonthlyWeekStats.weeks(YearMonth.of(2100, 12), listOf(record("2100-12-31")))
    verify("Dec 2100 valid", dec2100.last().lastDay == LocalDate.of(2100, 12, 31))
    verify("end-of-range record counted", dec2100.sumOf { it.minutes } == 60)
    verify("zero total no NaN", jan2000.all { it.sharePercent == 0.0 })
    verify("1999 rejected", !MonthlyWeekStats.supported(YearMonth.of(1999, 12)))
    verify("2101 rejected", !MonthlyWeekStats.supported(YearMonth.of(2101, 1)))
    verify("unsupported month throws before calculations", runCatching { MonthlyWeekStats.weeks(YearMonth.of(2101, 1), emptyList()) }.isFailure)

    for (year in 2000..2100) for (mon in 1..12) {
        val ym = YearMonth.of(year, mon)
        val weeks = MonthlyWeekStats.weeks(ym, emptyList())
        verify("$ym rows 4-6", weeks.size in 4..6)
        verify("$ym starts 1", weeks.first().firstDay == ym.atDay(1))
        verify("$ym ends last", weeks.last().lastDay == ym.atEndOfMonth())
        verify("$ym date continuity", weeks.zipWithNext().all { (a, b) -> a.lastDay.plusDays(1) == b.firstDay })
        verify("$ym weeks start Monday (except month first)", weeks.drop(1).all { it.firstDay.dayOfWeek == DayOfWeek.MONDAY })
        verify("$ym weeks end Sunday (except month end)", weeks.dropLast(1).all { it.lastDay.dayOfWeek == DayOfWeek.SUNDAY })
    }
    println("PASS: $checks calendar-week, percentage and range checks")
}
