package io.local.attendance

import java.time.YearMonth

fun main() {
    val years = listOf(1, 12, 99, 999, 1000, 1357, 1800, 1900, 1999, 2000, 2024, 2026, 2099, 2100, 2500, 4096, 9999)
    var checks = 0
    fun checkCase(desc: String, expected: Boolean) {
        check(expected) { "FAIL: $desc" }
        checks++
    }
    for (year in years) {
        for (month in 1..12) {
            val ym = YearMonth.of(year, month)
            val screen = """
                ${year.toString().padStart(4, '0')}.${month.toString().padStart(2, '0')}
                국가근로장학금
                ${month.toString().padStart(2, '0')}.01 2시간 0분 기관확인 전
                근무 09:00 ~ 11:00
            """.trimIndent()
            val found = AttendanceParser.fromListPage(screen, ym)
            checkCase("$year / $month header", AttendanceParser.monthHeader(screen) == ym)
            checkCase("$year / $month rows", found.size == 1 && found.single().date == ym.atDay(1).toString())
        }
    }
    for (year in years) {
        val ym = YearMonth.of(year, 3)
        val line = "${year.toString().padStart(4, '0')}-03-08 11:00 ~ 15:00"
        checkCase("$year editable", AttendanceParser.fromEditableText(line, ym).single().minutes == 240)
    }
    checkCase("placement period is not an attendance shift", AttendanceParser.fromListPage(
        "2026.09\n2026.09.10 ~\n10.01 2시간 0분\n근무 09:00 ~ 11:00", YearMonth.of(2026, 9)
    ).isEmpty())
    checkCase("placement full date isn't month header", AttendanceParser.monthHeader("근로기관 배치 2026.09.10 ~ 2027.02.28") == null)
    checkCase("invalid year not allowed", AttendanceParser.monthHeader("0000.01\n01.01 근무 09:00 ~ 10:00") == null)
    checkCase("wrong month not collected", AttendanceParser.fromListPage("2100.01\n01.02 근무 09:00 ~ 10:00", YearMonth.of(2100, 2)).isEmpty())
    println("ALL $checks YEAR-RANGE CHECKS PASSED")
}
