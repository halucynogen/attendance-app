"""V1.5 structural regression suite; run in addition to parser tests on each upload."""
from pathlib import Path
import re, zipfile
from xml.etree import ElementTree as ET
base=Path(__file__).resolve().parents[1]
main=(base/'app/src/main/java/io/local/attendance/MainActivity.kt').read_text()
svc=(base/'app/src/main/java/io/local/attendance/CollectorAccessibilityService.kt').read_text()
store=(base/'app/src/main/java/io/local/attendance/RecordStore.kt').read_text()
config=(base/'app/build.gradle.kts').read_text()
workflows=[(base/'.github/workflows'/n).read_text() for n in ('build-apk.yml','build-signed-release.yml')]
assert 'versionCode = 161' in config and 'versionName = "1.6.0"' in config
assert 'applicationId = "io.local.attendance"' in config
assert 'actual_code' in '\n'.join(workflows) and '161' in '\n'.join(workflows)
assert 'actual_name' in '\n'.join(workflows) and '1.6.0' in '\n'.join(workflows)
assert 'attendance-v1.6-' in '\n'.join(workflows)
assert 'val tabs = listOf("홈", "기록", "통계", "설정")' in main
assert '빠른 액션 허브' not in main
assert 'root.addView(section("텍스트 붙여넣기"' in main
assert main.index('root.addView(section("텍스트 붙여넣기"') < main.index('root.addView(section("추출 결과 · 편집"')
assert 'openRecordsTab()' in main
assert '한국장학재단 공식 출근부 열기' in main
assert 'com.kosaf.gpsAttendance' in main
assert 'renderWeeklyChart(root, rows)' in main
assert 'action("차트"' in main and 'action("그래프"' in main
assert 'lastRenderedCollectionInfoHash' in main
assert 'RecordStore.lastCollection(this).hashCode()' in main
assert 'setLastCollection' in store and 'RecordStore.setLastCollection' in svc
assert 'showLaunchSplash()' not in main, 'duplicate in-app splash must not return'
assert 'AttendanceSplashTheme' in (base/'app/src/main/AndroidManifest.xml').read_text()
assert 'private fun setDarkMode' in main and 'getSharedPreferences("attendance_display"' in main
assert 'root.addView(section("화면 모드"' in main
assert 'v0.1 ~ v0.7' in main and 'v0.7 ~ v1.4' in main
assert 'private fun cancelCollection(' in svc
assert 'private fun disableByUser()' in svc and 'disableFromApp()' in svc
assert svc.count('disableSelf()') == 1, 'only the explicit user action may disable accessibility'
assert svc.count('        disableSelf()') == 1, 'must not disable accessibility automatically'
assert 'if (!RecordStore.consent(this)) {' in svc and 'overlay?.visibility = View.GONE' in svc
assert 'shutdown(' not in svc
assert 'takeScreenshot' not in svc and 'com.google.mlkit' not in config
assert 'setMinimumHeight(dp(70))' in main and 'minHeight = dp(70)' not in main
assert 'versionName = "1.6.0"' in config
for res in (base/'app/src/main/res').rglob('*.xml'): ET.parse(res)
ET.parse(base/'app/src/main/AndroidManifest.xml')
print('PASS V1.5 version/workflows/4-tabs/stats/paste/official-app/splash/theme/a11y/XML')
