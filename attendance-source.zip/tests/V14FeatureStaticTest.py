"""V1.4 Android source, sharing, splash, storage, and accessibility regressions."""
from pathlib import Path
from xml.etree import ElementTree as ET
root = Path(__file__).resolve().parents[1]
main = (root/'app/src/main/java/io/local/attendance/MainActivity.kt').read_text()
parser = (root/'app/src/main/java/io/local/attendance/AttendanceParser.kt').read_text()
manifest = ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
a = '{http://schemas.android.com/apk/res/android}'
assert manifest.find('application').attrib[a+'theme'] == '@style/AttendanceSplashTheme'
assert manifest.find('application').attrib[a+'allowBackup'] == 'false'
assert manifest.find('application').attrib[a+'icon'] == '@mipmap/ic_launcher'
assert 'android.permission.INTERNET' not in (root/'app/src/main/AndroidManifest.xml').read_text()
assert 'windowSplashScreenAnimatedIcon' in (root/'app/src/main/res/values-v31/styles.xml').read_text()
assert '@drawable/ic_launcher_foreground' in (root/'app/src/main/res/values-v31/styles.xml').read_text()
assert 'ic_launcher_foreground' in (root/'app/src/main/res/drawable/splash_background.xml').read_text()
assert 'setTheme(if (darkMode) R.style.AttendanceThemeDark else R.style.AttendanceTheme)' in main
assert 'val destination = (scroll.scrollY + rectangle.top - topInset)' in main
assert 'editor.announceForAccessibility' in main
assert 'root.addView(createPeriodEditorCard())' in main
assert 'root.addView(createPeriodEditorCard())\n            return' not in main
assert 'shareSummary()' in main and '전체 날짜·시각 복사' in main
assert 'putExtra(Intent.EXTRA_TEXT, fullMonthText())' in main
assert 'AttendanceParser.monthlyShareText(currentRecords(), month)' in main
assert 'record.date' in parser and 'record.start' in parser and 'record.end' in parser
assert 'record.breakMinutes' in parser and 'record.reportedMinutes' in parser
assert 'val output = contentResolver.openOutputStream(data.data!!)' in main
assert '?: throw IOException("저장 위치에 파일을 열 수 없습니다")' in main
assert 'pendingFileContent = if (request == saveCsv)' in main
assert 'lastRenderedRecordsHash != RecordStore.read(this).hashCode()' in main
assert 'showLaunchSplash()' not in main and 'splashHandler.postDelayed(' not in main
assert 'monthly_share_illustration' in main and 'WeeklyFlowView' in main
assert 'renderStats(column)' in main and 'renderSettings(column)' in main
for xml in (root/'app/src/main/res').rglob('*.xml'):
    ET.parse(xml)
print('V1.4 FEATURE/ACCESSIBILITY/SPLASH/STORAGE STATIC CHECKS PASSED')
