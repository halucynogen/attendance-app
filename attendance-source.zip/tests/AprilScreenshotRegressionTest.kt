package io.local.attendance

import java.time.YearMonth

/** April 2026 screenshot: five 09:00-18:00 rows show lunch 12:00-13:00 and 8h. */
fun main() {
    val month = YearMonth.of(2026, 4)
    val screen = """
        2026. 4
        총 예상 근로시간 68시간
        제외예정시간 0분
        예상 장학금 869,720원
        국가근로장학금
        2026.03.01 ~ 2026.06.26
        근로기관
        기관확인 완료
        04.29 8시간 0분
        근무 09:00 ~ 18:00
        식사 12:00 ~ 13:00
        기관확인 완료
        04.28 4시간 0분
        근무 09:00 ~ 13:00
        기관확인 완료
        04.24 3시간 0분
        근무 09:00 ~ 12:00
        기관확인 완료
        04.22 8시간 0분
        근무 09:00 ~ 18:00
        식사 12:00 ~ 13:00
        기관확인 완료
        04.21 4시간 0분
        근무 09:00 ~ 13:00
        기관확인 완료
        04.17 3시간 0분
        근무 09:00 ~ 12:00
        기관확인 완료
        04.15 8시간 0분
        근무 09:00 ~ 18:00
        식사 12:00 ~ 13:00
        기관확인 완료
        04.14 4시간 0분
        근무 09:00 ~ 13:00
        기관확인 완료
        04.10 3시간 0분
        근무 09:00 ~ 12:00
        기관확인 완료
        04.08 8시간 0분
        근무 09:00 ~ 18:00
        식사 12:00 ~ 13:00
        기관확인 완료
        04.07 4시간 0분
        근무 09:00 ~ 13:00
        기관확인 완료
        04.03 3시간 0분
        근무 09:00 ~ 12:00
        기관확인 완료
        04.01 8시간 0분
        근무 09:00 ~ 18:00
        식사 12:00 ~ 13:00
    """.trimIndent()
    val rows = AttendanceParser.fromListPage(screen, month)
    check(rows.size == 13) { "Expected 13 shifts; found ${rows.size}: $rows" }
    check(rows.sumOf { it.grossMinutes } == 73 * 60) { "gross was ${rows.sumOf { it.grossMinutes }}" }
    check(rows.sumOf { it.breakMinutes } == 5 * 60)
    check(rows.sumOf { it.minutes } == 68 * 60) { "net was ${rows.sumOf { it.minutes }}" }
    check(rows.count { it.differentFromReported } == 0)
    check(rows.count { it.breakMinutes == 60 } == 5)
    check(rows.all { it.status == "기관확인 완료" })

    val april22 = rows.first { it.date == "2026-04-22" }
    check(april22.grossMinutes == 9 * 60 && april22.breakMinutes == 60 && april22.minutes == 8 * 60)
    check(april22.reportedMinutes == 8 * 60)

    val exported = AttendanceParser.export(rows, month)
    check(exported.contains("식사 12:00 ~ 13:00"))
    val edited = AttendanceParser.fromEditableText(exported, month)
    check(edited.size == 13 && edited.sumOf { it.minutes } == 68 * 60)
    check(edited.none { it.differentFromReported })
    val csv = AttendanceParser.csv(rows, month)
    check(csv.lines().size == 14)
    check(csv.contains("식사차감분"))

    val stale = WorkRecord("2026-04-22", "09:00", "18:00", 480, "기관확인 완료")
    check(stale.differentFromReported && stale.minutes == 540)
    check(AttendanceParser.unique(listOf(stale, april22)).single().minutes == 480) { "new lunch data should supersede saved old row" }

    // Do NOT silently assume lunch from 09:00-18:00 or from a mismatch alone.
    val noBreak = AttendanceParser.fromListPage("04.22 8시간 0분 근무 09:00 ~ 18:00", month).single()
    check(noBreak.minutes == 540 && noBreak.differentFromReported)
    val standaloneBreak = AttendanceParser.fromListPage("04.22 8시간 0분 09:00 ~ 18:00 식사 12:00 ~ 13:00", month)
    check(standaloneBreak.size == 1 && standaloneBreak.single().minutes == 480)
    val invalidBreak = AttendanceParser.fromListPage("04.22 8시간 0분 근무 09:00 ~ 18:00 식사 18:30 ~ 19:00", month).single()
    check(invalidBreak.breakMinutes == 0 && invalidBreak.differentFromReported)
    println("APRIL SCREENSHOT REGRESSION: 13 shifts, 73h gross, 5h break, 68h net, 0 mismatches PASSED")
}
