# V1.5 검증 결과 (2026-11-05)

## 완료한 점검

- `V15RegressionStaticTest.py` 등 정적 검사 **9종 통과**: 앱 버전, 4개 탭, 기록 입력, 그래프/차트 전환, 수집 상태 저장/갱신, 접근성 명시적 해제, 스플래시 복귀 제외, 설정 테마, 월간 공유, 공식 앱 바로가기, XML 리소스.
- Kotlin PSI 구문 파서: `AttendanceParser.kt`, `CollectorAccessibilityService.kt`, `MainActivity.kt`, `RecordStore.kt` **4개 구문 오류 없음**.
- JVM Kotlin 테스트: `ParserTest.kt` 11개, `ExtendedParserTest.kt` 35개 그룹(330개 자동 생성 케이스), `YearRangeTest.kt` 429개, `AprilScreenshotRegressionTest.kt` 13개 근무 기록 시나리오, `V14ShareTest.kt` 공유·CSV 보호 시나리오 **통과**.
- ZIP 무결성 검사와 GitHub 워크플로 버전 조건 확인.
- `MainActivity.kt`의 `LinearLayout.minHeight`를 `setMinimumHeight()`로 수정한 패치를 유지합니다.

## 아직 확인하지 못한 점

이 환경에는 **Android SDK 36와 Gradle 실행 환경이 없어 실제 `:app:assembleDebug` 및 `:app:assembleRelease`를 수행하지 못했습니다.** 정적/구문/로직 검사가 통과했더라도 Android API 타입 오류, OEM 접근성 동작, 실제 APK 설치·업데이트 성공을 보장할 수 없습니다. GitHub Actions에서 `Build APK` 통과를 확인하고 기기에서 자동 수집부터 확인해야 합니다.

## 간단 실기기 확인 순서

1. GitHub Actions로 V1.5 APK를 빌드하고 이전 앱과 동일한 서명키로 업데이트되는지 확인합니다.
2. 홈의 한국장학재단 공식 출근부 열기 및 날짜 변경을 확인합니다.
3. 공식 출근부 목록에서 수집 후 통계 탭의 기록 수/차트/그래프를 확인합니다. 수집 실패 시 안내 문구 확인.
4. 접근성 설정 왕복 후 기록 탭에서 텍스트 붙여넣기가 보이고 입력이 유지되는지 확인합니다.
5. 수집 중지 후 접근성 권한이 켜져 있는지 확인하고, 사용자가 설정에서 직접 끈 경우에만 꺼지는지 확인합니다.
6. 라이트/다크 전환 후 4개 탭을 살펴보고 앱 재진입 시 유지되는지 확인합니다.
7. 앱을 백그라운드로 보냈다가 돌아올 때 3초 스플래시가 다시 나타나지 않는지 확인합니다.

## 2026-11-05 추가: GitHub Actions ZIP 인식 오류 검증

- 기존 `unzip -tq` 성공 뒤 스크립트가 조용히 종료되던 경로 수정
- 정상 ZIP / 한 단계 상위 폴더 ZIP / 전체 업로드 묶음 ZIP / 구버전 ZIP / 프로젝트 누락 ZIP / ZIP 미업로드 등 **6가지 상황 × 2개 워크플로 = 12가지 쉘 실행 검사 모두 통과**
- 오류 상황은 `::error::` 메시지로 원인 표시
- 실제 Android SDK를 통한 APK 컴파일은 테스트하지 못함; GitHub Actions에서 확인 필요
