# 근무로그 v1.2 — GitHub Kotlin 빌드 오류 수정

## 수정된 오류

GitHub Actions `:app:compileReleaseKotlin` 단계에서 발생한 다음 컴파일 오류를 수정했습니다.

```
MainActivity.kt:930:53 Unresolved reference 'it'
```

`View.post { ... }` 내부에는 `it` 람다 인자가 없는데 스크롤 뷰로 사용한 것이 원인이었습니다.

이전 코드:

```kotlin
private fun restoreScroll(scrollY: Int) {
    (host.getChildAt(0) as? ScrollView)?.post { it.scrollTo(0, scrollY) }
}
```

수정 코드:

```kotlin
private fun restoreScroll(scrollY: Int) {
    val scrollView = host.getChildAt(0) as? ScrollView ?: return
    scrollView.post { scrollView.scrollTo(0, scrollY) }
}
```

수정된 코드는 기존의 연도/월 직접 적용, 이전/이번/다음 달 이동 시 스크롤 위치 유지 동작을 계속 사용합니다.

## GitHub 적용

1. `attendance-source.zip` 파일을 GitHub 저장소 루트의 같은 이름 파일로 교체하고 커밋합니다.
2. `Actions → Build Signed Attendance APK → Run workflow`를 실행합니다.
3. 기존 `SIGNING_KEYSTORE_B64`, `RELEASE_KEYSTORE_PASSWORD`, `RELEASE_KEY_ALIAS`, `RELEASE_KEY_PASSWORD`는 **그대로 유지**합니다.
4. 성공하면 최신 실행의 `Artifacts`에서 APK를 받습니다.

## 테스트

- 파서 단위 테스트: 11개 통과
- 2026년 4월 사례: 13건 / 73시간 출퇴근 합계 / 5시간 식사 차감 / 68시간 순수 근무 / 불일치 0건 통과
- 확장 파서: 35그룹 및 330개 시간 조합 통과
- 연도 범위: 429개 통과
- Android 16 초기화 및 접근성 보안 정적 검사 통과
- 스크롤 복원 코드 정적 검사 통과

이 실행 환경에 Android SDK가 없어 **전체 APK 빌드 및 실기기 실행은 검증하지 못했습니다**. APK 설치 차단 및 접근성 권한 거부와는 별개의 컴파일 수정입니다.
