package io.local.attendance

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.view.View
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import java.time.YearMonth
import kotlin.math.max

/**
 * User-initiated, read-only monthly LIST collector.
 * Never taps attendance modification, approval, submit, login or individual dates.
 * A11y text preferred; one-page OCR fallback requires Android 11+ and a permitted screenshot.
 */
class CollectorAccessibilityService : AccessibilityService() {
    companion object {
        // The app's explicit Exit button can request shutdown while the same-process
        // accessibility service is alive. There is intentionally no way to enable it silently.
        private var connected: CollectorAccessibilityService? = null
        fun shutdownFromApp() { connected?.shutdown("앱 종료") }
    }
    private val handler = Handler(Looper.getMainLooper())
    private var overlay: LinearLayout? = null
    private var info: TextView? = null
    private var wm: WindowManager? = null
    private var active = false
    private var runId = 0
    private var targetPackage = ""
    private var month: YearMonth? = null
    private var pages = 0
    private var collected = 0
    private var repeated = 0
    private var previousSignature = ""
    private var screenshotTried = 0
    private var previousPageText = ""
    private var startCheckInProgress = false
    private var startCheckToken = 0
    private var startedByOcr = false
    private var zeroRecordPages = 0
    private var diagnostic = ""
    private var screenshotInFlight = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        connected = this
        attachControls()
    }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // No unsolicited collection; only the user presses the visible Start button.
    }
    override fun onInterrupt() = shutdown("서비스 중단")
    override fun onDestroy() {
        active = false; runId++; startCheckToken++
        detachControls()
        if (connected === this) connected = null
        super.onDestroy()
    }

    private fun detachControls() {
        overlay?.let { runCatching { wm?.removeView(it) } }
        overlay = null
        info = null
    }

    private fun shutdown(reason: String) {
        // disableSelf() explicitly turns the accessibility switch OFF in Android settings.
        // The floating menu disappears immediately. Finishing the Activity in the background
        // alone does NOT stop a system-managed AccessibilityService.
        active = false; runId++
        startCheckToken++; startCheckInProgress = false
        handler.removeCallbacksAndMessages(null)
        detachControls()
        if (reason != "앱 종료") toast("접근성 자동 해제: $reason")
        disableSelf()
    }

    private fun attachControls() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = panelBackground(Color.parseColor("#F9FAFB"), Color.parseColor("#C7D7FE"))
        }
        wrap.addView(TextView(this).apply {
            text = "출근부 목록 수집"
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#163DAD"))
        })
        val status = TextView(this).apply {
            text = "목록 화면에서 시작"
            textSize = 12.5f
            maxLines = 4
            setTextColor(Color.parseColor("#344054"))
            setPadding(0, dp(6), 0, dp(8))
        }
        info = status
        wrap.addView(status)
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(overlayButton("목록 수집", Color.parseColor("#275DFF"), Color.WHITE) { begin() })
        buttons.addView(overlayButton("중지", Color.parseColor("#F2F4F7"), Color.parseColor("#101828")) {
            shutdown("사용자 중지")
        }.apply {
            (layoutParams as LinearLayout.LayoutParams).marginStart = dp(8)
        })
        wrap.addView(buttons)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(84) }
        try { wm?.addView(wrap, params); overlay = wrap }
        catch (e: Exception) { toast("표시 실패: ${e.localizedMessage}") }
    }

    private fun overlayButton(label: String, fill: Int, textColor: Int, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(textColor)
            background = panelBackground(fill, Color.TRANSPARENT, radiusDp = 14)
            textSize = 13f
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1f)
        }
    }

    private fun panelBackground(fill: Int, stroke: Int, radiusDp: Int = 18) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(radiusDp).toFloat()
        setColor(fill)
        if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }

    private fun begin() {
        if (active || startCheckInProgress) return
        if (!RecordStore.consent(this)) return toast("먼저 수집 앱에서 권한 안내에 동의하세요.")
        val root = rootInActiveWindow ?: return toast("현재 화면 텍스트에 접근할 수 없습니다.")
        val candidatePackage = root.packageName?.toString().orEmpty()
        if (candidatePackage.isBlank() || candidatePackage == packageName) {
            return toast("한국장학재단 조회 목록 화면에서 실행하세요.")
        }
        val text = mergedAccessibilityText(root)
        val headerMonth = AttendanceParser.monthHeader(text)
        val selected = RecordStore.selectedMonth(this)
        if (headerMonth != null && headerMonth != selected) {
            return toast("월 불일치: 앱 설정 $selected / 장학재단 화면 $headerMonth. 수집 앱에서 조회 월을 맞춰주세요.")
        }
        if (text.contains("국가근로장학금") && text.contains("조회") &&
            (headerMonth != null || AttendanceParser.fromListPage(text, selected).isNotEmpty())) {
            startCollection(candidatePackage, selected, false)
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // If the official app hides the accessibility text, verify the visible screen
            // via on-device OCR BEFORE allowing collection. A failed check never starts it.
            verifyStartScreenshot(candidatePackage)
        } else {
            toast("목록 화면/조회 월을 읽지 못했습니다. 저장된 스크린샷 OCR을 사용하세요.")
        }
    }

    private fun startCollection(appPackage: String, ym: YearMonth, viaOcr: Boolean) {
        if (active) return
        active = true
        runId++
        targetPackage = appPackage
        month = ym
        startedByOcr = viaOcr
        pages = 0; collected = 0; repeated = 0; zeroRecordPages = 0
        previousSignature = ""; screenshotTried = 0; previousPageText = ""
        status("${ym.year}.${ym.monthValue} 목록 수집 중")
        val id = runId
        handler.postDelayed({ processPage(id) }, if (viaOcr) 1500 else 300)
    }

    private fun verifyStartScreenshot(candidatePackage: String) {
        startCheckInProgress = true
        val checkId = ++startCheckToken
        status("목록 화면 확인용 OCR 진행 중")
        try {
            overlay?.visibility = View.INVISIBLE
            handler.postDelayed({
            try { takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onFailure(errorCode: Int) {
                    overlay?.visibility = View.VISIBLE
                    if (checkId != startCheckToken) return
                    startCheckInProgress = false
                    toast("목록 확인용 화면 캡처 실패($errorCode). 수집을 시작하지 않았습니다.")
                }
                override fun onSuccess(screenshot: ScreenshotResult) {
                    overlay?.visibility = View.VISIBLE
                    if (checkId != startCheckToken) { screenshot.hardwareBuffer.close(); return }
                    val hardware = screenshot.hardwareBuffer
                    val image = try {
                        Bitmap.wrapHardwareBuffer(hardware, screenshot.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                    } catch (_: Exception) { null } finally { hardware.close() }
                    if (image == null) {
                        startCheckInProgress = false
                        return toast("목록 화면을 읽지 못해 수집을 시작하지 않았습니다.")
                    }
                    runMultiRegionOcr(image, { textVariants ->
                        if (checkId != startCheckToken) return@runMultiRegionOcr
                        startCheckInProgress = false
                        val stillSameApp = rootInActiveWindow?.packageName?.toString() == candidatePackage
                        val selected = RecordStore.selectedMonth(this@CollectorAccessibilityService)
                        val combined = textVariants.joinToString("\n")
                        val visibleMonth = AttendanceParser.monthHeader(combined)
                        val recognizedRows = AttendanceParser.unique(textVariants.flatMap { AttendanceParser.fromListPage(it, selected) })
                        if (stillSameApp && (visibleMonth == null || visibleMonth == selected) &&
                            combined.contains("국가근로장학금") && recognizedRows.isNotEmpty()) {
                            startCollection(candidatePackage, selected, true)
                        } else {
                            toast("목록/조회 월을 읽지 못했습니다. 수집기에서 확인할 월(예: 2026-10)을 설정하고 목록 맨 위에서 시작하세요.")
                        }
                    }, {
                        if (checkId == startCheckToken) {
                            startCheckInProgress = false
                            toast("화면 확인 OCR 실패. 수집을 시작하지 않았습니다.")
                        }
                    })
                }
            })
            } catch (_: Exception) {
                overlay?.visibility = View.VISIBLE
                stop("화면 캡처 요청 실패")
            }
            }, 180)
        } catch (_: Exception) {
            overlay?.visibility = View.VISIBLE
            if (checkId == startCheckToken) {
                startCheckInProgress = false
                toast("화면 확인용 캡처를 할 수 없어 수집을 시작하지 않았습니다.")
            }
        }
    }

    private fun processPage(id: Int) {
        if (!active || id != runId) return
        if (pages >= 80) return stop("최대 80페이지 도달. 지금까지 기록을 확인하세요.")
        val root = verifiedRoot() ?: return stop("대상 앱을 벗어났거나 화면 정보가 차단됐습니다.")
        val ym = month ?: return stop("월 정보를 찾을 수 없습니다.")
        val text = mergedAccessibilityText(root)
        val visibleMonth = AttendanceParser.monthHeader(text)
        if (visibleMonth != null && visibleMonth != ym) return stop("조회 월이 바뀌었습니다. 중지합니다.")
        val entries = AttendanceParser.fromOverlappingPages(previousPageText, text, ym)
        if (entries.isNotEmpty() && (AttendanceParser.fromListPage(text, ym).isNotEmpty() || text.contains(":"))) {
            processParsed(id, entries, text)
        } else {
            // A WebView may hide text from accessibility. Try OS screenshot once per page.
            readPageWithOcr(id, text)
        }
    }

    private fun readPageWithOcr(id: Int, accessibilityText: String) {
        if (!active || id != runId) return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return stop("텍스트를 읽을 수 없고, 이 기기는 자동 OCR을 지원하지 않습니다.")
        screenshotTried++
        status("$pages 페이지 · 접근성 텍스트 없음 → OCR 시도")
        try {
            overlay?.visibility = View.INVISIBLE
            handler.postDelayed({
            try { takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onFailure(errorCode: Int) {
                    overlay?.visibility = View.VISIBLE
                    if (active && id == runId) stop("화면 캡처가 허용되지 않습니다($errorCode). 저장된 캡처 OCR을 사용하세요.")
                }
                override fun onSuccess(screenshot: ScreenshotResult) {
                    overlay?.visibility = View.VISIBLE
                    if (!active || id != runId) { screenshot.hardwareBuffer.close(); return }
                    val hardware = screenshot.hardwareBuffer
                    val image: Bitmap? = try {
                        Bitmap.wrapHardwareBuffer(hardware, screenshot.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                    } catch (_: Exception) { null } finally { hardware.close() }
                    if (image == null) return stop("캡처 이미지를 처리할 수 없습니다.")
                    runMultiRegionOcr(image, { textVariants ->
                        if (!active || id != runId) return@runMultiRegionOcr
                        val ym = month ?: return@runMultiRegionOcr
                        val combined = textVariants.joinToString("\n")
                        if (startedByOcr && AttendanceParser.monthHeader(combined)?.let { it != ym } == true) {
                            stop("대상 월/출근부 화면을 확인할 수 없습니다. 수집을 중지했습니다.")
                            return@runMultiRegionOcr
                        }
                        val rows = AttendanceParser.unique(textVariants.flatMap {
                            AttendanceParser.fromOverlappingPages(previousPageText, it, ym)
                        })
                        processParsed(id, rows, (textVariants + accessibilityText).filter { it.isNotBlank() }.joinToString("\n"))
                    }, { error ->
                        if (active && id == runId) stop("OCR 실패: ${error?.localizedMessage ?: "알 수 없는 오류"}")
                    })
                }
            })
            } catch (_: Exception) {
                overlay?.visibility = View.VISIBLE
                stop("화면 캡처 요청 실패")
            }
            }, 180)
        } catch (e: Exception) {
            overlay?.visibility = View.VISIBLE
            stop("캡처에 접근할 수 없습니다: ${e.localizedMessage}")
        }
    }

    private fun runMultiRegionOcr(image: Bitmap, onSuccess: (List<String>) -> Unit, onFailure: (Exception?) -> Unit) {
        val sources = mutableListOf<Bitmap>()
        sources += image
        val w = image.width
        val h = image.height
        fun crop(left: Int, top: Int, width: Int, height: Int) {
            val safeLeft = left.coerceIn(0, w - 1)
            val safeTop = top.coerceIn(0, h - 1)
            val safeWidth = width.coerceAtMost(w - safeLeft)
            val safeHeight = height.coerceAtMost(h - safeTop)
            if (safeWidth > 60 && safeHeight > 60) {
                runCatching { Bitmap.createBitmap(image, safeLeft, safeTop, safeWidth, safeHeight) }.getOrNull()?.let { sources += it }
            }
        }
        crop((w * 0.05f).toInt(), (h * 0.12f).toInt(), (w * 0.90f).toInt(), (h * 0.76f).toInt())
        crop((w * 0.03f).toInt(), (h * 0.24f).toInt(), (w * 0.94f).toInt(), (h * 0.70f).toInt())
        val recognizer = TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        val results = mutableListOf<String>()
        fun next(index: Int) {
            if (index >= sources.size) {
                recognizer.close()
                sources.drop(1).forEach { if (!it.isRecycled) it.recycle() }
                if (!image.isRecycled) image.recycle()
                val normalized = results.flatMap { raw ->
                    val ordered = raw.lines().joinToString("\n") { it.trim() }
                    listOf(raw, ordered)
                }.map { it.replace("\r", "").trim() }.filter { it.isNotBlank() }.distinct()
                if (normalized.isNotEmpty()) onSuccess(normalized) else onFailure(null)
                return
            }
            recognizer.process(InputImage.fromBitmap(sources[index], 0))
                .addOnSuccessListener { result ->
                    val ordered = spatiallyOrderedOcr(result)
                    if (result.text.isNotBlank()) results += result.text
                    if (ordered.isNotBlank()) results += ordered
                    next(index + 1)
                }
                .addOnFailureListener { err ->
                    if (index == 0) {
                        recognizer.close()
                        sources.drop(1).forEach { if (!it.isRecycled) it.recycle() }
                        if (!image.isRecycled) image.recycle()
                        onFailure(Exception(err))
                    } else {
                        next(index + 1)
                    }
                }
        }
        next(0)
    }

    private fun processParsed(id: Int, records: List<WorkRecord>, signatureText: String) {
        if (!active || id != runId) return
        val root = verifiedRoot() ?: return stop("대상 앱이 바뀌었습니다.")
        val ym = month ?: return stop("월 정보 오류")
        pages++
        val before = RecordStore.read(this).count { it.date.startsWith(ym.toString()) }
        RecordStore.add(this, AttendanceParser.fromOverlappingPages(previousPageText, signatureText, ym) + records)
        previousPageText = signatureText.takeLast(2800)
        val after = RecordStore.read(this).count { it.date.startsWith(ym.toString()) }
        collected += after - before
        zeroRecordPages = if (records.isEmpty()) zeroRecordPages + 1 else 0
        if (zeroRecordPages >= 2 && after == 0) {
            return finish("두 화면에서 근무기록을 하나도 읽지 못했습니다. 조회 월/원본 화면을 확인하세요.")
        }
        val signature = signatureText.replace(Regex("\\s+"), " ").trim().takeLast(850)
        repeated = if (signature == previousSignature) repeated + 1 else 0
        previousSignature = signature
        status("${ym.monthValue}월: ${pages}화면 / 전체 ${after}건 (신규 ${collected}건)")
        if (repeated >= 2) return finish("화면이 더 이상 변하지 않아 종료했습니다.")
        scroll(root) { didScroll ->
            if (!active || id != runId) return@scroll
            if (!didScroll) finish("더 내려갈 수 없는 화면입니다.")
            else handler.postDelayed({ processPage(id) }, 1400)
        }
    }

    private fun scroll(root: AccessibilityNodeInfo, next: (Boolean) -> Unit) {
        val scrollers = mutableListOf<AccessibilityNodeInfo>()
        walk(root) { node ->
            if (node.isScrollable && node.isVisibleToUser) {
                val r = Rect().also { node.getBoundsInScreen(it) }
                if (r.width() > dp(200) && r.height() > dp(180)) scrollers += node
            }
        }
        val candidates = scrollers.sortedBy { node ->
            Rect().also { node.getBoundsInScreen(it) }.let { it.width().toLong() * it.height() }
        }
        for (n in candidates) {
            if (n.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) return next(true)
        }
        // Some WebViews are scrollable only via a swipe. This gesture only moves the list.
        val size = resources.displayMetrics
        val w = size.widthPixels.toFloat(); val h = size.heightPixels.toFloat()
        val path = Path().apply { moveTo(w * .50f, h * .84f); lineTo(w * .50f, h * .28f) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 460)).build()
        val ok = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { next(true) }
            override fun onCancelled(gestureDescription: GestureDescription?) { next(false) }
        }, handler)
        if (!ok) next(false)
    }

    private fun verifiedRoot(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        if (root.packageName?.toString() != targetPackage) return null
        val text = mergedAccessibilityText(root)
        if (!text.contains("조회") && !startedByOcr && !text.contains("근무")) return null
        val visibleMonth = AttendanceParser.monthHeader(text)
        if (visibleMonth != null && visibleMonth != month) return null
        return root
    }

    private fun mergedAccessibilityText(root: AccessibilityNodeInfo): String {
        val all = readText(root)
        val focusedNodes = mutableListOf<AccessibilityNodeInfo>()
        walk(root) { node ->
            val r = Rect().also { node.getBoundsInScreen(it) }
            if (node.isVisibleToUser && r.height() > dp(120) && r.width() > dp(140)) {
                if (node.isScrollable || node.className?.toString()?.contains("Recycler", true) == true || node.className?.toString()?.contains("List", true) == true) {
                    focusedNodes += node
                }
            }
        }
        val listArea = focusedNodes.maxByOrNull { node ->
            Rect().also { node.getBoundsInScreen(it) }.let { it.width().toLong() * it.height() }
        }?.let { readText(it) }.orEmpty()
        return listOf(all, listArea)
            .filter { it.isNotBlank() }
            .distinct()
            .joinToString("\n")
    }

    private fun spatiallyOrderedOcr(result: com.google.mlkit.vision.text.Text): String {
        data class Item(val y: Int, val x: Int, val text: String)
        val lines = result.textBlocks.flatMap { it.lines }.mapNotNull { l ->
            l.boundingBox?.let { Item(it.centerY(), it.left, l.text) }
        }.sortedWith(compareBy(Item::y, Item::x))
        if (lines.isEmpty()) return result.text
        val rows = mutableListOf<MutableList<Item>>()
        for (line in lines) {
            val current = rows.lastOrNull()
            if (current != null && kotlin.math.abs(current.first().y - line.y) <= dp(12)) {
                current += line
            } else rows += mutableListOf(line)
        }
        return rows.joinToString("\n") { row -> row.sortedBy { it.x }.joinToString(" ") { it.text } }
    }

    private fun readText(root: AccessibilityNodeInfo): String {
        data class Line(val y: Int, val x: Int, val value: String)
        val lines = mutableListOf<Line>()
        val seen = hashSetOf<String>()
        walk(root) { n ->
            val value = (n.text ?: n.contentDescription)?.toString()?.trim().orEmpty()
            if (value.isBlank()) return@walk
            val r = Rect().also { n.getBoundsInScreen(it) }
            if (!n.isVisibleToUser || r.width() <= 0 || r.height() <= 0) return@walk
            val key = "${r.left}|${r.top}|${r.right}|${r.bottom}|$value"
            if (seen.add(key)) lines += Line(r.centerY(), r.left, value)
        }
        val sorted = lines.sortedWith(compareBy(Line::y, Line::x))
        val bands = mutableListOf<MutableList<Line>>()
        for (line in sorted) {
            val band = bands.lastOrNull()
            if (band != null && kotlin.math.abs(band.first().y - line.y) <= dp(14)) band.add(line)
            else bands.add(mutableListOf(line))
        }
        return bands.joinToString("\n") { band ->
            band.sortedBy { it.x }.joinToString(" ") { it.value }
        }
    }
    private fun walk(root: AccessibilityNodeInfo, action: (AccessibilityNodeInfo) -> Unit) {
        var count = 0
        fun visit(n: AccessibilityNodeInfo, depth: Int) {
            if (++count > 3200 || depth > 55) return
            action(n)
            for (i in 0 until n.childCount) n.getChild(i)?.let { visit(it, depth + 1) }
        }
        visit(root, 0)
    }
    private fun finish(reason: String) {
        if (!active) return
        val ym = month
        val total = ym?.let { selected -> RecordStore.read(this).count { it.date.startsWith(selected.toString()) } } ?: 0
        toast("수집 종료: 전체 ${total}건 / 새 ${collected}건 · ${pages}화면. $reason")
        shutdown(reason)
    }
    private fun stop(reason: String) {
        if (!active && !startCheckInProgress) return
        shutdown(reason)
    }
    private fun status(message: String) { info?.text = message }
    private fun toast(message: String) { Toast.makeText(this, message, Toast.LENGTH_LONG).show() }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
