package io.local.attendance

import java.time.LocalDate
import java.time.YearMonth

/** Android-independent parser. Only explicitly reported start/end times are recorded. */
data class WorkRecord(
    val date: String,
    val start: String,
    val end: String,
    val reportedMinutes: Int? = null,
    val status: String = ""
) {
    val minutes: Int get() {
        val a = parseTime(start) ?: return 0
        val b = parseTime(end) ?: return 0
        return b - a
    }
    val valid: Boolean get() = parseTime(start) != null && parseTime(end) != null && minutes > 0
    val key: String get() = "$date|$start|$end"
    val differentFromReported: Boolean get() = reportedMinutes != null && reportedMinutes != minutes
}

private fun parseTime(value: String): Int? {
    val m = Regex("^(\\d{1,2}):(\\d{2})$").matchEntire(value.trim()) ?: return null
    val h = m.groupValues[1].toInt()
    val min = m.groupValues[2].toInt()
    return if (h in 0..23 && min in 0..59) h * 60 + min else null
}

object AttendanceParser {
    private val monthPattern = Regex("(?<!\\d)(20\\d{2})\\s*[./-]\\s*(0?[1-9]|1[0-2])(?!\\s*[./-]\\s*\\d)(?!\\d)")
    // No match inside 2026.09.10 (the screenshot's work-site period).
    private val shortDate = Regex("(?<![\\d.])(0?[1-9]|1[0-2])\\s*[./]\\s*([0-3]?\\d)(?!\\d)")
    private val fullDate = Regex("(?<!\\d)(20\\d{2})\\s*[./-]\\s*(0?[1-9]|1[0-2])\\s*[./-]\\s*([0-3]?\\d)(?!\\d)")
    private val workTime = Regex("근무\\s*([01]?\\d|2[0-3]):([0-5]\\d)\\s*[~～〜∼–—-]\\s*([01]?\\d|2[0-3]):([0-5]\\d)")
    private val plainTime = Regex("(?<!\\d)([01]?\\d|2[0-3]):([0-5]\\d)\\s*[~～〜∼–—-]\\s*([01]?\\d|2[0-3]):([0-5]\\d)")
    private val reported = Regex("(\\d{1,2})\\s*시간\\s*(\\d{1,2})\\s*분")
    private val statusPattern = Regex("기관\\s*확인\\s*전|기관\\s*확인\\s*완료|미\\s*완료")
    private val manualLine = Regex("(?m)^\\s*(20\\d{2})[-./](\\d{1,2})[-./](\\d{1,2})\\s+([0-2]?\\d:[0-5]\\d)\\s*[~～〜∼–—-]\\s*([0-2]?\\d:[0-5]\\d)")

    private fun normalize(text: String): String = text
        .replace('\u00a0', ' ')
        .replace("\r", "")
        .replace(Regex("(?<=\\d)\\s*[:：]\\s*(?=\\d)"), ":")
        .replace(Regex("기관\\s+확인"), "기관확인")
        .replace(Regex("미\\s+완료"), "미완료")
        .replace(Regex("(?<!\\d)[Oo](?=\\d[:：])"), "0")

    private fun canonicalStatus(value: String): String {
        return when (value.replace(Regex("\\s+"), "")) {
            "기관확인전" -> "기관확인 전"
            "기관확인완료" -> "기관확인 완료"
            "미완료" -> "미완료"
            else -> value.trim()
        }
    }


    fun monthHeader(text: String): YearMonth? {
        val m = monthPattern.find(normalize(text)) ?: return null
        return runCatching { YearMonth.of(m.groupValues[1].toInt(), m.groupValues[2].toInt()) }.getOrNull()
    }

    /** For pasted text, accessibility tree pages, or OCR output. */
    fun fromListPage(text: String, selectedMonth: YearMonth): List<WorkRecord> {
        val normalized = normalize(text)
        val candidates = mutableListOf<Pair<Int, LocalDate>>()
        // Explicit full dates used by the editable export view.
        fullDate.findAll(normalized).forEach { m ->
            val d = runCatching {
                LocalDate.of(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3].toInt())
            }.getOrNull()
            if (d != null && YearMonth.from(d) == selectedMonth) candidates += m.range.first to d
        }
        shortDate.findAll(normalized).forEach { m ->
            // Full-date patterns are already covered. Reject their inner fragments.
            if (candidates.any { (index, _) -> index <= m.range.first && m.range.first - index <= 10 }) return@forEach
            val mth = m.groupValues[1].toInt()
            val day = m.groupValues[2].toInt()
            if (mth != selectedMonth.monthValue) return@forEach
            val d = runCatching { LocalDate.of(selectedMonth.year, mth, day) }.getOrNull()
            if (d != null) candidates += m.range.first to d
        }
        val dates = candidates.distinctBy { it.first }.sortedBy { it.first }
        val result = mutableListOf<WorkRecord>()
        for (i in dates.indices) {
            val (begin, date) = dates[i]
            val end = dates.getOrNull(i + 1)?.first ?: normalized.length
            val section = normalized.substring(begin, end)
            val compact = section.replace(Regex("\\s+"), " ")
            val matches = workTime.findAll(compact).toList()
            val timeMatches = if (matches.isEmpty()) plainTime.findAll(compact).toList() else matches
            val shownMinutes = reported.find(compact)?.let { it.groupValues[1].toInt() * 60 + it.groupValues[2].toInt() }
            // The actual monthly list places the status badge ABOVE the date at the right.
            val beforeFirstTime = compact.take(timeMatches.firstOrNull()?.range?.first ?: 0)
            val inlineState = statusPattern.find(beforeFirstTime)?.value.orEmpty()
            val precedingText = normalized.take(begin)
            val lastTimeEnd = plainTime.findAll(precedingText).lastOrNull()?.range?.last?.plus(1) ?: 0
            val lookBehind = precedingText.substring(maxOf(lastTimeEnd, begin - 260))
            val leadingState = statusPattern.findAll(lookBehind).lastOrNull()?.value.orEmpty()
            val state = canonicalStatus(inlineState.ifBlank { leadingState })
            timeMatches.forEach { match ->
                val (h1, m1, h2, m2) = match.destructured
                val record = WorkRecord(
                    date.toString(),
                    "${h1.padStart(2, '0')}:$m1",
                    "${h2.padStart(2, '0')}:$m2",
                    if (timeMatches.size == 1) shownMinutes else null,
                    state
                )
                if (record.valid) result += record
            }
        }
        return unique(result)
    }

    /** Merge one previous screen to recover a date or time split across a scroll boundary. */
    fun fromOverlappingPages(previousPage: String, currentPage: String, month: YearMonth): List<WorkRecord> {
        val current = fromListPage(currentPage, month)
        if (previousPage.isBlank()) return current
        val bridged = fromListPage(previousPage.takeLast(2600) + "\n" + currentPage, month)
        return unique(current + bridged)
    }

    fun fromText(text: String, fallbackMonth: YearMonth): List<WorkRecord> =
        fromListPage(text, monthHeader(text) ?: fallbackMonth)

    fun fromDetail(text: String, date: LocalDate): List<WorkRecord> =
        fromListPage("${date.monthValue}.${date.dayOfMonth}\n$text", YearMonth.from(date))

    /** For replacing one month's saved records after editing plain export lines. */
    fun fromEditableText(text: String, month: YearMonth): List<WorkRecord> {
        return unique(manualLine.findAll(text).mapNotNull { m ->
            val date = runCatching {
                LocalDate.of(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3].toInt())
            }.getOrNull()
            if (date == null || YearMonth.from(date) != month) return@mapNotNull null
            WorkRecord(date.toString(), m.groupValues[4], m.groupValues[5]).takeIf { it.valid }
        }.toList())
    }

    fun unique(records: List<WorkRecord>): List<WorkRecord> =
        records.filter { it.valid }.groupBy { it.key }.values.map { versions ->
            versions.maxByOrNull { (if (it.reportedMinutes != null) 1 else 0) + (if (it.status.isNotEmpty()) 1 else 0) }!!
        }.sortedWith(compareBy(WorkRecord::date, WorkRecord::start, WorkRecord::end))

    fun export(records: List<WorkRecord>, month: YearMonth): String {
        val entries = unique(records).filter { it.date.startsWith(month.toString()) }
        if (entries.isEmpty()) return "$month 근무 내역\n\n수집된 근무기록이 없습니다. 누락 여부를 확인하세요."
        val body = entries.joinToString("\n") { r ->
            val shown = r.reportedMinutes?.let { " / 표시시간 ${it / 60}시간 ${it % 60}분" }.orEmpty()
            val state = if (r.status.isNotBlank()) " / ${r.status}" else ""
            val warn = if (r.differentFromReported) " / ⚠ 시간 차이 확인" else ""
            "${r.date}  ${r.start} ~ ${r.end} (${r.minutes / 60}시간 ${r.minutes % 60}분)$shown$state$warn"
        }
        val total = entries.sumOf { it.minutes }
        val mismatch = entries.count { it.differentFromReported }
        return "$month 근무 내역\n\n$body\n\n출퇴근 시각 차이 합계: ${total / 60}시간 ${total % 60}분\n" +
            "표시시간 불일치: ${mismatch}건\n※ 휴게/제외/인정시간과 다를 수 있습니다. 원본 확인 필요"
    }

    fun csv(records: List<WorkRecord>, month: YearMonth): String {
        fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
        return "날짜,시작,종료,시각차이분,화면표시분,상태,시간불일치\n" +
            unique(records).filter { it.date.startsWith(month.toString()) }.joinToString("\n") { r ->
                listOf(
                    r.date,
                    r.start,
                    r.end,
                    r.minutes.toString(),
                    r.reportedMinutes?.toString().orEmpty(),
                    r.status,
                    if (r.differentFromReported) "확인 필요" else ""
                ).joinToString(",") { q(it) }
            }
    }
}
