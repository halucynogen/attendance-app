
package io.local.attendance

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import java.time.YearMonth

class MainActivity : Activity() {
    private val openImage = 1101
    private val saveTxt = 1102
    private val saveCsv = 1103
    private lateinit var monthInput: EditText
    private lateinit var pasteInput: EditText
    private lateinit var exportInput: EditText
    private lateinit var countText: TextView
    private lateinit var summaryText: TextView
    private lateinit var checkConsent: CheckBox

    private val primary = Color.parseColor("#275DFF")
    private val primaryDark = Color.parseColor("#163DAD")
    private val surface = Color.parseColor("#F5F7FB")
    private val border = Color.parseColor("#D7E0F5")
    private val success = Color.parseColor("#1B8F5C")
    private val warning = Color.parseColor("#D97706")
    private val muted = Color.parseColor("#667085")
    private val danger = Color.parseColor("#B42318")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(30))
            setBackgroundColor(surface)
        }
        setContentView(ScrollView(this).apply {
            setBackgroundColor(surface)
            addView(content)
        })

        content.addView(headerCard())
        content.addView(instructionCard())
        content.addView(consentCard())
        content.addView(monthCard())
        content.addView(summaryCard())
        content.addView(importCard())
        content.addView(resultCard())
        refresh()
    }

    override fun onResume() {
        super.onResume()
        if (::exportInput.isInitialized) refresh()
    }

    override fun onDestroy() {
        if (isFinishing) CollectorAccessibilityService.shutdownFromApp()
        super.onDestroy()
    }

    @Deprecated("Android back behavior across API levels")
    override fun onBackPressed() {
        CollectorAccessibilityService.shutdownFromApp()
        super.onBackPressed()
    }

    @Deprecated("For this small self-contained Android MVP")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        if (requestCode == saveTxt || requestCode == saveCsv) {
            val ym = chosenMonth() ?: return
            val text = if (requestCode == saveCsv) AttendanceParser.csv(RecordStore.read(this), ym) else exportInput.text.toString()
            try {
                contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                toast("저장 완료")
            } catch (e: Exception) {
                toast("파일 저장 실패: ${e.localizedMessage}")
            }
            return
        }
        if (requestCode != openImage) return
        val ym = chosenMonth() ?: return
        val recognizer = TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        try {
            recognizer.process(InputImage.fromFilePath(this, uri))
                .addOnSuccessListener { ocr ->
                    pasteInput.setText(ocr.text)
                    val parsed = AttendanceParser.fromListPage(ocr.text, ym)
                    if (parsed.isNotEmpty()) RecordStore.add(this, parsed)
                    refresh()
                    toast("OCR에서 ${parsed.size}건 추출. 내용을 검토하세요.")
                }
                .addOnFailureListener { toast("OCR 실패: ${it.localizedMessage}") }
                .addOnCompleteListener { recognizer.close() }
        } catch (e: Exception) {
            recognizer.close()
            toast("이미지 열기 실패: ${e.localizedMessage}")
        }
    }

    private fun headerCard(): LinearLayout {
        val card = card(primary, 0)
        card.addView(TextView(this).apply {
            text = "출근부 자동 정리기"
            textSize = 24f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
        })
        card.addView(TextView(this).apply {
            text = "한국장학재단 조회 목록에서 날짜 · 근무시간 · 상태를 읽어 기기 내부에만 저장합니다."
            textSize = 14f
            setTextColor(Color.parseColor("#E8EEFF"))
            setPadding(0, dp(6), 0, 0)
        })
        return card
    }

    private fun instructionCard(): LinearLayout {
        val card = sectionCard("사용 순서", "1) 공식 앱 로그인 → 조회 → 목록 화면\n2) 이 앱에서 조회 월 설정\n3) 접근성 켜고 목록 수집 시작\n4) 수집 후 결과 확인 · 복사 · 저장")
        card.addView(tag("개선사항", success))
        card.addView(TextView(this).apply {
            text = "• 더 넓은 텍스트 영역 검사\n• 스크롤 경계 복원 강화\n• 목록/OCR 복합 읽기\n• 수집 종료 시 접근성 자동 해제"
            textSize = 13f
            setTextColor(Color.parseColor("#344054"))
            setPadding(0, dp(10), 0, 0)
        })
        return card
    }

    private fun consentCard(): LinearLayout {
        val card = sectionCard("접근성 및 보안", "공식 앱 계정 비밀번호나 비공식 API는 사용하지 않습니다. 근무기록만 기기 내부에 저장합니다.")
        checkConsent = CheckBox(this).apply {
            text = "안내를 이해했고, 내가 시작할 때만 접근성 서비스가 목록을 읽고 자동 스크롤하는 것에 동의합니다."
            isChecked = RecordStore.consent(this@MainActivity)
            setOnCheckedChangeListener { _, checked -> RecordStore.setConsent(this@MainActivity, checked) }
        }
        card.addView(checkConsent)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(primaryButton("접근성 설정 열기") {
                if (!checkConsent.isChecked) toast("먼저 동의 체크를 해주세요.")
                else startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            })
            addView(secondaryButton("종료 · 접근성 자동 끄기") {
                CollectorAccessibilityService.shutdownFromApp()
                finish()
            }.apply { topMargin(dp(8)) })
        }
        card.addView(row)
        return card
    }

    private fun monthCard(): LinearLayout {
        val card = sectionCard("조회할 월", "공식 앱 목록 화면의 월과 동일하게 맞춰 주세요.")
        monthInput = EditText(this).apply {
            setSingleLine(true)
            setText(RecordStore.selectedMonth(this@MainActivity).toString())
            hint = "2026-11"
            inputType = InputType.TYPE_CLASS_DATETIME
            background = inputBackground()
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        card.addView(monthInput)
        card.addView(primaryButton("조회할 월 저장하고 기록 보기") {
            val selected = chosenMonth() ?: return@primaryButton
            RecordStore.setSelectedMonth(this, selected)
            refresh()
            toast("수집 대상 월: $selected")
        }.apply { topMargin(dp(10)) })
        return card
    }

    private fun summaryCard(): LinearLayout {
        val card = sectionCard("요약", "현재 저장된 이 달의 기록입니다.")
        summaryText = TextView(this).apply {
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#101828"))
            background = rounded(Color.WHITE, border)
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        countText = TextView(this).apply {
            textSize = 13f
            setTextColor(muted)
            setPadding(0, dp(8), 0, 0)
        }
        card.addView(summaryText)
        card.addView(countText)
        return card
    }

    private fun importCard(): LinearLayout {
        val card = sectionCard("입력 보조", "자동 수집이 어려운 경우 텍스트 붙여넣기 또는 저장된 목록 스크린샷 OCR을 사용하세요.")
        pasteInput = EditText(this).apply {
            gravity = Gravity.TOP
            minLines = 6
            maxLines = 12
            hint = "2026.11\n10.19 2시간 0분\n근무 09:00 ~ 11:00"
            background = inputBackground()
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        card.addView(pasteInput)
        card.addView(primaryButton("붙여넣은 목록에서 근무 내역 추출") {
            val ym = chosenMonth() ?: return@primaryButton
            val records = AttendanceParser.fromListPage(pasteInput.text.toString(), ym)
            if (records.isEmpty()) return@primaryButton toast("유효한 근무시간이 없습니다. 월과 인식 원문을 확인하세요.")
            RecordStore.add(this, records)
            refresh()
            toast("${records.size}건을 찾았습니다. 원본과 비교하세요.")
        }.apply { topMargin(dp(10)) })
        card.addView(secondaryButton("저장한 목록 스크린샷에서 한국어 OCR") {
            if (chosenMonth() == null) return@secondaryButton
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "image/*"
            }, openImage)
        }.apply { topMargin(dp(8)) })
        return card
    }

    private fun resultCard(): LinearLayout {
        val card = sectionCard("결과", "필요하면 텍스트를 직접 수정한 뒤 다시 저장할 수 있습니다.")
        exportInput = EditText(this).apply {
            gravity = Gravity.TOP
            minLines = 10
            maxLines = 28
            background = inputBackground()
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setTextColor(Color.parseColor("#101828"))
        }
        card.addView(exportInput)
        card.addView(primaryButton("현재 텍스트 복사") {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(
                ClipData.newPlainText("근로시간", exportInput.text.toString())
            )
            toast("복사했습니다.")
        }.apply { topMargin(dp(10)) })
        card.addView(secondaryButton("현재 텍스트 TXT 파일로 저장") {
            createFile(saveTxt, "text/plain", "근로시간_${chosenMonth() ?: return@secondaryButton}.txt")
        }.apply { topMargin(dp(8)) })
        card.addView(secondaryButton("저장된 근무기록 CSV 파일로 저장") {
            createFile(saveCsv, "text/csv", "근로시간_${chosenMonth() ?: return@secondaryButton}.csv")
        }.apply { topMargin(dp(8)) })
        card.addView(secondaryButton("수정한 날짜·시각으로 이 달 기록 교체") {
            val ym = chosenMonth() ?: return@secondaryButton
            val corrected = AttendanceParser.fromEditableText(exportInput.text.toString(), ym)
            if (corrected.isEmpty()) return@secondaryButton toast("'2026-11-02 09:00 ~ 11:00' 형식의 기록이 없습니다.")
            AlertDialog.Builder(this)
                .setTitle("수정한 기록 저장")
                .setMessage("${ym}의 저장 내역을 ${corrected.size}건으로 교체합니다. 계속할까요?")
                .setNegativeButton("취소", null)
                .setPositiveButton("교체") { _, _ -> RecordStore.replaceMonth(this, ym, corrected); refresh() }
                .show()
        }.apply { topMargin(dp(8)) })
        card.addView(dangerButton("이 달 저장 기록 삭제") {
            val ym = chosenMonth() ?: return@dangerButton
            AlertDialog.Builder(this)
                .setTitle("$ym 삭제")
                .setMessage("이 달의 저장된 기록만 지울까요?")
                .setNegativeButton("취소", null)
                .setPositiveButton("삭제") { _, _ -> RecordStore.replaceMonth(this, ym, emptyList()); refresh() }
                .show()
        }.apply { topMargin(dp(8)) })
        card.addView(TextView(this).apply {
            text = "※ 읽기에 실패한 기록은 추측해서 생성하지 않습니다. 표시시간과 실제 출퇴근 시각 차이, 휴게/제외/인정시간 차이는 원본에서 다시 확인하세요."
            textSize = 12.5f
            setTextColor(muted)
            setPadding(0, dp(10), 0, 0)
        })
        return card
    }

    private fun chosenMonth(): YearMonth? = try {
        YearMonth.parse(monthInput.text.toString().trim())
    } catch (_: Exception) {
        toast("월을 2026-11처럼 입력하세요.")
        null
    }

    private fun refresh() {
        val ym = chosenMonth() ?: return
        val items = RecordStore.read(this).filter { it.date.startsWith(ym.toString()) }
        val totalMinutes = items.sumOf { it.minutes }
        val mismatch = items.count { it.differentFromReported }
        summaryText.text = "기록 ${items.size}건  ·  총 ${totalMinutes / 60}시간 ${totalMinutes % 60}분\n표시시간 차이 ${mismatch}건"
        countText.text = "$ym 저장 내역 ${items.size}건 / 점검 필요한 기록 ${mismatch}건"
        exportInput.setText(AttendanceParser.export(items, ym))
    }

    private fun createFile(request: Int, mime: String, title: String) {
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
            putExtra(Intent.EXTRA_TITLE, title)
        }, request)
    }

    private fun sectionCard(title: String, subtitle: String): LinearLayout {
        return card(Color.WHITE, border).apply {
            addView(TextView(this@MainActivity).apply {
                text = title
                textSize = 19f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#101828"))
            })
            addView(TextView(this@MainActivity).apply {
                text = subtitle
                textSize = 13.5f
                setTextColor(muted)
                setPadding(0, dp(6), 0, dp(6))
            })
        }
    }

    private fun card(backgroundColor: Int, strokeColor: Int): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(backgroundColor, strokeColor)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(12)
            }
        }
    }

    private fun tag(text: String, color: Int): TextView = TextView(this).apply {
        this.text = text
        textSize = 11.5f
        setTextColor(color)
        background = rounded(Color.parseColor("#EEF4FF"), Color.TRANSPARENT, radiusDp = 100)
        setPadding(dp(10), dp(4), dp(10), dp(4))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(6)
        }
    }

    private fun primaryButton(title: String, action: () -> Unit): Button = actionButton(title, primary, Color.WHITE, action)
    private fun secondaryButton(title: String, action: () -> Unit): Button = actionButton(title, Color.WHITE, primaryDark, action, stroke = border)
    private fun dangerButton(title: String, action: () -> Unit): Button = actionButton(title, Color.parseColor("#FEE4E2"), danger, action, stroke = Color.parseColor("#FDA29B"))

    private fun actionButton(title: String, bg: Int, fg: Int, action: () -> Unit, stroke: Int = Color.TRANSPARENT): Button {
        return Button(this).apply {
            text = title
            setTextColor(fg)
            background = rounded(bg, stroke)
            setOnClickListener { action() }
            textSize = 14.5f
            isAllCaps = false
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
    }

    private fun Button.topMargin(px: Int): Button {
        (layoutParams as? LinearLayout.LayoutParams)?.topMargin = px
        return this
    }

    private fun rounded(fill: Int, stroke: Int, radiusDp: Int = 18) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(radiusDp).toFloat()
        setColor(fill)
        if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }

    private fun inputBackground() = rounded(Color.WHITE, border)

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
